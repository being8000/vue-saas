# 简介
用于游戏页面与厅内游戏进行通信交互


npm install

npm run build

外部执行

npm install ./package/messenger