import { startMainMessageListening, request, navigateTo, postMessage } from './message/post';
import { hooks as gzHooks } from './message/on-receiving-from-parent-post';
import { registerMessage, startIframeMessageListening } from './message/on-parent-receiving';
import { postResultToWebview } from './message/on-receiving-after-post';

export * from './message/on-parent-receiving';
export * from './message/post';
export { registerNativeMockFn } from './js-bridge/mock';
export * from './message/on-receiving-from-parent-post';
export interface MessageData<T = any> {
    success: boolean;
    body?: T;
    code: number | string;
    message: string;
}
export interface GamezoneMessengerConfig {
    timeout?: number;
    debug: boolean;
    userAgents: string[];
}
export type MessageId = string | number;
export interface MessageResponse<T = any> {
    data: MessageData<T>;
    messageId?: string | number;
    type: MessageEnum;
}
export interface MessagePayload<T = any> {
    messageId?: MessageId;
    type?: MessageEnum;
    method?: string;
    data?: T;
}
export interface MessagePostPayload<T = any> extends MessagePayload {
    method: string;
    payload?: T;
}
export interface MessageHttpPayload extends MessagePayload {
    url: string;
    config?: any;
}
export interface MessageTrackPayload extends MessagePayload {
    event: string;
    data?: any;
}
export interface MessageNavigationPayload extends MessagePayload {
    path?: string;
    query: Record<string, any>;
    replace: boolean;
    hash?: string;
}
export declare enum MessageEnum {
    POST = "POST",
    HTTP = "HTTP",
    NAVIGATE = "NAVIGATE",
    SENSOR_TRACK = "SENSOR_TRACK",// 神策埋点
    FROM_PARENT = "FROM_PARENT"
}
export declare function emitIframeEvent(method: string, payload?: any): Promise<MessageData<any>>;
declare const messenger: {
    start: typeof startMainMessageListening;
    request: typeof request;
    navigateTo: typeof navigateTo;
    postMessage: typeof postMessage;
};
declare const gzMain: {
    start: typeof startIframeMessageListening;
    registerMessage: typeof registerMessage;
    emitIframeEvent: typeof emitIframeEvent;
    successRes: (body?: any) => MessageData;
    errorRes: (body?: any, code?: number, message?: string) => MessageData;
};
declare global {
    interface Window {
        gzMessenger: typeof messenger;
        gzHooks: typeof gzHooks;
        gzMainMsger: typeof gzMain;
        webkit: any;
        emitIframeEvent: typeof emitIframeEvent;
        postResultToWebview: typeof postResultToWebview;
    }
}
declare const _default: {
    messenger: {
        start: typeof startMainMessageListening;
        request: typeof request;
        navigateTo: typeof navigateTo;
        postMessage: typeof postMessage;
    };
    gzHooks: {
        hookOnce(event: string, callbackFn: (params: any) => void): void;
        hook(event: string, callbackFn: (params: any) => void): void;
    };
};
export default _default;
