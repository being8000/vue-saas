import { MessageData, MessageEnum, MessagePayload } from '..';

export declare const createNativeMessageConsumer: <T = any>(payload: Omit<MessagePayload, "messageId">, type: MessageEnum) => Promise<MessageData<T>>;
