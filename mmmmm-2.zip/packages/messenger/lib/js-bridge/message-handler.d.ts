import { MessageData } from '..';

interface MessageHandlersFunction {
    (params?: any): Promise<MessageData> | MessageData;
}
export declare const nativeMessageHandler: Record<any, MessageHandlersFunction>;
export {};
