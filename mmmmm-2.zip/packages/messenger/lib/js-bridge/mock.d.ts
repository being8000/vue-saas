import { MessageData } from '..';

export declare const mockNativeHandler: Record<string, Function>;
type MockResultFn = () => MessageData | Promise<MessageData>;
type MockReulst = MessageData | MockResultFn;
export declare function registerNativeMockFn<T>(name: string, res: MockReulst): void;
export {};
