import { MessageData, MessageEnum, MessagePayload } from '..';

export declare const successRes: (body?: any) => MessageData;
export declare const errorRes: (body?: any, code?: number, message?: string) => MessageData;
type MessageHandler = (payload: any) => Promise<MessageData> | MessageData;
export declare const createIframeMessageEventConsumer: <T = any>(payload: Omit<MessagePayload, "messageId">, type: MessageEnum) => Promise<MessageData<T>>;
export declare function startIframeMessageListening({ router: _router, iframeEL: _iframeEl, }: {
    router?: any;
    iframeEL: HTMLIFrameElement;
}): void;
export declare function removeMessageListening(): void;
export declare function registerMessage(method: string, fn: MessageHandler): void;
export {};
