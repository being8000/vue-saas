export declare const onMessage: (response: MessageEvent) => void;
export declare function postResultToWebview(params: any): void;
