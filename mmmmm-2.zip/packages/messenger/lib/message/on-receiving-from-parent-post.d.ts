import { MessageEnum, MessageId, MessagePostPayload } from '..';

export interface MessageRecever<T = any> {
    type: MessageEnum;
    messageId: MessageId;
    payload: MessagePostPayload<T>;
    method: string;
}
export declare const messageBus: import('../utils/event-bus').UseEventBusReturn<unknown, any>;
export declare const hooks: {
    hookOnce(event: string, callbackFn: (params: any) => void): void;
    hook(event: string, callbackFn: (params: any) => void): void;
};
