import { GamezoneMessengerConfig, MessageData, MessageEnum, MessagePostPayload, MessageId, MessagePayload, MessageNavigationPayload } from '..';

export declare function getConfig(): GamezoneMessengerConfig;
export declare const getMessageID: () => number;
export declare const requestFnMap: Record<MessageId, (event: MessageData) => void>;
export declare const requestTimerMap: Record<MessageId, NodeJS.Timeout>;
export declare const createMessageConsumer: <T = any>(payload: Omit<MessagePayload, "messageId">, type: MessageEnum) => Promise<MessageData<T>>;
export declare function startMainMessageListening(_config: Partial<GamezoneMessengerConfig>): void;
export declare function stopListening(): void;
/**
 * 常规消息发送和接受
 * @param payload
 * @returns
 */
export declare function postMessage<T = any>(payload: MessagePostPayload): Promise<MessageData<T>>;
/**
 * 调用 gamezone http请能力
 * @param payload
 * @returns
 */
export declare function request<T = any>(url: string, config?: any): Promise<MessageData<T>>;
/**
 * 调用 gamezone 路由能力
 * @param payload
 * @returns
 */
export declare function navigateTo<T = any>(payload: MessageNavigationPayload): Promise<MessageData<T>>;
/**
 * 调用 gamezone 路由能力
 * @param payload
 * @returns
 */
export declare function track<T = any>(event: string, data: any): Promise<MessageData<T>>;
