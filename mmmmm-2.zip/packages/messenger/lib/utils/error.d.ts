import { MessageData } from '..';

export declare function error500(message: string): MessageData;
export declare function success<T = any>(body: T): MessageData;
export declare function error408Timeout(): MessageData;
