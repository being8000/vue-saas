import { EventBusEvents, EventBusIdentifier } from './event-bus';

export declare const events: Map<EventBusIdentifier<any>, EventBusEvents<any>>;
