# Using npm
GITLAB_AUTH_TOKEN=x npm publish

# Using yarn
GITLAB_AUTH_TOKEN=x yarn publish

# Using yarn workspaces
GITLAB_AUTH_TOKEN=x yarn workspace @digiplus/digi-iframyee publish

# Using lerna
GITLAB_AUTH_TOKEN=x lerna publish