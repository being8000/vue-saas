import { startMainMessageListening, request, navigateTo, postMessage } from './message/post'
import { hooks as gzHooks } from './message/on-receiving-from-parent-post'
import {
  createIframeMessageEventConsumer,
  errorRes,
  registerMessage,
  startIframeMessageListening,
  successRes,
} from './message/on-parent-receiving'
import { postResultToWebview } from './message/on-receiving-after-post'
export * from './message/on-parent-receiving'
export * from './message/post'
export { registerNativeMockFn } from './js-bridge/mock'
export * from './message/on-receiving-from-parent-post'
export interface MessageData<T = any> {
  success: boolean // 用于判断本次请求响应结果 成功还是失败
  body?: T
  code: number | string // 消息状态码，默认 200 表示成功
  message: string // 对应状态码的解释备注
}
export interface GamezoneMessengerConfig {
  timeout?: number // 设置消息超时时间， 默认 5s
  debug: boolean // 是否开启调试模式，原生模式下调试模式下使用mock数据
  userAgents: string[]
}
export type MessageId = string | number
export interface MessageResponse<T = any> {
  data: MessageData<T> // 发送数据
  messageId?: string | number
  type: MessageEnum
}

export interface MessagePayload<T = any> {
  messageId?: MessageId
  type?: MessageEnum
  method?: string // 方法名
  data?: T
}

export interface MessagePostPayload<T = any> extends MessagePayload {
  method: string // 方法名
  payload?: T // 发送数据
}
export interface MessageHttpPayload extends MessagePayload {
  url: string // 请求地址
  config?: any // 请求参数，参考 AxiosRequestConfig
}

export interface MessageTrackPayload extends MessagePayload {
  event: string // 请求地址
  data?: any // 请求参数，参考 AxiosRequestConfig
}

export interface MessageNavigationPayload extends MessagePayload {
  path?: string // 请求负载
  query: Record<string, any>
  replace: boolean
  hash?: string
}

export enum MessageEnum {
  POST = 'POST',
  HTTP = 'HTTP',
  NAVIGATE = 'NAVIGATE',
  SENSOR_TRACK = 'SENSOR_TRACK', // 神策埋点
  FROM_PARENT = 'FROM_PARENT',
}
export async function emitIframeEvent(method: string, payload?: any) {
  return createIframeMessageEventConsumer(
    {
      method,
      payload,
    } as MessagePostPayload,
    MessageEnum.FROM_PARENT
  )
}
const messenger = {
  start: startMainMessageListening,
  request,
  navigateTo,
  postMessage,
}
const gzMain = {
  start: startIframeMessageListening,
  registerMessage,
  emitIframeEvent,
  successRes,
  errorRes,
}

declare global {
  interface Window {
    gzMessenger: typeof messenger
    gzHooks: typeof gzHooks
    gzMainMsger: typeof gzMain
    webkit: any
    emitIframeEvent: typeof emitIframeEvent
    postResultToWebview: typeof postResultToWebview
  }
}
window.gzMessenger = messenger
window.gzMainMsger = gzMain
window.gzHooks = gzHooks
window.emitIframeEvent = emitIframeEvent
window.postResultToWebview = postResultToWebview

export default {
  messenger,
  gzHooks,
}
