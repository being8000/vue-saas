import { mockNativeHandler } from './mock'
import { nativeMessageHandler } from './message-handler'
import {
  getConfig,
  MessageData,
  MessageEnum,
  MessagePayload,
  requestFnMap,
  requestTimerMap,
} from '..'
import { encode, decode } from 'js-base64'
import useDevice from '@/utils/useDevice'
import { error408Timeout } from '@/utils/error'

const increaseMessageID = function () {
  let id = 1000000
  return function () {
    return id++
  }
}

const getMessageID = increaseMessageID()
export const createNativeMessageConsumer = <T = any>(
  payload: Omit<MessagePayload, 'messageId'>,
  type: MessageEnum
) => {
  return new Promise<MessageData<T>>((resolve, reject) => {
    const config = getConfig()
    // if (fromMethod) {
    //   params.fromMethod = fromMethod
    // }
    const messageId = getMessageID()
    const { method, data } = payload
    requestFnMap[messageId] = resolve
    const { isAndroid, isIos, isNativeApp } = useDevice()
    requestTimerMap[messageId] = setTimeout(() => {
      delete requestFnMap[messageId]
      resolve(error408Timeout())
      if (requestTimerMap[messageId]) {
        clearTimeout(requestTimerMap[messageId])
        delete requestTimerMap[messageId]
      }
    }, config.timeout || 5000)
    const params = Object.assign(payload, {
      messageId,
    })
    if (config.debug) {
      const my = mockNativeHandler
      my[method!](params)
      return
    }
    // 赋值安卓
    // window.location.href = `gamezone://h5Call?data=${base64Encode(JSON.stringify(payload))}`
    try {
      if (isNativeApp) {
        window.location.href = `gamezone://messenger?data=${encode(JSON.stringify(params))}`
        // let my = window.handler
        // if (!my) {
        //   my = mockNativeHandler
        //   my[method].call(this, JSON.stringify(params))
        // } else {
        //   my.h5Call(JSON.stringify(params || {}))
        // }
        // } else if (isIos) {
        //   if (!window.webkit) {
        //     const my = mockNativeHandler
        //     my[method!](JSON.stringify(data))
        //   } else {
        //     window.webkit.messageHandlers.h5Call.postMessage(JSON.stringify(payload || {}))
        //   }
      } else {
        const my = mockNativeHandler
        my[method!](JSON.stringify(data))
      }
    } catch (e) {
      console.error(method, mockNativeHandler, e)
      resolve({
        code: 500,
        message: 'exception',
        body: JSON.stringify(e) as any,
        success: false,
      })
    }
  })
}
