// interface MessageHandlersFunction {
//   <T = any>(params?: Bridge.SendMessageParams): Promise<Bridge.Response<T>>

import { MessageData, MessageResponse } from '..'

// }
interface MessageHandlersFunction {
  (params?: any): Promise<MessageData> | MessageData
}

export const nativeMessageHandler: Record<any, MessageHandlersFunction> = {
  async fetchWebtoken() {
    return {
      code: 200,
      message: '',
      data: {},
      success: false,
    }
  },
  async fetchLoginUser() {
    return {
      code: 200,
      message: '',
      success: false,
    }
  },
}
