import { MessageRecever } from '@/message/on-receiving-from-parent-post'
import { MessageData, MessageResponse } from '..'
import { postResultToWebview } from '@/message/on-receiving-after-post'
import { encode, decode } from 'js-base64'
const result = (params: MessageResponse) => {
  return encode(JSON.stringify(params))
}

export const mockNativeHandler: Record<string, Function> = {
  // fetchWebtoken(param: MessageRecever) {
  //   postResultToWebview(
  //     result({
  //       data: {
  //         success: true,
  //         code: 200,
  //         message: '',
  //         body: 'asdasdas',
  //       },
  //       messageId: param.messageId,
  //       type: param.type,
  //     })
  //   )
  // },
}
type MockResultFn = () => MessageData | Promise<MessageData>
type MockReulst = MessageData | MockResultFn
export function registerNativeMockFn<T>(name: string, res: MockReulst) {
  mockNativeHandler[name] = async (param: MessageRecever) => {
    postResultToWebview(
      result({
        data: typeof res === 'function' ? await res() : res,
        messageId: param.messageId,
        type: param.type,
      })
    )
  }
}
