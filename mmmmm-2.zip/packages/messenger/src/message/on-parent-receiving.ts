import { error500 } from '@/utils/error'
import {
  getMessageID,
  MessageData,
  MessageEnum,
  MessageNavigationPayload,
  MessagePayload,
  MessagePostPayload,
  requestFnMap,
} from '..'
import { onMessage } from './on-receiving-after-post'
import { Router } from 'vue-router'
let iframeEL: HTMLIFrameElement
let router: Router
export const successRes = (body?: any): MessageData => {
  return {
    success: true,
    body: body,
    code: 200,
    message: 'success',
  }
}

export const errorRes = (body?: any, code = 500, message = 'failed'): MessageData => {
  return {
    success: false,
    body: body,
    code,
    message,
  }
}
type MessageHandler = (payload: any) => Promise<MessageData> | MessageData
const messageHandlers: Record<string, MessageHandler> = {}
const response = (data: MessageData, event: MessageEvent<MessagePayload>) => {
  iframeEL!.contentWindow?.postMessage(
    {
      data: JSON.parse(JSON.stringify(data)),
      messageId: event.data.messageId,
    },
    event.origin
  )
}

export const createIframeMessageEventConsumer = <T = any>(
  payload: Omit<MessagePayload, 'messageId'>,
  type: MessageEnum
) => {
  return new Promise<MessageData<T>>(async (resolve, reject) => {
    if (!iframeEL) {
      return error500('iframe element is empty')
    }
    const messageId = getMessageID()
    requestFnMap[messageId] = resolve

    console.log({
      ...payload,
      messageId,
      type,
    })
    iframeEL.contentWindow?.postMessage(
      {
        ...payload,
        messageId,
        type,
      },
      '*'
    )
  })
}

const onIframeMessage = async (event: MessageEvent<MessagePayload>) => {
  if (!iframeEL) {
    response(
      {
        success: false,
        code: 101,
        message: 'Iframe Element is undefine',
      },
      event
    )
  }
  try {
    let data = event.data || {}
    switch (data.type) {
      case MessageEnum.POST:
        {
          let { messageId, method = '', payload = {} } = data as MessagePostPayload
          if (messageId != undefined && method) {
            if (!messageHandlers[method]) {
              return response(
                {
                  success: false,
                  code: 102,
                  message: `Parent window not register [${method}] yet!`,
                },
                event
              )
            }
            const res = await messageHandlers[method](payload)
            response(res, event)
          } else {
            throw new Error('Invalid Parameters or Method is not registered : ' + method)
          }
        }
        break
      case MessageEnum.NAVIGATE:
        {
          if (!router) {
            return response(
              {
                success: false,
                code: 102,
                message: 'http feature is not available',
              },
              event
            )
          } else {
            const {
              messageId,
              path = undefined,
              query = {},
              hash = undefined,
              replace = false,
            } = data as MessageNavigationPayload
            if (messageId != undefined) {
              if (replace) {
                router.replace({
                  path,
                  query,
                  hash,
                })
              } else {
                router.push({
                  path,
                  query,
                  hash,
                })
              }
              response(successRes(), event)
            } else {
              throw new Error('Invalid Parameters')
            }
          }
        }

        break
      case MessageEnum.FROM_PARENT:
        onMessage(event)
        break
      case MessageEnum.HTTP:
        response(
          {
            success: false,
            code: 102,
            message: 'http feature is not available',
          },
          event
        )
        // {
        //   const { messageId, url = '', config = {} } = data as MessageHttpPayload
        //   if (messageId != undefined && url) {
        //     const { success, body, head } = await request<BaseResponseType>(url, {
        //       ...config,
        //     }).then((res) => res.data)
        //     if (success) {
        //       response(successRes(body), event)
        //     } else {
        //       response(
        //         {
        //           success: false,
        //           body: body,
        //           code: head.errCode,
        //           message: head.errMsg,
        //         },
        //         event
        //       )
        //     }
        //   }
        // }
        break
      default: {
        const { messageId } = data
        if (messageId != undefined) {
          response(
            {
              success: false,
              code: 101,
              message: 'invalid request payload',
            },
            event
          )
        }
      }
    }
  } catch (error) {
    const { messageId } = event.data || {}
    if (messageId != undefined) {
      response(
        {
          success: false,
          code: 101,
          message: String(error),
        },
        event
      )
    }
  }
}
export function startIframeMessageListening({
  router: _router,
  iframeEL: _iframeEl,
}: {
  router?: any
  iframeEL: HTMLIFrameElement
}) {
  router = _router
  iframeEL = _iframeEl
  console.log('startIframeMessageListening', iframeEL)
  window.removeEventListener('message', onIframeMessage)
  window.addEventListener('message', onIframeMessage)
}

export function removeMessageListening() {
  window.removeEventListener('message', onIframeMessage)
}

export function registerMessage(method: string, fn: MessageHandler) {
  messageHandlers[method] = fn
}
