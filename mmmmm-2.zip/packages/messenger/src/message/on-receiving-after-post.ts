import { encode, decode } from 'js-base64'
import { requestFnMap, requestTimerMap } from '..'

export const onMessage = (response: MessageEvent) => {
  console.log('onMessage', response)
  const data = response.data
  const messageId = data.messageId
  if (requestTimerMap[messageId]) {
    clearTimeout(requestTimerMap[messageId])
    delete requestTimerMap[messageId]
  }
  if (requestFnMap[messageId]) {
    requestFnMap[messageId](data.data)
    delete requestFnMap[messageId]
  }
}

export function postResultToWebview(params: any) {
  let res: any = null
  try {
    if (!params) {
      params = decode(JSON.stringify({}))
    }
    res = JSON.parse(decode(params))
  } catch (e) {
    alert(e)
  }
  if (!res) {
    return
  }
  const messageId = res.messageId
  const data = res.data
  if (!messageId) {
    return
  }
  if (requestTimerMap[messageId]) {
    clearTimeout(requestTimerMap[messageId])
    delete requestTimerMap[messageId]
  }
  if (requestFnMap[messageId]) {
    requestFnMap[messageId](data)
    delete requestFnMap[messageId]
  }
}
