import { MessageEnum, MessageId, MessagePostPayload } from '..'
import { useEventBus } from '../utils/event-bus'

export interface MessageRecever<T = any> {
  type: MessageEnum
  messageId: MessageId
  payload: MessagePostPayload<T> // 发送数据
  method: string
}
export const messageBus = useEventBus('gameplus-messenger-command-hook')

/**
 * 用于接受到指令后处理返回
 * @param payload
 * @returns
 */
function responseToParent(data: any, payload: MessageRecever) {
  console.log('responseToGZ', payload)
  window.parent.postMessage(
    {
      messageId: payload.messageId,
      type: payload.type,
      data: data,
    },
    '*'
  )
}
const handlerRes = (res: any, messenger: MessageRecever) => {
  if (res instanceof Promise) {
    res
      .then((el) => {
        handlerRes(el, messenger)
      })
      .catch((el) => {
        responseToParent(JSON.stringify(el), messenger)
      })
  } else {
    responseToParent(res, messenger)
  }
}

export const hooks = {
  hookOnce(event: string, callbackFn: (params: any) => void) {
    const unsub = messageBus.on((listenEvent, data: MessageRecever) => {
      if (event === listenEvent) {
        unsub()
        handlerRes(callbackFn(data.payload), data)
      }
    })
  },
  hook(event: string, callbackFn: (params: any) => void) {
    console.log('hook', event)
    messageBus.on((listenEvent, data: MessageRecever) => {
      console.log('hook on', listenEvent, data)
      if (event === listenEvent) {
        handlerRes(callbackFn(data.payload), data)
      }
    })
  },
}
