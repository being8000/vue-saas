import useDevice from '@/utils/useDevice'
import {
  GamezoneMessengerConfig,
  MessageData,
  MessageEnum,
  MessagePostPayload,
  MessageId,
  MessagePayload,
  MessageHttpPayload,
  MessageNavigationPayload,
  MessageTrackPayload,
} from '..'
import { error408Timeout, error500 } from '../utils/error'
import { onMessage } from './on-receiving-after-post'
import { messageBus, MessageRecever } from './on-receiving-from-parent-post'
import { createNativeMessageConsumer } from '@/js-bridge'
import { mockNativeHandler } from '@/js-bridge/mock'

// import { JSDOM } from 'jsdom'
// const { window } = new JSDOM(``)

const MessageIdFn = function () {
  let id = 10000
  return function () {
    return id++
  }
}

let config: GamezoneMessengerConfig = {
  timeout: 5000,
  debug: false,
  userAgents: [],
}

export function getConfig() {
  return config
}
export const getMessageID = MessageIdFn()
export const requestFnMap: Record<MessageId, (event: MessageData) => void> = {}
export const requestTimerMap: Record<MessageId, NodeJS.Timeout> = {}

function onReceivingFromParent(message: MessageEvent<MessageRecever>) {
  const data = message.data
  console.log('onReceivingFromParant', message)
  if (data.type === MessageEnum.FROM_PARENT) {
    if (data.method) {
      messageBus.emit(data.method, data)
    }
  }
}

export const createMessageConsumer = <T = any>(
  payload: Omit<MessagePayload, 'messageId'>,
  type: MessageEnum
) => {
  return new Promise<MessageData<T>>(async (resolve, reject) => {
    const messageId = getMessageID()
    requestFnMap[messageId] = resolve
    requestTimerMap[messageId] = setTimeout(() => {
      delete requestFnMap[messageId]
      resolve(error408Timeout())
      if (requestTimerMap[messageId]) {
        clearTimeout(requestTimerMap[messageId])
        delete requestTimerMap[messageId]
      }
    }, config.timeout || 5000)
    if (config.debug) {
      const { method, data } = payload
      const params = Object.assign(payload, {
        messageId,
      })
      const my = mockNativeHandler
      my[method!](params)
      return
    } else {
      if (window.self == window.top) {
        resolve(error500('not found parent iframe element.'))
        return
      }
      window.parent.postMessage(
        {
          ...payload,
          messageId,
          type,
        },
        '*'
      )
    }
  })
}

export function startMainMessageListening(_config: Partial<GamezoneMessengerConfig>) {
  _config.userAgents = _config.userAgents || []
  _config.userAgents = ['GameZone', 'BingoPlus', 'ArenaPlus', ..._config.userAgents]
  config = { ...config, ..._config }
  window.removeEventListener('message', onMessage)
  window.addEventListener('message', onMessage)
  window.removeEventListener('message', onReceivingFromParent)
  window.addEventListener('message', onReceivingFromParent)
}

export function stopListening() {
  window.removeEventListener('message', onMessage)
  window.removeEventListener('message', onReceivingFromParent)
}

/**
 * 常规消息发送和接受
 * @param payload
 * @returns
 */
export function postMessage<T = any>(payload: MessagePostPayload) {
  console.log('postMessage', payload)
  const { isNativeApp } = useDevice()
  if (!isNativeApp) {
    return createMessageConsumer<T>(payload, MessageEnum.POST)
  }
  return createNativeMessageConsumer<T>(payload, MessageEnum.POST)
}

/**
 * 调用 gamezone http请能力
 * @param payload
 * @returns
 */
export function request<T = any>(url: string, config: any = {}) {
  console.log('request', url, config)
  config.method = config.method || 'get'
  const { isNativeApp } = useDevice()
  if (!isNativeApp) {
    return createMessageConsumer<T>(
      {
        url,
        config,
      } as MessageHttpPayload,
      MessageEnum.HTTP
    )
  }
  return createNativeMessageConsumer<T>(
    {
      url,
      config,
    } as MessageHttpPayload,
    MessageEnum.HTTP
  )
}

/**
 * 调用 gamezone 路由能力
 * @param payload
 * @returns
 */
export function navigateTo<T = any>(payload: MessageNavigationPayload) {
  console.log('navigateTo', payload)
  const { isNativeApp } = useDevice()
  if (!isNativeApp) {
    return createMessageConsumer<T>(payload, MessageEnum.NAVIGATE)
  }
  return createNativeMessageConsumer<T>(payload, MessageEnum.NAVIGATE)
}

/**
 * 调用 gamezone 路由能力
 * @param payload
 * @returns
 */
export function track<T = any>(event: string, data: any) {
  console.log('track', data)
  const { isNativeApp } = useDevice()
  if (!isNativeApp) {
    return createMessageConsumer<T>(
      {
        event,
        data,
      } as MessageTrackPayload,
      MessageEnum.SENSOR_TRACK
    )
  }
  return createNativeMessageConsumer<T>(
    {
      event,
      data,
    } as MessageTrackPayload,
    MessageEnum.SENSOR_TRACK
  )
}
