import { MessageData } from '..'

export function error500(message: string): MessageData {
  return {
    code: 500,
    message,
    success: false,
  }
}

export function success<T = any>(body: T): MessageData {
  return {
    code: 200,
    message: '请求成功',
    body,
    success: true,
  }
}

export function error408Timeout(): MessageData {
  return {
    code: 408,
    message: '响应超时',
    success: false,
  }
}
