import type { EventBusEvents, EventBusIdentifier } from './event-bus'

/* #__PURE__ */
export const events = new Map<EventBusIdentifier<any>, EventBusEvents<any>>()
