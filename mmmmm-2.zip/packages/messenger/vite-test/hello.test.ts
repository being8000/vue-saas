import { test, expect } from 'vitest'
import gz from '../src'
import { error408Timeout, error500 } from '../src/error'

test('error 500', async () => {
  expect(
    await gz.messenger
      .postMessage({
        method: 'test',
        payload: {},
      })
      .then((res) => res.code)
  ).toBe(error500('').code)
})

test('error timeout', async () => {
  expect(
    await gz.messenger
      .postMessage({
        method: 'test',
      })
      .then((res) => res.code)
  ).toBe(error408Timeout().code)
})
