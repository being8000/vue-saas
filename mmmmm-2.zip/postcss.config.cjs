module.exports = {
  plugins: {
    // ...
    // "postcss-px-to-viewport": {
    //   // rootValue: 25,
    //   // propList: ["*"],
    // },
    tailwindcss: {},
  },
};
