<script setup lang="ts">
import useJackportSocket from './composables/socket/useSocket'
import './composables/useLifeCycle'
const route = useRoute()

onMounted(() => {
  emitAppEvent('app:mounted', {})
  const { connect } = useJackportSocket()
  connect()
})

const hooks = useNuxtApp().hooks
hooks.hookOnce('page:finish', () => {})
</script>

<template>
  <div>
    <VLocaleProvider ref="refProvider">
      <VApp>
        <router-view></router-view>
      </VApp>
    </VLocaleProvider>
  </div>
</template>

<style>
#app {
  --app-navbar-height: 44px;
}

#app-navbar {
  height: var(--app-navbar-height);
}

.site-page-container {
  width: 100vw;
  overflow-y: scroll;
  min-height: calc(100vh - 44px);
}
</style>
