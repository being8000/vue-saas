export interface CasinoGame {
  exCode: string
  flag: number
  gameFree: number
  gameHotValue: string
  gameId: string
  gameImage: string
  gameKind: string
  gameName: string
  gameNameEn: string
  nameEn: string
  nameZh: string
  gamePreImage: string
  gameType: number
  gdGameId: string
  hotFlag: number
  indexFlag: number
  isFavorite: number
  isUpHot: number
  jackpotId: string
  jackpotValue: string
  jsonParam: string
  localFlag: number
  maintainEndTime: string
  maintainStartTime: string
  maintenanceFlag: number
  maxWinMultiple: number
  newFlag: number
  payLine: number
  payoutFlag: number
  platformCode: string
  platformId: string
  platformName: string
  platformStatus: number
  playerType: number
  poolFlag: number
  popularity: number
  preferenceFlag: number
  recommendFlag: number
  rtp: string
  screenFlag: number
  serverGameId: string
  showArea: number
  tryFlag: number
  typeUrl: string
  vid?: string
  gmtype?: string
  overlayColor: string
}

export interface CasinoGames {
  data: CasinoGame[]
  pageNo: number
  pageSize: number
  totalPage: number
  totalRow: number
}

export interface CasinoConfig {
  flag: number
  gameKindName: string
  id: number
  iconH5: string
  productId: string
  sortH5: number
  games: CasinoGames
  nameEn: string
}

export interface GameRespVO {
  buttonName: string
  endTime: string
  id: number
  autoAddGameBaseIds: number[]
  pagination: number
  productName: string
  recommendGameIds: number[]
  remark: string
  showGameCount: number
  sort: number
  startTime: string
  status: number
  updateTime: string
  updater: string
}

export interface GameBaseItem {
  gameImageNew: string
  flag: number // 游戏状态 2 维护中
  gameDesc: string
  gameId: string // 调用inGame接口 gameId 参数
  gameImage: string // 游戏图片
  gameImageBig: string // 游戏大图
  gameType: string // 游戏类型
  gdGameId: string
  id: number
  jsonParam: string // 调用inGame接口 jumpParam 参数
  maintainEndTime: string // 维护开始时间
  maintainStartTime: string // 维护结束时间
  scheduleStartTime: string // 每日维护开始时间
  scheduleEndTime: string // 每日维护结束时间 : ""
  nameEn: string // 游戏英文名
  nameZh: string
  operatingTime: string
  operator: string
  overlayColor: string
  platformId: string // 平台/厅方/游戏提供商ID， 调用inGame接口 platformCode参数
  platformName: string // 平台/厅方/游戏提供商名称
  platformStatus: number //（平台/厅方/游戏提供商）维护状态， 不等1的时候为维护中
  screenFlag: number
  sortNo: number // 排序号，查询游戏的时候默认需要降序处理
  vid?: string
  gmtype?: string
  jackpotShowFlag: number // 是否在游戏页面显示luckySpin（jackport转盘）挂件，
  isFavorite: number // 是否收藏游戏 1 是 0 否
  jackpotFlag: number // 是否jackport 1 是 0 否
  pvpFlag: number // 是否为PVP 游戏 1 是 0否
  hotFlag: number // 是否为热门游戏  1: 是 0 否
  newFlag: number // 是否为新游戏 1: 是 0 否
  recommendFlag: number // 是否为推荐游戏 1: 是 0 否
  ggr: number // 游戏热度统计值
  /** banner接口中获取 */
  jumpJson?: string
  platformDisplayName?: string
}

export interface GameBaseAllResp {
  data: GameBaseItem[]
  gameMap: Map<number, GameBaseItem>
  firstPage: boolean
  fistPage: number
  lastPage: boolean
  next: boolean
  nextPage: number
  onlyTotalCount: boolean
  pageEndRow: number
  pageIndexL: number
  pageSize: number
  pageStartRow: number
  previousPage: number
  totalPages: number
  totalRows: number
}

export interface InGameReq {
  gameCode: string
  /** 平台码 */
  platformCode: string
  gdGameId?: string // @TODO new game id , must find backend to finish this param
  gameId: string
  gameName: string
  gameType: string
  /** 回调路径 */
  callbackPath: string
  /** 回调域名 */
  domainName: string
  /** 语言 */
  lang: string
  isWithTransfer: string
  /** 平台货币 */
  platformCurrency: string
  roomType: string
  videoId: string
  jumpParam?: string
}

export interface InGameResp {
  body: {
    formMethod: string
    url: string
  }
  head: {
    cost: number
    errCode: string
    errMsg: string
  }
}

export async function fetchInGame(payload: InGameReq) {
  const url = withGlaxy(`/game/v2/inGame`)
  return $api<InGameResp>(url, {
    method: 'post',
    body: payload,
  })
}

export interface AddLikeReq {
  platformCode: string
  gameId: string
}

export interface AddLikeResp {
  body: boolean
  head: {
    cost: number
    errCode: string
    errMsg: string
    formatData: string
  }
}

export async function addLike(payload: AddLikeReq) {
  const url = withGlaxy(`/game/like`)
  return $api<AddLikeResp>(url, {
    method: 'post',
    body: payload,
  })
}

export interface CancelLikeReq {
  platformCode: string
  gameId: string
}

export interface CancelLikeResp {
  body: boolean
  head: {
    cost: number
    errCode: string
    errMsg: string
    formatData: string
  }
}

export async function cancelLike(payload: CancelLikeReq) {
  const url = withGlaxy(`/game/cancleLike`)
  return $api<CancelLikeResp>(url, {
    method: 'post',
    body: payload,
  })
}

export interface LikeGame {
  createDate?: string
  customerId?: string
  gameId: string
  id?: string
  platformCode: string
  status?: string
}

export interface LikeListResp {
  body: LikeGame[]
  head: {
    cost: number
    errCode: string
    errMsg: string
    formatData: string
  }
  success: boolean
}

export const fetchLikeListUrl = withFront(`/game/likeList`)

// export const fetchLikeListApiKey = stringifyApiKey(fetchLikeListUrl);

export async function fetchLikeList() {
  // const { data } = useNuxtData<LikeListResp>(fetchLikeListApiKey);
  // if (data.value) {
  //   return { data, pending: false };
  // }
  return $api<LikeListResp>(fetchLikeListUrl, {
    method: 'post',
  })
}

export interface RecentGame {
  createDate?: string
  customerId?: string
  gameId: string
  id?: string
  platformCode: string
  status?: string
}

export interface RecentGamesResp {
  body: RecentGame[]
  head: {
    cost: number
    errCode: string
    errMsg: string
    formatData: string
  }
}

export async function fetchRecentGames() {
  // const { data } = useNuxtData<RecentGamesResp>(fetchRecentGamesApiKey);
  // if (data.value) {
  //   return { data, pending: false };
  // }
  return $api<BaseResponseType<RecentGame[]>>(withFront(`/game/historyList`), {
    method: 'post',
  })
}

export interface ReportHistoryReq {
  platformCode: string
  gameId: string
}

export interface ReportHistoryResp {
  body: boolean
  head: {
    cost: number
    errCode: string
    errMsg: string
    formatData: string
  }
}

export async function reportHistory(payload: ReportHistoryReq) {
  const url = withFront(`/game/history`)
  return $api<ReportHistoryResp>(url, {
    method: 'post',
    body: payload,
  })
}

export const serverReportHistoryUrl = withFront(`/game/history`)

// export const serverReportHistoryApiKey = stringifyApiKey(
//   serverReportHistoryUrl
// );

export async function serverReportHistory(payload: ReportHistoryReq) {
  const url = serverReportHistoryUrl
  // const { data } = useNuxtData<ReportHistoryResp>(serverReportHistoryApiKey);
  // if (data.value) {
  //   return { data, pending: false };
  // }
  return $api<ReportHistoryResp>(url)
}

export interface DisableProviderLabel {
  id: number
  lobbyCode: string
  lobbyName: string
  opBy: string
  opTime: number
  productId: string
  productName: string
  status: number
}

export const disableLobbyLabelUrl = withFront(`/disableLobbyLabel`)

// export const disableLobbyLabelApiKey = stringifyApiKey(disableLobbyLabelUrl);

export async function fetchDisableLobbyLabel() {
  const url = disableLobbyLabelUrl
  // const { data } = useNuxtData<DisableProviderLabelResp>(disableLobbyLabelApiKey)
  // if (data.value) {
  //   return { data, pending: false }
  // }
  return $api<BaseResponseType<DisableProviderLabel[]>>(url, {
    method: 'get',
    body: {},
  })
}
