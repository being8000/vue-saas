import { SiteInfo } from '@/composables/useSiteInfoStore'

/**
 * 首次进入获取webToken
 * @returns
 */
export function fetctClientWebToken<T = any>(body = {}, params: Record<string, any> = {}) {
  return $api<T>(withGlaxy('/webToken'), {
    method: 'POST',
    body,
  })
}

/**
 * 获取站点配置信息
 * @returns
 */
export function fetchSiteInfo<T = BaseResponseType<SiteInfo>>(params: Record<string, any> = {}) {
  return $api<T>(withFront('/front/siteinfo'), {
    method: 'POST',
    ...params,
  } as any)
}

/**
 * 发送验证码
 * // TYPE
// 0: 'Register',
// 1: 'Login',
// 2: 'Change Account Information',
// 3: 'Change Account Password',
// 4: 'Change Withdrawal Password',
// 5: 'Modify Account Information',
// 6: 'Set Withdrawal Password'
 * {"type":3,"productId":"C66","loginName":"gpcp7ehm","customerId":"1025343868440846337"}
 * @returns
 */
export function sendSms<T = BaseResponseType<boolean>>(body = {}) {
  return $api<T>(withGlaxy('/customer/sendVerificationCode'), {
    method: 'POST',
    body,
  } as any)
}

/**
 * 校验验证码
{"captcha":"398047","customerName":"gpcp7ehm","type":1,"productId":"C66","loginName":"gpcp7ehm","customerId":"1025343868440846337"}
 * @returns
 */
export function checkSms<T = any>(body = {}) {
  return $api<T>(withGlaxy('/userAuth/otpCaptcha'), {
    method: 'POST',
    body,
    needCustomerName: true,
  } as any)
}

export function fetchSysTime() {
  return $api<number>(withFront(`/systemTime`), {
    method: 'get',
    original: true,
  })
}

// 校验取款密码
export function validatePwd<T = BaseResponseType<any>>(body: any) {
  return $api<T>(withGlaxy('/customer/validatePwd'), {
    method: 'post',
    body: body,
    needCustomerName: true,
  })
}

export async function getfile<T = string>(content: any, body?: any) {
  const el = await pureRequest<T>(content, {
    method: 'get',
  })
  return el.data
}
