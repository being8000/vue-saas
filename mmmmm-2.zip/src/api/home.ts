import { LinkToEnum } from '@/util/enum'
import { CasinoGame } from './game'

/** @see https://scfveb.axshare.com/#id=xasmg1&p=banner___0809___&g=1 */
export enum BannerCategory {
  /** 首页顶部banner */
  Top = '1',
  /** 首页底部banner */
  Bottom = '2',
  /** 首页侧边banner */
  Side = '3',
  /** 更多菜单banner1 */
  More1 = '4',
  /** 更多菜单banner2 */
  More2 = '5',
  /** 更多菜单banner3 */
  More3 = '6',
  /** 盖台banner */
  Poster = '7',
  /** 首页顶部banner为登录 */
  BannerUnlogin = '8',
  /** 自定义banner组件*/
  Customize = '9',
  /** 注册界面banner*/
  SignupBanner = '10',
  /** 登录界面banner*/
  LoginBanner = '11',
}

/** @see https://scfveb.axshare.com/#id=xasmg1&p=banner___0809___&g=1 */
export enum BannerSubCategory {
  /** 站内链接跳转 */
  SiteInner = '1',
  /** 站外链接跳转 */
  SiteOutter = '2',
  /** 游戏跳转 */
  GameJump = '3',
  /** 下载 */
  Download = '4',
  None = 'None',
}

export interface Banner {
  platformId: string
  /**
   * 页面类型
   * 1 - 站内页面
   * 2 - 站外页面
   * 3 - 进入游戏
   * 4 - 下载
   */
  redirectCategory: number
  picUrl: string
  picId: string
  category: string
  createdBy: string
  createdDate: string
  desc: string
  endTime: string
  featured: number
  gameCode: string
  gameId: string
  gameName: string
  gameType: string
  id: number
  imgUrl: string
  topBackground: string
  isNew: number
  jsonParam: string
  jumpJson: string
  /** jumpJson解析出来的参数，判断是不是下载功能 */
  download: boolean
  platformCode: string
  port: string
  productName: string
  promotion: number
  redirectLink: string
  remark: string
  showPage: string
  sort: number
  startTime: string
  status: string
  subCategory: BannerSubCategory
  targetUrl: string
  title: string
  updateDate: string
  updatedBy: string
}
export enum BlockType {
  game = 0,
  banner = 1,
  component = 2,
}
// 1 普通板式  2 2+6  3 9+1
export enum BlockStyle {
  Block1 = 1, //
  Block2 = 2,
  Block3 = 3,
}
export interface DirtyBlockConfig {
  gameBaseIdList: number[]
  bannerList: Banner[]
  style: BlockStyle
  blockParam: string
  blockGameList: unknown
  blockName: string
  blockPic: string
  themePic: string
  clientType: string
  endTime: string
  gameIndexIds: number[]
  gameItemsIds: number[]
  games: CasinoGame[]
  id: number
  pagination: string
  productId: string
  productName: string
  remark: string
  rowStyle: number
  columnStyle: number
  /** 是否显示view all 按钮 1否 2是 */
  showViewAll: number
  sort: number
  startTime: string
  status: number
  updateTime: string
  updater: string
  type: BlockType // 区块类型
  bannerResp: Banner[] | null
}
;[]

/** @see https://digiplus.sg.larksuite.com/wiki/SaNMwPOCwiIpIJkua6rlPKkDgve?fromScene=spaceOverview */
export enum MoreMenuSkipType {
  /** 站内链接跳转 */
  SiteInner = '1',
  /** 站外链接跳转 */
  SiteOutter = '2',
  /** 游戏跳转 */
  GameJump = '3',
}

export interface MoreMenuItemData {
  createTime: string
  functionType: number
  gameId: string
  iconSkipFlag: number
  id: number
  imgUrl: string
  name: string
  parentId: number
  platformCode: string
  remark: string
  selectFunctionFlag: number
  skipType: MoreMenuSkipType
  skipUrl: string
  sort: number
  status: number
  updateName: string
  updateTime: string
}

export interface MoreMenuItem {
  id: number
  productId: string
  productName: string
  deviceType: string
  showPage: string
  status: number
  menuTitle: string
  sort: number
  startTime: string
  endTime: string
  remark: string
  updateName: string
  updateTime: string
  createTime: string
  dataList: MoreMenuItemData[]
  dataQueryList: MoreMenuItemData[]
}

export interface MoreMenu {
  categoryIdFirst: number
  moreMenuRspList: MoreMenuItem[]
  pagination: string
}

export interface Marquee {
  /** 跑马灯id */
  id: number
  /** 产品编号 */
  productId: string
  /** 产品分组（GP,GM,TP） */
  productName: string
  /** 客户端类型(多个使用逗号分割) 1PC 2H5 3ANDROID 4IOS 5小程序 */
  clientType: string
  /** 跑马灯的标题 */
  title: string
  /** 跑马灯的内容 */
  context: string
  /** 排序 */
  sort: number
  /** 状态 1启用 2禁用 -1删除 */
  status: number
  /** 开始时间 */
  startTime: string
  /** 结束时间 */
  endTime: string
  /** 1.无跳转 2.站内页面 3.站外页面 4.进入游戏 */
  jumpType: number
  /** 跳转 */
  redirectLink: string
  /** gameBaseId */
  gameId: string
  platformId: string
  subCategory: LinkToEnum
  /** 备注 */
  remark: string
  /** 跳转特殊参数 */
  jumpJson: string
  /** 创建人账号 */
  creator: string
  /** 创建时间 */
  createTime: string
  /** 更新人账号 */
  updater: string
  /** 更新时间 */
  updateTime: string
  listtype?: number
  winningTime?: string
  loginName?: string
  amount?: number
  // 游戏图片
  gameImage?: string
  // 游戏名称
  nameEn?: string
  totalPrizeNum?: number
  type?: string
}

export interface MarqueeResp {
  body: {
    [key: string]: Marquee[]
  }
  head: {
    cost: number
    errCode: string
    errMsg: string
    formatData: string
  }
}

export const fetchMarqueeUrl = withFront(`/marqueeV2`)

export async function fetchMarquee() {
  const url = fetchMarqueeUrl
  return $api<MarqueeResp>(url, {
    method: 'post',
  })
}

export const providersUrl = withFront(`/gameProviders`)

// export const fetchMarqueeApiKey = stringifyApiKey(fetchMarqueeUrl);
export interface GameProviderVo {
  id: number
  productId: string
  appGroup: string
  platformId: string
  platformName: string
  platformDisplayName: string
  gameKind: string
  gameId: string
  cagent: string
  giDesKey: string
  giSignKey: string
  giPassword: string
  currency: string
  createDate: string
  createBy: string
  flag: number
  sortNo: number
  ggr: number
  logoUrl: string
  logoStatus: number
}
export async function fetchgameProviders() {
  const url = providersUrl
  // const { data } = useNuxtData<MarqueeResp>(fetchMarqueeApiKey);
  // if (data.value) {
  //   return { data, pending: false };
  // }
  return $api<BaseResponseType<GameProviderVo[]>>(url, {
    method: 'post',
  })
}

export interface WinnerArry {
  matchType: number // 赛事类型: 1 免费赛 2 付费赛
  loginName: string // 登录名
  endTime: number // 结算时间时间戳
  endTimeStr: string // 结算时间字符串
  rewardMoney: number // 结算金额
  rank: number // 排名
  tenant: string // 产品名称
  winningTime?: string
  amount?: number
  gameImage?: string
  nameEn?: string
  serverTime:number
}
interface TimeSecArry {
  finishTimeSec: number
  intervalSec: number
  startTimeSec: number
}
export interface TongitsMatchResp {
  awardType: number //奖池奖励类型 0:固定奖池 1:动态奖池
  bigBlind: number //大盲
  delayEnterEndTime: number //延迟进入时间戳（秒）
  earlyEnterTime: number //提前进入比赛时间戳（秒）
  gameName: string //游戏名称
  gameType: string //游戏类型
  lastUpdateTime: number //最后更新时间
  listId: number //比较列表ID
  matchId: number //比赛服务ID(可进入时有值)
  matchName: string //赛事名称
  minGuaranteeMoney: number //保底金额
  openType: number //赛制类型（MTT:2 SNG:1）
  prizeRate: number //动态坚持手续费（已放大1000倍）
  rebuyTotalMoney: number //rebuy总金额
  repeatType: number //赛事类型（循环赛的 单场不重复:0 单天单场:1 单天多场:2）
  rebuyCount: number //rebuy次数
  signNum: number //报名费用
  signStartTime: number //报名开始时间戳（秒）
  signType: number //报名方式（0：付费 1：免费）
  signUserNum: number //已报名人数
  startStatus: number //比赛状态（0：未开始 1：已开始 2：已结束）
  startTime: number //开赛时间时间戳（秒）
  startUserNum: number //最低开赛人数
  totalPrizeNum: number //动态奖池总奖池
  whiteList: string //用户白名单（以英文逗号分割）
  starttimeEn?: string //转换为英文日期格式
  serverTime: number //服务器时间
  countdowntime: number //倒计时
  usersigin?: boolean //用户是否报名
  isHide?: boolean //是否删除当前一条数据
  entertime: number //进入比赛时间戳
  signStartTimeEn?: string //格式化可报名时间
  cycleTimeItem: TimeSecArry[] // 赛事时间配置
  delaySeconds: number //赛事得间隔时间
}
// 首页赛事占位列表
export async function fetchpositionList() {
  return $api<BaseResponseType<TongitsMatchResp[]>>(withFront('/tiptopMatch/positionList'), {
    method: 'post',
  })
}
export interface TagItemResp {
  nameEn: string
  nameTagalog: string
  type: number
  value: string
  sort: number
  remark: string
}
export interface SignListResp {
  listIds: (string | number)[]
}
export interface TongitsInGameReq {
  gameCode: string
  /** 平台码 */
  platformCode: string
  gdGameId?: string // @TODO new game id , must find backend to finish this param
  gameId: string
  gameName: string
  gameType: string
  /** 回调路径 */
  callbackPath: string
  /** 回调域名 */
  domainName: string
  /** 语言 */
  lang: string
  isWithTransfer: string
  /** 平台货币 */
  platformCurrency: string
  roomType: string
  videoId: string
  jumpParam?: string
  listId?: number
}
export interface leaderBoardArray {
  loginName: string
  score: number
  rank: number
  awardAmount: number
  avatarUrl: string | null
  lastAwardAmount?: number
  differenceScore?: number
}
export interface rankConfig {
  rankName: String
  rankType: number
  status: number | undefined
  startTime: string
  endTime: string
  rankRules: string
}

export interface marqueeConfig {
  marketingTxt: string | undefined
}

// 榜单配置列表
export async function fetchRankConfig() {
  return $api<BaseResponseType<rankConfig[]>>(withActivity('/ranking/getRankingConfig'), {
    method: 'post',
  })
}
// 个人排行榜
export async function fetchQueryUserRank(rankType: Number) {
  return $api<BaseResponseType<leaderBoardArray>>(withActivity('/ranking/getPersonalRanking'), {
    method: 'post',
    body: {
      rankType,
    },
  })
}
// 赛事排行榜列表
export async function fetchQueryRank(rankType: Number) {
  return $api<BaseResponseType<leaderBoardArray[]>>(withActivity('/ranking/getRankingList'), {
    method: 'post',
    body: {
      rankType,
    },
  })
}

// 赛事列表
export async function fetchMatchList() {
  return $api<BaseResponseType<TongitsMatchResp[]>>(withFront('/tiptopMatch/matchList'), {
    method: 'post',
  })
}

// 标签列表
export async function fetchTagList() {
  return $api<BaseResponseType<TagItemResp[]>>(withFront('/tiptopMatch/tagList'), {
    method: 'post',
  })
}

// 获取用户已报名赛事列表
export async function fetchSignList() {
  return $api<BaseResponseType<SignListResp>>(withActivity('/tiptopMatch/signList'), {
    method: 'post',
  })
}

// 获取用户取消报名赛事
export async function fetchsignUpCancel(listId: any) {
  return $api<BaseResponseType<boolean>>(withActivity('/tiptopMatch/signUpCancel'), {
    method: 'post',
    body: {
      listId,
    },
  })
}

// 获取用户报名赛事
export async function fetchTongitsInGame(payload: TongitsInGameReq) {
  const url = withActivity(`/tiptopMatch/signUp`)
  return $api<BaseResponseType<TongitsInGameReq>>(url, {
    method: 'post',
    body: payload,
  })
}
// 历史爆奖数据
export async function fetchTopWinner() {
  const url = withFront(`/prizeCache/tiptopPrize`)
  return $api<BaseResponseType<string>>(url, {
    method: 'get',
  })
}

//bppoker页头部滚动marquee
export async function fetchMarqueeList() {
  return $api<BaseResponseType<marqueeConfig[]>>(withFront('/getMarqueeList'), {
    method: 'post',
  })
}
