/**
 * @see https://digiplus.sg.larksuite.com/wiki/Z4Y2wNXn3izeQ2km2HWl86tEg8b
 */
import { hooks, postMessage } from '@gameplus/messenger'
import { GameBaseItem } from './game'
import { useUserStore } from '@/composables/useUserStore'
import { WebToken } from '@/composables/useWebTokenStore'

hooks.hook('onLogin', () => {
  console.log('poker onLogin')
  fetchUserDetails()
  return {}
})
hooks.hook('onLogout', () => {
  console.log('poker onLogout')
  const userDetailStore = useUserDetailStore()
  const userStore = useUserStore()
  userDetailStore.value = {}
  userStore.value = {
    isLogin: false,
  }
  return {}
})
// 获取binggo用户详情。
export const fetchUserDetails = async () => {
  const { success, body } = await postMessage<any>({
    method: 'fetchUserDetails',
  })
  const userDetailStore = useUserDetailStore()
  const userStore = useUserStore()
  if (success) {
    userDetailStore.value = body
    userStore.value = {
      isLogin: true,
      loginName: userDetailStore.value.loginName,
      customerId: userDetailStore.value.customerId,
    }
    return body
  }

  userStore.value = {
    isLogin: false,
    loginName: undefined,
    customerId: undefined,
  }
  return undefined
}

/**
 * 首次进入获取bingo webToken
 * @returns
 */

export const fetctWebToken = async () => {
  return postMessage<WebToken>({
    method: 'fetchWebtoken',
  })
}

/**
 * 首次获取站点信息
 * @returns
 */

export const fetchAppInfo = async () => {
  return postMessage<{
    tenant: 'BP' | 'AP'
  }>({
    method: 'fetchAppInfo',
  })
}

/**
 * 6. 是否KYC
 * @returns
 */

export const fetchEKYCFlag = async () => {
  return postMessage<{
    ekycFlag: boolean
  }>({
    method: 'fetchEKYCFlag',
  })
}

/**
 * 通知BP跳转游戏
 * @returns
 */
export const navigateToGame = async (game: GameBaseItem) => {
  postMessage({
    method: 'navigateToGame',
    payload: game,
  })
  // postMessage({
  //   method: 'navigateToGame',
  //   payload: {
  //     videoId: '',
  //     jumpParam: '{}',
  //     gameType: '3',
  //     gdGameId: '4',
  //     platformId: '175',
  //     gameId: 'tongits',
  //     gameName: 'Tongits Go',
  //   },
  // })
}

/**
 * 通知BP打开登录页
 * @returns
 */
export const navigateToLogin = async () => {
  postMessage({
    method: 'navigateToLogin',
  })
}

/**
 * 通知BP跳转EKYC
 * @returns
 */
export const navigateToEKYC = async () => {
  postMessage({
    method: 'navigateToEKYC',
  })
}

/**
 * 检查用户是否是登录状态
 * @returns
 */
export const checkLoginStatus = async (type :boolean) => {
  await fetchUserDetails()
  const userStore = useUserStore()
  if (userStore.value.isLogin) {
    return true
  } else {
    if(type){
      navigateToLogin()
    }
    return false
  }
}
