import { LinkToEnum } from '@/util/enum'
export interface PromitionsItemType {
  id: any //主键id
  title: string //Promo标题
  clientType: string //应用端 1.PC 2.H5 3.ANDROID 4.IOS 5.小程序
  status: number //选择该配置是否启用 1.启用 2.禁用 3.删除
  startTime: string //开始时间
  endTime: string //结束时间
  sort: number //排序
  imgUrl: string //上传该Promo的 封面资源图片
  content: string //正文内容
  buttonContent: string //按钮文案
  skipType: LinkToEnum //1.站内页面 2.站外页面 3.进入游戏
  skipUrl: string //跳转链接
  platformCode: string //厅方编号
  gameId: string //游戏编号
  remark: string //备注
  jsonParam: string //跳转参数
  seoTitle: string //SEO标题
  seoDescribe: string //SEO描述
  seoKeyword: string //SEO关键词
  productId: string //产品id
  productName: string //产品编号
  updateName: string //更新用户
  createTime: Date //创建时间
  updateTime: Date //更新时间
  parsecontent: object
}
/**
 * [
  {
    "branchName": "Cebu Toledo Branch",
    "city": "Toledo",
    "createBy": "borg",
    "createDate": "2023-05-17 13:38:03",
    "eventContent": "<p>123d12d12d的哈萨克家里的撒谎的撒谎的撒谎的撒谎看 &nbsp;</p><p>&nbsp;</p><p>还是实打实的很深的伤口的</p><p>的撒肯定撒多喝水多喝水多好多好</p><p>世界顶级假的假的假的假的假的假的基督教</p><p>看见大家都基督教精神</p><figure class=\"image\"><img src=\"https://c66hk.s3.ap-east-1.amazonaws.com/5ba7f306-aeed-41a5-9f61-aa7ea2488ea9\"></figure>",
    "eventEndDate": "2023-05-17 23:59:59",
    "eventStartDate": "2023-05-17 00:00:00",
    "eventTitle": "r123121111",
    "expiredFlag": 2,
    "flag": 1,
    "id": 114,
    "lastUpdateBy": "ember",
    "lastUpdateDate": "2024-07-02 11:25:18",
    "picAddrH5PictureUrl": "https://c66hk.s3.ap-east-1.amazonaws.com/7cf33840-fbe8-401c-86d5-d2a8a2c638a1",
    "picAddrPcPictureUrl": "https://c66hk.s3.ap-east-1.amazonaws.com/97c276b9-3834-4aad-a42c-4780c01fe991",
    "picEvent": null,
    "picPictureH5": "7cf33840-fbe8-401c-86d5-d2a8a2c638a1",
    "picPicturePc": "97c276b9-3834-4aad-a42c-4780c01fe991",
    "picUrl": null,
    "province": "Cebu",
    "sortNo": 1,
    "storeBranchId": 37
  }
] 
 */

// export const getfile = (content: any) => {
//   return $api<string>(content, {
//     method: 'get',
//     blobToJson: false,
//     original: true,
//   })
// }
