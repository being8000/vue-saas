import { StorageKey } from '@/composables/useStorage'
import { CasinoConfig, GameBaseAllResp, GameRespVO } from './game'
import { PromitionsItemType } from './promotion'
import { Banner, DirtyBlockConfig, MoreMenu } from './home'

/**
 * 封装一个公用的请求js资源数据方法, 不暴露
 * 带有backup功能
 * @param {*} url
 * @param {*} storageKey
 */
const fetchJsWithBackup = async <T = any>(url: string, storageKey?: StorageKey) => {
  // 先去缓存里面的key找一下是否key有更新，如果没有更新直接从缓存里面拿数据，不需要请求接口
  // const storageVersionKey = storageKey + '_VERSION'
  // const storageData = useLocalStorage<T>(storageKey, null, {
  //   serializer: {
  //     read: (v: any) => (v ? JSON.parse(v) : null),
  //     write: (v: any) => JSON.stringify(v),
  //   },
  // })
  // const storageUrl = useLocalStorage<string>(storageVersionKey, null, {
  //   serializer: {
  //     read: (v: any) => (v ? JSON.parse(v) : null),
  //     write: (v: any) => JSON.stringify(v),
  //   },
  // })
  // console.log(storageKey, url)
  // console.log(storageKey, 'storageUrl', storageUrl.value)
  // if (storageUrl) {
  //   if (url === storageUrl.value) {
  //     // 如果相等说明key值不变，则无需请求接口，从缓存中拉取数据
  //     if (storageData.value) {
  //       console.log(storageKey, '版本一致，从缓存中取数据：', url, storageData.value)
  //       return storageData.value
  //     }
  //   }
  // }
  let data = await pureRequest<T>(withStaticJs(url), {
    method: 'get',
  }).then((el) => el.data)
  if (!data) {
    // siteinfo中的key请求失败，使用bakcupurl请求
    const backurl = url.replace(/(.*)_.*/, '$1.js?t=' + Date.now())
    data = await pureRequest<T>(withStaticJs(backurl), {
      method: 'get',
    }).then((el) => el.data)
    console.log(storageKey, '获取失败，从备份资源拉取', data)
    // storageData.value = data
  }

  return data
  if (data) {
    // storageData.value = data
    // storageUrl.value = url
  }
  // return storageData.value
}

/**
 * 获取所有游戏
 * fetchCasinoGames
 *
 * @returns
 */
export async function fetchAllBaseGame() {
  const siteInfo = useSiteInfoStore()
  const key = siteInfo.value?.GAME_JSON
  const url = `/gpgame/game_base_all_${key}.js`
  return fetchJsWithBackup<GameBaseAllResp>(url, StorageKey.GAME_JSON)
}
/**
 * 获取poker
 * fetchPokerGames
 *
 * @returns
 */
export async function fetchPokerConfigJs() {
  const siteInfo = useSiteInfoStore()
  const key = siteInfo.value?.POKER_BLOCK_CONFIG_JSON
  const url = `/gpgame/GP_poker_block_config_${key}.js`
  return fetchJsWithBackup<GameBaseAllResp>(url)
}

/**
 * 获取进厅推荐游戏
 * fetchGamesList
 * @returns
 */
export async function fetchGamingRecorment() {
  const siteInfo = useSiteInfoStore()
  const key = siteInfo.value?.ENTRY_CONFIG_JSON
  const url = `/gpgame/${key}.js`
  return fetchJsWithBackup<GameRespVO[]>(url, StorageKey.ENTRY_CONFIG_JSON)
}

/**
 * 获取首页banner数据
 * @returns
 */
export async function fetchBanners() {
  const siteInfo = useSiteInfoStore()
  const key = siteInfo.value?.BANNER_JSON
  const url = `/gpbanner/H5${key}.js`
  return fetchJsWithBackup<Banner[]>(url, StorageKey.BANNER_JSON)
}

/**
 * 获取首页区块数据 fetchDirtyBlockConfigs
 * @returns
 */
export async function fetchBlockConfigsJs() {
  const siteInfo = useSiteInfoStore()
  const key = siteInfo.value?.BLOCK_CONFIG_JSON
  const url = `/gpgame/GP_H5_block_game_${key}.js`
  return fetchJsWithBackup<DirtyBlockConfig[]>(url, StorageKey.BLOCK_CONFIG_JSON)
}
/**
 * 获取首页区块数据 fetchDirtyBlockConfigs 带banner和自定义组件
 * @returns
 */
export async function fetchAllBlockConfigsJs() {
  const siteInfo = useSiteInfoStore()
  const key = siteInfo.value?.BLOCK_CONFIG_JSON
  // const key = 'afec4bbc7acb401695cddf7e0f117907'
  const url = `/gpgame/GP_H5_block_game_all_${key}.js`
  return fetchJsWithBackup<DirtyBlockConfig[]>(url, StorageKey.BLOCK_CONFIG_JSON)
}

/**
 * 获取首页区块数据 fetchMoreMenu
 * @returns
 */
export async function fetchMoreMenu() {
  const siteInfo = useSiteInfoStore()
  const key = siteInfo.value?.MORE_MENU_JSON
  const url = `/gpmoremenu/H5${key}.js`
  return fetchJsWithBackup<MoreMenu[]>(url, StorageKey.MORE_MENU_JSON)
}

/**
 * 获取首页区块数据 fetchPromotions
 * @returns
 */
export async function fetchPromotions() {
  const siteInfo = useSiteInfoStore()
  const key = siteInfo.value?.PROMOTION_JSON
  const url = `/gpstorewebsite/H5${key}.js`
  return fetchJsWithBackup<PromitionsItemType[]>(url, StorageKey.PROMOTION_JSON)
}

/**
 * 获取首页TCC 赛事配置 fetchTCCInfo
 * @returns
 */
export const fetchTCCInfo = () => {
  const siteInfo = useSiteInfoStore()
  const key = siteInfo.value?.TCC_MATCH_ENTRY_JSON
  const url = `/gpstorewebsite/H5${key}.js`
  return fetchJsWithBackup<PromitionsItemType[]>(url, StorageKey.TCC_MATCH_ENTRY_JSON)
}
