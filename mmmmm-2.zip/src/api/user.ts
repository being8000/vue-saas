// 用户相关接口
enum LoginFromTypeEnum {
  Facebook = '0',
  Google = '1',
  Maya = '6',
}
// 登入或注册
export function loginAndReigister<T = BaseResponseType<AppUser>>(body = {}) {
  return $api<T>(withGlaxy('/userAuth/loginAndRegisterV4'), {
    method: 'post',
    body: body,
    withGlobal: false,
  })
}

// 发送短信验证码
export function sendSmsCode<T = BaseResponseType<boolean>>(body = {}) {
  return $api<T>(withGlaxy('/userAuth/loginAndRegisterSendSmsCode'), {
    method: 'post',
    body: body,
    withGlobal: false,
    showToast: true,
  })
}

// 获取用户详情信息Kyc等等
export function getUserInfo<T = BaseResponseType<AppUserDetail>>(body = {}) {
  return $api<T>(withGlaxy('/customer/getById'), {
    method: 'post',
    body: body,
  })
}

// 获取用户余额，因为后台刷新可能没完成，所以查询可能返回失败，需要尝试3次
export function getBalance<T = BaseResponseType<any>>(body = {}) {
  return $api<T>(withGlaxy('/customer/getBalanceV2'), {
    method: 'post',
    body,
  })
}

// 调用查询余额接口前，需要手动通知后端刷新余额。
export function refreshBalance<T = BaseResponseType<any>>(body = {}) {
  return $api<T>(withGlaxy('/customer/refreshBalance'), {
    method: 'post',
    body,
  })
}

interface CheckBindPayload {
  type: LoginFromTypeEnum // 0 facebook 1 google
  unionId: any // 三方授权后的id
  externalToken: string // 写死为空
  ticket: string // 滑块验证码
  nickName: string // 三方返回的昵称
  style: number // 写死为3
}

// 三方登录接口
export function checkBindV4<T = BaseResponseType<any>>(body: CheckBindPayload) {
  return $api<T>(withGlaxy('/auth/checkBindV4'), {
    method: 'post',
    body,
  })
}

// maya三方登录接口
export function mayaCheckBindV4<T = BaseResponseType<any>>(body: {
  type: LoginFromTypeEnum
  sessionId: string
  reference: string
  forceLogin: boolean
}) {
  return $api<T>(withGlaxy('/maya/checkBindV4'), {
    method: 'POST',
    body,
    withGlobal: false, // 去除全局 loginName和customerId, 如果去掉或设置true,接口会报错
    original: true,
  })
}

// 三方绑定注册接口
export function registerV2<T = BaseResponseType<any>>(body: {
  type: string | number
  unionId: string
  style: number
  nickName: string
  reference: string
  ticket: string
}) {
  return $api<T>(withGlaxy('/userAuth/registerV2'), {
    method: 'post',
    body,
    withGlobal: false,
  })
}

// 修改个人信息
export function modifyProfile<T = any>(body = {}) {
  return $api<T>(withGlaxy('/customer/modify'), {
    method: 'post',
    body,
  })
}

export enum MaskResultEnum {
  Success = 0,
  MaskVerifyFailed = 1,
  InvalidToken = 2,
  Maximum = 3,
}

interface verifyMaskResp {
  loseTryTimes: number //还可以尝试的次数,token错误不减少该次数
  failReason: MaskResultEnum // //failReason 错误原因 0无错误,1 mask错误 2 token超时或TOKEN错误 3到达最大次数
}

// 高风险用户掩码校验
export function verifyPhoneMask<T = BaseResponseType<verifyMaskResp>>(body: {
  customerId: string // 用户ID
  token: string // 登录接口所返回的临时token
  mask: string // 将要验证手机号的中间4位
}) {
  return $api<T>(withGlaxy('/userAuth/verifyPhoneMask'), {
    method: 'post',
    body,
    showToast: false,
  })
}

/**
 * 校验是否需要滑块
 */
export function isNeedCapcha<
  T = BaseResponseType<{
    frequency: boolean //为true则不需要滑块，使用data
    ignoreTicket: string // 不需要滑块认证的情况下， 使用ignoreTicket 代理滑块的ticket
  }>
>(body = {}) {
  return $api<T>(withGlaxy('/valid/check'), {
    method: 'post',
    body,
    withGlobal: false,
  })
}

export interface FullyRegisterRq {
  /** 手持证件照片 */
  faceId: string
  /** 证件类型 */
  firstIdType: string
  /** 证件号码 */
  firstIdNo?: string
  /** 证件照片 */
  firstIdScan: string
  activate: number
  reserve3?: string
  firstName: string
  middleName: string
  lastName: string
  birthday: string
  customerName?: string
  password?: string
  phone: string
  smsCode: string
  /** 当前居住地 */
  address: string
  nationality: string
  sourceOfIncome: string
  occupation: string
  /** 雇主名字 */
  reserve2: string
  /** 出生地 */
  province: string
  /** 永久居住地 */
  reserve4: string
  /** 推荐人 */
  reference: string
}

/**
 * 01 忘记密码找回，发送短信验证码
 * type =3
 * mobileNo 手机号，需要去掉首位 0
 * ticket 滑块验证ticket
 */
export function resetSendCode<
  T = BaseResponseType<{
    loginName: string //为true则不需要滑块，使用data
  }>
>(body: { mobileNo: string; type: number; ticket: string }) {
  return $api<T>(withGlaxy('/userAuth/sendCodeByForgetPwdV2'), {
    method: 'post',
    body,
    withGlobal: false,
  })
}
/**
 * 02 忘记密码找回，验证短信验证码
 * type = 1
 * captcha 短信验证码
 * customerName 用户登录名
 */
export function resetVerifyCode<T = BaseResponseType<any>>(body: {
  captcha: string
  type: number
  customerName: string
}) {
  return $api<T>(withGlaxy('/userAuth/otpCaptchaForForgetPwdV2'), {
    method: 'post',
    body,
    withGlobal: false,
  })
}

export interface ModifyPwdPayload {
  oldPassword: string // 新密码
  newPassword: string // 重复新密码
  loginName: string // 用户登录名，由之前接口返回
  struts: number // 固定值 1
  smsCode: string // 短信验证码
  type: number // 固定值 5
}

/**
 * 03 忘记密码找回，重置密码
 */
export function resetModifyPassword<T = BaseResponseType<any>>(body: ModifyPwdPayload) {
  return $api<T>(withGlaxy('/userAuth/modifyPwdForgetPwdV2'), {
    method: 'post',
    body,
    withGlobal: false,
  })
}
