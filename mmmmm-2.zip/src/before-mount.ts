export const setupSiteInfo = async () => {
  const siteInfoStore = useSiteInfoStore()

  if (siteInfoStore.value.isFetched) return
  const { success, body } = await fetchSiteInfo()
  if (success) {
    siteInfoStore.value = body || {}
    siteInfoStore.value.isFetched = true
  } else {
    siteInfoStore.value.isFetched = false
  }
}

export const setClientBeforeInit = () => {
  useAppClientState(AppClientEnum.H5)
}

export const setupWebToken = async () => {
  const webTokenStore = useWebTokenStore()
  const { success, body, message } = await fetctWebToken()
  console.log({ success, body, message })
  if (success && body) {
    webTokenStore.value = body
  } else {
    window.location.href = '/hello.js'
  }
}
