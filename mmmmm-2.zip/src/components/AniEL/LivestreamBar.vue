<template>
  <div class=" tw-flex tw-flex-row tw-items-center tw-justify-center tw-bg-[#fd0403] tw-rounded tw-overflow-hidden"  :class="{'!tw-w-[1.5rem] !tw-h-[1.5rem] tw-bg-[rgba(255,255,255,0.1)] tw-rounded-[50%] tw-border tw-border-[#5E244D]':isPokerPage}">
    <div class="bar-container tw-px-[3px] tw-space-x-[2px]" :class="{'other_color ':isPokerPage}">
      <div class="bar"></div>
      <div class="bar"></div>
      <div class="bar"></div>
    </div>
    <div class="tw-bg-[#989d9d] tw-text-white tw-text-[10px] tw-px-1" v-if="!isPokerPage">LIVE</div>
  </div>
</template>

<script setup lang="ts">
const route = useRoute()
// 判断是否是poker页
const isPokerPage = computed(() => {
  return route.name === '/tongits' || route.path === '/tongits'
})
</script>

<style lang="scss" scoped>
.bar-container {
  display: flex;
  align-items: flex-end;
  height: 10px;
}

.bar {
  width: 2px;
  height: 100%;
  background-color:  #ffffff;
  animation: bounce 1s ease-in-out infinite;
  border-radius: 5px;
}
.other_color{
  .bar{
    background-color:  #00FF4D;
  }
}
.bar:nth-child(1) {
  animation-delay: 0s;
}

.bar:nth-child(2) {
  animation-delay: 0.2s;
}

.bar:nth-child(3) {
  animation-delay: 0.4s;
}

@keyframes bounce {
  0%,
  100% {
    height: 20%;
  }
  50% {
    height: 80%;
  }
}
</style>
