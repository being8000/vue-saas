<template>
  <!-- :style="{ left: position.x + 'px', top: position.y + 'px' }" -->
  <div
    ref="refDraggable"
    class="draggable"
    :style="{ transform: `translate(${position.x}px, ${position.y}px)` }"
  >
    <slot></slot>
  </div>
</template>

<script lang="ts" setup>
interface Position {
  x: number
  y: number
}
const position = defineModel({
  default: {
    x: 0,
    y: 0,
  },
})
const isClick = ref(false)
const refDraggable = ref<HTMLElement>()
const initPosition = position.value
const prop = defineProps<{
  width: number
  height: number
  margin?: number
}>()

const emits = defineEmits(['resize', 'dragEnd', 'click', 'update:isDraging', 'dragStart'])
// const position = ref<Position>({
//   x: 0,
//   y: 0
// })
// watchEffect(() => {
//   model.value = position.value
// })
let isDragging = ref(false)
let startX = 0
let startY = 0
const draggableWidth = prop.width // 组件宽度
const draggableHeight = prop.height // 组件高度
const onClick = () => {
  emits('click')
}
const onMouseDown = (event: MouseEvent) => {
  event.preventDefault()
  window.addEventListener('mousemove', onMouseMove)
  window.addEventListener('mouseup', onMouseUp)
  isClick.value = true

  startDrag(event.clientX, event.clientY)
}
let clickTimer: any = null
let t = 0
const onTouchStart = (event: TouchEvent) => {
  event.preventDefault()
  const touch = event.touches[0]
  window.addEventListener('touchmove', onTouchMove)
  window.addEventListener('touchend', onTouchEnd)
  startDrag(touch.clientX, touch.clientY)
}

const startDrag = (clientX: number, clientY: number) => {
  startX = clientX - position.value.x
  startY = clientY - position.value.y
  t = new Date().getTime()
  emits('dragStart')
  emits('update:isDraging', true)
  refDraggable.value?.classList.remove('tw-transition-all')
  // document.querySelector('html')?.classList.add('tw-overflow-hidden')
}
const onMouseMove = (event: MouseEvent) => {
  clearTimeout(clickTimer)
  isDragging.value = true
  isClick.value = false
  position.value = {
    x: event.clientX - startX,
    y: event.clientY - startY,
  }
    // 限制上下边界
    const windowHeight = window.innerHeight
    // position.value.y = Math.max(0, Math.min(position.value.y, windowHeight - draggableHeight))
}

const onTouchMove = (event: TouchEvent) => {

  isDragging.value = true
  const touch = event.touches[0]
  // position.value.x = touch.clientX - startX
  // position.value.y = touch.clientY - startY
  position.value = {
    x: touch.clientX - startX,
    y: touch.clientY - startY,
  }
}

const throttleMouceMove = useThrottleFn(onMouseMove, 10)
const throttleTouchMove = useThrottleFn(onTouchMove, 10)
const onMouseUp = () => {
  window.removeEventListener('mousemove', onMouseMove)
  window.removeEventListener('mouseup', onMouseUp)
  endDrag()
}

const onTouchEnd = () => {
  window.removeEventListener('touchmove', onTouchMove)
  window.removeEventListener('touchend', onTouchEnd)
  endDrag()
}
const emitDebounceClick = useDebounceFn(onClick, 150, {
  maxWait: 5000
})
const endDrag = () => {
  const time = new Date().getTime()
  if(time - t <= 150) {
    emitDebounceClick()
  }
  isDragging.value = false
  emits('update:isDraging', false)
  smoothToPercentage()
  refDraggable.value?.classList.add('tw-transition-all')
  // document.querySelector('html')?.classList.remove('tw-overflow-hidden')
}

const smoothToPercentage = () => {
  const margin = prop.margin || 0
  const windowWidth = window.innerWidth - margin
  const windowHeight = window.innerHeight
  const centerX = windowWidth / 2
  // 计算当前位置与中心的距离百分比
  const distanceFromCenterX =
    ((position.value.x + draggableWidth / 2 - centerX) / (windowWidth / 2)) * draggableWidth

  // 计算目标位置
  let targetX = distanceFromCenterX < 0 ? margin : windowWidth - draggableWidth // 组件宽度
  let targetY = Math.max(margin, Math.min(position.value.y, windowHeight - draggableHeight)) // 保持原来的y位置

  // 确保目标位置不超出屏幕
  targetX = Math.max(margin, Math.min(targetX, windowWidth - draggableWidth))
  animateTo(targetX, targetY)
  emits('dragEnd', {
    x: targetX,
    y: targetY,
  })
}

const animateTo = (targetX: number, targetY: number) => {
  position.value.x = targetX // 确保最终位置准确
  position.value.y = targetY // 确保最终位置准确
  // const duration = 300 // 动画时长
  // const startX = position.value.x
  // const startY = position.value.y
  // const changeX = targetX - startX
  // const changeY = targetY - startY
  // const increment = 20 // 动画步进
  // let currentTime = 0

  // const animate = () => {
  //   currentTime += increment
  //   const t = currentTime / duration
  //   const newX = easeInOutCubic(t) * changeX + startX
  //   const newY = easeInOutCubic(t) * changeY + startY

  //   // position.value.x = newX
  //   // position.value.y = newY
  //   position.value = {
  //     x: newX,
  //     y: newY,
  //   }
  //   if (currentTime < duration) {
  //     requestAnimationFrame(animate)
  //   } else {
  //     // position.value.x = targetX // 确保最终位置准确
  //     // position.value.y = targetY // 确保最终位置准确
  //     position.value = {
  //       x: targetX,
  //       y: targetY,
  //     }
  //   }
  // }

  // animate()
}

const easeInOutCubic = (t: number) => {
  return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2
}
// 处理屏幕旋转
const handleResize = () => {
  // smoothToPercentage()
  emits('resize')
  // const windowWidth = window.innerWidth
  // const windowHeight = window.innerHeight
  // const centerX = windowWidth / 2

  // // 重新计算组件的位置
  // const distanceFromCenterX = ((position.value.x - centerX) / (windowWidth / 2)) * 100

  // let targetX = distanceFromCenterX < 0 ? 0 : windowWidth - draggableWidth
  // let targetY = Math.max(0, Math.min(position.value.y, windowHeight - draggableHeight)) // 保持原来的y位置

  // // 确保目标位置不超出屏幕
  // targetX = Math.max(0, Math.min(targetX, windowWidth - draggableWidth))

  // animateTo(targetX, targetY)
}

onMounted(() => {
  refDraggable.value?.addEventListener('touchstart', onTouchStart)
  refDraggable.value?.addEventListener('mousedown', onMouseDown)
  window.addEventListener('resize', handleResize)
})

onBeforeUnmount(() => {
  window.removeEventListener('resize', handleResize)
})
</script>

<style scoped>
.draggable {
  width: max-content;
  position: fixed;
  cursor: pointer;
  user-select: none;
  z-index: 1000;
  left: 0px;
  top: 0px;
  will-change: transform;
  /* transition: transform 0.15s; */
}
</style>
