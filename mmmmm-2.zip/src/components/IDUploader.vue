<template>
  <section
    class="custom-uploader-container"
    :class="{
      error: error,
    }"
  >
    <label
      :for="id"
      class="tw-py-8 tw-bg-[rgb(var(--v-theme-surface))] tw-rounded-lg tw-relative tw-flex tw-items-center tw-justify-center"
    >
      <div class="tw-absolute tw-w-full tw-h-full tw-flex tw-items-center tw-justify-center">
        <img v-if="blob" :src="blob" class="tw-object-contain tw-w-full tw-h-full" alt="" />
        <CameraSvg v-else></CameraSvg>
      </div>
      <div
        :style="{
          visibility: blob ? 'hidden' : 'initial',
        }"
      >
        <IDSvg v-if="type == 'ID'"></IDSvg>
        <SelfieSvg v-else></SelfieSvg>
      </div>
      <!-- <SelfieSvg></SelfieSvg> -->
      <input
        v-bind="{
          name,
          accept,
          placeholder,
        }"
        type="file"
        :id="id"
        ref="file"
        :multiple="false"
        @change="onFileChanged"
      />
    </label>
    <div class="error-message">
      {{ errorMessage || 'Please upload' }}
    </div>
  </section>
</template>

<script setup lang="ts">
import IDSvg from '@images/svg/upload-ID.svg'
import SelfieSvg from '@images/svg/upload-selfie.svg'
import CameraSvg from '@images/svg/camera.svg'
type UploadType = 'ID' | 'Selfie'
const props = withDefaults(
  defineProps<{
    type?: UploadType
    limit?: number
    name?: string
    accept?: string
    placeholder?: string
    errorMessage?: string
  }>(),
  {
    type: 'ID',
    limit: 999,
    accept: 'image/*',
    placeholder: '',
  }
)
const blob = ref('')
const fileCache = ref<File>()
const error = ref<boolean>(false)
const fileTypes = [
  'image/apng',
  'image/bmp',
  'image/gif',
  'image/jpeg',
  'image/pjpeg',
  'image/png',
  'image/svg+xml',
  'image/tiff',
  'image/webp',
  'image/x-icon',
]
function validFileType(file: File) {
  return fileTypes.includes(file.type)
}
const id = 'component-' + _Random(10 ** 15)

const onFileChanged = (e: any) => {
  // Check if file is selected
  if (e.target.files && e.target.files[0]) {
    // Get uploaded file
    const file = e.target.files[0]
    if (validFileType(file)) {
      blob.value = URL.createObjectURL(file)
      fileCache.value = file
      error.value = false
    } else {
      alert('File type invalid! Please upload png/jpg/jpeg file')
    }
  } else {
    alert('Upload Failed!')
  }
}
const check = () => {
  if (!fileCache.value) {
    error.value = true
    return false
  } else {
    error.value = false
    return true
  }
}
defineExpose({
  check,
  async upload() {
    if (!check()) {
      return
    }
    try {
      // 上传ID照片
      if (props.type == 'ID') {
        const formData = new FormData()
        formData.append('base64FaceImg', fileCache.value!)
        const { data } = await uploadID(formData)
        const { success, body } = data.value
        if (success) {
          return body.imageKey
        } else {
          return false
        }
      } else if (props.type == 'Selfie') {
        // 上传人脸图，这里实际是假上传，该字段没有用到
        const { success, body } = await uploadSelfie({
          base64FaceImg: fileCache.value,
        })
        if (success) {
          return body
        } else {
          return false
        }
      } else {
        return false
      }
    } catch (err) {
      return false
    }
  },
})
</script>

<style lang="scss" scoped>
.custom-uploader-container {
  margin: 2px auto;

  input {
    display: none;
  }

  label {
    box-shadow: rgba(0, 0, 0, 0.05) 0px 0px 0px 1px, rgb(31, 32, 34) 0px 0px 0px 1px inset;
  }

  .error-message {
    visibility: hidden;
    height: 12px;
    line-height: 12px;
    word-break: break-word;
    overflow-wrap: break-word;
    word-wrap: break-word;
    -webkit-hyphens: auto;
    hyphens: auto;
    transition-duration: 150ms;
    color: rgb(var(--v-theme-error));
    font-size: 12px;
    padding: 1px 10px;
    margin-top: 2px;
  }

  &.error {
    .error-message {
      visibility: initial;
    }

    label {
      border: 1px solid rgb(var(--v-theme-error));
    }
  }
}
</style>
