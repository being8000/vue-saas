<script lang="ts" setup>
import { capitalize } from 'vue';

interface Emit {
  (e: 'click:confirm'): void
  (e: 'click:cancel'): void
  (e: 'cancel'): void
}
const emit = defineEmits<Emit>()

const model = defineModel<boolean>({ default: false })
watch(model, () => {
  if (!model.value) {
    emit('cancel')
  }
})
const onConfirmClick = () => {
  model.value = false
  emit('click:confirm')
}

const router = useRouter()
const onCancelClick = () => {
  emit('click:cancel')
  emit('cancel')
  router.back()
  window.open('', '_self', '')
  window.close()
}

const { payload, $copy } = useNuxtApp()
const { logger } = useLogger()

const parseApiKey2Url = (key: string) => {
  const str = parseApiKey(key);
  const regxMatch = /(?<url>.+)\$\$(?<body>.+)\$\$(?<params>.+)/ig.exec(str)
  return regxMatch?.groups?.url
}
const parseApiKey2Body = (key: string) => {
  const str = parseApiKey(key);
  const regxMatch = /(?<url>.+)\$\$(?<body>.+)\$\$(?<params>.+)/ig.exec(str)
  return regxMatch?.groups?.body
}
const parseApiKey2Params = (key: string) => {
  const str = parseApiKey(key);
  const regxMatch = /(?<url>.+)\$\$(?<body>.+)\$\$(?<params>.+)/ig.exec(str)
  return regxMatch?.groups?.params
}

const onApiParseClick = (key: string) => {
  logger.logNet(parseApiKey2Url(key), `Api Url`)
  logger.logNet(parseApiKey2Body(key), `Api Body`)
  logger.logNet(parseApiKey2Params(key), `Api Params`)
  logger.logNet(payload.data[key], `Api Response`)
  return $copy(JSON.stringify(payload.data[key]))
}

const onLocalParseClick = (key: string) => {
  let result: any = null
  const v = StorageKey[key as keyof typeof StorageKey]
  result = useCookie(capitalize(v), {
    readonly: true
  }).value
  if (result) {
    logger.logModel(result, `cookie ${v}:`)
    return $copy(result)
  }
  result = localStorageRef(v, null).value
  if (result !== null) {
    logger.logModel(result, `local ${v}:`)
    return $copy(result)
  }
  result = sessionStorage.getItem(namespaceConfig(key))
  if (result !== null) {
    for (let k in StorageSerializers) {
      const serializer = StorageSerializers[k as keyof typeof StorageSerializers]
      try {
        logger.logModel(serializer.read(result), `session ${v}:`)
        return $copy(result)
      } catch (error) {
        continue
      }
    }
  }
  result = useState(v).value
  if (result !== null) {
    logger.logModel(result, `state ${v}:`,)
    return $copy(result)
  }
  logger.logModel('no data')
}
</script>

<template>
  <div class="tw-fixed tw-z-50 tw-left-1/2 tw-top-1/2 -tw-translate-x-1/2 -tw-translate-y-1/2">
    <div class="tw-absolute tw-left-1/2 tw-top-0 -tw-translate-x-1/2 -tw-translate-y-1/2 tw-transition-all tw-rounded-full tw-bg-[linear-gradient(45deg,#00dc82,#00dc82,#00dc82)] tw-blur-[3.75rem] tw-size-[10rem] tw-z-[-1]"></div>
    <div class="tw-bg-white  tw-rounded-full tw-font-bold tw-capitalize tw-text-xs tw-h-[1.875rem] tw-text-black tw-flex tw-items-center tw-justify-center tw-px-2 tw-min-w-[7.1875rem] tw-cursor-pointer" @click="model = true">
      debug
    </div>
  </div>
  <VDialog v-model="model" v-bind="$attrs" maxWidth="390" class="!tw-items-end" contentClass="!tw-m-0 !tw-w-full">
    <template v-slot:activator="scope">
      <slot v-bind="scope"></slot>
    </template>
    <template #default>
      <LazyCardWidgetDialog>
        <LazyCardWidgetDialogTitle title="Parser"/>
        <div class="tw-min-h-[18.75rem] tw-max-h-[31.25rem] tw-overflow-y-auto tw-p-3 tw-text-white">
          <h2 class="tw-font-bold tw-my-3 tw-text-base tw-border-b tw-border-dashed">API</h2>
          <div v-for="key in Object.keys(payload.data)" :key="key" class="tw-flex tw-flex-col tw-gap-1">
            <div class="tw-font-semibold">Url: {{ parseApiKey2Url(key) }}</div>
            <div class="tw-font-semibold">Body: {{ parseApiKey2Body(key) }}</div>
            <div class="tw-font-semibold">Params: {{ parseApiKey2Params(key) }}</div>
            <VBtn color="surface-light-4" size="x-small" @click="onApiParseClick(key)">控制台打印</VBtn>
          </div>
          <h2 class="tw-font-bold tw-my-3 tw-text-base tw-border-b tw-border-dashed">STORAGE</h2>
          <div v-for="key in Object.keys(StorageKey)" :key="key" class="tw-flex tw-flex-col tw-gap-3">
            <span class="tw-font-semibold">{{ key }}</span>
            <VBtn color="surface-light-4" size="x-small" @click="onLocalParseClick(key)">控制台打印</VBtn>
          </div>
        </div>
      </LazyCardWidgetDialog>
    </template>
  </VDialog>
</template>
