<script lang="ts" setup>
import { HolidayTheme } from '@/composables/useSiteInfoStore'

interface Props {
  /** 有效主题 默认全部生效 */
  themes?: HolidayTheme[]
}

withDefaults(defineProps<Props>(), {
  themes: () => {
    return Object.values(HolidayTheme)
  }
})

const siteInfo = useSiteInfoStore()
const themeValues = Object.values(HolidayTheme)
const theme = computed(() => {
  const theme = String(siteInfo.value.HOLIDAY_THEME_SWITCH) as HolidayTheme || HolidayTheme.Normal
  if (!themeValues.includes(theme)) {
    return HolidayTheme.Normal
  }
  return theme
})

const slots = defineSlots<{
  default(): any
  halloween?(): any
  christmas?(): any
}>()
</script>

<template>
  <!-- ANCHOR 默认主题 -->
  <slot v-if="HolidayTheme.Normal === theme && themes.includes(HolidayTheme.Normal)" name="default"></slot>
  <!-- ANCHOR 万圣节主题 -->
  <slot v-else-if="HolidayTheme.Halloween === theme && slots.halloween && themes.includes(HolidayTheme.Halloween)"
    name="halloween"></slot>
  <!-- ANCHOR 圣诞节主题 -->
  <slot v-else-if="HolidayTheme.Christmas === theme && slots.christmas && themes.includes(HolidayTheme.Christmas)"
    name="christmas"></slot>
  <!-- ANCHOR 默认主题 -->
  <slot v-else-if="themes.includes(theme)" name="default"></slot>
</template>
