<script lang="ts" setup>
import { isVideoUrl, getVideoType } from '@/util/index'

const LazyVideoPlayer = defineAsyncComponent(async () => {
  await asyncModule.VideoJs()
  return import('./VideoPlayer.vue')
})
interface Props {
  src?: string
  aspectRatio?: number
  cover?: boolean
  pointer?: 'none' | 'auto'
}

withDefaults(defineProps<Props>(), {
  cover: true,
})
</script>

<template>
  <VResponsive v-if="isVideoUrl(src)" :aspectRatio="aspectRatio">
    <LazyVideoPlayer
      :cover="cover"
      :options="{
            autoplay: 'muted',
            controls: false,
            playsinline: true,
            fluid: true,
            loop: true,
            sources: [
                {
                    type: getVideoType(src),
                    src: src!
                }
            ],
            fit: cover ? 'cover' : 'contain',
            pointer
        }"
    />
  </VResponsive>
  <VImg
    v-else
    :cover="cover"
    class="tw-rounded-xl"
    :lazySrc="src"
    :src="src"
    :aspectRatio="aspectRatio"
  />
</template>
