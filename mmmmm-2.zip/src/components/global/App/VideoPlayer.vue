<script lang="ts" setup>
import type videojs from 'video.js/dist/alt/video.core.novtt';
interface Props {
  options?: videojs.PlayerOptions & {
    fit: 'cover' | 'contain'
    pointer?: 'none' | 'auto'
  }
}

const props = withDefaults(defineProps<Props>(), {})

const videoPlayer = ref<Element>()

let player: videojs.Player
const isIntersecting = ref(false)
const init = async () => {
  const videojs = await asyncModule.VideoJs()
  player = videojs(videoPlayer.value!, props.options, function (this: videojs.Player) {
    if (!isIntersecting.value) {
      this.autoplay(false)
      this.pause()
    }
  })
}
init()

onUnmounted(() => {
  player?.dispose()
})

watch(
  () => props.options?.sources,
  (sources) => {
    if (sources) {
      player?.src(sources)
    }
  }
)

const pauseVideoIfNeeded = () => {
  if (!props.options?.autoplay) {
    return
  }
  if (isIntersecting.value && player && player.paused()) {
    player.muted(true)
    player?.play()?.catch(() => {
      player?.autoplay('muted')
    })
  } else {
    player?.pause()
  }
}

const onIntersect = (_isIntersecting: boolean) => {
  isIntersecting.value = _isIntersecting
  pauseVideoIfNeeded()
}
// const assetURL = "xxx.MP4";
// const mimeCodec = 'video/mp4; codecs="mp4a.40.2,avc1.64002a"';

// const supportMediaSource =
//   window.MediaSource &&
//   typeof window.MediaSource.isTypeSupported === "function" &&
//   window.MediaSource.isTypeSupported(mimeCodec)

// const mediaSource = new MediaSource()
// video.src = URL.createObjectURL(mediaSource);

// mediaSource.addEventListener("sourceopen", function () {
//     const sourceBuffer = mediaSource.addSourceBuffer(mimeCodec)
//     fetchBuffer(assetURL, (buffer) => {
//         sourceBuffer.addEventListener("updateend", function (_) {
//             if (!sourceBuffer.updating && mediaSource.readyState === "open") {
//                 mediaSource.endOfStream()
//                 // video.play()
//             }
//         })
//         sourceBuffer.appendBuffer(buffer)
//     })
// })

// function fetchBuffer(url: string, callback: (response: any) => void) {
//     const xhr = new XMLHttpRequest()
//     xhr.open("get", url)
//     xhr.responseType = "arraybuffer"
//     xhr.onload = function () {
//         callback(xhr.response)
//     }
//     xhr.send()
// }
</script>

<template>
  <div class="tw-size-full" v-intersect="onIntersect">
    <video
      ref="videoPlayer"
      class="mediabrowser video-js vjs-theme-city tw-pointer-events-none"
      :class="{
        'mediabrowser-fit--cover': options?.fit === 'cover',
        'mediabrowser-pointer--none': options?.pointer === 'none',
      }"
    ></video>
  </div>
</template>

<style lang="scss">
@import 'video.js/dist/video-js.min.css';

.mediabrowser {
  position: relative;

  &.mediabrowser-fit--cover.video-js .vjs-tech {
    object-fit: cover;
  }

  &.mediabrowser-pointer--none.video-js .vjs-tech {
    pointer-events: none;
  }

  &.video-js.vjs-fluid:not(.vjs-audio-only-mode) {
    height: 100%;
    padding-top: 0;
  }
}
</style>
