<script lang="ts" setup>
import { GameBaseItem } from '@/api/game'
import { isEmpty } from 'lodash-es'
import { isAfter, isBefore, parse } from 'date-fns'
import { Provider } from '@/composables/useBlock'
const { findProviderById } = useBlock()

interface Props {
  loading?: boolean
  game?: GameBaseItem
  spider?: boolean
  replace?: boolean
  aspectRatio?: number
  imgAspectRatio?: number
  bottomAspectRatio?: number
  gameBoxClass?: string
}

const props = withDefaults(defineProps<Props>(), {
  loading: false,
  game: () => {
    return {} as any
  },
  spider: false,
  aspectRatio: 114 / 142,
  imgAspectRatio: 1,
  bottomAspectRatio: 114 / 26,
})
// const { appEventBus } = useApp()
const { liked: likeGame, unLiked, has: hasLiked } = useFavoriteGame()
const el = ref(null)
const { width } = useElementSize(el)
const showWidgets = computed(() => {
  return width.value > 0
})

const userStore = useUserStore(true)
const isLogin = computed(() => {
  return userStore && userStore.value && userStore.value.isLogin
})
const showLike = computed(() => {
  return showWidgets.value && isLogin.value
})

const calcLikedInitValue = () => {
  return props.game.isFavorite === 1 || hasLiked(props.game.gameId)
}

const liked = ref(calcLikedInitValue())

watch(
  () => props.game.isFavorite,
  (value: number) => {
    if (value === 1) {
      liked.value = true
    } else {
      liked.value = false
    }
  }
)

watchEffect(() => {
  liked.value = hasLiked(props.game.gameId)
})

const tag = computed(() => {
  if (props.game.newFlag === 1) {
    return '/images/home/new.png'
  } else if (props.game.hotFlag === 1) {
    // return customWidgetHot
    return '/images/home/hot.png'
  }
  return ''
})

const router = useRouter()
const inGameLoading = ref(false)
const gameStore = useGameStore()

onUnmounted(() => {
  inGameLoading.value = false
  gameStore.value.locked = false
})

const onGameItemClick = async () => {
  console.log(props.game, 'props.game')
  // appEventBus.emit('onGameChange', props.game)
  if (isEmpty(props.game)) {
    return
  }
  if (gameStore.value.locked) {
    return
  }
  const { gameId, gdGameId, platformId } = props.game

  gameStore.value.locked = true
  inGameLoading.value = true
  if (props.replace) {
    const { platformId, gameId } = props.game
    await router.replace({ name: 'game-id', params: { platformId: platformId, gameId: gameId } })
  } else {
    await router.push({ name: 'game-id', params: { platformId: platformId, gameId: gameId } })
  }
  inGameLoading.value = false
  gameStore.value.locked = false
}

const isOtherMaintenance = computed(() => {
  return props.game.flag === 2 || props.game.platformStatus !== 1
})

const isTimeMaintenance = computed(() => {
  const current = +new Date()
  const start = +new Date(props.game.maintainStartTime)
  const end = +new Date(props.game.maintainEndTime)
  return props.game.flag === 1 && current >= start && current <= end
})

// 固定游戏每日定时维护
const isDayTimeMaintenance = computed<boolean>(() => {
  const start = props.game.scheduleStartTime
  const end = props.game.scheduleEndTime
  if (!start || !end) return false
  const currentTime = new Date()
  const startTime = parse(start, 'HH:mm:ss', new Date())
  const endTime = parse(end, 'HH:mm:ss', new Date())
  return isAfter(currentTime, startTime) && isBefore(currentTime, endTime)
})

const isMaintenance = computed(() => {
  return isOtherMaintenance.value || isTimeMaintenance.value || isDayTimeMaintenance.value
})

const maintenanceEndTime = computed(() => {
  const time = +new Date(props.game.maintainEndTime)
  return Number.isNaN(time) ? 0 : time
})

const onLikeClick = async () => {
  liked.value = !liked.value
  if (liked.value) {
    const isSuccess = await likeGame(props.game)
    liked.value = isSuccess
  } else {
    unLiked(props.game)
  }
}

const gameName = computed(() => {
  return props.game.nameEn || props.game.nameZh || ''
})

// NOTE 暂时不删除，需求频繁替换
// const route = useRoute()

const { isEnabled } = useDisableProviderLabels()
const showProvider = computed(() => {
  return isEnabled(props.game.platformId)
})

const isIntersecting = ref(true)
const onIntersect = (_isIntersecting: boolean) => {
  isIntersecting.value = _isIntersecting
}
const gameImg = computed(() => {
  return props.game?.gameImageBig || props.game?.gameImage
})
</script>

<template>
  <div
    ref="el"
    :data-gtp-ext="
      JSON.stringify({
        gameId: game.gameId,
        platformId: game.platformId,
        gameImageNew: game.gameImageNew,
        gameImage: game.gameImage,
        gdGameId: game.gdGameId,
        supplyId: game.platformId,
        cnick_name: game.nameEn,
        params: game.jsonParam,
      })
    "
    v-intersect="onIntersect"
    class="tw-relative tw-cursor-pointer tw-block"
    @click="onGameItemClick"
  >
    <v-responsive>
      <div class="tw-rounded-lg tw-overflow-hidden" :class="gameBoxClass">
        <v-responsive :aspectRatio="imgAspectRatio">
          <VImg
            cover
            class="!tw-w-full tw-object-cover tw-inline-block tw-align-top"
            :src="gameImg"
            :alt="gameName"
            :aspectRatio="imgAspectRatio"
          >
            <template v-slot:placeholder>
              <div
                class="d-flex align-center justify-center fill-height tw-bg-[length:100%_auto] tw-bg-[url('/images/home/gamea_utoimg.webp')]"
              ></div>
            </template>
          </VImg>
          <!-- ANCHOR 维护状态 -->
          <GlobalCardGameMaintenance
            v-if="isMaintenance"
            :maintenanceEndTime="maintenanceEndTime"
            :isTimeMaintenance="isTimeMaintenance"
            :maintenanceDayEndTime="game.scheduleEndTime"
            :isDayTimeMaintenance="isDayTimeMaintenance"
            :width="width"
          ></GlobalCardGameMaintenance>
        </v-responsive>
        <v-responsive :aspectRatio="bottomAspectRatio" class="tw-bg-white">
          <div class="tw-px-1 tw-flex tw-justify-between tw-h-full tw-items-center">
            <span
              class="tw-text-[12px] tw-font-bold tw-flex-1 tw-overflow-hidden tw-whitespace-nowrap tw-overflow-ellipsis"
            >
              {{ gameName }}
            </span>
            <!-- ANCHOR 收藏按钮 -->
            <div v-if="showLike" class="tw-size-5" @click.stop="onLikeClick">
              <img v-if="liked" src="@/assets/images/home/heart2.png" />
              <img v-else src="@/assets/images/home/heart.png" />
            </div>
          </div>
        </v-responsive>
      </div>
    </v-responsive>

    <!-- <img v-if="showProvider" class=" tw-absolute tw-top-0 tw-left-0 tw-bottom-0 tw-z-10" :src="gameBgkuang"/> -->
    <!-- <img v-else class=" tw-absolute tw-top-0 tw-left-0 tw-z-10" :src="gameSubtract"/> -->
    <template v-if="true">
      <!-- FIXME 有概率将文本变模糊，滚动后恢复 -->
      <!-- <div v-if="showProvider" class="tw-absolute tw-top-0 !tw-z-0 tw-w-full tw-h-[23%] tw-overflow-hidden"
        @click="onGameItemClick">
        <img class="!tw-absolute !tw-inset-0 !tw-size-full" :src="customWidgetTitle" />
      </div> -->

      <!-- ANCHOR 热门或新游戏图标 -->
      <img
        v-if="tag"
        class="!tw-absolute !tw-inset-auto !tw-left-[-9px] !tw-top-2 !tw-z-10 tw-w-[56px] tw-h-[28px]"
        :src="tag"
      />

      <!-- ANCHOR 进入游戏前的loading -->
      <div
        v-if="inGameLoading"
        class="tw-bg-[rgba(0,0,0,0.1)] tw-size-full tw-absolute tw-z-[51] tw-inset-0 tw-flex tw-flex-col tw-items-center tw-justify-center text-primary"
      >
        <VIcon
          :style="{
            fontSize: `${width / 0.3}%`,
          }"
          icon="custom-loading2"
        />
      </div>
    </template>
  </div>
</template>
