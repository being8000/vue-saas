<template>
  <div
    class="tw-text-[#D6D6D6] tw-bg-[rgba(0,0,0,0.8)] tw-absolute tw-z-50 -tw-left-px -tw-top-px -tw-right-px -tw-bottom-px tw-p-px tw-flex tw-flex-col tw-items-center tw-justify-center tw-rounded-lg"
    @click.prevent="() => {}"
  >
    <VIcon
      :style="{
        fontSize: `${width / 0.57}%`,
      }"
      icon="custom-maintenance"
    />
    <span class="tw-text-center tw-leading-none tw-mt-2 tw-capitalize tw-font-bold">
      <template v-if="isTimeMaintenance || isDayTimeMaintenance">
        <div>
          <div
            class="tw-text-white"
            :style="{
              fontSize: `${width / 1.47}%`,
            }"
          >
            Maintenance Until
          </div>
          <div
            class="text-warning tw-mt-[3%]"
            :style="{
              fontSize: `${width / 1.47}%`,
            }"
          >
            <template v-if="isDayTimeMaintenance">
              {{ maintenanceDayEndTime }}
            </template>
            <template v-else>
              {{ $d(maintenanceEndTime, 'mdhm').replace(',', '') }}
            </template>
          </div>
        </div>
      </template>
      <template v-else>
        <div
          :style="{
            fontSize: `${width / 1.47}%`,
          }"
        >
          Under<br />Maintenance
        </div>
      </template>
    </span>
  </div>
</template>

<script setup lang="ts">
defineProps<{
  width: number
  isTimeMaintenance: boolean // 是否维护
  isDayTimeMaintenance: boolean // 是否每日维护

  maintenanceEndTime: number // 维护截至时间
  maintenanceDayEndTime: string // 每日维护截至时间
}>()
</script>

<style></style>
