<script lang="ts" setup>
import { GameBaseItem } from '@/api/game'
import LazyCardGameItem from '@/components/global/Card/GameItem.vue'
import LazyCardLoadMore from '@/components/global/Card/LoadMore.vue'
import { RouteLocationRaw } from 'vue-router'

interface Props {
  games?: GameBaseItem[]
  total?: number
  fake?: boolean
  fakeSize?: number
  column?: number
  extraClass?: any
  isHome?: boolean
  to?: RouteLocationRaw
}

interface Emit {
  (e: 'click:load'): void
}

const emit = defineEmits<Emit>()

const props = withDefaults(defineProps<Props>(), {
  games: () => [],
  total: 0,
  fake: false,
  fakeSize: 12,
  column: 0,
})

defineOptions({
  inheritAttrs: false,
})

const fakeCount = ref(props.games.length > props.fakeSize ? props.fakeSize : props.games.length)
const intersectCount = ref(0)
const count = computed(() => {
  if (props.fake) {
    return Math.min(intersectCount.value, fakeCount.value)
  }
  return props.games?.length
})

const loading = ref(true)

onMounted(() => {
  loading.value = false
})

const total = computed(() => {
  if (props.fake) {
    return props.games.length
  }
  return props.total
})

const curGames = computed(() => {
  if (props.fake) {
    return props.games.slice(0, count.value)
  }
  return props.games
})

const intersect = ref<HTMLElement>()
// let stopfsp: (() => void) | undefined
// onMounted(() => {
//   stopfsp = runfps(() => {
//     if (isElementInView(intersect.value)) {
//       intersectCount.value = Math.min(intersectCount.value + props.column, fakeCount.value)
//     }
//   })
// })
// onUnmounted(() => {
//   stopfsp?.()
// })

// const onLoadClick = () => {
//   if (count.value < total.value) {
//     if (props.fake) {
//       if (count.value + props.fakeSize <= total.value) {
//         fakeCount.value += props.fakeSize
//       } else {
//         fakeCount.value = total.value
//       }
//     }
//     emit('click:load')
//   }
// }
</script>

<template>
  <GlobalCardItemsBar :extraClass="extraClass" v-bind="$attrs" :to="to">
    <div
      class="tw-gap-x-[10px] tw-gap-y-2 tw-grid tw-grid-cols-3"
      :class="extraClass"
      :style="`grid-template-columns: repeat(${column}, 1fr);`"
    >
      <LazyCardGameItem
        v-for="game in curGames"
        :key="game.gameId"
        :game="game"
        :loading="loading"
      />
    </div>
    <div ref="intersect" class="tw-h-[1px]"></div>
    <!-- <template v-if="count">
      <div v-if="isHome" class="tw-text-center tw-w-full tw-mt-3">
      </div>

      <template v-else>
        <LazyCardLoadMore class="tw-my-5" :count="count" :total="total" @click="onLoadClick" />
      </template>
    </template> -->
  </GlobalCardItemsBar>
</template>
