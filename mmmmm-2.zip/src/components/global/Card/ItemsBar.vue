<script lang="ts" setup>
import RightSvg from '@/assets/images/svg/tab/right.svg'
import type { RouteLocationRaw } from 'vue-router'

interface Props {
  icon?: string
  title?: string
  themeTitle?: string
  themeTitleClass?: any
  themeTitleStyle?: any
  to?: RouteLocationRaw
  swiper?: boolean
  viewBtn?: boolean
  isBeginning?: boolean
  isEnd?: boolean
  appendIcon?: string
  appendIconClass?: string | object | any[]
  active?: boolean
  extraClass?: any
}

interface Emit {
  (e: 'click:view'): void
  (e: 'click:prev'): void
  (e: 'click:next'): void
  (e: 'click:appendIcon', event: Event): void
  (e: 'reInit'): void
}

withDefaults(defineProps<Props>(), {
  isBeginning: true,
  isEnd: false,
  active: true,
  extraClass: [],
  title: '',
  icon: '',
})

const emit = defineEmits<Emit>()

const onViewAllClick = () => {
  emit('click:view')
}

const onPrevClick = () => {
  emit('click:prev')
}

const onNextClick = () => {
  emit('click:next')
}

const onAppendIconClick = (event: Event) => {
  emit('click:appendIcon', event)
}
// const isIntersecting = ref(true)
// const intersect = ref<HTMLElement>()
// let stopfsp: (() => void) | undefined
// onMounted(() => {
//   stopfsp = runfps(() => {
//     if (isElementInBelowView(intersect.value)) {
//       isIntersecting.value = false
//     } else if (!isIntersecting.value) {
//       isIntersecting.value = true
//       nextTick(() => {
//         emit('reInit')
//       })
//     }
//   })
// })
// onUnmounted(() => {
//   stopfsp?.()
// })
</script>

<template>
  <div ref="intersect">
    <div v-if="active" class="tw-flex tw-items-center tw-justify-between" :class="extraClass">
      <slot name="prepend">
        <div class="tw-font-extrabold tw-text-sm tw-text-black">
          {{ title }}
        </div>
        <!-- <component
          :class="themeTitleClass" 
          :title="title"
          :icon="icon"
          :style="themeTitleStyle"
          :src="themeTitle"
        ></component> -->
      </slot>
      <slot name="append">
        <div class="tw-flex tw-gap-2">
          <VBtn
            v-if="viewBtn"
            rounded
            color="!tw-text-[12px] !tw-px-2 !tw-font-normal"
            class="!tw-bg-[#474451] !tw-h-[26px] !tw-text-[#d5d2e1] vbtn-no-shadow"
            size="x-small"
            :to="to"
            @click="onViewAllClick"
          >
            <span class="flex-center tw-leading-4"> All <RightSvg class="tw-ml-[2px]" /> </span>
          </VBtn>
          <!-- ANCHOR 隐藏切换按钮 -->
          <!-- <div v-if="swiper"
            class="text-primary tw-flex tw-items-center tw-gap-4 tw-px-4 tw-py-2 border-sm tw-rounded-full bg-surface">
            <VIcon class="-tw-rotate-180 !tw-text-sm" :class="[isBeginning && 'tw-text-[rgb(var(--v-theme-primary-darken-6))]']"
              icon="custom-arrowfix-right" @click="onPrevClick" />
            <div class="tw-w-px tw-h-[.875rem] tw-bg-[rgb(var(--v-theme-primary-darken-6))]"></div>
            <VIcon class="!tw-text-sm" :class="[isEnd && 'tw-text-[rgb(var(--v-theme-primary-darken-6))]']" icon="custom-arrowfix-right"
              @click="onNextClick" />
          </div> -->
          <VIcon
            v-if="appendIcon"
            :class="appendIconClass"
            :icon="appendIcon"
            @click="onAppendIconClick"
          />
        </div>
      </slot>
    </div>
    <slot />
  </div>
</template>
