<script lang="ts" setup>
interface Props {
  count?: number
  total?: number
}

interface Emit {
  (e: 'click'): void
}

const emit = defineEmits<Emit>()

const props = withDefaults(defineProps<Props>(), {
  count: 0,
  total: 0
})
const ratio = computed(() => {
  return Number(Math.floor(props.count / (props.total || 1) * 100).toFixed(0))
})
const finished = computed(() => {
  return ratio.value === 100
})

const onLoadClick = () => {

}
</script>

<template>
  <div class="tw-flex tw-flex-col tw-items-center">
    <div class="tw-flex tw-items-center tw-justify-center tw-mb-3 tw-text-sm tw-text-[#6B6676]">
      <span class="text-primary">
        {{ count }}/</span>
      <span class="total">{{ total }}</span>
      <div class="tw-w-[6.25rem] tw-h-[0.375rem] tw-rounded bg-surface-light-4 tw-relative tw-mx-3">
        <div class="tw-absolute tw-left-0 tw-h-full tw-rounded tw-top-0 tw-max-w-full bg-primary"
          :style="`width: ${ratio}%;`">
        </div>
      </div>{{ ratio }}%
    </div>
    <VBtn style="background: linear-gradient(102.06deg, rgba(206, 166, 117, 0.3) 11.08%, rgba(126, 95, 57, 0.1) 92.06%);" :disabled="finished" class="!tw-rounded-[20px] !tw-px-[82px] !tw-font-normal !tw-text-sm !tw-text-[#FFC972] !tw-border-[#E7CE96] !tw-border-[1px] tw-w-[162px]" color="surface-light-0"
      size="small" @click="emit('click')">Load More</VBtn>
  </div>
</template>
