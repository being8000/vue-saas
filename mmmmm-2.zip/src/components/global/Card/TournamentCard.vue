<template>
  <!-- <VerticalNavLink type="3" platformId="175" gameId="tongits" :jumpJson="jumpJson">
    <VImg class="tw-w-[100%] tw-my-3" :src="TPEntranceJPG" :aspectRatio="390 / 196" />
    <TpEntrance>
      <template #banner3>
        <div
          ref="refTpCardEL"
          :style="{
            fontSize: `${width / 1.2}%`,
          }"
          class="tw-ml-0"
        >
          <VueCountDown :time="countdownTime" :transform="transformSlotProps" @end="onCountdownEnd">
            <template #="{ hours, minutes, seconds }">
              <div class="countdown tw-space-x-[0.2em]">
                <div class="countdown_number">{{ hours[0] }}</div>
                <div class="countdown_number">{{ hours[1] }}</div>
                <div class="countdown_number !tw-text-white !tw-bg-none !tw-px-0">:</div>
                <div class="countdown_number">{{ minutes[0] }}</div>
                <div class="countdown_number">{{ minutes[1] }}</div>
                <div class="countdown_number !tw-text-white !tw-bg-none !tw-px-0">:</div>
                <div class="countdown_number">{{ seconds[0] }}</div>
                <div class="countdown_number">{{ seconds[1] }}</div>
              </div>
            </template>
          </VueCountDown>
        </div>
      </template>
      <template #banner2>
        <div
          :style="{
            fontSize: `${width / 4.5}%`,
          }"
          class="tw-absolute tw-w-[43%] tw-left-[8%] tw-bottom-[13.6%] tw-text-[0.2em] tw-h-[1.65em] tw-leading-[1.65em]"
        >
          <Vue3Marquee :duration="10" class="tw-w-full">
            <span class="tw-text-[#FFE100] tw-font-medium">
              Free to Win&nbsp;&nbsp; No Deposit Needed&nbsp;&nbsp; Totally Free&nbsp;&nbsp; 24/7&nbsp;&nbsp; It's FREE!!!!!&nbsp;&nbsp;
            </span>
          </Vue3Marquee>
        </div>
      </template>
    </TpEntrance>
  </VerticalNavLink> -->
  <div class="tw-relative">
    <VImg class="tw-w-[100%] tw-my-3" :src="TPEntranceJanEight" :aspectRatio="390 / 196" />
    <div class="tw-absolute tw-top-1 tw-w-[100%] tw-h-[75%] tw-flex tw-mt-[10%] tw-px-[5px]">
      <VerticalNavLink
        type="3"
        platformId="175"
        gameId="tongits"
        :jumpJson="jumpJson"
        class="!tw-rounded-lg tw-h-full tw-w-full"
        ><VImg :src="item01"
      /></VerticalNavLink>
      <VerticalNavLink 
        type="3"
        platformId="175"
        gameId="tongits"
        :jumpJson="jumpJson"
        class="tw-rounded-lg tw-h-full tw-w-full"
        ><VImg :src="item02" /></VerticalNavLink>
      <VerticalNavLink 
        type="3"
        platformId="175"
        gameId="tongits"
        class="tw-rounded-lg tw-h-full tw-w-full"
        :jumpJson="jumpJson"
        ><VImg :src="item03" />
      </VerticalNavLink>
    </div>
  </div>
</template>

<script setup lang="ts">



import TPEntranceJPG from '@images/home/tonight/main.jpg'
import TPEntranceJan from '@images/home/tonight/01.01.webp'
import TPEntranceJanEight from '@images/home/tonight/bg.webp'
import VerticalNavLink from '@/layouts/components/VerticalNavLink.vue'
import item01 from '@images/home/tonight/01.webp'
import item02 from '@images/home/tonight/02.webp'
import item03 from '@images/home/tonight/03.webp'
// import TpEntrance from '../Swiper/TpEntrance.vue'
// import TPCardImageLeft from '@images/home/tournament-card1.png'
// import TPCardImageRight from '@images/home/tournament-card2.png'
// import VueCountDown from '@chenfengyuan/vue-countdown'
// import { Vue3Marquee } from 'vue3-marquee'
// import { addDays, getHours } from 'date-fns'
// const refTpCardEL = ref(null)
// const { width } = useElementSize(refTpCardEL)
const jumpJson = JSON.stringify({ activity: 'tournament' })
const imageUrlChange = ref<string>(TPEntranceJPG)
const imageVisiable  = ref(false)
// const transformSlotProps = (props: any) => {
//   const formattedProps: any = {}
//   Object.entries(props).forEach(([key, value]) => {
//     const str = Number(value) < 10 ? `0${value}` : String(value)
//     formattedProps[key] = [str[0], str[1]]
//   })

//   return formattedProps
// }
// // const countdownTime = ref(getSpecificHourOfDay(18).getTime() - Date.now())
// const countdownTime = ref()

// const test = ref(0)
// const calcCountDownTime = () => {
//   const currentDate = Date.now()
//   const hours = getHours(currentDate)
//   if (hours < 18) {
//     countdownTime.value = getSpecificHourOfDay(18).getTime() - currentDate
//   } else if (hours < 19) {
//     countdownTime.value = getSpecificHourOfDay(19).getTime() - currentDate
//   } else if (hours < 20) {
//     countdownTime.value = getSpecificHourOfDay(20).getTime() - currentDate
//   } else if (hours < 23) {
//     countdownTime.value = getSpecificHourOfDay(18).getTime() - currentDate
//   } else {
//     countdownTime.value = addDays(getSpecificHourOfDay(18), 1).getTime() - currentDate
//   }
// }
// calcCountDownTime()
// const onCountdownEnd = () => {
//   calcCountDownTime()
// }
onMounted(() => {
  const newYear = new Date('2025-01-01: 00:00:00').getTime() //新年
  const january7 = new Date('2025-01-07: 23:59:59').getTime() //一月七号
  const january8 = new Date('2025-01-00: 00:00:00').getTime() //一月七号
  const january31 = new Date('2025-01-31: 23:59:59').getTime() //一月七号
  const test1 = new Date('2024-12-26: 14:30:00').getTime() //一月三十号
  const test2 = new Date('2024-12-26: 14:40:00').getTime() //一月三十号; //一月七号
  const test3 = new Date('2024-12-26: 14:40:00').getTime() //一月三十号
  const test4 = new Date('2024-12-26: 14:50:00').getTime() //一月三十号; //一月七号
  
  // 获取当前日期
  let currentDate = new Date()
  // 获取当前年份
  let year = currentDate.getFullYear()
  let endDate = new Date(year, 0, 7) // 1 月 7 日
  const now: number = new Date().getTime()
  console.log(endDate.getTime(), 'now12333')
  const n = true
  switch (n) {
    case now > test1 && now < test2:
    case now > january8 && now < january31:
      imageUrlChange.value = TPEntranceJan
      break
    case now > test3 && now < test4:
      imageUrlChange.value = TPEntranceJanEight
      imageVisiable.value = true
      break
    case now > newYear && now < january7:
      imageUrlChange.value = TPEntranceJan
      break
      case now > january8 && now < january31:
      imageUrlChange.value = TPEntranceJanEight
      imageVisiable.value = true
      break
  }
})
</script>

<style lang="scss" scoped>
// .countdown {
//   display: flex;
//   flex-direction: row;
//   position: absolute;
//   bottom: 0.7em;
//   right: 0.51em;
//   height: max-content;
//   width: max-content;
//   &_number {
//     box-shadow: 0px 1px 0.5px 0px #00000073;
//     background: linear-gradient(180deg, #ffffff 33.33%, #dac2ff 86.67%);
//     color: #050505;
//     width: max-content;
//     height: max-content;
//     line-height: 1;
//     border-radius: 3px;
//     font-weight: 700;
//     font-size: 0.28em;
//     padding: 3px 2px;
//   }
// }
</style>
