<template>
  <v-checkbox
    class="custom tw-m-auto tw-text-on-surface v-checkbox-translate-y tw-w-full"
    density="comfortable"
    v-model="agreement"
    :hide-details="true"
    @click.prevent="onAgreement"
    :falseIcon="cfalse"
    :trueIcon="ctrue"
    data-gtp-d="btn_terms&policy"
  >
    <template #label>
      <span class="tw-text-sm tw-w-max tw-mt-[2px]  tw-text-[#7D7888] !tw-text-[12px]">
        I
        <!-- am <span class="!tw-text-white">21+ years old</span> and  -->
        agree to
        <span>
          <span class="!tw-text-[#645E6D] " style="text-decoration: underline;" @click.prevent="toPrivatePolicy()">the Terms of Use</span>
          and
          <span class="!tw-text-[#645E6D]" style="text-decoration: underline;" @click.prevent="toPrivatePolicy()"> Privacy Policy </span>
        </span>
        <template v-if="showIncludeingThat">, including that:</template>
        <template v-else>.</template>
      </span>
    </template>
  </v-checkbox>
</template>

<script setup lang="ts">
import cfalse from '@images/svg/checkbox-false-new.svg'
import ctrue from '@images/svg/checkbox-true-new.svg'
import CustomTAndC from '~/components/custom/TAndC.vue'
const props = defineProps<{
  showIncludeingThat?: boolean,
  gtpB?: string,
  gtpC?: string,
  gtpD?: string,
}>()
const agreement = ref(false)
const { isFullySignUp } = useApp()
// 用来测试
// const isFullySignUp = ref(true)
const toPrivatePolicy = () => {
  return new Promise((resolve, reject) => {
    const { toHashComponent, historyBus } = useHashComponent()
    historyBus.once((e, paylaod) => {
      if (e === 'onTermsConfirm') {
        agreement.value = true
        const t = setTimeout(() => {
          clearTimeout(t)
          resolve(true)
        }, 200)
      }
    })
    toHashComponent('terms', {
      mode: 'confirm',
    })
    // popPage(
    //   h(PagePrivacyPolicy, {
    //     mode: 'confirm',
    //     onConfirm() {
    //       agreement.value = true
    //       const t = setTimeout(() => {
    //         clearTimeout(t)
    //         resolve(true)
    //       }, 200)
    //     },
    //   })
    // )
  })
}

const onAgreement = async () => {
  if (isFullySignUp.value) {
    if (agreement.value) {
      agreement.value = false
      return
    }
    const res = await toPrivatePolicy()
    if (res) {
      agreement.value = true
    }
  } else {
    agreement.value = !agreement.value
  }
}

const isChecked = async () => {
  if (agreement.value) {
    return true
  }
  // 如果是完整KYC
  if (isFullySignUp.value) {
    const res = await toPrivatePolicy()
    if (res) {
      agreement.value = true
      return true
    } else {
      return false
    }
  }
  const res = await $dialog.pop({
    title: 'Tips',
    confirmButtonText: 'Agree',
    slots: {
      default: () => h(CustomTAndC),
    },
    'data-gtp-b': props.gtpB,
    'data-gtp-c': props.gtpC,
    gtpD: props.gtpD,
  })
  if (res) {
    agreement.value = true
    return true
  } else {
    return false
  }
}
defineExpose({
  isChecked,
  agreement
})
</script>

<style lang="scss" scoped>
:deep(.v-selection-control__input){
  margin-right: 1px !important;
}
</style>
