<script setup lang="ts">
const model = defineModel({ type: Boolean, default: false })
interface IProps {
    title: string
}
const props = withDefaults(defineProps<IProps>(), {
    title: '提示'
})
const emits = defineEmits<{
    (e: 'success', params: { ticket: string }): void
}>()
const onCloseClick = () => {
    model.value = false
}
const onSuccess = (params: { ticket: string }) => {
    emits('success', params)
}
</script>

<template> 
    <VDialog v-model="model" z-index="10000">
        <VCard class="tw-border tw-border-[#37333E] tw-rounded-[15px]  tw-w-[18.35rem]  tw-m-[0_auto]">
            <VCardTitle
                class="tw-relative tw-z-[1] !tw-h-10 !tw-leading-4  tw-text-center tw-bg-[#494551]">
                <div class="tw-relative tw-z-[1]  tw-text-[16px] tw-text-[#fff] ">{{ title }}</div>
                <!-- <div
                    class="tw-absolute tw-z-[-1] tw-inset-x-0 tw-h-full tw-w-[60%] tw-mx-auto tw-bottom-0  ">
                </div> -->
                <div class="!tw-absolute tw-z-[2] tw-top-0 tw-right-3 tw-h-full tw-flex tw-items-center"
                    data-gtp-d="btn_close"
                    @click="onCloseClick">
                    <VIcon
                        class="!tw-text-base tw-text-[#B9B3C8]"
                        icon="custom-close"
                        size="10"
                    />
                </div>
            </VCardTitle>
            <section class="!tw-p-[1.4375rem] !tw-pt-10 tw-text-[12px]  tw-text-white tw-rounded-bl-[15px] tw-rounded-br-[15px] tw-bg-[#2c2931]">
                <slot></slot>
            </section>
        </VCard>
    </VDialog>
</template>
