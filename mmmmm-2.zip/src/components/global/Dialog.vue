<template>
  <VDialog
    v-model="model"
    style="z-index: 10000;"
    :width="dialogWidth"
    min-width="300px"
    max-width="300px"
    v-bind="attrs"
  >
    <VCard class="!tw-border !tw-overflow-visible !tw-border-[#37333E]">
      <VCardTitle
        class="box-shadow tw-h-[2.5rem] tw-relative tw-z-[1] tw-rounded-t-2xl tw-text-center on-background  tw-shadow-[0px_4px_12px_0px_#0D142599]"
      >
        <div class="tw-relative tw-text-[1rem] tw-leading-4  tw-z-[1] !tw-font-bold">{{ title }}</div>
        <!-- <div
          class="tw-absolute tw-z-[-1] tw-inset-x-0 tw-h-[200%] tw-w-[14rem] tw-mx-auto tw-bottom-0 tw-translate-y-1/2 tw-opacity-[0.3] tw-bg-[radial-gradient(50%_50%_at_50%_58%,rgb(var(--v-theme-primary))_0%,rgba(var(--v-theme-surface-light-1),0)_100%)]"
        ></div> -->
        <div
          v-if="!hideCloseIcon"
          class="!tw-absolute tw-z-[2] tw-top-0 tw-right-3 tw-h-full tw-flex tw-items-center"
          @click="onCloseClick"
        >
          <VIcon
            class="!tw-text-base tw-text-[#B9B3C8]"
            icon="custom-close"
            size="10"
          />
        </div>
      </VCardTitle>
      <slot>
        <section class="tw-px-5 tw-py-[3.375rem] tw-text-center tw-text-[0.875rem] tw-leading-[1.125rem] tw-text-[#B9B3C8] tw-bg-[#2C2931]">
          <div class="tw-w-[246px] dialog-content"> {{ content }}</div> 
        </section>
      </slot>
      <slot name="bottom">
        <section
          v-if="!hideBottom"
          class="tw-text-center  tw-w-full tw-px-5 tw-mb-5 !tw-bg-[#2C2931]"
        >
          <!-- <VBtn color="primary" class="tw-w-[calc(50%-10px)]" :data-gtp-d="gtpD" @click="onConfirm">{{
            confirmButtonText
          }}</VBtn> -->
          <!-- <VBtn
            color="surface-light-4"
            class="!tw-font-medium tw-w-[calc(50%-10px)]"
            @click="onCancel"
            >{{ cancelButtonText }}</VBtn
          > -->
          <div 
            class="tw-w-[12.75rem] tw-font-bold tw-text-[0.875rem] tw-m-auto tw-mb-3 tw-text-white tw-h-[2.25rem] tw-border tw-border-[#FFE283] tw-text-center tw-leading-[2.25rem] tw-rounded-[3.125rem]" 
            style="background: linear-gradient(90deg, #FDB756, #F78336);"
            @click="onConfirm" 
          >
            {{confirmButtonText}}
          </div>
          <div class="!tw-font-semibold tw-m-auto tw-text-[0.875rem] tw-w-[calc(50%-10px)] tw-text-[#CEC7D8] tw-underline"
            @click="onCancel"
          >{{ cancelButtonText }}
          </div>
        </section>
      </slot>
    </VCard>
  </VDialog>
</template>
<script setup lang="ts">
const model = defineModel({ type: Boolean, default: false })
export interface DialigProps {
  title: string
  confirmButtonText: string
  cancelButtonText: string
  dialogWidth: string
  content: string
  hideBottom: boolean
  hideCloseIcon: boolean
  gtpD: string
  closeCha: Function
}
const attrs = useAttrs()
const props = withDefaults(defineProps<Partial<DialigProps>>(), {
  title: 'Tips',
  confirmButtonText: 'Confirm',
  cancelButtonText: 'Cancel',
  dialogWidth: '350px',
  content: 'No Content',
  hideBottom: false,
  hideCloseIcon: false,
  closeCha:()=>{}
})
const emits = defineEmits(['confirm', 'cancel', 'afterLeave'])
const onCloseClick = () => {
  model.value = false
  emits('cancel')
  props.closeCha()
}

const onAfterLeave = () => {
  emits('afterLeave')
}
let onConfirm: Function = () => {
  emits('confirm')
}
let onCancel: Function = () => {
  emits('cancel')
}

const $attrs = ref({})

defineExpose({
  pop() {
    model.value = true
    const promise = new Promise((resolve, reject) => {
      onConfirm = () => {
        model.value = false
        resolve(true)
      }
      onCancel = () => {
        model.value = false
        resolve(false)
      }
    })
    return promise
  },
  show() {
    model.value = true
    onCancel = () => {
      emits('cancel')
    }
  },
  close() {
    model.value = false
  },
})
</script>
<style lang="scss" scoped>
.box-shadow {
  box-shadow: rgba(0, 0, 0, 0.05) 0px 0px 0px 0.5px, #503d32 0px 0px 0px 0.3px inset;
  background-color: #322F37;
}
:deep( .v-card--density-default ) {
  background: #2C2931 !important;
}
.dialog-content {
  white-space: pre-line; /* 保留空白符和换行符 */
}
</style>
