<script lang="ts" setup>
const currentVal = ref()
const platformList = ref<PlatformItem[]>([])
interface PlatformItem {
  platformId: string
  platformName: string
}
;(async function getPlatformList() {
  const { success, body } = await getPlatformsV2()
  success && (platformList.value = body)
})()

const emits = defineEmits(['confirm'])
const onConfirm = () => {
  let platformId = platformList.value[currentVal.value]?.platformId
  if(platformId){
    emits('confirm', [platformId])
  }

}

defineOptions({
  inheritAttrs: false,
})
</script>

<template>
  <VDialog maxWidth="375">
    <template #activator="scope">
      <slot v-bind="scope"></slot>
    </template>
    <template #default="{ isActive }">
      <LazyCardWidgetDialog>
        <LazyCardWidgetDialogTitle title="Providers" />
        <div class="tw-p-3">
          <LazyCardBtnsGroup
            class="scrollbar-width-none tw-overflow-y-auto tw-max-h-[60vh]"
            :border="true"
            v-model="currentVal"
            :options="platformList"
          >
            <template #default="{ item }">
              {{ item.platformName }}
            </template>
          </LazyCardBtnsGroup>
        </div>
        <LazyCardWidgetActions
          @click:cancel="isActive.value = false"
          @click:confirm=";(isActive.value = false), onConfirm()"
        />
      </LazyCardWidgetDialog>
    </template>
  </VDialog>
</template>
