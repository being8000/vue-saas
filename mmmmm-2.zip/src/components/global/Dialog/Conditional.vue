<script lang="ts" setup>
import { TransactionAllStatusList, TransactionAllTypeList } from '~/util/const'

const typeList = TransactionAllTypeList
const statusList = TransactionAllStatusList

const model = reactive({ type: '0', status: '0' })

const emits = defineEmits(['confirm'])
const onConfirm = () => {
  let confirmParams = {
    billTypes: model.type !== '' ? TransactionAllTypeList[+model.type].value.split(',') : [],
    statuses: model.status !== '' ? TransactionAllStatusList[+model.status].value.split(',') : [],
  }
  emits('confirm', confirmParams)
}

defineOptions({
  inheritAttrs: false,
})
</script>

<template>
  <VDialog maxWidth="375">
    <template #activator="scope">
      <slot v-bind="scope"></slot>
    </template>
    <template #default="{ isActive }">
      <LazyCardWidgetDialog>
        <LazyCardWidgetDialogTitle title="Conditional Filtering" />
        <div class="tw-p-3">
          <h1 class="tw-font-bold tw-text-white tw-text-[1rem] tw-mb-2">Type</h1>
          <LazyCardBtnsGroup
            class="scrollbar-width-none tw-overflow-y-auto"
            :border="true"
            v-model="model.type"
            :options="typeList"
          >
            <template #default="{ item }">
              {{ item.label }}
            </template>
          </LazyCardBtnsGroup>
        </div>

        <div class="tw-p-3">
          <h1 class="tw-font-bold tw-text-white tw-text-[1rem] tw-mb-2">Status</h1>
          <LazyCardBtnsGroup
            class="scrollbar-width-none tw-overflow-y-auto"
            :border="true"
            v-model="model.status"
            :options="statusList"
          >
            <template #default="{ item }">
              {{ item.label }}
            </template>
          </LazyCardBtnsGroup>
        </div>

        <LazyCardWidgetActions
          @click:cancel="isActive.value = false"
          @click:confirm=";(isActive.value = false), onConfirm()"
        />
      </LazyCardWidgetDialog>
    </template>
  </VDialog>
</template>
