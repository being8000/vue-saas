<script lang="ts" setup>
interface Props {
  amount: string | number
  turnoverAmount: string | number
  startTime: string
  endTime: string
}

const props = withDefaults(defineProps<Props>(), {
  amount: 0,
  turnoverAmount: 0,
  startTime: '',
  endTime: '',
})

const startTime = computed(() => {
  return new Date(props.startTime || Date.now()).toLocaleDateString()
})

const endTime = computed(() => {
  return new Date(props.endTime || Date.now()).toLocaleDateString()
})

const closeDuration = ref(5)

defineOptions({
  inheritAttrs: false
})
interface Emit {
  (e: 'click:confirm'): void
  (e: 'click:cancel'): void
  (e: 'cancel'): void
}
const emit = defineEmits<Emit>()

const model = defineModel<boolean>({ default: false })
watch(model, () => {
  if (!model.value) {
    emit('cancel')
  } else {
    const { pause } = useIntervalFn(() => {
      closeDuration.value--
      if (closeDuration.value <= 0) {
        pause()
        onCancelClick()
      }
    }, 1000)
  }
})
const onConfirmClick = () => {
  model.value = false
  emit('click:confirm')
}
const onCancelClick = () => {
  model.value = false
  emit('click:cancel')
  emit('cancel')
}
</script>

<template>
  <VDialog v-model="model" v-bind="$attrs" maxWidth="336">
    <template v-slot:activator="scope">
      <slot v-bind="scope"></slot>
    </template>
    <template #default>
      <div class="tw-relative">
        <img src="@/assets/images/bonus/deposit-bonus-bg.png" />
        <div
          class="tw-absolute tw-bottom-0 tw-w-full tw-h-[61%] tw-bg-[#FFF0EC] tw-rounded-[1.5rem] tw-space-y-2 tw-text-center tw-pt-5 tw-pb-6 tw-px-3">
          <div class="tw-text-black tw-font-bold tw-text-xl tw-leading-[1.6875rem]">Promotion Reminder</div>
          <div class="tw-text-[#828282] tw-text-sm tw-leading-[1.1875rem]">Complete The Deposit And You Will Receive
            This Rewards!</div>
          <div class="tw-bg-[#FD673A] tw-rounded-xl tw-p-3 tw-space-y-[.625rem]">
            <div class="tw-flex tw-justify-between tw-items-center">
              <span class="tw-font-din tw-font-bold tw-text-2xl">₱ {{ $n(Number(amount), 'decimal') }}</span>
              <span class="tw-text-xs tw-leading-4 tw-text-[#FFE1D8]">{{ DF.yMdDot(startTime) }}~{{ DF.yMdDot(endTime)
                }}</span>
            </div>
            <div class="tw-text-sm tw-leading-4 tw-text-[#FFE1D8] tw-text-left">
              Bet&nbsp;<span class="tw-font-semibold on-background">{{ $n(Number(turnoverAmount), 'decimal')
                }}</span>&nbsp;to unlocked
            </div>
          </div>
        </div>
      </div>
      <div class="tw-flex tw-justify-center tw-mt-5">
        <button
          class="tw-bg-[#FF6533] tw-rounded-lg tw-w-[16.25rem] tw-h-[2.75rem] tw-flex tw-text-lg tw-justify-center tw-items-center tw-font-semibold"
          @click="onConfirmClick">
          OK <span class="tw-text-[#ffd71f] tw-ml-2 tw-align-middle tw-font-normal">({{ closeDuration }}S)</span>
        </button>
      </div>
    </template>
  </VDialog>
</template>
