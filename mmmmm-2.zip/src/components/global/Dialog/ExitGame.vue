<script lang="ts" setup>
import LazyCardWidgetDialog from '@/components/global/Card/Widget/Dialog.vue'
import LazyCardWidgetDialogTitle from '@/components/global/Card/Widget/DialogTitle.vue'

defineOptions({
  inheritAttrs: false
})
interface Emit {
  (e: 'click:confirm'): void
  (e: 'click:cancel'): void
  (e: 'cancel'): void
}
const emit = defineEmits<Emit>()

const model = defineModel<boolean>({ default: false })
watch(model, () => {
  if (!model.value) {
    emit('cancel')
  }
})
const onConfirmClick = () => {
  model.value = false
  emit('click:confirm')
}
const onCancelClick = () => {
  model.value = false
  emit('click:cancel')
  emit('cancel')
}
</script>

<template>
  <VDialog v-model="model" v-bind="$attrs" maxWidth="375">
    <template v-slot:activator="scope">
      <slot v-bind="scope"></slot>
    </template>
    <template #default>
      <LazyCardWidgetDialog>
        <LazyCardWidgetDialogTitle title="Notification" closeIcon="custom-close" @click:close="onCancelClick" />
        <div class="tw-px-3 tw-py-5 tw-flex tw-flex-col tw-gap-5">
          <div class="tw-text-white tw-text-center tw-normal-case tw-py-3">Exit game and return to lobby?</div>
          <div class="tw-flex tw-justify-center tw-items-center tw-gap-5">
            <PrimaryBtn class="tw-flex-1" size="large" @click="onConfirmClick">
              <span class="tw-font-semibold tw-capitalize">Agree</span>
            </PrimaryBtn>
            <VBtn class="tw-flex-1" color="surface-light-4" size="large" @click="onCancelClick">
              <span class="tw-font-semibold tw-capitalize">Cancel</span>
            </VBtn>
          </div>
        </div>
      </LazyCardWidgetDialog>
    </template>
  </VDialog>
</template>
