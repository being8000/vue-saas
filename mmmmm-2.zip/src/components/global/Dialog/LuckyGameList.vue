<script setup lang="ts">
import LazyCardGameItem from '@/components/global/Card/GameItem.vue'
import router from '@/router'
import { $jackportFrame } from '~/composables/jackport/component'

const visible = defineModel({
    type: Boolean,
    default: false
})

const toggle = (value: boolean) => {
    visible.value = value
};

/**
 * 跳转 all 分页下，最后一个区块的view all(所有游戏)页面
 */
const navigateToAllGame = () => {
    const blockConfigs = toValue(dirtyBlockConfigsStore)
    // 找到all 分类下的数据
    const allTabConfig = blockConfigs.find((el) => el.categoryIdFirst === 0)
    if (allTabConfig) {
        // 找到 all分类下的最后一个blockConfig
        const blockConfig = allTabConfig.blockConfig
        if (blockConfig.length > 0) {
            const lastBlockConfig = blockConfig[blockConfig.length - 1]
            if (lastBlockConfig) {
                const { id, blockName } = lastBlockConfig
                router.push({
                    name: 'home-tab-games-block',
                    params: {
                        tab: allTabConfig.pagination.toLowerCase(),
                        block: `${blockName}-${id}`,
                    },
                })
                $jackportFrame.hide()
                toggle(false)
            }
        }
    }
}
const closeDialog = () => {
    $jackportFrame.hide()
    toggle(false)
}

const { games: allGames, fetchList } = useRecentGame(20)
fetchList()
const games = computed(() => {
    let gameList = allGames.value.filter((item) => {
        return item.jackpotShowFlag === 1
    })
    return gameList.splice(0, 9) || []
})

</script>

<template>
    <VDialog v-model="visible" v-bind="$attrs" persistent maxWidth="319" class="!tw-items-center mb-15"
        contentClass="!tw-m-0 !tw-w-full" style="z-index:10001 !important;">
        <div class="tw-bg-gradient-to-t tw-from-[#FFEAE8] tw-to-[#FFEFDF] tw-flex tw-justify-between">
            <div class="pillar"></div>
            <div class="tw-w-full">
                <div class="tw-flex tw-items-center">
                    <div class="tw-font-bold tw-text-[#5E1F0F] tw-text-xs tw-pt-5 tw-ml-8">Get a chance to spin with
                        every ₱1
                        bet!
                    </div>
                    <VIcon @click="toggle(false)" icon="custom-lucky-close" size="20" class="tw-ml-3 tw-mt-4" />
                </div>
                <div class=" tw-mt-4 tw-gap-2 tw-grid tw-grid-cols-3">
                    <div v-for="(game, index) in games" class="tw-mx-2">
                        <LazyCardGameItem :game="game" :data-gtp-d="`item_${index}`" @click="closeDialog" />
                    </div>
                </div>
                <div @click="navigateToAllGame"
                    class="tw-text-[#000000] tw-text-center tw-font-miduim tw-my-2 tw-underline">More Games
                </div>
            </div>
            <div class="pillar"></div>
            <!-- class="tw-min-w-0 tw-flex-[0_0_var(--slide-size)] tw-pl-[var(--slide-spacing)] tw-flex tw-flex-col tw-gap-[var(--slide-spacing)]" -->
        </div>
    </VDialog>
</template>

<style>
.pillar {
    background: url('@images/lucky/pillar.png');
    background-size: 100%;
    width: 8px
}
</style>