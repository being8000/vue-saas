<script lang="ts" setup>
import LazyCardWidgetDialog from '@/components/global/Card/Widget/Dialog.vue'
import LazyCardWidgetDialogTitle from '@/components/global/Card/Widget/DialogTitle.vue'

interface Props {
  content?: string
}

defineProps<Props>()

defineOptions({
  inheritAttrs: false
})
interface Emit {
  (e: 'click:confirm'): void
  (e: 'cancel'): void
}
const emit = defineEmits<Emit>()

const model = defineModel<boolean>({ default: false })

watch(model, () => {
  if (!model.value) {
    emit('cancel')
  }
})
const onConfirmClick = () => {
  model.value = false
  emit('click:confirm')
}
</script>

<template>
  <VDialog v-model="model" v-bind="$attrs" maxWidth="375">
    <template v-slot:activator="scope">
      <slot v-bind="scope"></slot>
    </template>
    <template #default>
      <LazyCardWidgetDialog>
        <LazyCardWidgetDialogTitle title="Notices" />
        <div class="tw-px-3 tw-py-5 tw-flex tw-flex-col tw-gap-4">
          <div class="on-surface-light-1 tw-text-center tw-normal-case">{{ content }}</div>
          <PrimaryBtn class="tw-w-full" size="large" @click="onConfirmClick">
            <span class="tw-font-normal tw-capitalize">Confirm</span>
          </PrimaryBtn>
        </div>
      </LazyCardWidgetDialog>
    </template>
  </VDialog>
</template>
