<script lang="ts" setup>
import LazySwiperPoster from '@/components/global/Swiper/Poster.vue'
import emblaCarouselVue from 'embla-carousel-vue'
import Autoplay from 'embla-carousel-autoplay'
import type {EmblaCarouselVueType} from 'embla-carousel-vue'
import type { UnwrapRef } from 'vue';

type EmblaCarouselType = UnwrapRef<EmblaCarouselVueType[1]> & {}

const activeIndex = ref(0)

const { showPosterBanners, posterBanners } = usePoster()

const LazyVerticalNavLink = defineAsyncComponent(() => import('~/layouts/components/VerticalNavLink.vue'))

const [emblaRef, emblaApi] = emblaCarouselVue({ loop: true }, [
  Autoplay({ playOnInit: true, delay: 3000 })
])
const onSelect = (emblaApi: EmblaCarouselType, evt: string) => {
  activeIndex.value = emblaApi.internalEngine().index.get()
}
onMounted(() => {
  emblaApi.value?.on('reInit', onSelect).on('init', onSelect).on('select', onSelect)
})

const onPosterClick = (index: number) => {
  showPosterBanners.value = false
}

const hooks = useNuxtApp().hooks

</script>

<template>
  <VDialog v-if="showPosterBanners && posterBanners.length > 0 && $route.name != 'game-id'" v-model="showPosterBanners"
    :retainFocus="false" maxWidth="375">
    <template #default>
      <LazySwiperPoster />
      <div class="tw-flex tw-items-center tw-justify-center tw-text-3xl tw-cursor-pointer tw-mt-6"
        @click="showPosterBanners = false">
        <VIcon icon="custom-close-circle3" />
      </div>
    </template>
  </VDialog>
</template>
