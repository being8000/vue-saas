<script lang="ts" setup>
import LazyCardWidgetDialog from '@/components/global/Card/Widget/Dialog.vue'
import LazyCardWidgetDialogTitle from '@/components/global/Card/Widget/DialogTitle.vue'
import LazyCardWidgetActions from '@/components/global/Card/Widget/Actions.vue'
import LazyCardBtnsGroup from '@/components/global/Card/BtnsGroup.vue'

defineOptions({
  inheritAttrs: false
})
interface Emit {
  (e: 'click:confirm'): void
  (e: 'click:cancel'): void
  (e: 'cancel'): void
}
const emit = defineEmits<Emit>()

const model = defineModel<boolean>({ default: false })
const { providers } = useBlock()
const providerOptions = computed(() => {
  return ['All', ...providers.value.map(provider => provider.platformName)]
})
const providerModel = defineModel<number[]>('provider', { default: () => [] })
const innerProviderModel = ref<number[]>([])
const allValue = 0
watch(innerProviderModel, (curValue, oldValue) => {
  if (curValue.length > 1 && curValue[curValue.length - 1] === allValue) {
    innerProviderModel.value = [allValue]
  } else if (curValue.length > 1) {
    const index = innerProviderModel.value?.findIndex(item => item === allValue)
    if (index >= 0) {
      innerProviderModel.value.splice(index, 1)
    }
  }
})
const restore = ref<number[]>([])
watchEffect(() => {
  if (model.value) {
    innerProviderModel.value = restore.value
  }
})
watch(model, () => {
  if (!model.value) {
    emit('cancel')
  }
})
const onConfirmClick = () => {
  providerModel.value = restore.value = innerProviderModel.value
  model.value = false
  emit('click:confirm')
}
const onCancelCLick = () => {
  model.value = false
  emit('click:cancel')
  emit('cancel')
}
</script>

<template>
  <VDialog v-model="model" v-bind="$attrs" maxWidth="375">
    <template v-slot:activator="scope">
      <slot v-bind="scope"></slot>
    </template>
    <template #default>
      <LazyCardWidgetDialog>
        <LazyCardWidgetDialogTitle title="Providers" />
        <LazyCardBtnsGroup class="tw-p-5 scrollbar-width-none tw-overflow-y-auto tw-max-h-48" multiple border
          v-model="innerProviderModel" :options="providerOptions" />
        <LazyCardWidgetActions @click:cancel="onCancelCLick" @click:confirm="onConfirmClick" />
      </LazyCardWidgetDialog>
    </template>
  </VDialog>
</template>
