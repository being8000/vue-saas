<script lang="ts" setup>
import gamezoneImg from '@/assets/images/logo/gamezone3.png'
import yearsoldImg from '@/assets/images/logo/yearsold2.png'

defineOptions({
  inheritAttrs: false,
})
interface Emit {
  (e: 'click:confirm'): void
  (e: 'click:cancel'): void
  (e: 'cancel'): void
}
const emit = defineEmits<Emit>()

const model = defineModel<boolean>({ default: false })
watch(model, () => {
  if (!model.value) {
    emit('cancel')
  }
})
const onConfirmClick = () => {
  model.value = false
  emit('click:confirm')
}

const router = useRouter()
const onCancelClick = () => {
  emit('click:cancel')
  emit('cancel')
}
</script>

<template>
  <VDialog v-model="model" v-bind="$attrs" persistent maxWidth="390" class="!tw-items-end"
    contentClass="!tw-m-0 !tw-w-full" style="z-index:10001 !important;">
    <template v-slot:activator="scope">
      <slot v-bind="scope"></slot>
    </template>
    <template #default>
      <div
        class="tw-relative tw-bg-[linear-gradient(180deg,#FD784F_0%,#FFFFFF_100%)] tw-min-h-[16.0625rem] tw-rounded-t-[1.75rem]">
        <div
          class="tw-bg-white tw-min-h-[19.375rem] tw-absolute tw-bottom-0 tw-left-3 tw-right-3 tw-mx-auto tw-rounded-t-[1.75rem] tw-px-3 tw-pb-4 tw-space-y-4">
          <VImg class="!tw-w-[9.75rem] tw-mx-auto tw-mt-6" :src="gamezoneImg" :aspectRatio="156 / 72" />
          <div class="tw-bg-[#FFF4F0] tw-rounded-lg">
            <div class="tw-font-bold tw-text-black tw-text-xs tw-p-2">The following personalities are NOT ALLOWED to register and/or play in this online gaming website:</div>
            <ul
              class="tw-list-disc tw-text-xs tw-leading-4 tw-text-[#666666] tw-space-y-1 tw-pt tw-pr-2 tw-pl-6 tw-pb-3">
              <li>Government Official or employee connected directly with the operation of the Government or any of its agencies.</li>
              <li>Members of the Armed Forces of the Philippines, including the Army, Navy, Air Force, or the Philippine National Police.</li>
              <li>Persons under 21 years of age.</li>
              <li>Persons included in the PAGCOR's National Database of Restricted Persons (NDRP).</li>
              <li>Gaming Employment License (GEL) holder.</li>
            </ul>
            <div class="tw-font-bold tw-text-black tw-text-xs tw-my-1 tw-px-2">NOTICE OF FORFEITURE</div>
            <div class="tw-text-[#666666] tw-text-xs tw-font-normal tw-px-2 tw-mb-3">Funds or credits in the account of player who is found ineligible to play shall mean forfeiture of said funds/credits in favor of the Government.</div>
            <VBtn
              class="tw-w-full !tw-border-[0.5px] !tw-border-solid !tw-border-[#ffffff] !tw-bg-[linear-gradient(180deg,#FF6533_0%,#FF3700_100%)] !tw-shadow-[0px_4px_4px_0px_#FFB9A3]"
              color="primary" @click="onConfirmClick">
              <span class="tw-font-semibold tw-text-lg tw-normal-case">I Agree To All The Above</span>
            </VBtn>
          </div>

          <VBtn class="tw-w-full tw-mt-[1.25rem]" elevation="0" variant="outlined" color="primary"
            @click="onCancelClick">
            <span class="tw-font-semibold tw-text-lg tw-normal-case">Exit</span>
          </VBtn>

          <VImg class="!tw-w-[15.125rem] tw-mx-auto" :src="yearsoldImg" :aspectRatio="242 / 32" />
        </div>
      </div>
    </template>
  </VDialog>
</template>
