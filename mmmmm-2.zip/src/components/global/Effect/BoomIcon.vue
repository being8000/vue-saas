<script lang="ts" setup>
interface Props {
  layer1Color?: string
  layer2Color?: string
  layer3Color?: string
  size?: string
  icon?: string
  perf?: boolean
}

const model = defineModel({ type: Boolean, default: false })

withDefaults(defineProps<Props>(), {
  layer1Color: 'rgb(var(--v-theme-warning))',
  layer2Color: 'rgb(var(--v-theme-warning-darken-1))',
  layer3Color: 'rgb(var(--v-theme-primary))',
  size: '40%',
  icon: 'custom-heart',
  perf: false
})
</script>

<template>
  <div class="!tw-absolute !tw-size-full !tw-inset-0 effect-liked"
    :class="[model ? 'effect-liked--active tw-opacity-100' : 'tw-opacity-0']">
    <div v-if="!perf" class="tw-absolute tw-size-full tw-inset-0 effect-liked__circle">
      <div v-for="i in 14" class="effect-liked__point tw-absolute tw-rounded-full"></div>
    </div>
    <VIcon v-if="icon.startsWith('custom-')"
      class="effect-liked__heart !tw-absolute !tw-inset-0 !tw-m-auto text-primary !tw-top-[6%]" :icon="icon" />
    <img v-else
      class="effect-liked__heart !tw-absolute !tw-inset-0 !tw-m-auto text-primary !tw-top-[8%] !tw-object-contain"
      :src="icon" />
    <div v-if="!perf" class="tw-absolute tw-inset-0 tw-m-auto effect-liked__layer"></div>
  </div>
</template>

<style lang="scss" scoped>
@use "sass:math";
@use "sass:map";

$points: 7;
$inner-radius: 25%;
$outer-radius: 30%;
$angle: math.div(360deg, $points);
$inner-size: 5%;
$outer-size: 6%;
$inner-offset: 15%;
$outer-offset: 25%;
$outer-angle-offset: 0.3;
$circle1-colors1: (
  1: #cbafc7,
  2: #c9a7fe,
  3: #eead59,
  4: #cdcba3,
  5: #6ba3e2,
  6: #a7f0b8,
  7: #609af4,
);
$circle1-colors2: (
  1: #aa3eda,
  2: #bbe9dc,
  3: #daed73,
  4: #4fbb8a,
  5: #6ba3e2,
  6: #848bdc,
  7: #74c9a5,
);
$circle2-colors1: (
  1: #8ce8c3,
  2: #91d2fa,
  3: #cc8ef5,
  4: #8ce8c3,
  5: #f48ea7,
  6: #91d2fa,
  7: #91d2fa,
);
$circle2-colors2: (
  1: #d97aca,
  2: #d79cf5,
  3: #f3ba30,
  4: #c3b789,
  5: #339ff0,
  6: #b0d5a5,
  7: #b0d5a5,
);

@keyframes heart {
  0% {
    transform: scale(0.1);
  }

  70% {
    transform: scale(1.4);
  }

  100% {
    transform: scale(1);
  }
}

@keyframes layer {
  0% {
    background: v-bind(layer1Color);
    border-radius: 9999px;
  }

  20% {
    background: v-bind(layer2Color);
    border-radius: 9999px;
  }

  40% {
    background: v-bind(layer3Color);
    border-radius: 9999px;
  }

  60% {
    background: transparent;
    border-radius: 9999px;
    border: 6px solid v-bind(layer3Color);
  }

  80% {
    background: transparent;
    border-radius: 9999px;
    border: 2px solid v-bind(layer3Color);
  }

  100% {
    background: transparent;
    border-radius: 9999px;
    border: 0.5px solid v-bind(layer3Color);
  }
}

.effect-liked {
  &__point {
    @for $i from 1 through $points {
      $point-angle: $angle * ($i - 1);

      &:nth-child(#{$i}) {
        width: $inner-size;
        height: $inner-size;
        top: calc(50% - #{math.div($inner-size, 2)} - #{$inner-radius} * #{math.sin($point-angle)});
        left: calc(50% - #{math.div($inner-size, 2)} + #{$inner-radius} * #{math.cos($point-angle)});
        background: map.get($circle1-colors1, $i);
      }
    }

    @for $i from 1 through $points {
      $point-angle: $angle * ($i - 1 - $outer-angle-offset);
      $idx: $i + 7;

      &:nth-child(#{$idx}) {
        width: $outer-size;
        height: $outer-size;
        top: calc(50% - #{math.div($outer-size, 2)} - #{$outer-radius} * #{math.sin($point-angle)});
        left: calc(50% - #{math.div($outer-size, 2)} + #{$outer-radius} * #{math.cos($point-angle)});
        background: map.get($circle2-colors1, $i);
      }
    }
  }

  &--active &__point {
    @for $i from 1 through $points {
      $point-angle: $angle * ($i - 1);

      &:nth-child(#{$i}) {
        animation: circle#{$i} 0.3s steps(18) 0.2s forwards;

        @keyframes circle#{$i} {
          0% {
            background: map.get($circle1-colors1, $i);
            opacity: 1;
          }

          100% {
            width: 0%;
            height: 0%;
            top: calc(50% - #{math.div($inner-size, 2)} - #{$inner-radius + $inner-offset} * #{math.sin($point-angle)});
            left: calc(50% - #{math.div($inner-size, 2)} + #{$inner-radius + $inner-offset} * #{math.cos($point-angle)});
            opacity: 0;
            background: map.get($circle1-colors2, $i);
          }
        }
      }
    }

    @for $i from 1 through $points {
      $point-angle: $angle * ($i - 1 - $outer-angle-offset);
      $idx: $i + 7;

      &:nth-child(#{$idx}) {
        animation: circle#{$idx} 0.6s steps(18) 0.2s forwards;

        @keyframes circle#{$idx} {
          0% {
            background: map.get($circle2-colors1, $i);
            opacity: 1;
          }

          100% {
            width: 0%;
            height: 0%;
            top: calc(50% - #{math.div($outer-size, 2)} - #{$outer-radius + $outer-offset} * #{math.sin($point-angle)});
            left: calc(50% - #{math.div($outer-size, 2)} + #{$outer-radius + $outer-offset} * #{math.cos($point-angle)});
            opacity: 0;
            background: map.get($circle2-colors2, $i);
          }
        }
      }
    }
  }

  &__heart {
    width: v-bind(size);
    height: v-bind(size);
    will-change: transform;
  }

  &__layer {
    will-change: background, border-width, border-color, border-radius;
  }

  &__point {
    will-change: width, height, top, left, opacity, background;
  }

  &--active &__heart {
    animation: heart 0.2s linear 0.2s forwards;
    transform-origin: center;
    transform: scale(0);
  }

  &--active &__layer {
    box-sizing: border-box;
    animation: layer 0.3s steps(5);
    opacity: 1;
    width: 70%;
    height: 70%;
  }
}
</style>
