<template>
  <teleport to="body">
    <Transition>
      <div v-if="visible" id="gamezone-custom-loading">
        <Loading style="color: rgb(var(--v-theme-primary))" />
      </div>
    </Transition>
  </teleport>
</template>

<script setup lang="ts">
import Loading from '@images/svg/loading.svg'
const visible = ref(false)
defineExpose({
  show() {
    visible.value = true
  },
  hide() {
    visible.value = false
  },
})
</script>
<style lang="scss" scoped>
.v-enter-active,
.v-leave-active {
  transition: opacity 0.5s ease;
}

.v-enter-from,
.v-leave-to {
  opacity: 0;
}

#gamezone-custom-loading {
  position: fixed;
  z-index: 9999;
  left: 0;
  top: 0;
  width: 100vw;
  height: 100vh;
  display: flex;
  align-items: center;
  background: rgba(0, 0, 0, 0.6);
  justify-content: center;
}
</style>
