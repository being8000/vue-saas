<script lang="ts" setup>
  interface Props {
    downDay?: number // 超过{*}天 显示倒计时天
    blockColor?: string
    textColor?: string | undefined | object
    countdowntime: number
    startTime?:number | undefined
  }

  const props = withDefaults(defineProps<Props>(), {
    startTime:0
  })
  const formattedHours = ref<string>('00')
  const formattedMinutes = ref<string>('00')
  const formattedSeconds = ref<string>('00')
  const timer = ref<number>(0)
  const intervalId = ref<number>(0)
  // 触发父组件的方法
  const emit = defineEmits(['countdownemit'])
  // 倒计时
  const startCountdown = (duration: number): void => {
    if (duration < 1) return
    timer.value = duration
    let hours, minutes, seconds
    function fn() {
      hours = Math.floor(timer.value / 3600)
      minutes = Math.floor((timer.value % 3600) / 60)
      seconds = Math.floor(timer.value % 60)
      formattedHours.value = `${hours}`.padStart(2, '0')
      formattedMinutes.value = `${minutes}`.padStart(2, '0')
      formattedSeconds.value = `${seconds}`.padStart(2, '0')
      timer.value -= 1
    }
    fn()
    intervalId.value = window.setInterval(() => {
      fn()
      if (timer.value < 0) {
        clearInterval(intervalId.value)
        emit('countdownemit', timer.value)
      }
    }, 1000)
  }
  // 更新倒计时数据
  const changeCountDown = () => {
    // return timer.value
    // console.log(timer.value)
    emit('countdownemit', timer.value)
  }
  defineExpose({
    changeCountDown,
  })

  const clear = () => {
    if (intervalId.value) {
      clearInterval(intervalId.value)
    }
  }
  const cutdownDays = computed(() => {
    return Math.floor(props.countdowntime / 24 / 60 / 60)
  })
  const downDayNum = computed(() => {
    return props.downDay && cutdownDays.value >= props.downDay
  })
  if (!downDayNum.value) {
    startCountdown(props.countdowntime)
  }
  onUnmounted(() => {
    clear()
  })
</script>

<template>
  <div v-if="timer <= 36000">
    <p v-if="downDayNum" class="tw-text-[12px] tw-text-[#57E142]">{{ cutdownDays }} days remaining</p>
    <p :class="[textColor]">
      <span class="tw-rounded-[5px] tw-text-[14px] tw-font-bold" :class="[blockColor]"
        >{{ formattedHours }}</span
      ><label class="tw-text-[12px]">:</label>
      <span class="tw-rounded-[5px] tw-text-[14px] tw-font-bold" :class="[blockColor]"
        >{{ formattedMinutes }}</span
      ><label class="tw-text-[12px]">:</label>
      <span class="tw-rounded-[5px] tw-text-[14px] tw-font-bold" :class="[blockColor]"
        >{{ formattedSeconds }}</span
      >
    </p>
  </div>
  <div v-else>
    {{ DF.Hm(startTime * 1000) }}
  </div>
</template>
