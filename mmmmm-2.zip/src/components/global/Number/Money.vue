 <script lang="ts" setup>

withDefaults(defineProps<{
  showZero?:boolean
  showPIcon?:boolean
  showAddIcon?:boolean
  num:number
  fontClass?:string
}>(),{
  showPIcon:true,
  showAddIcon:false,
  num:0,
  showZero:true
})
</script>
<template>
<div class="num-money tw-flex tw-relative tw-items-center tw-justify-center tw-font-bold">
  <div v-if="showPIcon" class="p"><img src="/images/jianianhua/icons/p.webp" ></img>
  </div>
  <div class="tw-blod tw-flex tran"> 
    <span class="money" :class="fontClass"><template v-if="showAddIcon">+</template>{{ num }}</span><template v-if="showZero">.<span class="zero">00</span></template>
  </div>
  <!-- <div class="tw-blod tw-flex"> 
    <span v-if="showAddIcon" class="tran">+</span> <span><i class="money">{{ num }}</i>.<i class="zero">00</i></span>
  </div> -->
</div>
</template>

<style lang="scss" scoped>
.num-money{
  color: #FFDF5F;
}
.p{ 
  box-sizing: border-box;
  width: 20px;
  height: 20px;
}
.money{
  font-size: 18px;
  // line-height: 25px;
}
.zero{
  font-size: 12px;
}
.tran{
  display: inline-block;
  transform: matrix(1, 0, -0.17, 0.98, 0, 0);
}
</style>