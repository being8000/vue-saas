<!-- 带logo 页面 -->
<template>
  <div
    ref="refPageContainer"
    class="page-container common-page tw-text-white-600 max-md:tw-w-full max-md:tw-h-full tw-bg-[#04010a] tw-bg-contain bg-no-repeat"
    style="background-position: 0px 3.75rem"
  >
    <VCardTitle
      style="height: 60px; line-height: 60px; padding: 0px"
      class="tw-fixed tw-w-full page-container tw-top-0 tw-z-[1] tw-bg-[#1d1d1d] tw-text-center on-background tw-border-b tw-border-b-[rgba(var(--v-border-color),var(--v-border-opacity))]"
    >
      <v-icon icon="custom-logo" style="width: 12.5rem; height: 2.5rem"></v-icon>
      <div
        class="tw-absolute tw-z-[-1] tw-inset-x-0 tw-h-full tw-w-[8.8125rem] tw-mx-auto tw-bottom-0 tw-translate-y-1/2 tw-opacity-[0.3] tw-bg-[radial-gradient(50%_50%_at_50%_50%,rgb(var(--v-theme-primary))_0%,rgba(var(--v-theme-surface-light-1),0)_100%)]"
      ></div>
      <div
        class="!tw-absolute tw-z-[2] tw-top-0 tw-right-5 tw-h-full tw-flex tw-items-center"
        @click="onAppBack"
      >
        <VIcon
          class="!tw-text-base tw-text-[rgb(var(--v-theme-on-surface-light-1))]"
          icon="custom-close"
        />
      </div>
    </VCardTitle>
    <div style="height: 3.75rem"></div>
    <section class="tw-relative tw-w-full tw-overflow-scroll">
      <slot></slot>
    </section>
  </div>
</template>
<script setup lang="ts">
import { onAppBack } from '@/plugins/hash-page';

const refPageContainer = ref<HTMLElement>()
defineExpose({
  getElement() {
    return toValue(refPageContainer)
  },
})
</script>
<style lang="scss" scoped>
.common-page {
  min-width: min(37.5rem, 100vw);
  min-height: min(18.75rem, 100vh);
  overflow: scroll;
}
</style>
