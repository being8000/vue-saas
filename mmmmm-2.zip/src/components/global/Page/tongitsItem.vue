

<template>
  <div class="tw-relative tw-h-full tw-cursor-pointer tw-overflow-hidden">
    <div
      class="tw-w-full tw-h-full tw-bg-cover tw-py-[9px] bgOne"
    >
    <p class=" tw-h-[14px] tw-absolute tw-top-[4px] tw-right-[4px] tw-px-[4px] tw-py-[1px] tw-bg-[rgba(0,0,0,0.3)] tw-flex tw-justify-center tw-items-center tw-rounded-[10px] tw-min-w-[46px]">
        <span class="tw-w-[12px]">
          <img class=" tw-w-full" src="@images/home/tonight/member_icon.png"/>
        </span>
        <span class="tw-text-[10px] tw-text-[#ffffff] tw-text-center tw-font-medium tw-ml-[2px] tw-leading-[14px]">{{listitem.signUserNum}}</span>
    </p>
      <p
        class="tw-text-center tw-text-[12px] tw-text-[#FFD8BB] tw-font-medium tw-pt-[0.75rem] !tw-pb-[6px]"
      >
      <!-- 0 -->
        <span v-if="listitem.repeatType == 0 || listitem.repeatType == 1">
          <!-- 免费 -->
          <template v-if="listitem.signType == 1">
            4 MATCHES DAILY
          </template>
          <!-- 付费 -->
          <template v-if="listitem.signType == 0">
            <template v-if="listitem.signNum <= 20000 ">Classic</template>
            <template v-else-if="listitem.signNum < 40000 ">Grand</template>
            <template v-else-if="listitem.signNum < 199000 ">Major</template>
            <template v-else>Supreme</template>
          </template>
        </span>
        <span v-if="listitem.repeatType == 2">{{
          listitem.delaySeconds > 30 ? '4 MATCHES DAILY' : listitem.delaySeconds + ' Mins Loop'
        }}</span>
      </p>
      <p
        class="tw-flex tw-items-center tw-justify-center tw-text-[20px] tw-text-[#FFFFFF] tw-font-bold" style="text-shadow: 0px 3px 2px rgba(255, 115, 0, 1);"
      >
        <span class="tw-font-inter tw-text-center">
          <span>₱</span>
          <span class="tw-pl-[0.1rem]">{{$n(Math.floor((listitem.totalPrizeNum) / 1000 || 0))}}</span>
        </span>
      </p>
      <Countdown
        :data-gtp-d="listitem.listId"
        ref="freecount"
        blockColor="tw-px-[1px] tw-py-[2px]"
        textColor="tw-text-[#FF0000]"
        :countdowntime="listitem.countdowntime"
        :startTime="listitem.startTime"
        @countdownemit="endtimefunc"
        class="tw-flex tw-items-center tw-justify-center tw-mt-[0.25rem]"
        style="background: linear-gradient(90deg, rgba(255, 255, 255, 0) 0%, #FFFFFF 50%, rgba(255, 255, 255, 0) 100%);"
      ></Countdown>
      <p class="tw-flex tw-items-center tw-justify-center tw-mt-[0.55rem] tw-text-[#ffffff]" >
        <template v-if="listitem.usersigin">
          <!-- 免费赛跟付费赛报名以后状态展示一致 -->
          <!-- 不可进入比赛 -->
          <template v-if="listitem.serverTime <= listitem.earlyEnterTime">
            <span
              class="tw-grid tw-w-[6rem] tw-h-[1.5rem] tw-place-items-center tw-text-center tw-font-medium tw-text-[0.75rem] tw-rounded-[0.75rem] tw-border tw-border-[#CE0BFF] tw-bg-[linear-gradient(to_bottom,#FFFFFF,#F9DFFF)] tw-text-[#CE0BFF]" 
              style="box-shadow: 0px 2px 4px rgba(157, 0, 255, 0.33)"
              @click="openpop(listitem)" >
              Waiting →
            </span>
          </template>
          <!-- 允许进入比赛 -->
          <template v-if="listitem.serverTime > listitem.earlyEnterTime">
            <span
              class="tw-grid tw-w-[6rem] tw-h-[1.5rem] tw-place-items-center tw-text-center tw-font-medium tw-text-[0.75rem] tw-bg-[linear-gradient(to_right,#FA5CFF,#690BFF)] tw-rounded-[0.75rem]"
              @click="openpop(listitem)" >
              Enter Now
            </span>
          </template>
        </template>
        <template v-else>
          <template v-if="listitem.countdowntime <= 0  && listitem.startStatus == 0">
            <span
              class="tw-grid tw-w-[5.375rem] tw-h-[1.5rem] tw-place-items-center tw-text-center tw-font-medium tw-text-[0.75rem] tw-bg-[#D28040]  tw-rounded-[0.75rem]"
              style="text-shadow: 0px 1px 0px #df6941"
              @click="entertongits()" 
            >
              In Processes
            </span>
          </template>
          <template v-else>
            <!-- 付费赛未报名 -->
            <template v-if="listitem.signType == 0">
              <span
                class="tw-grid tw-w-[6rem] tw-h-[1.5rem] tw-place-items-center tw-text-center tw-font-medium tw-text-[0.75rem] tw-bg-[#FF6600] tw-rounded-[0.75rem]"
                style="text-shadow: 0px 1px 0px #e95505;box-shadow: 0px 0px 5px rgba(255, 98, 0,0.8);"
                @click="openpop(listitem)"
              >
              ₱{{$n(Math.floor(listitem.signNum / 1000 || 0))}} To Join
              </span>
            </template>
            <!-- 免费赛未报名 -->
            <template v-if="listitem.signType == 1">
              <span
                class="tw-grid tw-w-[5.375rem] tw-h-[1.5rem] tw-place-items-center tw-text-center tw-font-medium tw-text-[0.75rem] tw-bg-[#FF6600]  tw-rounded-[0.75rem]"
                style="text-shadow: 0px 1px 0px #df6941;box-shadow: 0px 0px 5px rgba(255, 98, 0, 0.8);"
                @click="entertongits()" 
              >
                Free To Win
              </span>
            </template>
          </template>
        </template>
      </p>
    </div>
  </div>
  <VDialog v-model="showregister">
    <PopDialog @update:showregister="showregisterUpdate" @useSingin="Tingame" :popdetail="clickItem"></PopDialog>
  </VDialog>
  
</template>
<script lang="ts" setup>
  import { TongitsMatchResp } from '@/api/home'
  import Countdown from '@/components/global/Number/Countdown.vue'
  import router from '@/router'
  import PopDialog from '../../tongits/PopDialog.vue'
  const { fetchTongitsSignList } = useTongits()

  const freecount = ref()
  const showregister = ref<boolean>(false)
  const countdownchild = ref();
  const clickItem = ref<TongitsMatchResp>()
  

  interface Props {
    loading?: boolean
    listitem?: TongitsMatchResp
    index: number
  }
  const { $toast } = useNuxtApp()

  const props = withDefaults(defineProps<Props>(), {
    loading: false,
    listitem: () => {
      return {} as TongitsMatchResp
    },
  })
  watch(()=>props.listitem,(data)=>{
    if(data.listId == props.listitem.listId){
      clickItem.value = data;
      clickItem.value.countdowntime = props.listitem.countdowntime;
      clickItem.value.entertime = props.listitem.entertime;
    }else{
      showregister.value = false;
    }
  })
  // 如果倒计时结束不可以跳转
  const endtimefunc = (times: number) => {
    let runtime = props.listitem.countdowntime - times
    props.listitem.countdowntime = times
    props.listitem.entertime = props.listitem.entertime - runtime
  }
  const entertongits = () => {
    // 获取计时器最新的倒计时
    if (freecount.value) {
      freecount.value.changeCountDown()
    }
    if (props.listitem.countdowntime == 0 && props.listitem.startStatus == 0) return
    Tingame(props.listitem)
  }
  // 赛事报名
  async function Tingame(listitem : TongitsMatchResp) {
    const userLoginInfo = await checkLoginStatus(true);
    if(userLoginInfo != true) return
    if (listitem!.countdowntime <= 0) return
    if (listitem!.countdowntime < 60) {
      tongitsGameLobby(listitem)
    } else {
      if (listitem.usersigin) {
        if (listitem.entertime <= 0) {
          enterbtn(listitem)
        } else {
          tongitsGameLobby(listitem)
        }
      } else {
        const url = useRequestURL()
        let params = {
          gameCode: 'C66175',
          platformCode: '175',
          gameId: 'tongits',
          gameName: '',
          gameType: '3',
          gdGameId: '4',
          callbackPath: window.location.origin,
          domainName: url.host,
          lang: 'EN',
          isWithTransfer: '1',
          platformCurrency: 'PHP',
          roomType: '',
          videoId: '',
          jumpParam: '',
          listId: listitem?.listId,
        }
        try {
          const { success, body } = await fetchTongitsInGame(params)
          if (!success) return
          if (body) {
            $toast('Registration Successful !')
            fetchTongitsSignList()
          } else {
            $toast('Registration Unsuccessful !')
          }
          if(showregister.value == true){
            showregister.value = false
          }
        } catch (e) {
          console.error('checkfetchTongitsInGame error', e)
        }
      }
    }
  }
  // 进游戏按钮
  const enterbtn = (item: TongitsMatchResp | undefined) => {
    router.push({
      name: 'game-id',
      params: {
        platformId: '175',
        gameId: 'tongits',
      },
      query: { jumpJson: `{"activity":"matchjoin_${item!.matchId}"}` },
    })
  }
  // 进游戏大厅
  const tongitsGameLobby = (item: TongitsMatchResp | undefined) => {
    router.push({
      name: 'game-id',
      params: {
        platformId: '175',
        gameId: 'tongits',
      },
      query: { jumpJson: `{"activity":"tournament_${item!.listId}"}` },
    })
  }
  const openpop = (data : TongitsMatchResp) => {
  if(props.listitem.countdowntime == 0 && props.listitem.startStatus == 0) return
  // 获取计时器最新的倒计时
  if (countdownchild.value) {
    countdownchild.value.changeCountDown();
  }
  if(data.serverTime - data.signStartTime < 0)  return
  clickItem.value = data;
  clickItem.value.countdowntime = props.listitem.countdowntime;
  clickItem.value.entertime = props.listitem.entertime;
  // 倒计时小于10秒,停止报名
  if(clickItem.value.countdowntime < 10 && clickItem.value.countdowntime >= 0) {
    $toast('The match is in progress, Please join another one.')
  }
  showregister.value = true;
}
  // 更新父组件的状态弹框关闭
  const showregisterUpdate = (newValue :  boolean) =>{
    showregister.value = newValue;
  }
</script>
<style lang="scss" scoped>
.bgOne {
  background: url('@images/home/tonight/tongits_item_bg.png?v2');
  background-size: 100%;
}
:deep(.v-overlay__content){
 width: auto !important;
}
</style>
