<template>
  <Teleport to="body">
    <Transition name="custom-animation" @after-leave="emits('close')">
      
      <div v-if="model" class="page-component-container" >
        
        <slot></slot>
      </div>
    </Transition>
  </Teleport>
</template>

<script setup lang="ts">
const model = defineModel({ type: Boolean, default: false })
const emits = defineEmits(['close'])
const onTouchStart = () => {}
defineExpose({
  show() {
    model.value = true
  },
  hide(){
    model.value = false
  }
})
</script>

<style lang="scss" scoped>
.page-component-container {
  position: fixed;
  z-index: 1500;
  height: 100vh;
  width: 100vw;
  left: 0;
  top: 0;
  display: flex;
  justify-content: center;
  align-items: center;
  font-size: 24px;
  overflow-y: scroll;
  background-color: #030209;
}

.v-enter-active,
.v-leave-active {
  transition: opacity 0.5s ease;
}

.v-enter-from,
.v-leave-to {
  opacity: 0;
}

.custom-animation-enter-active {
  animation: fadeInAndScale 0.25s ease-in-out both;
}

.custom-animation-leave-active {
  animation: fadeOutAndScale 0.25s ease-in-out both;
}

@keyframes fadeInAndScale {
  0% {
    opacity: 0;
    height: 100vh;
    transform: translateY(20%);
  }

  100% {
    opacity: 1;
    height: 100vh;
    transform: translateY(0%);
  }
}

@keyframes fadeOutAndScale {
  0% {
    opacity: 1;
    transform:  translateY(0%);
  }

  100% {
    opacity: 0;
    height: 100vh;
    transform:  translateY(20%);
  }
}
</style>
