<template>
  <v-bottom-sheet v-model="visible" :location="'bottom'" class="page-container" z-index="10000">
    <VCardTitle
      class="box-shadow tw-relative tw-z-[1] tw-rounded-t-2xl tw-text-center on-background tw-border-b tw-border-b-[rgba(var(--v-border-color),var(--v-border-opacity))] tw-shadow-[0px_4px_12px_0px_#0D142599]"
    >
      <div class="tw-relative tw-z-[1] tw-font-semibold">{{ title }}</div>
      <div
        class="tw-absolute tw-z-[-1] tw-inset-x-0 tw-h-[200%] tw-w-[14rem] tw-mx-auto tw-bottom-0 tw-translate-y-1/2 tw-opacity-[0.3] tw-bg-[radial-gradient(50%_50%_at_50%_58%,rgb(var(--v-theme-primary))_0%,rgba(var(--v-theme-surface-light-1),0)_100%)]"
      ></div>
      <div
        class="!tw-absolute tw-z-[2] tw-top-0 tw-right-5 tw-h-full tw-flex tw-items-center"
        @click="onCloseClick"
      >
        <VIcon
          class="!tw-text-base tw-text-[rgb(var(--v-theme-on-surface-light-1))]"
          icon="custom-close"
        />
      </div>
    </VCardTitle>
    <VCard class="select-container-body tw-max-h-[60vh] tw-min-h-[30vh] tw-h-full">
      <slot></slot>
    </VCard>
  </v-bottom-sheet>
</template>

<script setup lang="ts">
const props = defineProps<{
  modelValue: boolean
  title: string
}>()

const emits = defineEmits(['update:modelValue'])
const visible = computed({
  get() {
    return props.modelValue
  },
  set(value) {
    emits('update:modelValue', value)
  },
})
const onCloseClick = () => {
  visible.value = false
}
</script>

<style lang="scss" scoped>
.box-shadow {
  box-shadow: rgba(0, 0, 0, 0.05) 0px 0px 0px 1px, #503d32 0px 0px 0px .3px inset;
  background-color: #1a1512;
}

.select-container-body {
  background-color: #141414;
}
</style>
