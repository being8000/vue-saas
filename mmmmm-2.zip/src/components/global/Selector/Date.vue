<template>
  <Teleport to="body">
    <Container v-model="visible" :title="title || 'Please set Title'">
      <div class="custom-selector">
        <v-date-picker
          color="primary"
          mode-icon="custom-arrow-down-fill"
          prev-icon="custom-arrow-left-circle"
          next-icon="custom-arrow-right-circle"
          v-model="value"
          style="width: 100%"
          v-bind="$attrs"
          @update:model-value="onChange(value)"
        >
          <template #title></template>
          <template #header></template>
        </v-date-picker>
      </div>
    </Container>
  </Teleport>
</template>

<script setup lang="ts">
import Container from './Container.vue'
import { format } from 'date-fns'
const visible = ref(true)
const title = ref('')
const autoClose = ref(true)
let onChangeCache: null | Function = null
let value = ref()
let _formatType = 'yyyy-MM-dd'
const onChange = (date: string | null) => {
  const ftDate = date ? format(date as any, _formatType) : undefined
  onChangeCache && onChangeCache(ftDate)
  if (autoClose.value) {
    visible.value = false
  }
}
defineExpose({
  setOptions({ defaultValue, onChange, title: t, autoClose: ac, field = '', formatType }: any) {
    value.value = defaultValue ? new Date(defaultValue) : undefined
    if (onChange) {
      onChangeCache = onChange
    }

    formatType && (_formatType = formatType)

    autoClose.value = ac === false ? false : true
    title.value = t
    visible.value = true
  },
})
</script>

<style lang="scss" scoped>
.custom-selector {
  width: 100%;
  height: 100%;

  :deep(.v-date-picker) {
    .v-picker-title,
    .v-picker__header {
      display: none;
    }
  }
}
</style>
