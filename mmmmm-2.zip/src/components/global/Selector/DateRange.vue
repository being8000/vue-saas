<template>
  <Teleport to="body">
    <Container v-model="visible" :title="title || 'Please set Title'">
      <div class="custom-selector">
        <section class="tw-px-3 tw-pt-4 tw-pb-1">
          <div class="tw-w-full tw-m-auto tw-grid tw-grid-cols-3 tw-gap-2">
            <VBtn
              v-for="item in showDateList"
              :color="isSame(dateCacheMap[item], value) ? 'primary' : 'surface-light-4'"
              @click="onDays(item)"
            >
              {{ item }} Days
            </VBtn>
          </div>
        </section>
        <v-date-picker
          color="primary"
          mode-icon="custom-arrow-down-fill"
          prev-icon="custom-arrow-left-circle"
          next-icon="custom-arrow-right-circle"
          v-model="value"
          style="width: 100%"
          multiple="range"
          v-bind="computedAttrs"
          @update:model-value="onChange(value)"
        >
          <template #title></template>
          <template #header></template>
        </v-date-picker>
      </div>
    </Container>
  </Teleport>
</template>

<script setup lang="ts">
import { VBtn } from 'vuetify/components'
import Container from './Container.vue'
import { format, isValid, eachDayOfInterval, startOfDay, subDays, parse, isEqual,isToday } from 'date-fns'
const visible = ref(true)
const title = ref('')
const _multiple = ref<boolean | 'range'>(false)
const autoClose = ref(true)
let onChangeCache: null | Function = null
let value = ref<Date[]>([])
let _formatType = 'yyyy-MM-dd'
let dynamicAttrs = reactive<any>({})
const attrs = useAttrs()
const computedAttrs = computed(() => ({ ...dynamicAttrs, ...attrs }))
let momoryList:Date[] = []
const onChange = (date: Date[]) => {
 
  if (!onChangeCache) return
  // 重复点击今天
  if( momoryList.length == 1 &&  date.length == 0 ){
    onChangeCache && onChangeCache([momoryList[0],momoryList[0]].map((e) => format(e, _formatType)))
    autoClose.value && (visible.value = false)  
    momoryList = []
    return
  }
  momoryList = [...date]

  if (date.length == 1 ) {
    const { $toast } = useNuxtApp()
    $toast('Please select end date', {
      position: 'bottom-center',
      autoClose: 1000,
    })
  }
  if (date.length >= 2) {
    value.value = date.filter((e) => isValid(e))
    onChangeCache && onChangeCache(value.value.map((e) => format(e, _formatType)))
    autoClose.value && (visible.value = false)
  }
}
defineExpose({
  setOptions({
    defaultValue,
    onChange,
    title: t,
    autoClose: ac,
    field = '',
    formatType,
    multiple = false,
    limitedDays,
  }: any) {
    defaultValue &&
      (value.value = defaultValue.map((e: string) => parse(e, formatType, new Date())))

    onChange && (onChangeCache = onChange)
    formatType && (_formatType = formatType)

    autoClose.value = ac === false ? false : true
    title.value = t
    visible.value = true
    _multiple.value = multiple
    if (limitedDays) {
      const endDate = startOfDay(new Date())
      const startDate = subDays(endDate, limitedDays - 1)
      dynamicAttrs.min = startDate
      dynamicAttrs.max = endDate
    }
  },
})

const showDateList = ref([3, 7, 30])
const dateCacheMap = reactive<Record<string, Date[]>>({})
const isSame = (d1: Date[], d2: Date[] = value.value) => {
  if (d1?.length < 2 || d2?.length < 2) return false
  return (
    d1.length === d2.length &&
    isEqual(d1[0], d2[0]) &&
    isEqual(d1[d1.length - 1], d2[d1.length - 1])
  )
}
const getDayArr = (days: number): Date[] => {
  if (!dateCacheMap[days]) {
    const endDate = startOfDay(new Date())
    const startDate = subDays(endDate, days - 1)
    const lastDays = eachDayOfInterval({
      start: startDate,
      end: endDate,
    })
    return (dateCacheMap[days] = lastDays)
  } else {
    return dateCacheMap[days]
  }
}
showDateList.value.forEach((days) => getDayArr(days))
const onDays = (days: number) => {
  onChange(getDayArr(days))
}
</script>

<style lang="scss" scoped>
.custom-selector {
  width: 100%;
  height: 100%;

  :deep(.v-date-picker) {
    .v-picker-title,
    .v-picker__header {
      display: none;
    }
  }
}
</style>
