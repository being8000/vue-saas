<template>
  <Teleport to="body">
    <Container v-model="visible" :title="title || 'Please set Title'">
      <div class="search-box" v-if="isShowSearch">
        <SearchTextField
          autofocus
          v-model="bankkeyWord"
          class="tw-mt-2"
          :placeholder="placeholderTitle"
        />
      </div>
      
      <div class="custom-selector">
        <label @change="onChange(item)" v-for="(item, index) in filterOptions" :key="index">
          <input v-model="value" type="radio" :value="item.value" name="custom-selector-options-component">
          <img v-if="item.imgSrc" :src="item.imgSrc" class="tw-size-9 tw-mr-2">
          <div class="left">{{ item.label }}</div>
          <div class="right">
            <CheckTrueSvg class="icon checked animate__animated animate__zoomIn animate__faster" />
            <CheckFalseSvg class="icon default " />
          </div>
        </label>
      </div>
    </Container>
  </Teleport>
</template>

<script setup lang='ts'>
import CheckTrueSvg from '@images/svg/check-2-true.svg'
import CheckFalseSvg from '@images/svg/check-2-false.svg'
import Container from './Container.vue'
import type { SelectOptionsExpose, Option } from './Selectors';
const visible = ref(false)
const title = ref('')
const bankkeyWord  = ref('')
const placeholderTitle = ref('')
const isShowSearch = ref(false)
const debouncedSearch = debouncedRef(bankkeyWord, 400)
const autoClose = ref(true)
const show = () => {
  visible.value = true
}
const options = ref<Option[]>([])
const props = defineProps<{
  modelValue: any,
  key: string | undefined,
}>()
let onChangeCache: null | Function = null
const onChange = (item: any) => {
  onChangeCache && onChangeCache(item)
  if (autoClose.value) {
    visible.value = false
    bankkeyWord.value = ''
  }
}
let value: any = ref()
defineExpose<SelectOptionsExpose<any>>({
  async setOptions({ defaultValue, onChange, title: t, placeholderTitle: i, isShowSearch: b, options: o, labelKey = 'label', valueKey = 'value', autoClose: ac, imgKey:ik }) {
    if (onChange) onChangeCache = onChange
    autoClose.value = ac === false ? false : true
    title.value = t
    placeholderTitle.value = i
    isShowSearch.value = b
    options.value = o.map(el => ({
      label: el[labelKey],
      value: el[valueKey],
      imgSrc: ik ? el[ik] : ''
    }))
    value.value = defaultValue || null
    await nextTick()
    visible.value = true
    console.log('visible.value',visible.value);
  }
})
const filterOptions = computed(() => {
  if (!bankkeyWord.value) {
    return options.value; // 未输入时显示原始数据
  }
  const normalizedSearchText = bankkeyWord.value.toLowerCase();
  return options.value.filter((item:any) => item['label'].toLowerCase().includes(normalizedSearchText)
  );
});
watch(debouncedSearch, () => {
  console.log(debouncedSearch.value,'keywordName')
  // changeBankList(keywordName)
}, {
  deep: true
})
</script>

<style lang="scss" scoped>
.search-box {
  width: 90%;
  height: 40px;
  margin: 0 auto;
}
.custom-selector {
  width: 100%;
  height: 100%;
  min-height: 100vh;
  label {
    width: 95%;
    display: flex;
    background-color: #212121; 
    margin: 10px auto;
    padding: 0px 13px;
    height: 44px;
    line-height: 44px;
    border-radius: 8px;
    align-items: center;
    //  box-shadow: rgba(44, 44, 44, 0.05) 0px 0px 0px 1px, rgb(29, 30, 32) 0px 0px 0px 1px inset;

    .left {
      display: inline-block;
      max-width: calc(100% - 28px);
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
      color: #999999;
      font-size: 16px;
      padding-right: 5px;
    }

    .right {
      width: 28px;
      display: inline-block;
      margin-left: auto;

      .checked {
        display: none;
      }
    }


    &:has(:checked) {
      background-color: #0A0605;
      border: 1px solid #FF6533;
      font-weight: 600;

      .left {
        color: rgb(var(--v-theme-primary));
      }

      .right {

        .icon.checked {
          display: initial;
        }

        .icon.default {
          display: none
        }
      }
    }

    input {
      display: none
    }
  }
}
</style>