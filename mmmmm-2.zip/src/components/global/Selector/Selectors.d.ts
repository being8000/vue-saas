export interface Option {
  label: string
  value: any
  imgSrc?: string
}
type SelectorOptionsReturn<T = any> = {
  show: () => void
}

type SetOptionParams<T = Option> = {
  defaultValue?: any // 默认值
  title: string // 弹框名称
  labelKey?: string // 自定义options中的 key字段
  valueKey?: string // 自定义options中的 value字段
  imgKey?: string // label左侧显示小图片 
  autoClose?: boolean // 选择后自动关闭弹窗
  options: T[],
  placeholderTitle?: string // 搜索框文字
  isShowSearch?: boolean // 是否显示搜索框
  onChange?: (p: Option) => void
}
export interface SelectOptionsExpose<T = Option> {
  setOptions(params: SetOptionParams<T>): any
}
