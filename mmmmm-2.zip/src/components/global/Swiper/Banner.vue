<script lang="ts" setup>
import emblaCarouselVue, { EmblaCarouselVueType } from 'embla-carousel-vue'
import Autoplay from 'embla-carousel-autoplay'
import { Banner } from '@/api/home'
import LazyMediaEmbed from '@/components/global/App/MediaEmbed.vue'
// import LazyCardBannerItem from '@/components/global/Card/BannerItem.vue'
import { UnwrapRef } from 'vue'
import router from '@/router'
type EmblaCarouselType = UnwrapRef<EmblaCarouselVueType[1]> & {}
interface Props {
  banners: Banner[]
  aspectRatio?: number
  showDots?: boolean
}

const props = withDefaults(defineProps<Props>(), {
  banners: () => [],
  aspectRatio: 351 / 100,
  showDots: true,
})
const activeIndex = ref(0)
const [emblaRef, emblaApi] = emblaCarouselVue({ loop: true }, [
  Autoplay({
    playOnInit: true,
    delay: 5000,
    stopOnFocusIn: false,
    stopOnInteraction: false,
    stopOnMouseEnter: false,
    stopOnLastSnap: false,
  }),
])
const onInit = (emblaApi: EmblaCarouselType) => {
  activeIndex.value = emblaApi.internalEngine().index.get()
}
const onSelect = (emblaApi: EmblaCarouselType) => {
  activeIndex.value = emblaApi.internalEngine().index.get()
}
onMounted(() => {
  emblaApi.value?.on('reInit', onInit).on('init', onInit).on('select', onSelect)
})

const onBannerClick = (banner: Banner) => {
  const { gameId, platformId, jumpJson, jsonParam } = banner
  if (banner.redirectCategory == 3) {
    router.push({
      name: 'game-id',
      params: { platformId, gameId: gameId },
      query: { jumpJson: jsonParam },
    })
  }
}
</script>

<template>
  <!-- 首页banner  -tw-mt-[calc(var(--v-toolbar-content-height)+var(--v-toolbar-extension-height)+0.75rem)]-->
  <div v-if="banners.length" class="tw-relative" @touchstart.stop @mousedown.stop>
    <div class="tw-flex">
      <VResponsive :aspectRatio="aspectRatio">
        <div class="tw-overflow-hidden tw-relative tw-z-[2] tw-flex-1" ref="emblaRef">
          <div class="tw-flex tw-gap-1">
            <div
              v-for="(banner, index) in banners"
              :key="banner.id"
              class="tw-shrink-0 tw-grow-0 tw-basis-full tw-px-[0.15rem]"
              :data-gtp-d="`b_${index}`"
              :id="index.toString()"
            >
              <div
                class="tw-relative tw-cursor-pointer tw-overflow-hidden"
                :type="(banner?.subCategory as string)"
                :link="banner?.redirectLink"
                :platformId="banner?.platformCode"
                :gameId="banner?.gameId"
                :jumpJson="banner?.jumpJson"
                @click="onBannerClick(banner)"
              >
                <!-- <div v-if="showToolbar" class="tw-h-[calc(var(--v-toolbar-content-height)+var(--v-toolbar-extension-height)+0.75rem)]"></div> -->
                <LazyMediaEmbed
                  class="tw-rounded-lg"
                  pointer="none"
                  :src="banner.imgUrl || banner.picUrl"
                  :aspectRatio="aspectRatio"
                />
              </div>
            </div>
          </div></div
      ></VResponsive>
    </div>

    <div
      v-if="showDots && banners.length && banners.length > 1"
      class="tw-mt-2 tw-h-1 tw-flex tw-items-center tw-z-[9] tw-justify-center tw-gap-2"
    >
      <span
        v-for="(_, i) in banners.length"
        :key="i"
        class="tw-bg-[#39373D] tw-w-2 tw-h-1 tw-rounded-full tw-duration-300 tw-ease-linear"
        :class="[activeIndex == i ? 'tw-w-9 act' : 'tw-opacity-50 tw-transform-[width]']"
        @click="emblaApi?.scrollTo(i)"
      ></span>
    </div>
  </div>
  <!-- <LazyVerticalNavLink v-if="isPokerPage" :type="gameJumpType" platformId="175" gameId="live" :jumpJson="''">
    <div class="tw-relative tw-px-3">
      <VImg class="tw-w-full tw-mx-auto" :src="livestream" :aspectRatio="366 / 150" />
      <LivestreamBar class="tw-absolute tw-left-4 tw-top-7"/>
    </div>
  </LazyVerticalNavLink> -->
  <!-- <qrjWidget @close="onCloseQrj"/> -->
</template>
<style>
.act {
  /* background: linear-gradient(317.49deg, #ffd67d 28.26%, #ff821b 100.27%); */
  /* box-shadow: 0px 0px 6px rgba(255, 123, 57, 0.9); */
  border-radius: 10px;
  width: 16px;
  background: linear-gradient(90deg, #fe823d 0%, #fd5c1d 100%);
}
</style>
