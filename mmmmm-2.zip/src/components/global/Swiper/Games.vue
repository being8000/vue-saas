<script lang="ts" setup>
import type { RouteLocationRaw } from 'vue-router'
import emblaCarouselVue from 'embla-carousel-vue'
import type { EmblaCarouselVueType } from 'embla-carousel-vue'
import type { UnwrapRef } from 'vue'
import { GameBaseItem } from '@/api/game'
import { chunk } from 'lodash-es'
import LazyCardItemsBar from '@/components/global/Card/ItemsBar.vue'
import LazyCardGameItem from '@/components/global/Card/GameItem.vue'

type EmblaCarouselType = UnwrapRef<EmblaCarouselVueType[1]> & {}

interface Props {
  icon?: string
  title?: string
  themeTitle?: string
  slidesPerView?: number
  scaler?: number
  viewBtn?: boolean
  to?: RouteLocationRaw
  games?: GameBaseItem[]
  rows?: number
  cols?: number
  max?: number
  spaceBetween?: number
}

const props = withDefaults(defineProps<Props>(), {
  icon: 'custom-provider',
  title: 'N/A',
  scaler: 1.1,
  viewBtn: true,
  rows: 1,
  cols: 3,
  max: 18,
  spaceBetween: 0.625,
})

const games = computed(() => {
  return props.games?.slice(0, props.max) || []
})

const activeIndex = ref(0)

const onViewClick = () => {}
const showItemsbarSwiper = computed(() => {
  return games.value.length > props.rows * props.cols
})

const [emblaRef, emblaApi] = emblaCarouselVue({ slidesToScroll: 'auto', align: 'start' })
const prevBtnDisabled = ref(true)
const nextBtnDisabled = ref(true)
const setPrevBtnDisabled = (disabled: boolean) => {
  prevBtnDisabled.value = disabled
}
const setNextBtnDisabled = (disabled: boolean) => {
  nextBtnDisabled.value = disabled
}
const onPrevClick = () => {
  if (!emblaApi.value) return
  emblaApi.value.scrollPrev()
}
const onNextClick = () => {
  if (!emblaApi.value) return
  emblaApi.value.scrollNext()
}

const onSelect = (emblaApi: EmblaCarouselType, evt: string) => {
  activeIndex.value = emblaApi.internalEngine().index.get()
  setPrevBtnDisabled(!emblaApi.canScrollPrev())
  setNextBtnDisabled(!emblaApi.canScrollNext())
}
onMounted(() => {
  emblaApi.value?.on('init', onSelect).on('reInit', onSelect).on('select', onSelect)
})

const onReInit = () => {
  setTimeout(() => {
    const [emblaRef, emblaApi] = emblaCarouselVue({ slidesToScroll: 'auto', align: 'start' })
  }, 1000)
}
</script>

<template>
  <LazyCardItemsBar
    :swiper="showItemsbarSwiper"
    :viewBtn="viewBtn"
    :title="title"
    :icon="icon"
    :themeTitle="themeTitle"
    :to="to"
    :isBeginning="prevBtnDisabled"
    :isEnd="nextBtnDisabled"
    @click:prev="onPrevClick"
    @click:next="onNextClick"
    @click:view="onViewClick"
    @reInit="onReInit"
    extraClass="tw-px-3"
  >
    <section
      class="tw-m-auto tw-relative"
      :style="`
        --slide-spacing: ${spaceBetween}rem;
        --slide-size: calc(${100 / cols + 1}%  );
      `"
      @touchstart.stop
      @mousedown.stop
    >
      <div class="tw-overflow-hiddens tw-px-6 tw-overflow-hidden" ref="emblaRef">
        <div
          class="backface-hidden tw-flex tw-touch-pan-y tw-touch-pinch-zoom tw-ml-[calc(var(--slide-spacing)*-1)]"
        >
          <div
            v-for="(rows, oIdx) in chunk(games, rows)"
            :key="oIdx"
            class="tw-min-w-0 tw-flex-[0_0_var(--slide-size)] tw-pl-[var(--slide-spacing)] tw-flex tw-flex-col tw-gap-[var(--slide-spacing)]"
          >
            <LazyCardGameItem
              :data-gtp-d="`item_${index}`"
              :class="[
                activeIndex === 0 ? 'tw-translate-x-[-0.75rem]' : '',
                activeIndex !== 0 && activeIndex == chunk(games, props.rows).length / cols - 1
                  ? 'tw-translate-x-[0.75rem]'
                  : '',
              ]"
              v-for="(game, index) in rows"
              :key="index"
              :game="game"
              :spider="oIdx == 0 && index == 0 && Math.random() > 0.5"
            />
          </div>
        </div>
      </div>
    </section>
  </LazyCardItemsBar>
</template>
