<script lang="ts" setup>
import emblaCarouselVue from 'embla-carousel-vue'
import Autoplay from 'embla-carousel-autoplay'
import type { EmblaCarouselVueType } from 'embla-carousel-vue'
import type { UnwrapRef } from 'vue';

type EmblaCarouselType = UnwrapRef<EmblaCarouselVueType[1]> & {}

const activeIndex = ref(0)

const { showPosterBanners, posterBanners } = usePoster()

const LazyVerticalNavLink = defineAsyncComponent(() => import('~/layouts/components/VerticalNavLink.vue'))

const [emblaRef, emblaApi] = emblaCarouselVue({ loop: true }, [
    Autoplay({ playOnInit: true, delay: 3000 })
])
const onSelect = (emblaApi: EmblaCarouselType, _evt: string) => {
    activeIndex.value = emblaApi.internalEngine().index.get()
}
onMounted(() => {
    emblaApi.value?.on('reInit', onSelect).on('init', onSelect).on('select', onSelect)
})

const onPosterClick = (_index: number) => {
    showPosterBanners.value = false
}
</script>

<template>
    <div class="tw-relative">
        <div class="tw-overflow-hidden" ref="emblaRef">
            <div class="tw-flex">
                <div v-for="(banner, index) in posterBanners" :key="banner.id"
                    class="tw-shrink-0 tw-grow-0 tw-basis-full">
                    <LazyVerticalNavLink class="tw-flex-1" :type="(banner?.subCategory as string)"
                        :link="banner?.redirectLink" :platformId="banner?.platformCode" :gameId="banner?.gameId"
                        :jumpJson="banner?.jumpJson" @click="onPosterClick(index)">
                        <VImg cover class="tw-w-full tw-mx-auto tw-object-cover tw-object-[center] tw-rounded-3xl"
                            :src="banner.imgUrl" :aspectRatio="366 / 468" />
                    </LazyVerticalNavLink>
                </div>
            </div>
        </div>
        <div class="tw-h-7 tw-flex tw-items-center tw-z-[9] tw-justify-end tw-gap-2 tw-absolute tw-bottom-0 tw-right-4">
            <span v-for="(_, i) in posterBanners.length" :key="i"
                class="tw-bg-white tw-size-1 tw-rounded-full tw-duration-300 tw-ease-linear"
                :class="[activeIndex == i ? 'tw-w-9' : 'tw-opacity-50 tw-transform-[width]']"
                @click="emblaApi?.scrollTo(i)"></span>
        </div>
    </div>
</template>
