<script lang="ts" setup>
import type { RouteLocationRaw } from 'vue-router';
import emblaCarouselVue from 'embla-carousel-vue'
import type { EmblaCarouselVueType } from 'embla-carousel-vue'
import type { UnwrapRef } from 'vue';
import { chunk } from 'lodash-es'
import LazyCardItemsBar from '@/components/global/Card/ItemsBar.vue'
import LazyCardProviderItem from '@/components/global/Card/ProviderItem.vue'
import providersImg from '~/assets/images/theme/home/providers.png'

interface Props {
  icon?: string
  title?: string
  to?: RouteLocationRaw
}

withDefaults(defineProps<Props>(), {
  icon: 'custom-provider',
  title: 'N/A',
})

const slidesPerView = ref(3)
const scaler = ref(1.033)
const rows = ref(2)
const activeIndex = ref(0)
const { providers } = useBlock()

const showItemsbarSwiper = computed(() => {
  return providers.value.length > (rows.value * slidesPerView.value)
})

type EmblaCarouselType = UnwrapRef<EmblaCarouselVueType[1]> & {}

const [emblaRef, emblaApi] = emblaCarouselVue({ slidesToScroll: 'auto' })
const prevBtnDisabled = ref(true)
const nextBtnDisabled = ref(true)
const setPrevBtnDisabled = (disabled: boolean) => {
  prevBtnDisabled.value = disabled
}
const setNextBtnDisabled = (disabled: boolean) => {
  nextBtnDisabled.value = disabled
}
const onPrevClick = () => {
  if (!emblaApi.value) return
  emblaApi.value.scrollPrev()
}
const onNextClick = () => {
  if (!emblaApi.value) return
  emblaApi.value.scrollNext()
}

const onSelect = (emblaApi: EmblaCarouselType, evt: string) => {
  activeIndex.value = emblaApi.internalEngine().index.get()
  setPrevBtnDisabled(!emblaApi.canScrollPrev())
  setNextBtnDisabled(!emblaApi.canScrollNext())
}
onMounted(() => {
  emblaApi.value?.on('init', onSelect).on('reInit', onSelect).on('select', onSelect)
})

</script>

<template>
  <LazyCardItemsBar data-gtp-c="game_providers" extraClass="tw-px-3" :swiper="showItemsbarSwiper" viewBtn :title="title" :icon="icon" :themeTitle="providersImg" :to="to"
    :isBeginning="prevBtnDisabled" :isEnd="nextBtnDisabled" @click:prev="onPrevClick" @click:next="onNextClick">
    <section class="tw-m-auto tw-relative tw-px-3" :style="`
        --slide-spacing: 0.625rem;
        --slide-size: ${100 / (slidesPerView * scaler)}%;
      `" @touchstart.stop  @mousedown.stop>
      <div class="tw-overflow-hidden" ref="emblaRef">
        <div class="backface-hidden tw-flex tw-touch-pan-y tw-touch-pinch-zoom tw-ml-[calc(var(--slide-spacing)*-1)]">
          <div v-for="(rows, index) in chunk(providers, 2)" :key="index"
            class="tw-min-w-0 tw-flex-[0_0_var(--slide-size)] tw-pl-[var(--slide-spacing)] tw-flex tw-flex-col tw-gap-[var(--slide-spacing)]">
            <div v-for="provider in rows" :key="provider.platformId">
              <LazyCardProviderItem :src="provider.imgUrl"
                :data-gtp-d="`item_${index}`"
                @click="$router.push({ name: 'home-tab-games-provider-id', params: { tab: 'all', id: `${(provider.platformName || '').toLowerCase()}` } })" />
            </div>
          </div>
        </div>
      </div>
    </section>
  </LazyCardItemsBar>
</template>
