<script lang="ts" setup>
import type { RouteLocationRaw } from 'vue-router';
import emblaCarouselVue from 'embla-carousel-vue'
import type { EmblaCarouselVueType } from 'embla-carousel-vue'
import type { UnwrapRef } from 'vue';
import { chunk } from 'lodash-es'
import LazyCardItemsBar from '@/components/global/Card/ItemsBar.vue'
import LazyCardGameItem from '@/components/global/Card/GameItem.vue'
import recentGamesImg from '~/assets/images/theme/home/recent-games.png'

type EmblaCarouselType = UnwrapRef<EmblaCarouselVueType[1]> & {}

interface Props {
  icon?: string
  title?: string
  scaler?: number
  viewBtn?: boolean
  to?: RouteLocationRaw
  rows?: number
  cols?: number
  max?: number
  spaceBetween?: number
}

const props = withDefaults(defineProps<Props>(), {
  icon: 'custom-provider',
  title: 'N/A',
  scaler: 1.1,
  viewBtn: true,
  rows: 1,
  cols: 4,
  max: 20,
  spaceBetween: 0.625,
})
const { games: allGames, fetchList } = useRecentGame()
fetchList() 
const games = computed(() => {
  return allGames.value.slice(0, props.max)
})

const activeIndex = ref(0)

const onViewClick = () => {
}

const showItemsbarSwiper = computed(() => {
  return games.value.length > (props.rows * props.cols)
})

const [emblaRef, emblaApi] = emblaCarouselVue({ slidesToScroll: 'auto' })
console.log(emblaApi, 'emblaApi')
const prevBtnDisabled = ref(true)
const nextBtnDisabled = ref(true)
const setPrevBtnDisabled = (disabled: boolean) => {
  prevBtnDisabled.value = disabled
}
const setNextBtnDisabled = (disabled: boolean) => {
  nextBtnDisabled.value = disabled
}
const onPrevClick = () => {
  if (!emblaApi.value) return
  emblaApi.value.scrollPrev()
}
const onNextClick = () => {
  if (!emblaApi.value) return
  emblaApi.value.scrollNext()
}

const onSelect = (emblaApi: EmblaCarouselType, evt: string) => {
  activeIndex.value = emblaApi.internalEngine().index.get()
  setPrevBtnDisabled(!emblaApi.canScrollPrev())
  setNextBtnDisabled(!emblaApi.canScrollNext())
}
onMounted(() => {
  emblaApi.value?.on('init', onSelect).on('reInit', onSelect).on('select', onSelect)
})
</script>

<template>
  <LazyCardItemsBar data-gtp-c="recent_game" v-if="games.length" :swiper="showItemsbarSwiper" :viewBtn="viewBtn" :title="title" :icon="icon"
    :themeTitle="recentGamesImg" :to="to" :isBeginning="prevBtnDisabled" :isEnd="nextBtnDisabled"
    @click:prev="onPrevClick" @click:next="onNextClick" @click:view="onViewClick"  extraClass="tw-px-3">
    <section class="tw-m-auto tw-relative" :style="`
        --slide-spacing: ${spaceBetween}rem;
        --slide-size: calc(${(100 / cols ) }%);
      `" @touchstart.stop  @mousedown.stop>
      <div class="tw-overflow-hidden tw-px-6" ref="emblaRef">
        <div class="backface-hidden tw-flex tw-touch-pan-y tw-touch-pinch-zoom tw-ml-[calc(var(--slide-spacing)*-1)]">
          <div v-for="(rows, index) in chunk(games, rows)" :key="index"
            class="tw-min-w-0 tw-flex-[0_0_var(--slide-size)] tw-pl-[var(--slide-spacing)] tw-flex tw-flex-col tw-gap-[var(--slide-spacing)]">
            <div v-for="(game, index) in rows" :key="index" 
            :class="[
              activeIndex === 0 ? 'tw-translate-x-[-0.75rem]' : '',
              activeIndex !== 0 && activeIndex == chunk(games, props.rows).length / cols - 1 ? 'tw-translate-x-[0.75rem]' : ''
            ]">
              <LazyCardGameItem :game="game" :data-gtp-d="`item_${index}`" />
            </div>
          </div>
        </div>
      </div>
    </section>
  </LazyCardItemsBar>
</template>
