<script lang="ts" setup>
import { Swiper, SwiperSlide } from 'swiper/vue';
import type { Swiper as SwiperClass } from 'swiper';
import type { SwiperModule } from 'swiper/types';
import LazyCardVip from '@/components/global/Card/Vip.vue'
import { VipInfoData } from '@/api/vip';
import LazyDialogNotices from '@/components/global/Dialog/Notices.vue'
const vipInfoStore = useVipInfoStore()

const modules: SwiperModule[] = []
const swiper = ref<SwiperClass | null>(null)
const activeIndex = ref(0)
const length = computed(() => {
  return vipInfoStore.value.data?.length || 0
})

const onSwiper = (_swiper: SwiperClass) => {
  swiper.value = _swiper
  let cv:number = vipInfoStore.value.currentLevel || 0
  swiper.value?.slideTo((cv == 0 ? vipInfoStore.value.maxLevel : cv - 1 )as number , 0, true)
  // 0-- 15
  // 1    0
  // 2    1
  // 15   14
  // jump2Level()
}

const jump2Level = () => {
  const levelIndex = (vipInfoStore.value.currentLevel || 0)
  if (swiper.value?.activeIndex !== levelIndex) {
    swiper.value?.slideTo(levelIndex+1, 0, true)
  }
}

// NOTE Nuxt Bug @see https://github.com/nuxt/nuxt/issues/25755
const id = useId().replace('_', '-')

const pathId = computed(() => {
  return `level_path_${id}`
})

const progress = ref<number>(0)

const onProgress = (swiper: SwiperClass, _progress: number) => {
  progress.value = _progress
}

const onTransitionEnd = (swiper: SwiperClass) => {
  // activeIndex.value = swiper.activeIndex || 0
  // vipInfoStore.value.activeLevel = activeIndex.value > 15 ? activeIndex.value - 15  : activeIndex.value
  // activeIndex.value = vipInfoStore.value.activeLevel
  console.log(swiper)
  let acEl = document.querySelector('.swiper-slide-active')
  console.log(acEl?.getAttribute('data-swiper-slide-index'))
  let transitionIndex:number = +(acEl?.getAttribute('data-swiper-slide-index') || 0)
  let v = transitionIndex + 1 >= 16 ? transitionIndex + 1 - 16 : transitionIndex + 1
  vipInfoStore.value.activeLevel = v >= 16 ? 0 : v
}


const lerp = (start: number, end: number, t: number) => {
  return start + (end - start) * t
}

const initOffset = 1

const genPoints = () => {
  const pointLength = length.value + initOffset
  const emptyLength = pointLength - 4
  const sgDistances = [
    [40, 45],
    [25, 40],
    [10, 25],
    [5, 10],
    ...Array.from({ length: emptyLength }).fill([0, 5]) as number[][]
  ]
  const sgCurColors = [
    [97, 61, 50, 1],
    [255, 101, 51, 1],
    [99, 93, 93, 1],
    [99, 93, 93, 0],
    ...Array.from({ length: emptyLength }).fill([99, 93, 93, 0]) as number[][]
  ]
  const sgTargetColors = [
    [97, 61, 50, 0],
    [97, 61, 50, 1],
    [255, 101, 51, 1],
    [99, 93, 93, 1],
    ...Array.from({ length: emptyLength }).fill([99, 93, 93, 0]) as number[][]
  ]
  const sgCurCircleColors = [
    [97, 61, 50, 1],
    [255, 255, 255, 1],
    [99, 93, 93, 1],
    [99, 93, 93, 0],
    ...Array.from({ length: emptyLength }).fill([99, 93, 93, 0]) as number[][]
  ]
  const sgTargetCircleColors = [
    [97, 61, 50, 0],
    [97, 61, 50, 1],
    [255, 255, 255, 1],
    [99, 93, 93, 1],
    ...Array.from({ length: emptyLength }).fill([99, 93, 93, 0]) as number[][]
  ]

  const ret = []

  for (let i = 0; i < pointLength; i++) {
    const distance = computed(() => {
      const _sgDistances = sgDistances.slice(0, i + 1).reverse()
      const index = swiper.value?.swipeDirection === 'next' ? Math.min(activeIndex.value, _sgDistances.length - 1) : Math.max(0, (Math.min(activeIndex.value, _sgDistances.length) - 1))
      const target = _sgDistances[index][1]
      const point = _sgDistances[index][0]
      const ratio = (progress.value * (length.value - 1)) - index
      const offset = point + Math.min((target - point) * ratio, target - point)
      return offset
    })
    const color = computed(() => {
      const _sgDistances = sgDistances.slice(0, i + 1).reverse()
      const index = swiper.value?.swipeDirection === 'next' ? Math.min(activeIndex.value, _sgDistances.length - 1) : Math.max(0, (Math.min(activeIndex.value, _sgDistances.length) - 1))
      const target = _sgDistances[index][1]
      const point = _sgDistances[index][0]
      const t = (distance.value - point) / (target - point)
      const _sgCurColors = sgCurColors.slice(0, i + 1).reverse()
      const _sgTargetColors = sgTargetColors.slice(0, i + 1).reverse()
      const curColor = _sgCurColors[index]
      const targetColor = _sgTargetColors[index]
      const r = lerp(curColor[0], targetColor[0], t)
      const g = lerp(curColor[1], targetColor[1], t)
      const b = lerp(curColor[2], targetColor[2], t)
      const a = lerp(curColor[3], targetColor[3], t)
      return `rgba(${r}, ${g}, ${b}, ${a})`
    })
    const circleColor = computed(() => {
      const _sgDistances = sgDistances.slice(0, i + 1).reverse()
      const index = swiper.value?.swipeDirection === 'next' ? Math.min(activeIndex.value, _sgDistances.length - 1) : Math.max(0, (Math.min(activeIndex.value, _sgDistances.length) - 1))
      const target = _sgDistances[index][1]
      const point = _sgDistances[index][0]
      const t = (distance.value - point) / (target - point)
      const _sgCurColors = sgCurCircleColors.slice(0, i + 1).reverse()
      const _sgTargetColors = sgTargetCircleColors.slice(0, i + 1).reverse()
      const curColor = _sgCurColors[index]
      const targetColor = _sgTargetColors[index]
      const r = lerp(curColor[0], targetColor[0], t)
      const g = lerp(curColor[1], targetColor[1], t)
      const b = lerp(curColor[2], targetColor[2], t)
      const a = lerp(curColor[3], targetColor[3], t)
      return `rgba(${r}, ${g}, ${b}, ${a})`
    })
    ret.push({
      distance,
      color,
      circleColor
    })
  }
  return ret
}
// const points = genPoints()
// const { width } = useElementSize(el)
// const el = ref(null)

watch(() => vipInfoStore.value.currentLevel, jump2Level, {
  immediate: true
})

let computedData = computed<VipInfoData[]>(()=>{
  return [...vipInfoStore.value.data,...vipInfoStore.value.data]
})

const currentVipDataInfo = computed(()=>{
  return vipInfoStore.value.data[vipInfoStore.value.activeLevel || 0]  
})
const isMaxLevel = computed(() => {
  return ((vipInfoStore.value.data?.length || 0) - 1) === vipInfoStore.value.activeLevel
})
const isLocked = (level:number) => {
  return vipInfoStore.value.currentLevel < level
}
// let data = [vipInfoStore.value.data[14],...vipInfoStore.value.data]  
</script>

<template>
  <div class="tw-select-none">
    <!-- REVIEW Swiper性能很差 -->
    <Swiper observer observeParents observeSlideChildren  :resistanceRatio="0" :modules="modules"
      :slidesPerView="3" :loop="true" @afterInit="onSwiper" @progress="onProgress"
      @slideChangeTransitionEnd="onTransitionEnd"
      >
      <SwiperSlide v-for="(item, index) in computedData" :key="index"
       class="first:!tw-ml-[5px]"
       >
       <!-- <div class="currentLevel">
      {{ item.vipLevel }}
       </div> -->
        <!-- <LazyCardVip :item="item" />  -->
         <div class="tw-w-[116px] tw-h-[200px] tw-relative">
          <img v-if="item.background" :src="item.background" style="height:200px">
          <img v-else src="/src/assets/images/vip/vip-bg.png" style="height:200px">
          <div style="transition: all 0.5s;" class="tw-text-[14px] tw-absolute tw-top-[25%] tw-w-full" :class="{'!tw-top-[20%]':vipInfoStore.activeLevel==item.vipLevel}">
            <p :style="{color:item.textColor}" class="tw-text-center tw-w-full" :class="{'tw-font-bold tw-text-[16px] !tw-text-white':vipInfoStore.activeLevel==item.vipLevel}">{{ item.vipName }}</p>
            <img :src="item.vipIcon" class="tw-size-[67px] tw-m-auto" :class="{'tw-size-[80px]':vipInfoStore.activeLevel==item.vipLevel}">
          </div>
          <!-- ANCHOR 当前等级图标 -->
          <img class="tw-absolute tw-bottom-[16%] tw-z-10" v-if="item.vipLevel == vipInfoStore.currentLevel" src="/src/assets/images/vip/current-level.png">
          <!-- ANCHOR locked图标 -->
          <div v-if="isLocked(item.vipLevel)" class="tw-absolute  tw-bottom-[15%] tw-left-[25px] tw-rounded-lg tw-w-[64px] tw-text-[12px] tw-h-[18px] tw-flex tw-bg-[rgba(0,0,0,.5)] tw-items-center tw-pl-[5px] tw-text-[#999999]">
            <VIcon class="tw-mr-1" color="#999999" icon="custom-locked" size="12"/> Locked
          </div>
         </div>
      </SwiperSlide>
    </Swiper>
    <div ref="el" class="tw-relative tw-px-3 tw-h-[80px]">
      <div class="tw-relative"> 
        <img src="/src/assets/images/vip/line.png" alt="">
        <div class="tw-absolute tw-left-[14%] tw-top-[2%] tw-text-center tw-w-[30px] tw-text-[#613D32]">V{{ vipInfoStore.activeLevel == 0 ? vipInfoStore.maxLevel : vipInfoStore.activeLevel!-1 }}</div>
        <div class="tw-absolute tw-left-[47%] tw-bottom-[50%] tw-text-center tw-w-[30px] tw-text-primary tw-font-bold" >V{{ vipInfoStore.activeLevel }}</div>
        <div class="tw-absolute tw-right-[10%] tw-top-[2%] tw-text-center tw-w-[30px] tw-text-[#613D32]">V{{vipInfoStore.activeLevel == vipInfoStore.maxLevel ? 0 : vipInfoStore.activeLevel!+1}}</div>
      </div>
      <!-- <img src="/src/assets/images/vip/vip-point.png" class="tw-absolute tw-size-6 tw-bottom-0 tw-left-0 tw-right-0 tw-m-auto" alt=""> -->
 
      <!-- <svg class="tw-text-primary tw-w-full" viewBox="0 0 387 58" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path :id="pathId"
          d="M0 0C16.3305 15.4006 50.4571 34.4731 83.9055 43.6959C117.354 52.9186 156.373 57.8833 196.313 57.9981C236.253 58.1129 275.428 53.3731 309.171 44.3435C342.913 35.3139 369.799 22.3754 386.624 7.07008L369.622 15.0003C353.803 26.5003 336.616 32.481 304.337 41.119C272.058 49.7569 234.582 54.2912 196.374 54.1813C158.167 54.0715 120.84 49.3222 88.8425 40.4995C56.8449 31.6767 27.2223 20.195 11.6001 5.4624L0 0Z"
          :fill="`url(#paint0_linear_1143_19099_${id})`" />
        <defs>
          <linearGradient :id="`paint0_linear_1143_19099_${id}`" x1="21.0911" y1="30.0005" x2="365.403" y2="30.5565"
            gradientUnits="userSpaceOnUse">
            <stop stop-color="currentColor" stop-opacity="0" />
            <stop offset="0.217801" stop-color="currentColor" stop-opacity="0.2" />
            <stop offset="0.514004" stop-color="currentColor" />
            <stop offset="0.755926" stop-color="currentColor" stop-opacity="0.2" />
            <stop offset="1" stop-color="currentColor" stop-opacity="0" />
          </linearGradient>
        </defs>
      </svg> -->
      <!-- <div class="tw-rounded-[50%] tw-absolute tw-inset-x-0 tw-bottom-0 tw-left-[2%] tw-h-[275%]">
        <div v-for="(point, index) in points" :key="index"
          class="tw-w-[3%] tw-pb-[3%] tw-transition-all tw-will-change-[offset-distance,color,background-color] tw-ease-linear tw-rounded-[50%] tw-absolute level-center tw-text-center tw-flex tw-justify-center tw-items-center"
          :style="{
            offsetPath: `ellipse(51% 49% at 50% 50%)`,
            offsetRotate: '0deg',
            offsetDistance: `${point.distance.value}%`,
            color: point.color.value,
            backgroundColor: point.color.value,
            opacity: index < initOffset ? 0 : 1
          }">
          <div class="tw-absolute tw-inset-[10%] tw-rounded-[50%] tw-will-change-[color,background-color]" :style="{
            backgroundColor: point.circleColor.value
          }"></div>
          <div class="tw-absolute tw-inset-[16%] tw-rounded-[50%] tw-will-change-[color,background-color]" :style="{
            backgroundColor: point.color.value
          }"></div>
          <div
            class="tw-absolute tw-whitespace-nowrap tw-text-center -tw-left-1/2 tw-top-[-180%] tw-font-semibold tw-text-xs tw-w-[200%]"
            :style="{
              fontSize: `${width / 5}%`
            }">V{{ index - initOffset }}</div>
        </div>
      </div> -->
    </div>
    
    <div class="tw-px-3 tw-mt-3 tw-text-[12px]">
      <div class=" tw-flex tw-gap-1 tw-items-center on-background tw-text-base tw-font-bold tw-capitalize">
        <img class="tw-size-7" src="/src/assets/images/vip/to-next-level.png" loading="lazy" decoding="async" />
        <span v-show="!isMaxLevel">To Next Level</span>
        <span v-show="isMaxLevel">ALL LEVELS UNLOCKED</span>
      </div>
      <div class="tw-mt-2 tw-relative">
        <img src="/src/assets/images/vip/to-next-level-bg.png" loading="lazy" decoding="async" />
        <div class="tw-flex tw-absolute tw-inset-0 tw-z-10 tw-text-black tw-p-4">
          <div class="tw-flex-1 tw-h-full">
            <div class="tw-flex tw-items-center">
              <span class="tw-capitalize tw-mr-1" >Wager</span>
              <LazyDialogNotices  content="Data will be reflected within 24 hours.">
                <template #default="{ props }">
                  <VIcon v-bind="props" icon="custom-warning"/>
                </template>
              </LazyDialogNotices>
            </div>
            <div class="tw-mt-3 tw-text-white">
              <span class="tw-text-primary">{{ $n(Number(currentVipDataInfo.currentBetAmount), 'decimal') }} <span v-show="!isMaxLevel">/</span>
              </span>
              <span v-show="!isMaxLevel" class="tw-text-black"> {{ $n(Number(currentVipDataInfo.nextBetAmount), 'decimal') }}</span>
            </div>
            <div class="tw-relative tw-rounded-full tw-overflow-hidden tw-bg-white tw-w-[83%] tw-h-[10%]">
              <div class="tw-size-full tw-bg-primary tw-rounded-md" :style="{
                width: !currentVipDataInfo.currentBetAmount ? '0%' : `${Number(currentVipDataInfo.currentBetAmount) / Number(currentVipDataInfo.nextBetAmount) * 100}%`,
              }"></div>
            </div>
          </div>
          <div class="tw-flex-1 tw-h-full">
            <div class="tw-flex tw-items-center">
              <span class="tw-capitalize tw-mr-1">Deposit</span>
              <LazyDialogNotices content="VIP deposit records only include transactions made within GameZone.">
                <template #default="{ props }">
                  <VIcon v-bind="props" icon="custom-warning"/>
                </template>
              </LazyDialogNotices>
            </div>
            <div class="tw-mt-3 tw-text-white">
              <span class="tw-text-[#2dc25c]">{{ $n(Number(currentVipDataInfo.currentRecharge), 'decimal') }} <span v-show="!isMaxLevel">/</span>
              </span>
              <span v-show="!isMaxLevel" class="tw-text-black"> {{ $n(Number(currentVipDataInfo.nextRecharge), 'decimal') }}</span>
            </div>
            <div class="tw-relative tw-rounded-full tw-overflow-hidden tw-bg-white tw-w-[83%] tw-h-[10%]">
              <div class="tw-size-full tw-bg-[#2dc25c] tw-rounded-md" :style="{
                width: !currentVipDataInfo.currentRecharge ? '0%' : `${Number(currentVipDataInfo.currentRecharge) / Number(currentVipDataInfo.nextRecharge) * 100}%`
              }"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
