<!-- FIXME 错误的组件文件路径位置，需要转移到Card目录下 -->
<script lang="ts" setup>
import { VipInfoPower } from '@/api/vip';

const router = useRouter()
const { $toast } = useNuxtApp()
const userDetailStore = useUserDetailStore()

const hasKYC = computed<boolean>(() => {
  return userDetailStore.value.firstIdStatus == '1'
})

const isKYCReview = computed(() => {
  return userDetailStore.value.firstIdStatus == '0'
})

const birthday = computed(() => {
  return getBirthDayGap(userDetailStore.value.birthday || '')
})

const vipInfoStore = useVipInfoStore()

const activeLevel = computed(() => {
  return vipInfoStore.value.activeLevel || 0
})

const currentLevel = computed(() => {
  return vipInfoStore.value.currentLevel || 0
})

const viewInCurLevel = computed(() => {
  return activeLevel.value === currentLevel.value
})

const curLevelData = computed(() => {
  return vipInfoStore.value.data?.find(d => {
    return d.vipLevel === currentLevel.value
  })
})

const activeLevelData = computed(() => {
  return vipInfoStore.value.data?.find(d => {
    return d.vipLevel === activeLevel.value
  })
})

const findActiveDetail = (powerId: number) => {
  return activeLevelData.value?.detailList.find(detail => {
    return detail.id === powerId
  })
}

const powerList = computed(() => {
  return vipInfoStore.value.powerList || []
})
watchEffect(() => {
  for (let power of (vipInfoStore.value.powerList || [])) {
    const powerId = power.id
    if (power.unLockLevel) {
      continue
    }
    for (let d of (vipInfoStore.value.data) || []) {
      const unLockLevel = d.vipLevel
      const isExist = d.detailList.find(detail => {
        return detail.id === powerId
      })
      if (isExist) {
        power.unLockLevel = unLockLevel
        break
      }
    }
  }
  (vipInfoStore.value.powerList || []).sort((a, b) => a.unLockLevel - b.unLockLevel)
})

const isLocked = (power: VipInfoPower) => {
  return (vipInfoStore.value.activeLevel || 0) < power.unLockLevel
}

const isCollected = (power: VipInfoPower) => {
  const detail = findActiveDetail(power.id)
  return detail?.isDone && detail.bonusStatus === VipBonusStatus.Collected && activeLevel.value <= currentLevel.value
}

const notCollected = (power: VipInfoPower) => {
  const detail = findActiveDetail(power.id)
  return !detail?.isDone && detail?.bonusStatus === VipBonusStatus.Collected && power.powerCode === VipPowerCode.UpGrade && activeLevel.value <= currentLevel.value
}

const isReceived = (power: VipInfoPower) => {
  const detail = findActiveDetail(power.id)
  return detail?.bonusStatus === VipBonusStatus.Received && activeLevel.value <= currentLevel.value
}

const isExpired = (power: VipInfoPower) => {
  const detail = findActiveDetail(power.id)
  return detail?.bonusStatus === VipBonusStatus.Expired && power.powerType === VipPowerType.Cash && activeLevel.value <= currentLevel.value
}

const isBirth = (power: VipInfoPower) => {
  return power.powerCode === VipPowerCode.Birth
}

const noKYCBirth = (power: VipInfoPower) => {
  return !hasKYC.value && isBirth(power)
}

const isKYCBirth = (power: VipInfoPower) => {
  return hasKYC.value && isBirth(power) && birthday.value > 0
}

const isCash = (power: VipInfoPower) => {
  return VipPowerType.Cash === power.powerType
}

const isRate = (power: VipInfoPower) => {
  return VipPowerType.Rate === power.powerType
}

const isKeepGrade = (power: VipInfoPower) => {
  return VipPowerCode.KeepGrade === power.powerCode && viewInCurLevel.value
}

const currentBetAmount = computed(() => {
  return Number(vipInfoStore.value.currentBetAmount || curLevelData.value?.currentBetAmount || 0)
})

const currentkeepAmount = computed(() => {
  return Number(vipInfoStore.value.currentkeepAmount || 0)
})

const onClaimClick = async (power: VipInfoPower) => {
  const detail = findActiveDetail(power.id)
  const data = await receiveVipBenfits({
    powerCode: power.powerCode,
    recordId: detail?.recordId || -1
  })
  if (data.body && detail) {
    detail.isDone = false
    detail.bonusStatus = VipBonusStatus.Received
  }
}

const onSetKYCClick = () => {
  router.push({ path: 'account/kyc' })
}
</script>

<template>
  <div class="tw-px-3 tw-py-6 tw-space-y-3 tw-bg-black">
    <div class="tw-flex tw-gap-1 tw-items-center on-background tw-text-base tw-font-bold tw-capitalize">
      <img class="tw-size-7" src="/src/assets/images/vip/level-reward.png" loading="lazy" decoding="async" />
      <!-- <img class="tw-size-7" src="/images/vip/rewards.png" loading="lazy" decoding="async" /> -->
      <span>current level rewards</span>
    </div>
    <div v-for="(power, index) in powerList" :key="index"
      class="tw-relative tw-rounded-xl tw-bg-[#1b1b1b] tw-border tw-border-solid tw-border-[rgb(var(--v-theme-surface-light-3))] tw-group"
      :class="[isLocked(power) && 'locked']">
      <div class="tw-flex tw-items-center tw-gap-3 tw-p-3 tw-h-[70px]">
        <img class="tw-size-9 tw-flex-shrink-0" :src="power.powerIcon" loading="lazy" decoding="async" />
        <div class="tw-capitalize tw-flex-1">
          <div class="tw-text-sm on-surface-light-1">{{ power.powerName }}</div>
          <div
            class="tw-text-base tw-font-semibold tw-text-white tw-mt-1 tw-flex tw-items-center tw-justify-between ">
            <span v-if="isCash(power)">₱{{ findActiveDetail(power.id)?.value || 0 }}</span>
            <span v-if="isRate(power)">{{ findActiveDetail(power.id)?.value || 0 }}%</span>
            <div v-if="isKeepGrade(power) && notCollected(power)"
              class="tw-rounded-full bg-surface-light-4 tw-font-semibold tw-text-xs tw-px-2 tw-py-[0.125rem]">
              <span class="tw-text-white">{{ $n(currentBetAmount, 'decimal') }} / </span>{{
                $n(currentkeepAmount, 'decimal') }}
            </div>
          </div>
        </div>
        <div>
          <template v-if="viewInCurLevel">
            <!-- ANCHOR 设置了KYC，展示距离生日天数 -->
            <VBtn v-if="isKYCBirth(power)" rounded class="!tw-w-[6.25rem] group-[&.locked]:tw-hidden" size="small">
              <span class="tw-normal-case on-background tw-text-base tw-font-semibold">{{ birthday }} day</span>
            </VBtn>
            <!-- ANCHOR KYC未设置或审查中 -->
            <VBtn v-if="noKYCBirth(power)" rounded class="!tw-w-[6.25rem] group-[&.locked]:tw-hidden"
              :disabled="isKYCReview" color="#007AFF" size="small" @click="onSetKYCClick">
              <span v-if="isKYCReview" class="tw-capitalize on-background tw-text-base tw-font-semibold">Review</span>
              <span v-else class="tw-capitalize tw-text-base tw-font-semibold"
                :class="[isKYCReview ? 'on-surface-light-1' : 'on-background']">Set KYC</span>
            </VBtn>
          </template>
          <PrimaryBtn v-if="isCollected(power)" rounded class="!tw-w-[6.25rem] group-[&.locked]:tw-hidden"
            @click="onClaimClick(power)">Claim</PrimaryBtn>
          <VBtn v-if="notCollected(power)" disabled rounded class="!tw-w-[6.25rem] group-[&.locked]:tw-hidden"
            size="small">
            <span class="on-surface-light-1">Claim</span>
          </VBtn>
          <VBtn v-if="isReceived(power)" rounded
            class="!tw-w-[6.25rem] !tw-border !tw-border-solid !tw-border-[rgb(var(--v-theme-primary-darken-6))] group-[&.locked]:tw-hidden"
            size="small" color="primary-darken-5">
            <span class="text-primary">Received</span>
          </VBtn>
          <VBtn v-if="isExpired(power)" disabled rounded class="!tw-w-[6.25rem] group-[&.locked]:tw-hidden"
            size="small">
            <span class="on-surface-light-1">Expired</span>
          </VBtn>
        </div>
      </div>
      <div
        class="tw-hidden group-[&.locked]:tw-block tw-absolute tw-right-0 tw-top-0 tw-w-[4.625rem] tw-h-[1.5rem] on-surface-light-1 tw-text-sm">
        <img class="tw-w-full tw-h-[24px]" src="/images/vip/status.png" />
        <div class="tw-absolute tw-inset-0 tw-flex tw-justify-center tw-items-center">
          <VIcon class="tw-mr-1 tw-text-white " color="white" icon="custom-locked" /> 
          <span class="tw-text-white">VIP {{ power.unLockLevel }}</span>
        </div>
      </div>
    </div>
  </div>
</template>
