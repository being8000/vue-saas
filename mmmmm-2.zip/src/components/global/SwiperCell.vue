<template>
  <div class="swipe-cell-container" ref="swipeCell">
    <div class="animate__lightSpeedInRight anim-box animate__animated animate__faster">
      <div
        class="cell-wraper"
        :style="translateStyle"
        @touchstart.passive="touchStart"
        @touchmove.passive="touchMove"
        @touchend.passive="touchEnd"
      >
        <div class="cell-content">
          <slot> </slot>
        </div>
        <div class="cell-actions" ref="actionBtns" @touchstart.stop  @mousedown.stop.passive>
          <slot name="actions"> </slot>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
interface SwipeCellProps {}

const state = reactive({
  start: 0,
  current: 0,
  opening: false,
  swiping: false,
})

const swipeCell = ref<HTMLDivElement | null>(null)
const actionBtns = ref<HTMLDivElement | null>(null)

const translateStyle = computed(() => {
  return {
    transform: `translateX(${state.current}px)`,
  }
})
const actionsWidth = computed(() => {
  return Math.ceil(actionBtns.value?.getBoundingClientRect().width || 0)
})

watchEffect(() => {
  // 如果 state.opening 放前面 touchEnd 结束将不会触发 else 分支
  if (!state.swiping && state.opening) {
    state.current = -actionsWidth.value
  } else {
    state.current = 0
  }
})

useClickAway(
  () => {
    state.opening = false
  },
  swipeCell,
  'touchstart'
)
const touchStart = (e: TouchEvent) => {
  state.start = e.changedTouches[0].clientX
  if (state.opening) {
    state.opening = false
  }
}
const touchMove = (e: TouchEvent) => {
  const current = e.targetTouches[0].clientX
  const scale = current - state.start
  if (scale > 0 || state.opening) {
    return
  }
  const swipeScale = Math.abs(scale) < actionsWidth.value ? scale : -actionsWidth.value
  state.swiping = true
  state.current = swipeScale
}
const touchEnd = () => {
  if (Math.abs(state.current) >= actionsWidth.value / 2) {
    state.opening = true
  }
  state.swiping = false
}
</script>

<style lang="scss" scoped>
.swipe-cell-container {
  width: 100%;
  .anim-box {
    width: 100%;
    overflow-x: hidden;
    border-radius: 12px;
  }
  .cell-wraper {
    display: flex;
    position: relative;
    transform: translateX(0);
    transition: transform 0.2s linear;
    width: 100%;
    .cell-content {
      width: 100%;
    }
    .cell-actions {
      display: flex;
      align-items: center;
      justify-content: center;
      height: 100%;
      position: absolute;
      right: 0;
      top: 0;
      transform: translateX(100%);
    }
  }
}

.animate__scaleIn {
  animation-name: scaleIn;
  animation-timing-function: ease-out;
}
@keyframes scaleIn {
  from {
    transform: scale(2);
  }

  to {
    transform: scale(1);
  }
}
</style>
