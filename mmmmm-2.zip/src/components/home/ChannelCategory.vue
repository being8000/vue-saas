<!-- 频道分类组件 -->
<template>
  <div class="tw-pb-3">
    <Suspense>
      <KeepAlive>
        <template v-for="(layout, index) in block">
          <component v-bind="layout.props" :is="resolveComponent(layout.component)" />
        </template>
      </KeepAlive>
      <template #fallback>
        <div class="tw-size-full tw-flex tw-flex-col tw-items-center text-primary">
          <VIcon class="!tw-size-20 !tw-mt-[50%]" icon="custom-loading2" />
        </div>
      </template>
    </Suspense>
  </div>
</template>

<script lang="ts" setup>
import { BlockConfig, BlockLayout } from '@/composables/useBlock'
// import { pokerMock } from '@/mock/block'

// const LazySwiperProviders = defineAsyncComponent(
//   () => import('@/components/global/Swiper/Providers.vue')
// )
const Chunk2 = defineAsyncComponent(() => import('./chunk/Chunk2.vue'))
const Chunk3 = defineAsyncComponent(() => import('./chunk/Chunk3.vue'))
const ChunkGames = defineAsyncComponent(() => import('@/components/global/Card/Games.vue'))
// const LazySwiperGames = defineAsyncComponent(() => import('@/components/global/Swiper/Games.vue'))
// const LazySwiperBanner = defineAsyncComponent(() => import('@/components/home/BlockBanner.vue'))
const LazySwiperBanner = defineAsyncComponent(() => import('@/components/global/Swiper/Banner.vue'))
// const LazyCardGames = h(
//   defineAsyncComponent(() => import('@/components/global/Card/Games.vue')),
//   {
//     extraClass: 'tw-px-3',
//     isHome: true,
//   }
// )
// const TournamentCard = defineAsyncComponent(
//   () => import('@/components/global/Card/TournamentCard.vue')
// )
// const TCC = defineAsyncComponent(() => import('@/components/global/Card/TCC.vue'))
// const HomeTournamentList = defineAsyncComponent(
//   () => import('@/components/home/TournamentList.vue')
// )
// const HomeEventList = defineAsyncComponent(() => import('@/components/home/EventList.vue'))
// const BiggerWins = defineAsyncComponent(() => import('@/components/biggerWins/index.vue')) //Biggest Winings
// const Tongitslivestream = defineAsyncComponent(() => import('@/components/global/livestream.vue')) //直播自定义组件
// const AboutTour = defineAsyncComponent(() => import('@/components/home/AboutTour.vue')) //home tongits 宣传页面
const resolveComponent = (componentName: string) => {
  return {
    // LazySwiperProviders,
    // LazySwiperRecentGames,
    // LazySwiperGames,
    // LazyCardGames,
    LazySwiperBanner,
    ChunkGames,
    Chunk2,
    Chunk3,
    // TournamentCard,
    // TCC,
    // HomeTournamentList,
    // HomeEventList,
    // BiggerWins,
    // Tongitslivestream,
    // AboutTour,
  }[componentName]
}
const { verifyBlockConditions, normalizeDirtyBlockConfigs } = useBlock()

const block = ref<BlockLayout[]>()

fetchPokerConfigJs().then((r: any) => {
  console.log(r)
  block.value = normalizeDirtyBlockConfigs(r)
})
</script>
