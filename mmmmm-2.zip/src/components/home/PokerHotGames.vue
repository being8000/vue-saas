<template>
  <div class="container mx-auto p-4">
    <div v-for="(group, index) in itemGroups" :key="index" class="mb-8">
      <div class="tw-flex tw-mb-4 tw-gap-4">
        <div
          v-for="(item, i) in group.slice(0, 2)"
          :key="i"
          class="tw-flex-1 tw-bg-blue-500 tw-p-4 tw-text-white"
        >
          {{ item }}
        </div>
      </div>

      <div class="tw-grid tw-grid-cols-3 tw-gap-4">
        <div
          v-for="(item, i) in group.slice(2)"
          :key="i"
          class="tw-bg-green-500 tw-p-4 tw-text-white"
        >
          {{ item }}
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      items: Array.from({ length: 16 }, (_, i) => `Item ${i + 1}`),
    }
  },
  computed: {
    itemGroups() {
      // 每 8 项分为一组
      let groups = []
      for (let i = 0; i < this.items.length; i += 8) {
        groups.push(this.items.slice(i, i + 8))
      }
      return groups
    },
  },
}
</script>
<style lang="scss" scoped></style>
