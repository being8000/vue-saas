<template>
  <div>
    <LazyCardItemsBar data-gtp-c="Tongits" icon="custom-TPLogo" title="">
      <div class="tw-flex tw-justify-between tw-pl-[16px] tw-pr-[8px]">
        <div
          v-for="(item, index) in images"
          :key="index"
          class="tw-bg-cover tw-flex-1 tw-mr-[8px]"
          @click="jumpTongits(item)"
        >
          <VResponsive :aspectRatio="127 / 127" class="!tw-overflow-visible">
            <div class="tw-bg-[#fff] tw-flex tw-flex-col tw-relative tw-rounded-[8px]">
              <img
                class="tw-w-[50px] tw-absolute tw-left-[-8px] tw-top-[8px]"
                :src="item.labelUrl"
                alt=""
              />
              <img
                class="tw-w-full tw-rounded-tl-[8px] tw-rounded-tr-[8px]"
                :src="item.imageUrl"
                alt=""
              />
              <div
                class="tw-text-[12px] tw-text-[#323136] tw-ml-[4px] tw-font-bold tw-h-[26px] tw-flex tw-items-center"
              >
                {{ item.txt }}
              </div>
            </div>
          </VResponsive>
        </div>
      </div>
    </LazyCardItemsBar>
  </div>
</template>
<script setup lang="ts">
import LazyCardItemsBar from '@/components/global/Card/ItemsBar.vue'
import { gzlinkTo } from '@/util'
import { LinkToEnum } from '@/util/enum'
import classicLabel from '@images/poker/classic-label.png'
import turboLabel from '@images/poker/turbo-label.png'
import jokerLabel from '@images/poker/joker-label.png'

interface ImageData {
  imageUrl: string
  gameId: string
  txt: string
  labelUrl: any
}
const getBoxClass = (index: number) => {}

const images: ImageData[] = [
  {
    imageUrl: '/images/tongits/tongits-plus1.webp',
    gameId: 'tongits',
    txt: 'Tongits plus',
    labelUrl: classicLabel,
  },
  {
    imageUrl: '/images/tongits/tongits-joker1.webp',
    gameId: 'tongits_joker',
    txt: 'Tongits joker',
    labelUrl: jokerLabel,
  },
  {
    imageUrl: '/images/tongits/tongits-quick1.webp',
    gameId: 'tongits_quick',
    txt: 'Tongits quick',
    labelUrl: turboLabel,
  },
]

const jumpTongits = (item: ImageData) => {
  gzlinkTo(LinkToEnum.ToGame, {
    targetUrl: '',
    gameId: item.gameId,
    platformCode: '175',
  })
}
</script>
<style lang="scss" scoped>
.lastChild {
  &:last-child {
    margin-right: 0px;
  }
}
</style>
