<template>
  <div class="tw-pl-[12px] tw-pr-[12px] tw-mb-[12px] tw-mt-[12px]">
    <div
      class="w-full overflow-hidden tw-flex tw-flex-row tw-border-[#FF6533] tw-border tw-rounded-[8px] tw-h-[36px] tw-flex tw-justify-center tw-items-center marqueeBox"
    >
      <div
        class="tw-w-[36px] tw-h-[100%] tw-mr-[3px] tw-flex tw-justify-center tw-items-center iconbox"
      >
        <img :src="marqueenIcon" alt="" class="tw-w-[24px] tw-h-[24px]" />
      </div>
      <!-- <vue3-marquee
        :direction="'left'"
        :scrollamount="3"
        :duration="20"
        class="tw-text-[#323136] tw-font-[500] tw-twxt-[14px]"
      >
        <p class="tw-mr-[20px]" v-for="(item, index) in marqueeListData" :key="index">
          {{ item.marketingTxt }}
        </p>
      </vue3-marquee> -->
      <v-carousel
        height="36"
        class="slideBox"
        cycle
        hide-delimiters
        hide-delimiter-background
        :direction="'vertical'"
        v-if="marqueeListData"
        :interval="3500"
      >
        <v-carousel-item v-for="(slide, i) in marqueeListData" :key="i">
          <div>
            <div class="tw-text-[#323136] tw-font-[500] tw-text-[12px]">
              {{ slide.marketingTxt }}
            </div>
          </div>
        </v-carousel-item>
      </v-carousel>
    </div>
  </div>
</template>
<script setup lang="ts">
import { Vue3Marquee } from 'vue3-marquee'
import marqueenIcon from '@images/poker/marqueen-icon.png'
import { marqueeConfig } from '@/api/home'

let marqueeListData = ref([])
const marqueeList = async () => {
  const { body } = await fetchMarqueeList()

  if (!body) return

  const sortedMarquee = body.sort((a, b) => b.sort - a.sort)

  marqueeListData.value = sortedMarquee
}

onMounted(() => {
  marqueeList()
})
</script>
<style lang="scss" scoped>
.marqueeBox {
  box-shadow: 0px 0px 6px rgba(255, 102, 0, 0.3);
  // backdrop-filter: blur(5px);
}
.iconbox {
  background: rgba(255, 101, 51, 0.1);
}
:deep(.slideBox) {
  line-height: 36px;
}
:deep(.v-window__left) {
  display: none !important;
}
:deep(.v-window__right) {
  display: none !important;
}
</style>
