<template>
  <LazyCardItemsBar
    title="Tongits Daily Tournaments"
    extra-class="!tw-mb-0 tw-px-3 tw-pt-[0.5rem]"
    icon="custom-TPLogo"
  >
    <div class="tw-px-3">
      <div
        class="tw-w-full tw-h-[34px] tw-bg-[linear-gradient(to_right,#FA5CFF,#690BFF)] tw-rounded-[20px] tw-text-[0.75rem] tw-my-[0.5rem] tw-relative tw-overflow-hidden tw-border tw-border-[#ffffff]"
      >
        <div
          class="tw-w-full tw-h-[34px] tw-absolute tw-pl-[1rem] tw-pr-[10px]"
          :style="{ top: listTop + 'px' }"
        >
          <div
            class="tw-h-[34px] tw-flex tw-justify-start tw-items-center"
            v-for="(item, index) in winnerList"
            :key="item.rank + '_' + index"
          >
            <p
              class="tw-text-center tw-text-[#FFFFFF] tw-text-[12px] tw-flex tw-justify-center tw-items-center"
            >
              <span class="tw-leading-[32px]"
                >Player
                <span class="tw-mx-[4px] tw-text-[#E8FF51] tw-font-semibold">{{
                  item.loginName
                }}</span>
                just won
                <span class="tw-mx-[4px] tw-text-[#E8FF51] tw-font-semibold"
                  >₱ {{ $n(Math.min(item.rewardMoney / 1000 || 0, 9999999.99), 'decimal') }}</span
                >
                <span class="tw-mr-[4px]">{{ item.endTimeStr }}</span> ago!</span
              >
              <img
                class="tw-w-[23px] tw-h-[21px] tw-ml-[5px]"
                src="@images/home/tonight/prize_bg.png"
              />
            </p>
          </div>
        </div>
      </div>
    </div>
    <div class="tw-mt-[10px] tw-pb-[0.5rem]">
      <div class="tw-flex tw-gap-[.375rem]">
        <div class="tw-overflow-hidden tw-relative tw-z-[2] tw-flex-1 tw-px-3" ref="emblaRef">
          <div class="tw-flex tw-gap-[10px]">
            <div
              v-for="(item, index) in feegamelist"
              :key="item.listId + '_' + index"
              class="tw-shrink-0 tw-grow-0 tw-h-[141px] tw-w-[7rem]"
              :data-gtp-d="`b_${index}`"
            >
              <LazyCardTongitsItem :index="index" :listitem="item"></LazyCardTongitsItem>
            </div>
          </div>
        </div>
      </div>
    </div>
  </LazyCardItemsBar>
</template>

<script setup lang="ts">
// 引入头部组件
import LazyCardItemsBar from '@/components/global/Card/ItemsBar.vue'
import emblaCarouselVue from 'embla-carousel-vue'
import LazyCardTongitsItem from '@/components/global/Page/tongitsItem.vue'
import useJackportSocket from '@/composables/socket/useSocket'
import { TongitsMatchResp, WinnerArry } from '@/api/home'
import { tr } from 'date-fns/locale'
// 赛事爆奖名单
const winnerList = ref<WinnerArry[]>([])
const ifClearinterval = ref<number>(0)
const listTop = ref<number>(0)
const [emblaRef] = emblaCarouselVue({ loop: false, align: 'start' })
// 初始化得赛事数据
// const Canentergamelist = ref<TongitsMatchResp[]>([]) //免费赛赛事列表
const feegamelist = ref<TongitsMatchResp[]>([]) //付费赛赛事列表

const { tongitsEventBus } = useJackportSocket()
const { TongitsuserlistId, fetchTongitsSignList, tongitsMatchs } = useTongits()
let potTime = 0

//筛选出免费赛跟付费赛赛事
const getnewlist = () => {
  // 可以进入比赛的赛事
  let Canentergamelist = tongitsMatchs.value
    .filter((item) => {
      return item.entertime <= 0 && item.usersigin != true
    })
    .sort((a, b) => a.entertime - b.entertime)
  // 未报名，未进入比赛时间
  let userSignArry = tongitsMatchs.value
    .filter((item) => {
      return item.usersigin != true && item.entertime > 0
    })
    .sort((a, b) => a.startTime - b.startTime)
  // 已经报名的比赛
  let DropTimeArry = tongitsMatchs.value
    .filter((item) => {
      return (
        (item.entertime > 0 || item.usersigin == true) &&
        (item.entertime < 0 || item.usersigin == true) &&
        item.usersigin == true
      )
    })
    .sort((a, b) => a.startTime - b.startTime)
  feegamelist.value = [...Canentergamelist, ...userSignArry, ...DropTimeArry]
}
//
//获取赛事列表
async function getHistoryWinerList() {
  try {
    const { success, body } = await fetchTopWinner()
    if (!success) return
    winnerList.value = body == null ? [] : [JSON.parse(body)]
    winnerList.value.forEach((item) => {
      potTime = item.serverTime - item.endTime
      if (potTime < 60) {
        item.endTimeStr = potTime + 'S'
      } else if (potTime < 3600) {
        item.endTimeStr = Math.floor(potTime / 60) + ' mins'
      } else if (potTime < 3600 * 24) {
        item.endTimeStr = Math.floor(potTime / 3600) + ' hours'
      } else if (potTime < 3600 * 48) {
        item.endTimeStr = Math.floor(potTime / 3600) + ' hours'
      } else {
        item.endTimeStr = getDateDifference(potTime)
      }
    })
  } catch (e) {
    console.error('checkHistoryWinerList error', e)
  }
}
// 计算两个日期相差的天数
const getDateDifference = (time: number) => {
  // 将毫秒差转换为天数
  const dayDifference = Math.floor(time / (3600 * 24))

  return dayDifference == 0 ? 'Yesterday' : dayDifference + ' days'
}
// 监听 winnerList 的变化，如果是数据滚动结束，就重新触发定时器
watch(winnerList, () => {
  if (!ifClearinterval.value) {
    showUpMarquee()
  }
})
// 数据滚动
const showIndexItem = () => {
  if (winnerList.value.length != 0) {
    ifClearinterval.value = window.setInterval(() => {
      if (winnerList.value.length <= 1) {
        // 如果数组长度为1，就清除定时器，然后停留在最后一条数据
        if (ifClearinterval.value) {
          clearInterval(ifClearinterval.value)
          ifClearinterval.value = 0
        }
      } else {
        // 数据滚动
        setScroll()
      }
    }, 1500)
  }
}
// 滚动时间
const setScroll = () => {
  var t = setInterval(() => {
    listTop.value -= 1
    if (listTop.value === -34) {
      //删除数组第一个元素
      winnerList.value.shift()
      listTop.value = 0 //重置top
      clearInterval(t) //取消定时器
    }
  }, 20)
}
const showUpMarquee = () => {
  showIndexItem()
}
let unsubscribeEvent = null
// 离开界面的时候清除定时器
onUnmounted(async () => {
  if (ifClearinterval.value) {
    clearInterval(ifClearinterval.value)
  }
})
onMounted(async () => {
  // 获取用户登录信息
  const userLoginInfo = await checkLoginStatus(false)
  if (userLoginInfo == true) {
    await fetchTongitsSignList()
  }
  getnewlist()
  getHistoryWinerList()
  await nextTick()
  unsubscribeEvent = tongitsEventBus.on((event, paylaod) => {
    if (event === 'MatchWinner') {
      // 将推送过来的数据放在数组中
      winnerList.value = winnerList.value.concat(JSON.parse(paylaod.winners))
      winnerList.value.forEach((item) => {
        potTime = item.serverTime - item.endTime
        if (potTime < 60) {
          item.endTimeStr = potTime + 'S'
        } else if (potTime < 3600) {
          item.endTimeStr = Math.floor(potTime / 60) + ' mins'
        } else if (potTime < 3600 * 24) {
          item.endTimeStr = Math.floor(potTime / 3600) + ' hours'
        } else if (potTime < 3600 * 48) {
          item.endTimeStr = Math.floor(potTime / 3600) + ' hours'
        } else {
          item.endTimeStr = getDateDifference(potTime)
        }
      })
    }
    // 监听赛事列表数据变化
    if (event === 'MatchListChange') {
      const homeTongitsList = JSON.parse(paylaod.matchList).map((items: TongitsMatchResp) => {
        if (items.cycleTimeItem && items.cycleTimeItem.length > 0) {
          const findCycle = items.cycleTimeItem.find(
            (TimeItem) =>
              items.serverTime >= TimeItem.startTimeSec &&
              items.serverTime <= TimeItem.finishTimeSec
          )
          if (findCycle) {
            items.delaySeconds = findCycle.intervalSec / 60
          } else {
            items.delaySeconds = 0
          }
        } else {
          items.delaySeconds = 0
        }
        items.countdowntime = items.startTime - items.serverTime
        items = manualSetMatchesPrize(items)
        return items
      })
      tongitsMatchs.value = homeTongitsList
      getnewlist()
    }

    // 监听赛事列表数据变化
    if (event === 'MatchListChange') {
      const NewTongitsArry =
        JSON.parse(paylaod.matchList)
          .map((items: TongitsMatchResp) => {
            if (TongitsuserlistId.value.includes(items.listId)) {
              items.usersigin = true
            } else {
              items.usersigin = false
            }
            if (items.cycleTimeItem && items.cycleTimeItem.length > 0) {
              const findCycle = items.cycleTimeItem.find(
                (TimeItem) =>
                  items.serverTime >= TimeItem.startTimeSec &&
                  items.serverTime <= TimeItem.finishTimeSec
              )
              if (findCycle) {
                items.delaySeconds = findCycle.intervalSec / 60
              } else {
                items.delaySeconds = 0
              }
            } else {
              items.delaySeconds = 0
            }
            items.starttimeEn = DF.MdHm(items.startTime * 1000)
            items.signStartTimeEn = DF.MdHm(items.signStartTime * 1000)
            items.countdowntime = items.startTime - items.serverTime
            items.entertime = items.earlyEnterTime - items.serverTime
            items = manualSetMatchesPrize(items)
            if ([0, 1].includes(items.signType)) {
              return items
            }
          })
          .filter(Boolean) || []
      tongitsMatchs.value = NewTongitsArry
      getnewlist()
    }
  })
})
</script>

<style lang="scss" scoped></style>
