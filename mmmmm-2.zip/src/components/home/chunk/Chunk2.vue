<!-- 2+6 模板  -->
<template>
  <GlobalCardItemsBar v-bind="$attrs" class="tw-mt-2 tw-px-3">
    <div class="tw-grid tw-grid-cols-2 tw-gap-2 mt">
      <GlobalCardGameItem
        :game="games[0]"
        :img-aspect-ratio="178 / 122"
        :bottom-aspect-ratio="178 / 26"
        game-box-class="!tw-rounded-xl"
      />
      <GlobalCardGameItem
        :game="games[1]"
        :img-aspect-ratio="178 / 122"
        :bottom-aspect-ratio="178 / 26"
        game-box-class="!tw-rounded-xl"
      />
    </div>
    <GlobalCardGames :games="games.slice(2, 8)"></GlobalCardGames>
    <GlobalSwiperBanner
      v-if="bannerList.length"
      :banners="bannerList"
      class="tw-pt-4"
    ></GlobalSwiperBanner>
  </GlobalCardItemsBar>
</template>
<script setup lang="ts">
import { GameBaseItem } from '@/api/game'
import { Banner } from '@/api/home'
interface Props {
  games: GameBaseItem[]
  bannerList: Banner[]
}
defineProps<Props>()
</script>
