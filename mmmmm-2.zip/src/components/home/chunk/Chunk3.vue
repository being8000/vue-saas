<!-- 9+1 模板  -->
<template>
  <GlobalCardItemsBar v-bind="$attrs" class="tw-mt-2 tw-px-3">
    <div v-for="(_, idx) in maxSize" class="tw-pt-2">
      <GlobalCardGames
        v-if="games.slice(idx * 9, idx * 9 + 9).length"
        :games="games.slice(idx * 9, idx * 9 + 9)"
      ></GlobalCardGames>
      <GlobalSwiperBanner
        v-if="bannerList[idx]"
        :banners="[bannerList[idx]]"
        class="tw-pt-4"
      ></GlobalSwiperBanner>
    </div>
  </GlobalCardItemsBar>
</template>
<script setup lang="ts">
import { GameBaseItem } from '@/api/game'
import { Banner } from '@/api/home'

const maxSize = computed(() => {
  return Math.max(props.bannerList.length, Math.ceil(props.games.length / 9))
})
interface Props {
  bannerList: Banner[]
  games: GameBaseItem[]
}
const props = defineProps<Props>()
</script>
<style lang=""></style>
