<template>
  <LazyCardItemsBar title="GTCL Leader Board" extra-class="!tw-mb-0 tw-px-3 tw-pt-[0.5rem]">
    <section class="tw-text-black tw-mt-2">
      <VResponsive :aspect-ratio="366 / 185" class="tw-px-[0.75rem] tw-mb-4">
        <div
          class="background-container tw-w-[100%] tw-h-full tw-px-[18px]"
          style="box-sizing: border-box"
        >
          <div class="tw-w-[100%] tw-h-[99%] tw-flex tw-items-end tw-justify-center">
            <rankItem :seq="0" :queryRankInfo="queryRankInfo[1]"></rankItem>
            <rankItem :seq="1" :queryRankInfo="queryRankInfo[0]"></rankItem>
            <rankItem :seq="2" :queryRankInfo="queryRankInfo[2]"></rankItem>
          </div>
        </div>
      </VResponsive>
    </section>
  </LazyCardItemsBar>
</template>

<script setup lang="ts">
import { leaderBoardArray } from '@/api/home'
import rankItem from '@/components/tongits/rankItem.vue'
import LazyCardItemsBar from '@/components/global/Card/ItemsBar.vue'
const queryRankInfo = ref<leaderBoardArray[]>([])
// const userRankInfo = ref()

const fetchQueryRankConfig = async () => {
  const data = await fetchRankConfig()
  if (!data.body) return
  getQueryRankInfo()
  // getQueryUserRankInfo()
}

const getQueryRankInfo = async () => {
  const { success, body } = await fetchQueryRank(0)
  if (!success || !body || body.length === 0) {
    throw new Error('Failed to fetch rank info')
    return
  }
  queryRankInfo.value = body
}

// const getQueryUserRankInfo = async () => {
//   const { success, body } = await fetchQueryUserRank(0)
//   if (success && !!body) {
//     userRankInfo.value = body
//   } else {
//     return false
//   }
// }
fetchQueryRankConfig()
onMounted(() => {
  console.log('组件已挂载')
})
</script>
<style lang="scss" scoped>
.background-container {
  background-image: url('@/assets/images/tongits/rank-bg.png');
  background-size: 100% 100%;
  background-repeat: no-repeat;
  background-position: 0 0;
  box-shadow: 0px 4px 8px rgba(255, 199, 180, 0.2);
}
</style>
