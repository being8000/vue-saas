<template>
      <!--  -->
  <!-- <VDialog v-model="showDialog"> -->
    <div class="tw-w-[336px] tw-min-h-[332px] tw-bg-[#ffffff] tw-rounded-[15px] tw-pb-[28px] tw-relative">
      <div class="tw-absolute tw-left-[50%] -tw-bottom-[50px] -tw-translate-x-[50%] tw-w-[40px]" @click="hiddenpop">
        <img class="tw-w-full" src="@images/home/tonight/ic_colse.png"/>
      </div>
      <div class="tw-text-[#222222] tw-relative tw-text-[18px] tw-text-center tw-bg-[#FFFFFF] tw-leading-[32px] tw-rounded-[15px] tw-pt-[14px] tw-font-extrabold">
        Register
      </div>
      <p class="tw-text-[1rem] tw-font-bold tw-text-[#222222] tw-text-left tw-px-[1.5rem] tw-pb-[1rem] tw-pt-0"><span>{{popdetail?.matchName}}</span></p>
      <ul class="tw-px-[1.5rem] tw-text-[#666666]">
        <li class="tw-flex tw-justify-between tw-text-[14px] tw-leading-[28px] tw-mb-[0.75rem]">
          <span>Time:</span>
          <span class="tw-text-[#323136] tw-text-[1rem] tw-font-bold">{{popdetail?.starttimeEn}}</span>
        </li>
        <li class="tw-flex tw-justify-between tw-text-[16px] tw-leading-[28px]">
          <span>Amount:</span>
          <span class=" tw-font-bold tw-text-[#FF6533]">₱ <label class="tw-font-inter">{{popdetail!.signNum / 1000}}</label></span>
        </li>
        <!-- <li v-for="item in renderDIalogList" class="tw-mt-2">{{ item }}</li> -->
      </ul>
      <p class="tw-text-[#7D7888] tw-text-[14px] tw-pl-[1.5rem] tw-pr-[3rem] tw-text-left tw-pt-[16px] tw-leading-[18px]">
        Upon registration. your account will be credited with the amount of the fee，which will be refunded if the race is canceied.
      </p>
      <div class="tw-flex tw-justify-center tw-mt-[1rem] dialog-footer-btn tw-h-[44px]" v-if="popdetail && popdetail.entertime > 0 && popdetail?.usersigin">
        <div class=" tw-w-[16.25rem]  tw-text-[18px] tw-font-semibold tw-text-[#323136] tw-bg-[#FFF4F4] tw-rounded-[40px] tw-border tw-border-[#FF6533] tw-text-center tw-flex tw-justify-center" >
          <p class=" tw-leading-[44px]">Join </p>
          <Countdown :data-gtp-d="popdetail?.listId" blockColor="!tw-text-[24px]" textColor=" tw-px-[0.25rem] tw-text-[#FE4949]" :countdowntime="popdetail?.entertime" @countdownemit="endtimefunc" class="tw-flex tw-items-center tw-justify-center" ></Countdown>
        </div>
      </div>
      <div class="tw-flex tw-justify-center tw-mt-[1rem] dialog-footer-btn" v-if="popdetail?.startStatus == 0 && !popdetail?.usersigin">
         <span class="tw-w-[16.25rem] tw-h-[44px] tw-leading-[44px] tw-bg-[#FF6533] tw-text-center tw-rounded-[3.125rem] tw-font-bold tw-text-[18px] tw-text-[#ffffff]"  @click="Tingame()">Confirm</span>
      </div>
      <div class="tw-flex tw-justify-center tw-mt-[1rem] dialog-footer-btn" v-if="(popdetail && popdetail.entertime <= 0) && popdetail?.usersigin">
         <span v-if="popdetail.matchId" class="tw-w-[16.25rem] tw-h-[44px] tw-bg-[#FF6533] tw-text-center tw-leading-[44px] tw-rounded-[3.125rem] tw-font-bold tw-text-[18px] tw-text-[#ffffff]"  @click="entertongits(popdetail)">Enter</span>
         <span v-else class="tw-w-[16.25rem] tw-h-[44px] tw-bg-[#C8C2CD] tw-text-center tw-leading-[44px] tw-rounded-[3.125rem] tw-font-bold tw-text-[14px]" >Enter</span>
        </div> 
      <div class="tw-flex tw-justify-center tw-mt-[0.75rem] dialog-footer-btn" v-if="popdetail?.startStatus == 0 && popdetail?.usersigin">
        <span class="tw-text-[#B4B4B4] tw-text-[18px]" @click="cancelgame()">Cancel</span>
      </div>
    </div> 
  <!-- </VDialog> -->
</template>
<script setup lang="ts">
import { TongitsMatchResp } from '@/api/home';
import Countdown from '@/components/global/Number/Countdown.vue'
import router from '@/router';
const props = defineProps<{
  popdetail: TongitsMatchResp | undefined
}>()
const showDialog = ref<boolean>(true)
const emits = defineEmits(['update:showregister','useSingin'])
const { fetchTongitsSignList} = useTongits()
const { $toast } = useNuxtApp()
// const { userStore } = useBonusBanner()


// 如果倒计时结束不可以跳转
const endtimefunc = (times:number) =>{
  props.popdetail!.entertime = times;
}
const hiddenpop = () =>{
  emits('update:showregister', false);
}
// 赛事报名
async function Tingame(){
  emits('useSingin', props.popdetail)
}
// 取消报名
async function cancelgame(){
  try{
    const { success, body } = await fetchsignUpCancel(props.popdetail?.listId)
      if (!success) return
      if(body){
        $toast('Cancellation Successful !')
        fetchTongitsSignList()
      }else{
        $toast('Cancellation Unsuccessful !')
      }
      emits('update:showregister', false);
    }catch(e){
      console.error('checkfetchsignUpCancel error',e)
    }
}
// 进游戏按钮
const entertongits = (item : TongitsMatchResp | undefined) =>{
  router.push({
    name: 'game-id',
    params: {
      platformId: '175',
      gameId: 'tongits',
    },
    query: { jumpJson: `{"activity":"matchjoin_${item!.matchId}"}`},
  })
}
</script>
<style scoped>
:deep(.v-overlay__content){
  width: 292px;
}
</style>