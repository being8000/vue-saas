<template>
  <div
    class="tw-h-[100%] tw-flex-[30%] tw-flex tw-flex-col tw-justify-end tw-items-center"
    :class="{ 'tw-flex-[35%] tw-mx-[3px]': seq == 1 }"
  >
    <div
      class="profile tw-rounded-full tw-flex tw-justify-center tw-items-center"
      :style="{
        width: styles.width,
        height: styles.height,
        backgroundImage: `url(${styles.profileUrl})`,
      }"
    >
      <img
        v-if="queryRankInfo?.avatarUrl"
        :src="queryRankInfo.avatarUrl"
        alt=""
        class="tw-rounded-full tw-w-[70%] tw-h-[70%] tw-object-cover"
      />
      <img
        v-else
        src="@/assets/images/tongits/gamezone.png"
        alt=""
        class="tw-rounded-full tw-w-[70%]"
      />
    </div>
    <p class="tw-text-[#ff9900] tw-text-[14px] tw-font-bold abc">
      ₱ {{ $n(Math.min(queryRankInfo?.awardAmount || 0, 9999999.99)) }}
    </p>
    <p class="tw-text-gray-2 tw-text-[12px] tw-mb-[5px]">{{ queryRankInfo?.loginName }}</p>
    <img :src="styles.rankUrl" alt="" />
  </div>
</template>

<script setup lang="ts">
import rank2 from '@images/tongits/rank2.png'
import rank1 from '@images/tongits/rank1.webp'
import rank3 from '@images/tongits/rank3.png'
import profileUrl1 from '@images/tongits/gold1.png'
import profileUrl0 from '@images/tongits/gold0.png'
import profileUrl2 from '@images/tongits/gold2.png'

const props = defineProps(['seq', 'queryRankInfo'])
const stylesMap: Record<
  number,
  {
    profileUrl: string
    width: string
    height: string
    rankUrl: string
  }
> = {
  0: {
    profileUrl: profileUrl1,
    width: '58px',
    height: '58px',
    rankUrl: rank2,
  },
  1: {
    profileUrl: profileUrl0,
    width: '68px',
    height: '68px',
    rankUrl: rank1,
  },
  2: {
    profileUrl: profileUrl2,
    width: '48px',
    height: '48px',
    rankUrl: rank3,
  },
}
const styles = computed(() => {
  return stylesMap[props.seq]
})
onMounted(() => {
  console.log('组件已挂载')
})
</script>
<style lang="scss" scoped>
.profile {
  background-size: 100% 100%;
  background-repeat: no-repeat;
  background-position: 0 0;
}
.abc {
  font-family: 'Inter';
}
</style>
