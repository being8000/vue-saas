import { MessageData } from 'packages/messenger/lib'
let count = 50
export const postMethodsFn: Record<string, (payload: any) => Promise<MessageData> | MessageData> = {
  async fetchValentineInfo() {
    return successRes({})
  },
  popupValentineConfirmBox(payload: { tid: string }) {
    return successRes({})
  },
  popupValentineDetailBox() {
    logger.logBusiness('处理 popupValentineConfirmBox999', '网关SDK')
    const { showDuijiangDialogFn } = useValentineDialog()

    showDuijiangDialogFn()
    return successRes({
      test: 'popupValentineDetailBox',
    })
  },
}
