// import router from '@/router'
// import {
//   MessageData,
//   MessageEnum,
//   MessageNavigationPayload,
//   MessagePayload,
//   createChildMessagePromise,
//   MessagePostPayload,
// } from '@gameplus/messenger'

// let iframeEL: HTMLIFrameElement | undefined = undefined
export const successRes = (body?: any) => {
  return {
    success: true,
    body: body,
    code: 200,
    message: 'success',
  }
}

// const response = (data: MessageData, event: MessageEvent<MessagePayload>) => {
//   iframeEL?.contentWindow?.postMessage(
//     {
//       data: JSON.parse(JSON.stringify(data)),
//       messageId: event.data.messageId,
//     },
//     event.origin
//   )
// }

// const onMessage = async (event: MessageEvent<MessagePayload>) => {
//   logger.logBusiness('parent: receive message from child', '网关SDK')
//   logger.logBusiness(event.data, '网关SDK')
//   try {
//     let data = event.data || {}
//     switch (data.type) {
//       case MessageEnum.POST:
//         {
//           let { messageId, method = '', payload = {} } = data as MessagePostPayload
//           if (messageId != undefined && method) {
//             const res = await postMethodsFn[method](payload)
//             response(res, event)
//           } else {
//             throw new Error('Invalid Parameters')
//           }
//         }
//         break
//       case MessageEnum.NAVIGATE:
//         {
//           const {
//             messageId,
//             path = undefined,
//             query = {},
//             hash = undefined,
//             replace = false,
//           } = data as MessageNavigationPayload
//           if (messageId != undefined) {
//             if (replace) {
//               router.replace({
//                 path,
//                 query,
//                 hash,
//               })
//             } else {
//               router.push({
//                 path,
//                 query,
//                 hash,
//               })
//             }
//             response(successRes(), event)
//           } else {
//             throw new Error('Invalid Parameters')
//           }
//         }

//         break
//       case MessageEnum.FROM_PARENT:
//         on(event)
//         break
//       case MessageEnum.HTTP:
//         response(
//           {
//             success: false,
//             code: 102,
//             message: 'http feature is not available',
//           },
//           event
//         )
//         // {
//         //   const { messageId, url = '', config = {} } = data as MessageHttpPayload
//         //   if (messageId != undefined && url) {
//         //     const { success, body, head } = await request<BaseResponseType>(url, {
//         //       ...config,
//         //     }).then((res) => res.data)
//         //     if (success) {
//         //       response(successRes(body), event)
//         //     } else {
//         //       response(
//         //         {
//         //           success: false,
//         //           body: body,
//         //           code: head.errCode,
//         //           message: head.errMsg,
//         //         },
//         //         event
//         //       )
//         //     }
//         //   }
//         // }
//         break
//       default: {
//         const { messageId } = data
//         if (messageId != undefined) {
//           response(
//             {
//               success: false,
//               code: 101,
//               message: '无效的请求载体',
//             },
//             event
//           )
//         }
//       }
//     }
//   } catch (error) {
//     const { messageId } = event.data || {}
//     if (messageId != undefined) {
//       response(
//         {
//           success: false,
//           code: 101,
//           message: 'invalid request data structure',
//         },
//         event
//       )
//     }
//   }
// }
// export async function notifyIframeMessage(method: string, payload?: any) {
//   console.log('notifyIframeMessage', method, payload)
//   return createChildMessagePromise(
//     {
//       method,
//       payload,
//     } as MessagePostPayload,
//     MessageEnum.FROM_GAMEZONE,
//     iframeEL
//   )
// }
export default function (el: globalThis.Ref<HTMLIFrameElement>) {
  // function startParentListening() {
  //   window.removeEventListener('message', onMessage)
  //   window.addEventListener('message', onMessage)
  // }
  // onMounted(() => {
  //   startParentListening()
  //   iframeEL = unref(el)
  // })
  // onBeforeMount(() => {
  //   window.removeEventListener('message', onMessage)
  // })
}
