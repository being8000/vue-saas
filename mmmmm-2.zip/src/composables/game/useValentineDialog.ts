const confirmBoxVisible = ref(false)
const confirmDuijiangVisible = ref(false)
const packageInfo = ref({
  gain: 0, // 获得的卡包数量
  packageCount: 0 // 卡包总数
})
export default function () {
  const showBox = async (tid: string) => {
    // TODO 通过TID 调用接口获取获得卡包数量
    const record = await qrjPackageRecord({
      eventId: tid
    })
    if(record.success){
      if(!record.body.data.length ) return
      packageInfo.value.gain = record.body.data[0]?.count || 0
      const userData = await qrjUserData()
      if(userData.success){
        packageInfo.value.packageCount = userData.body.packageCount
        confirmBoxVisible.value = true
      }
    }
  }

  const showDuijiangDialogFn = () => {

    confirmDuijiangVisible.value =true
  }

  const toOpenDuijiangDialog = () => {
    confirmBoxVisible.value = false
    confirmDuijiangVisible.value = true
  }

  return {
    confirmBoxVisible,
    packageInfo,
    confirmDuijiangVisible,
    showBox,
    showDuijiangDialogFn,
    toOpenDuijiangDialog
  }
}
