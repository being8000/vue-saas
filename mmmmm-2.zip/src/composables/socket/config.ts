export const getSocketUrl = () => {
  if (isUat()) {
    return 'https://gp-websocket-uat.uatextback66.com/ws'
  } else {
    return 'https://gp-websocket.xinba66.com/ws'
  }
}
