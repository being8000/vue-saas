//@ts-ignore
import SockJS from 'sockjs-client/lib/entry.js'
import { Client as StompClient } from '@stomp/stompjs'

// 订阅的事件列表
enum SubscriptEvent {
  // 获取额外的可抽奖次数
  awardTimesChange = 'awardTimesChange',
  // 更新奖池金额
  jackportAmountIncrease = 'jackportAmountIncrease',
  // 投注金额到账通知
  notifyBetReward = 'notifyBetReward',
  // tcc赛事爆奖信息
  MatchWinner = 'MatchWinner',
}
// 订阅的事件列表
enum TongitsSubscriptEvent {
  // tcc赛事爆奖信息
  MatchWinner = 'MatchWinner',
  // 获取一般游戏暴奖
  bigPrizeMatchWinner = 'bigPrizeMatchWinner',
  // 赛事列表变更
  MatchListChange = 'MatchListChange',
  // 赛事报名推送
  MatchListSign = 'tiptopMatchListSign',
  // betRebateEmit = 'tipBetRebateEmit',
}
// 订阅投注金事件
enum BetRebateSubscriptEvent {
  betRebateEmit = 'tipBetRebateEmit',
}
let isMounted = false
const getNewStompClient = () => {
  return new StompClient({
    webSocketFactory: () => socketInstance,
    reconnectDelay: 1000, // 设置重连间隔时间
    onConnect: () => {
      console.log('&&&YYYY')
      logger.logBusiness('连接成功', 'Websocket')
      reconnectTimerChecker && clearTimeout(reconnectTimerChecker)
      reconnectTimerChecker = null
      isConnected.value = true
      // 新增奖池金额
      _stompClient?.subscribe('/topic/notifyIncreaseJackpot', (message) => {
        const newbody: any = parseJson(message.body)
        jackportEventBus.emit('jackportAmountIncrease', newbody)
      })
      // 获取赛事爆奖信息
      _stompClient?.subscribe('/topic/tiptopMatchWinner', (message) => {
        const newbody: any = parseJson(message.body)
        tongitsEventBus.emit('MatchWinner', newbody)
      })
      // 赛事列表变更
      _stompClient?.subscribe('/topic/tiptopMatchListChange', (message) => {
        const newbody: any = parseJson(message.body)
        tongitsEventBus.emit('MatchListChange', newbody)
      })
      subscribeLoginUser()
    },
    onStompError: (frame) => {
      isConnected.value = false
      _stompClient?.unsubscribe('/topic/notifyIncreaseJackpot')
      _stompClient?.unsubscribe('/tiptopMatchWinner')
      unsubscribeLoginUser()
      reconnect()
      console.error('Broker reported error: ' + frame.headers['message'])
      console.error('Additional details: ' + frame.body)
    },
    onWebSocketClose: () => {
      isConnected.value = false
      reconnect()
      console.log('socket closed, attempting to reconnect...')
    },
    onDisconnect() {
      isConnected.value = false
      reconnect()
      console.log('onDisconnect')
    },
    onWebSocketError() {
      isConnected.value = false
      reconnect()
      console.log('onWebSocketError')
    },
  })
}
let _stompClient: StompClient | null = null
const isConnected = ref(false)
const parseJson = (data: string) => {
  try {
    return JSON.parse(data)
  } catch (error) {
    return data
  }
}
let currentSubscribleUser = '' // 缓存当前订阅的用户
let socketInstance: any = null
let reconnectTimerChecker: any = null
const jackportEventBus = useEventBus<keyof typeof SubscriptEvent>('jackport-eventbus')
const tongitsEventBus = useEventBus<keyof typeof TongitsSubscriptEvent>('tongits-eventbus')
const betRwardsEventBus = useEventBus<keyof typeof BetRebateSubscriptEvent>('bet-rwards-eventbus')
const connect = () => {
  socketInstance = new SockJS(getSocketUrl())
  _stompClient = getNewStompClient()
  _stompClient.activate()
}

const reconnect = () => {
  reconnectTimerChecker && clearTimeout(reconnectTimerChecker)
  reconnectTimerChecker = null
  logger.logBusiness('5s 后开始重连', 'Websocket')
  reconnectTimerChecker = setTimeout(() => {
    // 5秒后判断是否链接成功，如果没有重新链接
    logger.logBusiness('开始重连', 'Websocket')
    if (socketInstance) {
      logger.logBusiness('清除 socketInstance 实例', 'Websocket')
      socketInstance.close()
      socketInstance = null
    }
    if (_stompClient) {
      _stompClient.deactivate()
      logger.logBusiness('清除 _stompClient 实例', 'Websocket')
      _stompClient = null
    }
    connect()
    clearTimeout(reconnectTimerChecker)
  }, 5000)
}
const unsubscribeLoginUser = () => {
  if (_stompClient) {
    if (currentSubscribleUser) {
      // _stompClient.unsubscribe(`/user/${currentSubscribleUser}/notifyBetTransfer`)
      currentSubscribleUser = ''
    }
  }
}

const subscribeLoginUser = () => {
  const userStore = useUserStore(true)
  // 已经订阅
  if (currentSubscribleUser) {
    return
  }
  if (userStore.value.isLogin) {
    if (_stompClient && isConnected.value) {
      const loginName = userStore.value.loginName
      currentSubscribleUser = loginName + ''
      // 更新抽奖次数
      _stompClient.subscribe(
        `/user/${loginName}/notifyPlayerOpportunity`,
        (message) => {
          const newbody: any = parseJson(message.body)
          // message.ack(message.headers)
          _stompClient?.publish({ destination: `/gp/ack/${newbody.messageId}` })
          jackportEventBus.emit('awardTimesChange', newbody)
        },
        { 'X-Auth-Token': loginName + '' }
      )
    }
  }
}

export default function useJackportSocket() {
  // const disconnect = () => {
  //   _stompClient?.deactivate()
  //   console.log('Disconnected')
  // }
  return {
    connect() {
      if (isMounted) return
      isMounted = true
      connect()
    },
    subscribeLoginUser,
    unsubscribeLoginUser,
    jackportEventBus,
    tongitsEventBus,
    betRwardsEventBus,
  }
}
function getSocketUrl(): any {
  if (isUat()) {
    return 'https://gp-websocket-uat.uatextback66.com/ws'
  } else {
    return 'https://gp-websocket.xinba66.com/ws'
  }
}
