import { Banner, TongitsMatchResp } from '@/api/home'

const tongitsMatchs = ref<TongitsMatchResp[]>([])
const tongitsBanners = ref<Banner[]>([])
// 获取用户得赛事列表
const TongitsuserlistId = ref<(string | number)[]>([])
export function manualSetMatchesPrize(match: TongitsMatchResp) {
  // 金额等于0的时候需要手动写死
  if (Number(match.totalPrizeNum) <= 0) {
    // 每日当场设置 12888
    if (match.repeatType == 1) {
      match.totalPrizeNum = 12888 * 1000
    } else if (match.repeatType == 2) {
      match.totalPrizeNum = 188 * 1000
    }
  }
  return match
}
export default function () {
  const fetchTongitsMatches = async () => {
    try {
      const { success, body = [] } = await fetchMatchList()
      if (success) {
        tongitsMatchs.value = body.map((item) => {
          item.starttimeEn = DF.MdHm(item.startTime * 1000)
          item.signStartTimeEn = DF.MdHm(item.signStartTime * 1000)
          item.countdowntime = item.startTime - item.serverTime
          item.entertime = item.earlyEnterTime - item.serverTime
          if (item.cycleTimeItem && item.cycleTimeItem.length > 0) {
            const findCycle = item.cycleTimeItem.find(
              (TimeItem) =>
                item.serverTime >= TimeItem.startTimeSec &&
                item.serverTime <= TimeItem.finishTimeSec
            )
            if (findCycle) {
              item.delaySeconds = findCycle.intervalSec / 60
            } else {
              item.delaySeconds = 0
            }
          } else {
            item.delaySeconds = 0
          }
          item = manualSetMatchesPrize(item)
          if(item.signType ==  0 || item.signType ==  1 ){
            return item
          }
        }).filter(Boolean) as TongitsMatchResp[]
      }
    } catch (e) {
      console.error('checkfetchMatchList error', e)
    }
  }
  const fetchTongitsSignList = async () => {
    try {
      const { success, body } = await fetchSignList()
      if (!success) return
      TongitsuserlistId.value = body.listIds
      getuserGameList(TongitsuserlistId.value)
    } catch (e) {
      console.error('checkfetchSignList error', e)
    }
  }
  // 筛选出用户报名的赛事列表
  const getuserGameList = (list: (string | number)[]) => {
    tongitsMatchs.value.forEach((item) => {
      if (list?.includes(item.listId)) {
        item.usersigin = true
      } else {
        item.usersigin = false
      }
    })
  }
  return {
    tongitsMatchs,
    tongitsBanners,
    TongitsuserlistId,
    fetchTongitsMatches,
    fetchTongitsSignList,
  }
}
