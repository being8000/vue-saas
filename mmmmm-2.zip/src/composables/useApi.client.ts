import request from '@/util/request'
import { AlertType } from 'types/axios'
import { klona } from 'klona'
import { AxiosResponse } from 'axios'
interface MockFetchOptions {
  method: 'post' | 'get' | 'POST' | 'GET'
  body: any
  showLoading?: boolean // 是否全局加载loading, 默认为 false
  signature?: boolean // 设置是否请求需要带上签名, 默认为true
  encrypt?: boolean // 设置是否对默认数据加密, 默认为true
  withGlobal?: boolean // 是否带上全局数据, 默认为true
  needCustomerName?: boolean // 是否需要customerName参数（等于loginName）, 默认为false
  original?: boolean // 不经过拦截器直接放回response.data, 默认为 false
  skipCheck?: boolean // 不经过拦截器直接放回 { body } = response.data, 中的Body, 默认为 false
  alertType?: AlertType // 是否需要全局提示错误信息, 默认为 Toast 类型
  formData?: boolean // 默认false, 是否为表单提交
  auth?: boolean // 默认false , 检查当前环境是否已经登入，如果没有会弹出登录页面
  blobToJson?: boolean // 默认false, 将返回的blob转成json并输出
  showToast?: boolean // 默认true, 默认如果接口返回错误码 toast提示
  successTip?: string // 接口成功后示文案 默认Successed
  symbol?: Symbol
  key: any
  domainName: boolean
  backupUrls: string[] // url请求失败后依次请求备份urls地址直到成功
}

export const getUserOnlyId = (ip = '') => {
  if (!ip) return console.warn('userOnlyId:请输入IP参数,Please enter IP parameters')
  const screen = window.screen
  const width = screen.width
  const height = screen.height
  const newStr = ip?.replace(/\./g, '')
  return `${width}${newStr}${height}`
}
export const $api = async function <T = any>(url: string, options?: Partial<MockFetchOptions>) {
  options = options || {}
  const config: any = klona(options)
  config.body = undefined
  config.method = undefined

  const retryBackupUrls = async () => {
    const backupUrls = options.backupUrls || []
    const backupUrl = backupUrls.shift()
    if (!backupUrl) {
      return void 0
    }
    return $api<T>(backupUrl, {
      ...options,
      backupUrls,
    })
  }

  if (options.method?.toLowerCase() === 'post') {
    return new Promise<T>(async (resolve, reject) => {
      try {
        const res = await request
          .post<T>(url, options.body || {}, config)
          .then((res: AxiosResponse<T>) => {
            if (url.startsWith('/staticJs/') && !res?.data) {
              throw new Error(`url: ${url} response empty`)
            }
            return res.data
          })
        return resolve(res)
      } catch (error) {
        console.error(`url: ${url} error:`, error)
        if (!options.backupUrls?.length) {
          return resolve(null as T)
        }
      }
      return resolve((await retryBackupUrls()) as T)
    })
  } else {
    return new Promise<T>(async (resolve, reject) => {
      try {
        const res = await request
          .get<T>(url, {
            params: options.body || {},
            ...config,
          })
          .then((res: AxiosResponse<T>) => {
            if (url.startsWith('/staticJs/') && !res?.data) {
              throw new Error(`url: ${url} response empty`)
            }
            return res.data
          })
        return resolve(res)
      } catch (error) {
        console.error(`url: ${url} error:`, error)
        if (!options.backupUrls?.length) {
          return resolve(null as T)
        }
      }
      return resolve((await retryBackupUrls()) as T)
    })
  }
}
