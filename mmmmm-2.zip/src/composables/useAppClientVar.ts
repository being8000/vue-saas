/**
 * 该文件用于存放所有根据客户端变量需要
 */
/**
 * APP当前客户端环境, 如果要判断苹果手机/安卓手机等，可以使用 useDevice
 */
export enum AppClientEnum {
  Glife = 'Glife',
  Maya = 'Maya',
  Lazada = 'Lazada',
  Android = 'Android',
  Ios = 'Ios',
  H5 = 'H5',
  PC = 'PC',
}
export const palcodeSession = useStorage<string>('gamezone-palcode', null, window.sessionStorage)
export const isUat = () => {
  const url = useRequestURL()
  return (
    url.host.includes('c66uat.com') || url.host.includes('uatext66gp.com') || import.meta.env.DEV
  )
}
export type AppClientVar<T = any> = Record<AppClientEnum, T>
export enum AppPlatformEnum {
  H5 = 'H5',
  PC = 'PC',
  MINIAPP = 'MINIAPP',
  IOS = 'IOS',
  ANDROID = 'ANDROID',
}
export enum AppPackageEnum {
  GLIFE = 'MINI_GLIFE',
  MAYA = 'MINI_MAYA',
  LAZADA = 'MINI_MAYA',
}

export const useAppClientState = (defaultClient: AppClientEnum) => {
  const cookieClient = useCookie(StorageKey.AppClient)
  const appClient = useState<AppClientEnum>(StorageKey.AppClient, () => defaultClient)
  const setClient = (client: AppClientEnum) => {
    appClient.value = client
    cookieClient.value = client
  }
  setClient(defaultClient)

  // 用于实时更新当前的环境状态
  const updateClient = () => {
    const { isMobile } = useDevice()
  }
  return {
    setClient,
    updateClient,
  }
}
export default function () {
  // useCookie不能设置默认值，否则会存在浏览器首次访问后无法动态修改cookie值得问题。
  const appClient = useState<AppClientEnum>(StorageKey.AppClient)
  const cookieClient = useCookie<AppClientEnum>(StorageKey.AppClient)
  const isClient = (client: AppClientEnum) => {
    const current = getClient()
    return client === current
  }

  const isMaya = computed(() => isClient(AppClientEnum.Maya))
  const isGlife = computed(() => isClient(AppClientEnum.Glife))
  const isLazada = computed(() => isClient(AppClientEnum.Lazada))

  const getClient = () => {
    const { isNativeApp, isApple } = useDevice()
    if (isNativeApp) {
      return isApple ? AppClientEnum.Ios : AppClientEnum.Android
    }
    return appClient.value || cookieClient.value
  }
  const getCurrentClientConfig = <T = any>(configMap: AppClientVar<T>) => {
    return configMap[getClient()]
  }

  const isNativeAppAndroid = () => {
    const { isNativeApp, isAndroid } = useDevice()
    return isAndroid && isNativeApp
  }
  const isNativeAppIos = () => {
    const { isNativeApp, isIos } = useDevice()
    return isIos && isNativeApp
  }

  const isNativeApp = () => {
    const { isNativeApp } = useDevice()
    return isNativeApp
  }

  const isNativeAppMini = () => {
    const current = getClient()
    return [AppClientEnum.Glife, AppClientEnum.Lazada, AppClientEnum.Maya].includes(current)
  }

  const getEnvClientConfig = <T = any>(uat: AppClientVar<T>, prod: AppClientVar<T>) => {
    return isUat() ? uat[getClient()] : prod[getClient()]
  }

  // 根据不同环境获取推荐吗
  const getReferenceCode = () => {
    if (palcodeSession.value) return palcodeSession.value
    // 也是 palcode
    const refUatCodeMap: AppClientVar<string> = {
      [AppClientEnum.H5]: '1005768133',
      [AppClientEnum.PC]: '1005768133',
      [AppClientEnum.Maya]: '1005768136',
      [AppClientEnum.Glife]: '1005768135',
      [AppClientEnum.Lazada]: '1005768138',
      [AppClientEnum.Android]: '1005768134',
      [AppClientEnum.Ios]: '1005768134',
    }
    const refProdCodeMap: AppClientVar<string> = {
      [AppClientEnum.H5]: '967786933428158464',
      [AppClientEnum.PC]: '967786933428158464',
      [AppClientEnum.Maya]: '967822821055004672',
      [AppClientEnum.Glife]: '967821219124477953',
      [AppClientEnum.Lazada]: '968801100113117185',
      [AppClientEnum.Android]: '967819025398628353',
      [AppClientEnum.Ios]: '967819025398628353',
    }

    return getEnvClientConfig(refUatCodeMap, refProdCodeMap)
  }

  // 获取当前平台，平台只有ANDROID,IOS,MINIAPP,H5,PC ，和 客户端类型有点区别
  const getPlatform = () => {
    //   * ANDROID,IOS,MINIAPP,H5,PC

    return getCurrentClientConfig({
      [AppClientEnum.H5]: AppPlatformEnum.H5,
      [AppClientEnum.PC]: AppPlatformEnum.PC,
      [AppClientEnum.Maya]: AppPlatformEnum.MINIAPP,
      [AppClientEnum.Glife]: AppPlatformEnum.MINIAPP,
      [AppClientEnum.Lazada]: AppPlatformEnum.MINIAPP,
      [AppClientEnum.Android]: AppPlatformEnum.ANDROID,
      [AppClientEnum.Ios]: AppPlatformEnum.IOS,
    })
  }
  // https://project.larksuite.com/test123/story/detail/3707356
  const getPackage = () => {
    return getCurrentClientConfig({
      [AppClientEnum.Maya]: AppPackageEnum.MAYA,
      [AppClientEnum.Glife]: AppPackageEnum.GLIFE,
      [AppClientEnum.Lazada]: AppPackageEnum.LAZADA,
      [AppClientEnum.H5]: '',
      [AppClientEnum.PC]: '',
      [AppClientEnum.Android]: '',
      [AppClientEnum.Ios]: '',
    })
  }

  // 获取当前AppId
  const getAppId = () => {
    return getCurrentClientConfig({
      [AppClientEnum.H5]: 'C66GPH508',
      [AppClientEnum.PC]: 'C66GPPC08',
      [AppClientEnum.Maya]: 'C66GPMAYA08',
      [AppClientEnum.Glife]: 'C66GPGLIFE08',
      [AppClientEnum.Lazada]: 'C66GPLAZADA08',
      [AppClientEnum.Android]: 'C66GPAPP08',
      [AppClientEnum.Ios]: 'C66GPAPP06',
    })
  }

  // 获取当前AppId
  const getPayTerminal = () => {
    return getCurrentClientConfig({
      [AppClientEnum.H5]: 'MOB',
      [AppClientEnum.PC]: 'PC',
      [AppClientEnum.Maya]: 'MAYAMINIAPP',
      [AppClientEnum.Glife]: 'GLIFE',
      [AppClientEnum.Lazada]: 'LAZADAMINIAPP',
      [AppClientEnum.Android]: 'MOB',
      [AppClientEnum.Ios]: 'MOB',
    })
  }
  return {
    isClient,
    isNativeApp,
    isNativeAppMini,
    isNativeAppAndroid,
    isNativeAppIos,
    getClient,
    getCurrentClientConfig,
    getReferenceCode,
    getPlatform,
    getPackage,
    getAppId,
    getPayTerminal,
    isMaya,
    isGlife,
    isLazada,
  }
}
