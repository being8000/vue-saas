import { GameBaseAllResp, GameBaseItem } from '@/api/game'
import { Banner, BlockStyle, DirtyBlockConfig, GameProviderVo } from '@/api/home'
import { isArray, isFunction } from 'lodash-es'
export type BlockLayoutCondition = string | (() => boolean)

export interface BlockLayout {
  id: number | string
  component: string
  props: Record<string, any>
  conditions?: BlockLayoutCondition[]
}

export interface BlockConfig {
  id: number
  label: string
  code: string
  icon: string
  iconH5V2: string
  sortH5V2: number
  allGames: GameBaseItem[]
  layoutId2AllGames: Record<number, GameBaseItem[]>
  layouts: BlockLayout[]
  lastBlockId?: string | number
}

export interface CasinoTaxonomy {
  id: number
  name: string
  code: string
  params?: any
  label: string
  icon: string
  searchLabel: string
}

export interface Provider {
  platformId: string
  platformName: string
  platformCode: string
  imgUrl: string
  gameLogoUrl: string
  platformDisplayName?: string
}

interface NormalizeConfig {
  defaultPrepend?: BlockLayout[]
  prepend?: Record<PropertyKey, BlockLayout[]>
  defaultAppend?: BlockLayout[]
  append?: Record<PropertyKey, BlockLayout[]>
}

// ANCHOR 游戏基础数据状态存储
export const gameBaseAll = ref<GameBaseAllResp>({
  data: [],
  gameMap: new Map(),
  firstPage: false,
  fistPage: 0,
  lastPage: false,
  next: false,
  nextPage: 0,
  onlyTotalCount: false,
  pageEndRow: 0,
  pageIndexL: 0,
  pageSize: 0,
  pageStartRow: 0,
  previousPage: 0,
  totalPages: 0,
  totalRows: 0,
})
// ANCHOR 区块数据状态存储

/**
 * @zh 通过游戏id集合查询所有相关游戏数据
 * NOTE 是基础数据中的id字段不是gameId字段
 *
 * @param {number[]} ids id集合
 * @return {*}  {GameBaseItem[]}
 */
export const findAllGamesByIds = (ids: number[]): GameBaseItem[] => {
  if (!ids || !ids.length) return []
  let games = ids?.map((id) => gameBaseAll.value.gameMap.get(id)).filter(Boolean) as GameBaseItem[]
  // let games = (gameBaseAll.value.data || []).filter((game) => ids.includes(game.id))
  // games = ids
  //   .map((id) => {
  //     return games.find((game) => game.id == id) as GameBaseItem
  //   })
  //   .filter(Boolean)
  const maintenanceGames = remove(games, (game) => isMaintenanceOfGame(game)).sort((a, b) => {
    return +new Date(a.maintainEndTime) - +new Date(b.maintainEndTime)
  })

  return [...games, ...maintenanceGames]
}
/**
 * @zh 从全部游戏中找到对应游戏
 *
 * @param {string} platformId 提供商id
 * @param {string} gameId 游戏id
 * @return {*}
 */
const findAllCasinoGame = (platformId: string, gameId: string) => {
  const allGames = gameBaseAll.value.data || []
  return allGames.find((game) => game.platformId == platformId && gameId == game.gameId)
}

/**
 * @zh 查找所有基础游戏数据
 *
 * @return {*}  {GameBaseItem[]}
 */
const findAllCasinoGames = (): GameBaseItem[] => {
  return gameBaseAll.value.data || []
}
const findGameByGameId = (gameId: number): GameBaseItem | undefined => {
  return gameBaseAll.value.gameMap.get(gameId)
}
/**
 * @zh 通过提供商id查找对应提供商
 *
 * @param {string} platformId
 * @return {*}  {(Provider | undefined)}
 */
const findProviderById = (platformId: string) => {
  // return providers.value?.find((provider) => provider.platformId === platformId)
}

/**
 * @zh 查找所有基础游戏数据, 过滤维护中的游戏
 *
 * @return {*}  {GameBaseItem[]}
 */
const findAllNormalGames = (): GameBaseItem[] => {
  const res = _OrderBy(
    (gameBaseAll.value.data || []).filter(
      (el) =>
        el.flag != 2 &&
        el.platformStatus === 1 &&
        (+new Date(el.maintainStartTime) > Date.now() || +new Date(el.maintainEndTime) < Date.now())
    ),
    ['ggr'],
    ['desc']
  )
  return res
}

/**
 * @zh 所有游戏下通过gameIds查找相关游戏
 *
 * @param {string[]} gameIds game中gameId字段
 * @return {*}  {GameBaseItem[]}
 */
const findAllCasinoGamesByGameIds = (gameIds: string[]): GameBaseItem[] => {
  const filterGames = findAllCasinoGames().filter((game) => gameIds.includes(game.gameId))
  return gameIds
    .map((gameId) => {
      return filterGames.find((game) => game.gameId === gameId) as GameBaseItem
    })
    .filter(Boolean)
}

/**
 * @zh 基础游戏去重、排序、维护游戏置于底部
 * NOTE 去重需要使用gameId+platformId
 *
 * @param {GameBaseItem[]} games
 * @return {*}
 */
const sortGames = (games: GameBaseItem[]) => {
  // 查找维护中的游戏并按维护结束时间从小到大排序
  const maintenanceGames = remove(games, (game) => isMaintenanceOfGame(game)).sort((a, b) => {
    return +new Date(a.maintainEndTime) - +new Date(b.maintainEndTime)
  })

  const sortGames = games.sort((a, b) => {
    return b.sortNo - a.sortNo
  })

  return [...sortGames, ...maintenanceGames]
}

// ANCHOR 平铺游戏中jsonParam字段到game中
const normalizeGameJsonParam = (games: GameBaseItem[]) => {
  games.forEach((game) => {
    try {
      const jsonParam = game.jsonParam ? JSON.parse(game.jsonParam) : ''
      game['vid'] = jsonParam.vid || ''
      game['gmtype'] = jsonParam.gmType || ''
      game['jumpJson'] = JSON.stringify(jsonParam.jumpParam) || ''
    } catch (error) {
      game['vid'] = ''
      game['gmtype'] = ''
      game['jumpJson'] = ''
    }
  })
  return games
}
const formatGameImage = (game: any, formatKey = 'gameImage') => {
  if (
    !game[formatKey]?.startsWith('http://') &&
    !game[formatKey]?.startsWith('https://') &&
    !game[formatKey]?.startsWith('/externals') &&
    !game[formatKey]?.startsWith('externals/')
  ) {
    // REVIEW 在没有性能影响的情况下能后台实现的功能全部由后台实现
    game[formatKey] = `${'/externals/C66FM/img/_wms/_l/electronicgames/'}${game[formatKey]}`
  }
}

// ANCHOR API获取所有游戏并进行处理
const _fetchCasinoGames = async () => {
  const data = await fetchAllBaseGame()
  console.log('_fetchCasinoGames', data)
  const games: GameBaseItem[] = sortGames(isArray(data?.data) ? data?.data : [])
  gameBaseAll.value.data = games

  // note 遍历base all函数
  mapGameBaseAll()
}

const mapGameBaseAll = () => {
  const games = gameBaseAll.value.data
  games.forEach((game) => {
    let gameId = game.id
    formatGameImage(game, 'gameImage')
    formatGameImage(game, 'gameImageNew')

    gameBaseAll.value.gameMap.set(gameId, game)
  })
}

const normalizeDirtyBlockConfigs = (dirtyBlockConfigs: any[]): BlockLayout[] => {
  // dirtyBlockConfigs = blockList
  const blockLayout = dirtyBlockConfigs
    .sort((a, b) => b.sort - a.sort)
    .map((dirtyBlock, _index) => {
      // NOTE 区块的展示结束逻辑
      const startTime = +new Date(dirtyBlock.startTime)
      const endTime = +new Date(dirtyBlock.endTime)
      const now = Date.now()
      if (!(now >= startTime && now <= endTime)) {
        return
      }
      if (dirtyBlock.style == BlockStyle.Block1) {
        if (!dirtyBlock.bannerList) return undefined
        const LazySwiperBannerlayout: BlockLayout = {
          id: dirtyBlock.id,
          component: 'LazySwiperBanner',
          props: {
            aspectRatio: 351 / 100,
            class: 'tw-px-3 mt',
            banners: dirtyBlock.bannerList,
          },
        }
        return LazySwiperBannerlayout
      } else if (dirtyBlock.style == BlockStyle.Block2) {
        const CardGameslayout: BlockLayout = {
          id: dirtyBlock.id,
          component: 'Chunk2',
          props: {
            bannerList: dirtyBlock.bannerList,
            title: dirtyBlock.blockName,
            games: findAllGamesByIds(dirtyBlock.gameBaseIdList),
          },
        }
        return CardGameslayout
      } else if (dirtyBlock.style == BlockStyle.Block3) {
        const CardGameslayout: BlockLayout = {
          id: dirtyBlock.id,
          component: 'Chunk3',
          props: {
            bannerList: dirtyBlock.bannerList,
            title: dirtyBlock.blockName,
            games: findAllGamesByIds(dirtyBlock.gameBaseIdList),
          },
        }
        return CardGameslayout
      } else if (dirtyBlock.type == BlockType.component) {
        // 自定义
        const CustomComponent: BlockLayout = {
          id: dirtyBlock.id,
          component: dirtyBlock.blockParam,
          props: {},
        }
        return CustomComponent
      }
      dirtyBlock.columnStyle = 3
      const CardGameslayout: BlockLayout = {
        id: dirtyBlock.id,
        component: 'ChunkGames',
        props: {
          title: dirtyBlock.blockName,
          games: findAllGamesByIds(dirtyBlock.gameBaseIdList),
          column: dirtyBlock.columnStyle,
        },
      }
      return CardGameslayout
    })
    .filter(Boolean) as BlockLayout[]

  return blockLayout
}

// ANCHOR useBlock
// NOTE 区块为首页选项卡中各个大类配置
// 而布局是区块中的各种组件例如：可滑动的游戏、可滑动的提供商、游戏列表等等
export const useBlock = () => {
  const userStore = useUserStore(true)

  // ANCHOR 区块布局的显示隐藏条件
  const conditions = {
    isLogin() {
      return userStore && userStore.value && userStore.value.isLogin
    },
    unLogin() {
      return !userStore || !userStore.value || !userStore.value.isLogin
    },
  }

  /**
   * @zh 验证区块中的layout是否应该被显示
   *
   * @param {BlockLayoutCondition[]} [cds] 条件集合（conditions中的函数名或() => boolean函数）
   * @return {*}  {boolean}
   */
  const verifyBlockConditions = _Memoize((cds?: BlockLayoutCondition[]): boolean => {
    if (!cds || cds.length === 0) {
      return true
    }
    return cds.every((cd) => {
      if (isFunction(cd)) {
        return cd()
      } else {
        const condition = (conditions as any)[cd]
        return condition && condition()
      }
    })
  })

  watch(
    () => userStore.value.isLogin,
    () => {
      verifyBlockConditions.cache.clear?.()
    }
  )

  return {
    verifyBlockConditions,
    fetchCasinoGames: _fetchCasinoGames,
    findAllCasinoGamesByGameIds,
    findAllCasinoGames,
    findAllCasinoGame,
    findAllNormalGames,
    findGameByGameId,
    findAllGamesByIds,
    normalizeDirtyBlockConfigs,
    findProviderById,
  }
}
