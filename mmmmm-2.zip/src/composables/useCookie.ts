import {
  customRef,
  getCurrentScope,
  nextTick,
  onScopeDispose,
  ref,
  watch,
} from "vue";
import { parse, serialize } from "cookie-es";
import destr from "destr";
import { isEqual } from "ohash";
import { klona } from "klona";
import type { Ref } from "vue";
import type { CookieParseOptions, CookieSerializeOptions } from "cookie-es";
type _CookieOptions = Omit<
  CookieSerializeOptions & CookieParseOptions,
  "decode" | "encode"
>;
interface CookieOptions<T = any> extends _CookieOptions {
  decode?(value: string): T;
  encode?(value: T): string;
  default?: () => T | Ref<T>;
  watch?: boolean | "shallow";
  readonly?: boolean;
}
const CookieDefaults: CookieOptions = {
  path: "/",
  watch: true,
  decode: (val) => destr(decodeURIComponent(val)),
  encode: (val) =>
    encodeURIComponent(typeof val === "string" ? val : JSON.stringify(val)),
};

const store = window.cookieStore;

export function useCookie<T = any>(name: string | number, _opts?: any) {
  const opts = { ...CookieDefaults, ..._opts };
  opts.filter ??= (key: any) => key === name;
  const cookies = readRawCookies(opts) || {};
  let delay;
  if (opts.maxAge !== void 0) {
    delay = opts.maxAge * 1e3;
  } else if (opts.expires) {
    delay = opts.expires.getTime() - Date.now();
  }
  const hasExpired = delay !== void 0 && delay <= 0;
  const cookieValue = klona(
    hasExpired ? void 0 : cookies[name] ?? opts.default?.()
  );
  const cookie =
    delay && !hasExpired
      ? cookieRef(cookieValue, delay, opts.watch && opts.watch !== "shallow")
      : ref(cookieValue);
  if (import.meta.env.DEV && hasExpired) {
    console.warn(
      `[nuxt] not setting cookie \`${name}\` as it has already expired.`
    );
  }
  let channel = null;
  try {
    if (!store && typeof BroadcastChannel !== "undefined") {
      channel = new BroadcastChannel(`nuxt:cookies:${name}`);
    }
  } catch {}
  const callback = () => {
    if (opts.readonly || isEqual(cookie.value, cookies[name])) {
      return;
    }
    writeClientCookie(name, cookie.value, opts);
    cookies[name] = klona(cookie.value) || "";
    channel?.postMessage({ value: opts.encode(cookie.value) });
  };
  const handleChange = (data: { value: any; refresh?: any }) => {
    const value = data.refresh
      ? readRawCookies(opts)?.[name]
      : opts.decode(data.value);
    watchPaused = true;
    cookie.value = value;
    cookies[name] = klona(value);
    nextTick(() => {
      watchPaused = false;
    });
  };
  let watchPaused = false;
  const hasScope = !!getCurrentScope();
  if (hasScope) {
    onScopeDispose(() => {
      watchPaused = true;
      callback();
      channel?.close();
    });
  }
  if (store) {
    const changeHandler = (event: { changed: any[]; deleted: any[] }) => {
      const changedCookie = event.changed.find(
        (c: { name: any }) => c.name === name
      );
      const removedCookie = event.deleted.find(
        (c: { name: any }) => c.name === name
      );
      if (changedCookie) {
        handleChange({ value: changedCookie.value });
      }
      if (removedCookie) {
        handleChange({ value: null });
      }
    };
    store.addEventListener("change", changeHandler);
    if (hasScope) {
      onScopeDispose(() => store.removeEventListener("change", changeHandler));
    }
  } else if (channel) {
    channel.onmessage = ({ data }) => handleChange(data);
  }
  if (opts.watch) {
    watch(
      cookie,
      () => {
        if (watchPaused) {
          return;
        }
        callback();
      },
      { deep: opts.watch !== "shallow" }
    );
  } else {
    callback();
  }
  return cookie;
}
export function refreshCookie(name: any) {
  new BroadcastChannel(`nuxt:cookies:${name}`)?.postMessage({ refresh: true });
}
function readRawCookies(opts = {}) {
  return parse(document.cookie, opts);
}
function serializeCookie(
  name: string,
  value: string | null | undefined,
  opts = {}
) {
  if (value === null || value === void 0) {
    return serialize(name, value || "", { ...opts, maxAge: -1 });
  }
  return serialize(name, value, opts);
}
function writeClientCookie(name: any, value: any, opts = {}) {
  document.cookie = serializeCookie(name, value, opts);
}

const MAX_TIMEOUT_DELAY = 2147483647;
function cookieRef(value: string | undefined, delay: number, shouldWatch: any) {
  let timeout: string | number | NodeJS.Timeout | undefined;
  let unsubscribe: () => void;
  let elapsed = 0;
  const internalRef = shouldWatch ? ref(value) : { value };
  if (getCurrentScope()) {
    onScopeDispose(() => {
      unsubscribe?.();
      clearTimeout(timeout);
    });
  }
  return customRef((track, trigger) => {
    if (shouldWatch) {
      unsubscribe = watch(internalRef, trigger);
    }
    function createExpirationTimeout() {
      elapsed = 0;
      clearTimeout(timeout);
      const timeRemaining = delay - elapsed;
      const timeoutLength =
        timeRemaining < MAX_TIMEOUT_DELAY ? timeRemaining : MAX_TIMEOUT_DELAY;
      timeout = setTimeout(() => {
        elapsed += timeoutLength;
        if (elapsed < delay) {
          return createExpirationTimeout();
        }
        internalRef.value = void 0;
        trigger();
      }, timeoutLength);
    }
    return {
      get() {
        track();
        return internalRef.value;
      },
      set(newValue) {
        createExpirationTimeout();
        internalRef.value = newValue;
        trigger();
      },
    };
  });
}
