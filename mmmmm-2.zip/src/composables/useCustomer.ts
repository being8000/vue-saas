export interface CustomerStore {
  loading: boolean
}

export function useCustomer() {
  const show = async (username?: string) => {
    // TODO 打开bp客服
  }
  return {
    show,
  }
}
