export function useDelayRender(): { delay: Function } {
  const current = ref(0)
  const max = 20
  function run() {
    const step = () => {
      window.requestAnimationFrame(() => {
        if (current.value++ < max) {
          step()
        }
      })
    }
    step()
  }
  function delay(sort: number) {
    return current.value >= sort
  }
  setTimeout(() => {
    run()
  })
  return {
    delay,
  }
}
