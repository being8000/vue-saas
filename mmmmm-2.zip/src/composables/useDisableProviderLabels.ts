import { DisableProviderLabel } from '@/api/game'

export const useDisableProviderLabelsStore = () => {
  const storeDisableProviderLabel = useState<DisableProviderLabel[]>(
    StorageKey.DisableProviderLabel,
    () => []
  )
  return storeDisableProviderLabel
}

export const useDisableProviderLabels = () => {
  const storeDisableProviderLabel = useDisableProviderLabelsStore()

  const fetchList = async () => {
    if (storeDisableProviderLabel.value.length) {
      return
    }
    const { success, body } = await fetchDisableLobbyLabel()
    if (success) {
      storeDisableProviderLabel.value = _UnionBy(
        body.map((game) => {
          return game
        }) || [],
        'lobbyCode'
      )
    }
  }

  const diableCodes = computed(() => {
    return storeDisableProviderLabel.value.map((item) => item.lobbyCode)
  })

  const filterEnableProviders = (providers: string[]) => {
    return providers.map((provider) => !diableCodes.value.includes(provider))
  }

  const isDisabled = (provider: string) => {
    return diableCodes.value.some((item) => item == provider)
  }

  const isEnabled = (provider: string) => {
    return !isDisabled(provider)
  }

  return {
    disableProviderLabelStore: storeDisableProviderLabel,
    fetchList,
    diableCodes,
    filterEnableProviders,
    isEnabled,
    isDisabled,
  }
}
