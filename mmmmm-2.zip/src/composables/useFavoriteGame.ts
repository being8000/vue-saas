import { GameBaseItem, LikeGame } from '@/api/game'

export const useFavoriteGames = () => {
  const storeFavoriteGame = localStorageRef<LikeGame[]>('favoriteGames', []) as Ref<LikeGame[]>
  const { findAllCasinoGamesByGameIds } = useBlock()
  const games = computed(() => {
    return findAllCasinoGamesByGameIds(storeFavoriteGame.value.map((game) => game.gameId))
  })
  const total = computed(() => {
    return storeFavoriteGame.value.length
  })
  return {
    favoriteGameStore: storeFavoriteGame,
    games,
    total,
  }
}

export const useFavoriteGame = () => {
  const { $toast } = useNuxtApp()
  const storeFavoriteGame = localStorageRef<LikeGame[]>(`favoriteGames`, []) as Ref<LikeGame[]>

  const liked = async (game: GameBaseItem) => {
    const item = {
      platformCode: game.platformId,
      gameId: game.gameId,
    }
    if (storeFavoriteGame.value.length >= 20) {
      $toast(
        'You have reached 20 Liked games, must remove one or more to add this to your Like Games'
      )
      return false
    }
    if (storeFavoriteGame.value.some((item) => item.gameId === game.gameId)) {
      return false
    }
    try {
      const { body } = await addLike(_CloneDeep(item))
      if (body) {
        storeFavoriteGame.value.push(item)
        return true
      }
    } catch (error) {
      console.error(error)
    }
    return false
  }
  const unLiked = (game: GameBaseItem) => {
    const index = storeFavoriteGame.value?.findIndex((item) => item.gameId === game.gameId)
    if (index >= 0) {
      storeFavoriteGame.value.splice(index, 1)
    }
    cancelLike({
      platformCode: game.platformId,
      gameId: game.gameId,
    })
  }
  const has = (gameId: string) => {
    return storeFavoriteGame.value.some((game) => game.gameId === gameId)
  }
  const fetchList = async () => {
    const data = await fetchLikeList()
    if (!Array.isArray(data.body)) return
    storeFavoriteGame.value = _UnionBy(
      data.body.map((game) => {
        return {
          gameId: game.gameId,
          platformCode: game.platformCode,
        } as LikeGame
      }) || [],
      'gameId'
    )
  }
  return {
    favoriteGameStore: storeFavoriteGame,
    liked,
    unLiked,
    has,
    fetchList,
  }
}
