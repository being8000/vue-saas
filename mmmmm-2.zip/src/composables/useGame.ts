import { GameRespVO, GameBaseItem, GameBaseAllResp } from '@/api/game'
import { gameBaseAll } from '@/composables/useBlock'
import useState from './useState'

export interface UseGameConfig {
  navigate?: boolean
  jumpJson?: string
}

export interface GameStore {
  locked: boolean
  url: string
}

export const useGameStore = () => {
  return useState<GameStore>(StorageKey.Game, () => {
    return {
      locked: false,
      url: '',
    }
  })
}

export function useGame(platformId: string, gameId: string, config?: UseGameConfig) {
  const { findAllCasinoGame } = useBlock()
  const game = findAllCasinoGame(platformId, gameId)!
  const userStore = useUserStore(true)
  const userDetailStore = useUserDetailStore()
  const siteInfoStore = useSiteInfoStore()
  const router = useRouter()
  const { $toast } = useNuxtApp()

  const toast = (msg: string) => {
    $toast(msg, {
      async onClose() {
        if (!config?.navigate) {
          return
        }
        if (history?.state?.back) {
          router.back()
        } else {
          await router.push({ name: 'index', replace: true })
        }
      },
    })
  }

  const fetchGameUrl = async () => {
    const { productId } = useRuntimeConfig().public
    const url = useRequestURL()
    try {
      const jsonParam = strToJson(game.jsonParam, {
        vid: '',
        gmType: '',
        jumpParam: {},
      })
      game.vid = jsonParam.vid || ''
      game.gmtype = jsonParam.gmType || ''
      const queryJson = strToJson(config?.jumpJson, {})
      game.jumpJson = JSON.stringify(_Merge(queryJson, jsonParam.jumpParam || {}))
    } catch (error) {}
    console.log('inGame', game)
    const data = await fetchInGame({
      gameCode: `${productId}${game?.platformId}`,
      platformCode: game?.platformId || '',
      gameId: game?.gameId || '',
      gameName: game?.nameEn || game?.nameZh || '',
      gameType: game?.gameType || '-1',
      gdGameId: game?.gdGameId || '',
      callbackPath: window.location.origin,
      domainName: url.host,
      lang: 'EN',
      isWithTransfer: '1',
      platformCurrency: 'PHP',
      roomType: game?.gmtype || '',
      videoId: game?.vid || '',
      jumpParam: game.jumpJson,
    })
    return {
      url: data?.body?.url || '',
      message: data?.head.errMsg || '',
    }
  }

  const verifyLogin = async () => {
    if (!userStore.value.isLogin) {
      return false
    }
    return true
  }

  const verifyGlife = async () => {
    const isGlife = userStore.value.isFrom?.toLowerCase() === 'glife'
    const isSwitch = siteInfoStore.value.GLIFE_PERSONAL_INFO_SWITCH == '1'
    const isFullPersonInfo = () => {
      if (
        userDetailStore.value.firstName &&
        userDetailStore.value.lastName &&
        userDetailStore.value.birthday &&
        userDetailStore.value.nationality &&
        userDetailStore.value.birthPlace &&
        userDetailStore.value.presentAddress &&
        userDetailStore.value.permanentAddress &&
        userDetailStore.value.sourceOfIncome &&
        userDetailStore.value.work &&
        userDetailStore.value.employerName
      ) {
        return true
      } else {
        return false
      }
    }
    const isOver7Day = async () => {
      const sysTime = await fetchSysTime()
      const r = new Date(userDetailStore.value.registDate || '').getTime()
      const n = new Date(sysTime || Date.now()).getTime()
      const gap = Math.ceil((n - r) / (24 * 60 * 60 * 1000))
      if (gap > 7) {
        return true
      } else {
        return false
      }
    }
    if (isGlife && isSwitch && !isFullPersonInfo() && (await isOver7Day())) {
      return false
    }
    return true
  }

  const verifyPlatformStatus = async () => {
    if (game?.flag !== 1 || game?.platformStatus !== 1) {
      return false
    }
    return true
  }

  const verifyBlackList = async () => {
    if (userDetailStore.value.isBlackList == 1) {
      return false
    }
    return true
  }

  const verify = async () => {
    if (!(await verifyLogin())) {
      console.info('Please log in to your account')
      toast('Please log in to your account')
      return false
    }
    if (!(await verifyGlife())) {
      console.info('You must complete KYC to continue playing!')
      toast('You must complete KYC to continue playing!')
      return false
    }
    // if (!await verifyMargin()) {
    //   console.info('Sorry,You need to activate Online Betting first')
    //   toast("Sorry,You need to activate Online Betting first")
    //   return false
    // }
    if (!(await verifyPlatformStatus())) {
      console.info('Sorry, platform is under maintenance!')
      toast('Sorry, platform is under maintenance!')
      return false
    }
    if (!(await verifyBlackList())) {
      console.info('Maintenance in progress')
      toast('Maintenance in progress')
      return false
    }
    return true
  }

  return {
    verifyLogin,
    fetchGameUrl,
    verify,
    toast,
    game,
  }
}

//进厅游戏
const getGameData = ref<GameRespVO | undefined>()
export const useGameMenu = () => {
  //console.log('进入游戏')
  const gameListMenu = async (game: GameBaseItem) => {
    console.log(game, 'game444')
    let data = await fetchGamingRecorment()
    data = (Array.isArray(data) ? data : [])
      .filter((el) => Number(el.pagination) == Number(game.gameType))
      .filter((item) => {
        const startTime = +new Date(item.startTime)
        const endTime = +new Date(item.endTime)
        const now = Date.now()
        if (!(now >= startTime && now <= endTime)) {
          return false
        }
        return true
      })
      .sort((a, b) => b.sort - a.sort)
    //console.log(data, '777')
    getGameData.value = data[0]
    //console.log(data, 'data34343')
  }
  return {
    gameListMenu,
    getGameData,
  }
}
// 转换所有的游戏数据格式
export const changeBasGame = () => {
  const gameListMap = gameBaseAll.value.data.reduce((acc: any, item: GameBaseItem) => {
    acc[item.id] = item
    return acc
  }, {} as { [key: number]: string })
  return {
    gameListMap,
  }
}
