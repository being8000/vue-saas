export function useHydrated(fn: () => Promise<void> | void) {
  onMounted(async () => {
    const pending = async () => {
      await promisedTimeout(1)
      const nuxtApp = useNuxtApp()
      if (nuxtApp.isHydrating) {
        await pending()
      } else {
        await fn()
      }
    }
    await pending()
  })
}
