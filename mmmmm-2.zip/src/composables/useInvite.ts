
export default function useInvite() {
  const inviteId = sessionStorageRef<string>(StorageKey.InviteId, '')
  const setInviteId = (id: string) => {
    inviteId.value = id
  }

  const trackInviteId = () => {
    const requestUrl = useRequestURL()
    const urlParams = new URLSearchParams(requestUrl.search);
    const id = urlParams.get("inviteId")
    if (!id) return
    setInviteId(id)
  }

  const bindInviteId = async () => {
    if (!inviteId.value) return
    bindInvite({
      inviteId: inviteId.value
    })
  }

  return {
    inviteId,
    trackInviteId,
    bindInviteId
  }
}
