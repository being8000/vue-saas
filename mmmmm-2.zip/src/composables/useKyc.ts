import { differenceInDays, differenceInHours } from 'date-fns'
import router from '@/router'
import { VBtn } from 'vuetify/components/VBtn'

const isTwolevelSwitchNoKyc = computed<boolean>(() => {
  const siteInfoStore = useSiteInfoStore()
  const userDetailStore = useUserDetailStore()
  const diffHours = differenceInHours(new Date(), new Date(userDetailStore.value.registDate || ''))
  const isGpNewUserNoKyc =
    siteInfoStore.value.GPUSER_KYC_EXEMPT == '1' &&
    userDetailStore.value.product == 3 &&
    diffHours < 24
  const isDepositUserNoKyc =
    siteInfoStore.value.DEPOSIT_USER_KYC_EXEMPTION == '1' && userDetailStore.value.firstDepositFlag

  const isNewRegisterNoKyc = diffHours < 24 && siteInfoStore.value.REGISTRATION_KYC_EXEMPTION == '1'
  const isOldRegisterNoKyc = diffHours >= 24 && siteInfoStore.value.OLDUSER_KYC_EXEMPTION == '1'

  return isGpNewUserNoKyc || isDepositUserNoKyc || isNewRegisterNoKyc || isOldRegisterNoKyc
})
// 注册超过{*}天强制kyc kyc改成文本动态配置
export const use7daysKyc = () => {
  return new Promise<void>(async (resolve, reject) => {
    const siteInfoStore = useSiteInfoStore()
    const userDetailStore = useUserDetailStore()

    if (isTwolevelSwitchNoKyc.value) {
      return resolve()
    }
    // userDetailStore.value.requireEkyc = true
    // userDetailStore.value.rejectReason = 'id repeated'
    // userDetailStore.value.isPopupWindow = false
    // 用户需要重新做ekyc --eKyc3.0
    if (userDetailStore.value.requireEkyc) {
      let content =
        'Dear User，In line with PAGCOR regulatory requirements，we are conducting periodic updates to ensure the accuracy of user information. As part of this process, we kindly request that you re-authenticate your KYC information. Thank you for your cooperation.'
      if (userDetailStore.value.rejectReason?.includes('id repeated')) {
        // EKYC ID重复 修改提示
        content =
          'Dear User，Thank you for submitting your ID for verification. As the provided ID has exceeded the maximum number of allowed verifications，the authentication has not been successful. We appreciate your understanding and cooperation. If you have any questions, please feel free to contact us.'
      }
      $dialog.pop({
        closeCha() {
          if (userDetailStore.value.isPopupWindow) {
            reject()
          } else {
            resolve()
          }
        },
        title: 'Complete your KYC now! ',
        slots: {
          bottom: () =>
            h(
              'div',
              {
                class: 'tw-flex tw-full tw-px-3 tw-mb-4',
              },
              [
                h(
                  VBtn,
                  {
                    color: 'primary',
                    class: 'tw-mr-3  tw-flex-1',
                    onClick: () => {
                      $dialog.close()
                      reject()
                      setTimeout(() => {
                        router.push({ path: '/account/kyc' })
                      })
                    },
                  },
                  'Go',
                ),
                userDetailStore.value.isPopupWindow
                  ? null
                  : h(
                      VBtn,
                      {
                        color: 'surface-light-4',
                        class: 'tw-flex-1',
                        onClick: () => {
                          $dialog.close()
                          resolve()
                        },
                      },
                      'Later',
                    ),
              ],
            ),
        },
        content,
      })
      return
    }
    const { GAME_7_DAYS_KYC_SWITCH = undefined } = siteInfoStore.value
    // '' 不强制kyc
    // '0' 代表立即做kyc  '3'代表3天后做kyc
    const kycSwitch =
      typeof GAME_7_DAYS_KYC_SWITCH == 'string' &&
      GAME_7_DAYS_KYC_SWITCH.length >= 1 &&
      +GAME_7_DAYS_KYC_SWITCH >= 0
    if (kycSwitch) {
      const finishKyc = userDetailStore.value.firstIdStatus == '1'
      // 如果已经做了kyc或者打开子kyc开关 则不校验
      if (finishKyc) {
        return resolve()
      }

      let diffDays = differenceInDays(new Date(), new Date(userDetailStore.value.registDate || ''))
      const needKyc = diffDays >= +GAME_7_DAYS_KYC_SWITCH
      if (!finishKyc && needKyc) {
        $dialog
          .pop({
            title: 'Complete your KYC now!',
            confirmButtonText: 'Go',
            cancelButtonText: 'Later',
            content:
              'According to PAGCOR regulations, users must complete KYC certification first！',
          })
          .then((res: any) => {
            if (res) {
              router.push({ path: '/account/kyc' })
            }
          })
        reject()
      }
    }
    resolve()
  })
}
