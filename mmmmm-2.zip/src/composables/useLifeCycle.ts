import { useUserStore } from './useUserStore'
const { fetchList } = useFavoriteGame()
const userStore = useUserStore()
watch(
  () => userStore.value.isLogin,
  (v) => {
    if (!v) return
    fetchList()
  }
)
