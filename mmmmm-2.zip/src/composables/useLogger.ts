/**
 * @zh 日志输出对应标记
 *
 * @export
 * @enum {number}
 */
export enum LoggerStdout {
  /**
   * @zh 服务端输出日志
   */
  Server = 1 << 0,
  /**
   * @zh 客户端输出日志
   */
  Client = 1 << 1,
}

/** 开启日志 */
export const loggerEnabled = true
/** 输出对应日志 */
export const loggerTags = LoggerStdout.Client | LoggerStdout.Server

/**
 * @zh 是否开启对应端输出日志
 *
 * @param {LoggerStdout} tag
 * @return {*}
 */
const isOpen = (tag: LoggerStdout) => {
  return (loggerTags & tag) != 0
}

/**
 * @zh 对应端日志是否未启用
 *
 * @param {LoggerStdout} tag
 * @return {*}
 */
const isClose = (tag: LoggerStdout) => {
  return !isOpen(tag)
}

const logger = new Logger()
logger.setBadgePrefix('应用日志')
logger.setBadgeSuffix('GameZone')

export function useLogger() {
  if (!loggerEnabled) {
    logger.clearTags()
  }
  if (import.meta.env.PROD) {
    logger.clearTags()
  }
  if (isClose(LoggerStdout.Client)) {
    logger.clearTags()
  }
  if (isClose(LoggerStdout.Server)) {
    logger.clearTags()
  }

  return {
    logger,
  }
}
