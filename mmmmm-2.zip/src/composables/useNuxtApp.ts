import { loadingInstance } from '~/util/component/loading'
import { toast } from 'vue3-toastify'
enum RouterEvents {
  'app:beforeMount' = 'app:beforeMount',
  'app:mounted' = 'app:mounted',
  'page:loading:start' = 'page:loading:start',
  'page:loading:finish' = 'page:loading:finish',
  'page:start' = 'page:start',
  'page:finish' = 'page:finish',
}
const appLifeCycleEventBus = useEventBus<keyof typeof RouterEvents>('router-event-bus')
export default function () {
  const hooks = {
    hookOnce(event: keyof typeof RouterEvents, callbackFn: (params: any) => void) {
      const unsub = appLifeCycleEventBus.on((listenEvent, data) => {
        if (event === listenEvent) {
          callbackFn(data)
          unsub()
        }
      })
    },
    hook(event: keyof typeof RouterEvents, callbackFn: (params: any) => void) {
      appLifeCycleEventBus.on((listenEvent, data) => {
        if (event === listenEvent) {
          callbackFn(data)
        }
      })
    },
  }
  return {
    $loading: loadingInstance,
    $toast: toast,
    hooks,
    async $copy(copyStr: string = '', toastStr: string = 'Copied!') {
      const { copy, isSupported } = useClipboard()
      if (copyStr && isSupported) {
        copy(copyStr)
        toast(toastStr)
      } else {
        toast('Error Copied!')
      }
    },
  }
}

export const emitAppEvent = (event: keyof typeof RouterEvents, params: any) => {
  appLifeCycleEventBus.emit(event, params)
}
