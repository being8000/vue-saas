export default function () {
  return window.location
}
