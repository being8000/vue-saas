export interface RetryReject {
  (reason?: any): void
}

export interface RetryCallback<T> {
  (): Promise<T>
}

export interface RetryFinally {
  (): void
}

export interface RetryOptions {
  timeout: number
}

export const useRetry = <T>(fn: RetryCallback<T>, times: number, callback?: RetryFinally, options: RetryOptions = { timeout: 2000 }) => {
  const defaultTimes = times
  return new Promise((resolve, reject) => {
    const attempt = () => {
      fn().then((v) => {
        callback?.()
        resolve(v)
      }).catch(async (error) => {
        if (times-- > 0) {
          await promisedTimeout(options.timeout === -1 ? (defaultTimes - times) * 1000 : options.timeout)
          attempt()
        } else {
          callback?.()
          reject(error)
        }
      });
    };
    attempt();
  });
}
