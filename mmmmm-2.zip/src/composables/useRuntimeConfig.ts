export default function () {
  return {
    public: {
      apiBaseUrl: "",
      productId: "C66",
      appid: "C66GPH508",
      appidPC: "C66GPPC08",
      version: "1.0.0",
    },
  };
}
