export enum HolidayTheme {
  /** 正常节日主题 */
  Normal = '0',
  /** 万圣节 */
  Halloween = '1',
  /** 圣诞节 */
  Christmas = '2',
}

export interface SiteInfo {
  appsfly_relation: Record<string, string>[]
  s_w_c_s: string
  INVITE_FRONT_CALL_SWITCH: string
  ENTRY_CONFIG_JSON: string
  VISITOR_LOGIN_SWITCH: string
  PRE_POPUB_BOX: Record<string, string>[]
  appinstall_switch: Record<string, string>[]
  POPUB_BOX: Record<string, string>[]
  GLIFE_VIEW_SWITCH: Record<string, string>[]
  MAINTENANCE_IMG: Record<string, string>[]
  g_h_c_s: string
  completeRegis: boolean
  b_n_c_s: string
  onlineCsUrl: string
  S_POPUP_BOX: Record<string, string>[]
  HOME_MARQUEE: { text: string; id: string }[]
  gp_miniapp: Record<string, string>[]
  /** 旧版游戏ID api */
  GAME_JSON: string
  GAMEPLUS_GAME_JSON: string // NOTE /gpgame/H5${key}.js 获取所有游戏的key
  PROMO_GAMEPLUS_JSON: string
  /** facebook_client_id客户端ID， 如果有配置则取该值 */
  facebook_client_id: string
  h5_facebook_client_id: string
  sport_facebook_client_id: string
  GLIFE_JUMP_TIP_SWITCH: string
  site_game_display_list: string
  SWITCH_REGISTER: Record<string, string>[]
  p_c_s: string
  STORE_WEBSITE_EVENT_JSON: string
  GLIFE_PERSONAL_INFO_SWITCH: string
  MARGIN_SWITCH: string
  GAMEPLUS_HOME_MARQUEE: { text: string; id: string }[]
  g_c_s: string
  APP_DOWNLOAD_LINK: string
  b_c_s: string
  downloadIconSwitch: string
  /** google客户端ID， 如果有配置则取该值 */
  google_client_id: string
  GOOGLE_RECAPTCHER_FLAG: string
  BANNER_JSON: string // NOTE 获取首页中各个 Tab里面的banner More/All/Casino .....
  GOOGLE_RECAPTCHER_SITE_KEY: string
  clientIp: string
  /** 热门游戏 api */
  HOT_GAME_JSON: string
  isOtpSwitch: boolean
  HOT_UPDATE_VERSION: string
  isFetched: boolean
  BLOCK_CONFIG_JSON: string // 获取首页 Tab里面显示的游戏区块
  // 注册超过7天强制kyc
  GAME_7_DAYS_KYC_SWITCH: string
  MORE_MENU_JSON: string // NOTE /gpmoremenu/H5${key}.js 获取首页 More菜单页里面的动态配置菜单
  /* 顶部导航栏 注册送礼金文本 有值显示 */
  REGISTER_BUTTON_STYLE_SWITCH: string
  HOLIDAY_THEME_SWITCH: HolidayTheme
  PROMOTION_JSON: string
  H5_EKYC_SWITCH: string
  // 21岁开关
  AGE_CONFIRM_SWITCH: string
  TCC_MATCH_ENTRY_JSON: string // 用于获取TCC赛事入口配置
  GPUSER_KYC_EXEMPT: string // GP新用户免除KYC
  DEPOSIT_USER_KYC_EXEMPTION: string // 存款用户免除KYC
  REGISTRATION_KYC_EXEMPTION: string // 新注册用户免除KYC 注册时间小于24小时
  OLDUSER_KYC_EXEMPTION: string // 老用户免除kyc
  GO_TO_GLIFE_JUMP_SWITCH: string // Glife充提跳转开关
  POKER_BLOCK_CONFIG_JSON: string
}

export const useSiteInfoStore = () => {
  const storeSiteInfo = useState<Partial<SiteInfo>>(StorageKey.SiteInfo, () => ({
    isFetched: false,
    google_client_id: '',
    facebook_client_id: '',
    GAME_JSON: '',
    HOT_GAME_JSON: '',
    GAMEPLUS_GAME_JSON: '', // 新版游戏ID api
    GLIFE_PERSONAL_INFO_SWITCH: '', // Glife 检查个人信息完整性开关 1 表示打开检查
    GO_TO_GLIFE_JUMP_SWITCH: '1', // Glife充提跳转开关
    APP_DOWNLOAD_LINK: '', // 安装包下载地址
    BANNER_JSON: '', // 大厅banner Key值
    GAMEPLUS_HOME_MARQUEE: [], // 滚动新闻
    clientIp: '', //客户端IP
    downloadIconSwitch: '', // 下载按钮是否显示 0 显示 1 不显示
    STORE_WEBSITE_EVENT_JSON: '', // 获取promotion 列表
    HOT_UPDATE_VERSION: '', // 热更版本
    ENTRY_CONFIG_JSON: '', //进入游戏按钮列表
    SWITCH_REGISTER: [
      {
        switch: '1', // '0' 简单注册， '1' 完整注册
      },
    ],
    PROMOTION_JSON: '', //Promotion管理js文件
    HOLIDAY_THEME_SWITCH: HolidayTheme.Normal,
  })) as Ref<Partial<SiteInfo>>
  return storeSiteInfo
}
