const stateStore = new Map();
// function stateRef<T = any>(value: any) {
//   return customRef<T>((track, trigger) => {
//     const internalRef = { value };
//     return {
//       get() {
//         track();
//         return internalRef.value;
//       },
//       set(newValue) {
//         internalRef.value = newValue;
//         trigger();
//       },
//     };
//   });
// }
export default function <T = any>(key: string, defFnc?: Function) {
  const state = stateStore.get(key);

  if (state) {
    return state as Ref<T>;
  } else {
    const _st = ref<T>(defFnc?.());
    stateStore.set(key, _st);
    return _st;
  }
}
