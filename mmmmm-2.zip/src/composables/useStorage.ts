import type { Serializer, UseStorageOptions } from '@vueuse/core'
import { capitalize } from 'vue'
import { guessSerializerType } from '~/util'
import { aesDecrypt } from '~/util/codec/aes'

const appTitle = 'GameZone'
const cookieMaxAge1Year = 365 * 24 * 60 * 60
const encrypt = false // import.meta.env.PROD || false

export enum StorageKey {
  User = 'Gper',
  UserDetail = 'GperDetail',
  VipInfo = 'VipInfo',
  WebToken = 'WebToken',
  SiteInfo = 'SiteInfo',
  DirtyBlockConfigs = 'DirtyBlockConfigs',
  AppClient = 'App-Client',
  GAMEPLUS_GAME_JSON = 'GameZone-GAMEPLUS_GAME_JSON',
  GAME_JSON = 'GameZone-GAME_JSON',
  ENTRY_CONFIG_JSON = 'GameZone-ENTRY_CONFIG_JSON',
  BANNER_JSON = 'GameZone-BANNER_JSON',
  BLOCK_CONFIG_JSON = 'GameZone-BLOCK_CONFIG_JSON',
  MORE_MENU_JSON = 'GameZone-MORE_MENU_JSON',
  PROMOTION_JSON = 'GameZone-PROMOTION_JSON',
  TCC_MATCH_ENTRY_JSON = 'GameZone-TCC_MATCH_ENTRY_JSON',
  DisableProviderLabel = 'DisableProviderLabel',
}

export const StorageSerializers: Record<
  'boolean' | 'object' | 'number' | 'any' | 'string' | 'map' | 'set' | 'date',
  Serializer<any>
> = {
  boolean: {
    read: (v: any) => {
      return encrypt ? aesDecrypt(v) === 'true' : v === 'true'
    },
    write: (v: any) => {
      return encrypt ? aesEncrypt(String(v)) : String(v)
    },
  },
  object: {
    read: (v: any) => {
      return encrypt ? JSON.parse(aesDecrypt(v)) : JSON.parse(v)
    },
    write: (v: any) => {
      return encrypt ? aesEncrypt(JSON.stringify(v)) : JSON.stringify(v)
    },
  },
  number: {
    read: (v: any) => {
      return encrypt ? Number.parseFloat(aesDecrypt(v)) : Number.parseFloat(v)
    },
    write: (v: any) => {
      return encrypt ? aesEncrypt(String(v)) : String(v)
    },
  },
  any: {
    read: (v: any) => {
      return encrypt ? aesDecrypt(v) : v
    },
    write: (v: any) => {
      return encrypt ? aesEncrypt(String(v)) : String(v)
    },
  },
  string: {
    read: (v: any) => {
      return encrypt ? aesDecrypt(v) : v
    },
    write: (v: any) => {
      return encrypt ? aesEncrypt(String(v)) : String(v)
    },
  },
  map: {
    read: (v: any) => {
      return encrypt ? new Map(JSON.parse(aesDecrypt(v))) : new Map(JSON.parse(v))
    },
    write: (v: any) => {
      return encrypt
        ? aesEncrypt(JSON.stringify(Array.from((v as Map<any, any>).entries())))
        : JSON.stringify(Array.from((v as Map<any, any>).entries()))
    },
  },
  set: {
    read: (v: any) => {
      return encrypt ? new Set(JSON.parse(aesDecrypt(v))) : new Set(JSON.parse(v))
    },
    write: (v: any) => {
      return encrypt
        ? aesEncrypt(JSON.stringify(Array.from(v as Set<any>)))
        : JSON.stringify(Array.from(v as Set<any>))
    },
  },
  date: {
    read: (v: any) => {
      return encrypt ? new Date(aesDecrypt(v)) : new Date(v)
    },
    write: (v: any) => {
      return encrypt ? aesEncrypt(v.toISOString()) : v.toISOString()
    },
  },
}

export const namespaceConfig = (str: string) => {
  if (encrypt) {
    return aesEncrypt(`${appTitle}-${capitalize(str)}`)
  }
  return `${appTitle}-${capitalize(str)}`
}

export const decryptNamespaceConfig = (str: string) => {
  if (encrypt) {
    return aesDecrypt(str)
  }
  return str
}

export const refreshCookieRef = (key: string) => {
  refreshCookie(capitalize(key))
}

export const storageRecordKey = 'storageRecord'
export const useStorageRecordStore = () => {
  const storageRecordStore = useState<Partial<Record<string, any[]>>>(storageRecordKey, () => ({}))
  return storageRecordStore
}

/**
 * NOTE 只需要读不需要写时一定要将readonly设置为true
 * 上线前一定要清理缓存刷新页面检查html响应头的Set-Cookie是否过多
 * 过大的响应头会造成服务端502
 *
 * @param key 缓存key
 * @param defaultValue 缓存默认值
 * @param readonly 只读
 * @returns CookieRef<T>
 */
export const cookieRef = <T = string | null | undefined>(
  key: string,
  defaultValue: T,
  readonly = false
) => {
  return useCookie<T>(capitalize(key), {
    default: () => defaultValue,
    maxAge: cookieMaxAge1Year,
    readonly: readonly as any,
  })
}

export const localStorageRef = <T extends string | number | boolean | object | null>(
  key: string,
  defaultValue: MaybeRefOrGetter<T>,
  options?: UseStorageOptions<T> | undefined
) => {
  const rawInit: T = toValue(defaultValue)
  const type = guessSerializerType<T>(rawInit)
  const serializer = StorageSerializers[type]

  return useLocalStorage(namespaceConfig(key), defaultValue, {
    ...options,
    serializer,
  })
}

export const sessionStorageRef = <T extends string | number | boolean | object | null>(
  key: string,
  defaultValue: MaybeRefOrGetter<T>,
  options?: UseStorageOptions<T> | undefined
) => {
  const rawInit: T = toValue(defaultValue)
  const type = guessSerializerType<T>(rawInit)
  const serializer = StorageSerializers[type]
  return useSessionStorage(namespaceConfig(key), defaultValue, {
    ...options,
    serializer,
  })
}
