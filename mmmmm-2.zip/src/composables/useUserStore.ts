/**
 * 用户存放系统变量，系统功能交互
 */
import { StorageKey } from './useStorage'
export enum LoginFromTypeEnum {
  Facebook = '0',
  Google = '1',
  Maya = '6',
}
export const useUserStore = (readonly = false) => {
  const cookieUser = cookieRef<Partial<AppUser>>(StorageKey.User, {}, readonly)
  const storeUser = useState<Partial<AppUser>>(StorageKey.User, () => cookieUser.value || {})
  syncRef(storeUser, cookieUser, { deep: true, direction: 'ltr' })
  return storeUser
}

export const useUserDetailStore = () => {
  const localUserDetail = localStorageRef<Partial<AppUserDetail>>(StorageKey.UserDetail, {})
  const storeUserDetail = useState<Partial<AppUserDetail>>(
    StorageKey.UserDetail,
    () => localUserDetail.value || {}
  )

  if (!_IsEqual(localUserDetail.value, storeUserDetail.value)) {
    storeUserDetail.value = localUserDetail.value
  }
  syncRef(storeUserDetail, localUserDetail, { deep: true, direction: 'ltr' })
  return storeUserDetail
}

export function useUserStoreClient() {
  const userStore = useUserStore(true)
  const userDetailStore = useUserDetailStore()

  const updateUserInfoStore = async () => {
    const data = getUserInfo()
  }
  // 用来判断用户是否已经登入
  const isLogin = () => userStore.value.isLogin

  // 登入
  const signUp = async (data: any): Promise<BaseResponseType<any>> => {
    const userStore = useUserStore()
    /**
     * 字段很多大部分都没有用到
     */
    const { success, head, body } = await loginAndReigister(data)
    if (success) {
      userStore.value = {
        ...body,
        isLogin: true,
      }
      await fetchLatestUserInfo()
    }
    return { success, head, body }
  }

  const logoOut = async (replace = true) => {
    // TODO 通知用户登出
  }

  /**
   * 获取最新的用户详情并更新缓存
   */
  const fetchLatestUserInfo = async () => {
    const userStore = useUserStore()
    const { success, body } = await getUserInfo({
      isShowgfStatus: userStore.value.isShowgfStatus ?? 0,
    })
    if (success) {
      userDetailStore.value = body
      // $gz.onLoginSuccess(userDetailStore.value)
      return true
    } else {
      return false
    }
  }
  return {
    logoOut,
  }
}

export const useUserBalance = function () {
  const isRefresh = ref(false)
  const refresh = async () => {
    const { body } = await getBalance({ flag: 1, type: 0 })
    if (body) {
      const { balance, balanceFlag } = body
      if (balanceFlag === 0) {
        throw new Error(`balanceFlag: ${balanceFlag}`)
      } else {
        const userStore = useUserStore()
        userStore.value.balance = balance
      }
    }
  }
  const onRefreshClick = async () => {
    const userStore = useUserStore(true)
    if (!userStore.value.isLogin) {
      return
    }
    isRefresh.value = true
    await refreshBalance()
    await promisedTimeout(1000)
    useRetry(refresh, 8, () => {
      isRefresh.value = false
    })
  }

  return {
    isRefresh,
    onRefreshClick,
  }
}
