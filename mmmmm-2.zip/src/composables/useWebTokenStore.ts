export interface WebToken {
  token: string
  u2token: string
  deviceId: string
}

export const useWebTokenStore = () => {
  const cookieWebToken = cookieRef<Partial<WebToken>>(StorageKey.WebToken, {})
  const storeWebToken = useState<Partial<WebToken>>(StorageKey.WebToken, () => cookieWebToken.value || {})
  syncRef(storeWebToken, cookieWebToken, { deep: true, direction: 'ltr' })
  return storeWebToken
}
