export const WEB_KEY =
  'MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDSu2AZPdT2Fqpqxctx3EbnRuuYdBxFZDYG7MASIgw/DFl3P9FAp7S9WaQjdM1NmgBDgvfUWx1xj72LNz4EP4Euh9EESKceNCeoE4M8ZP4ENUQX0nDMbpmIG3/JCI8B5Iv2FKj2q0gGbE0WsLdrYDzFXTYbZKRJSbMMjHT3HtKD/wIDAQAB'

export const APP_ID = 'C66GPGLIFE08'
export const withGlaxy = (path: string) => `/_glaxy_c66_${path}`.replace(/\/\//g, '/')
export const withFront = (path: string) => `/_front_api_${path}`.replace(/\/\//g, '/')
export const withActivity = (path: string) => `/_activity_api_${path}`.replace(/\/\//g, '/')
export const SITE_CONFIG = {
  timeout: 50000,
  // appToken: window.yunweiConfig.appToken,
  host: '/',
  // host: 'http://10.62.12.60:8083/',
  productId: 'C66',
  // appid: 'C66H501',
  appid: APP_ID, // switch for meantime if developing colorgame
  version: '1.0.0',
  pid: 'c66',
  webkey: WEB_KEY,
  siteId: 100,
}

export enum GameType {
  Slot = 5,
  Perya = 7,
  TableGame = 3,
  Bingo = 27,
  Fishing = 8,
  Casino = 17,
  Sports = 1,
}
