import { App } from 'vue'
import { vRequired, vMobilePhone } from '@/util/validator'
import { subString } from '@/util/index'
import { DF } from '@/util/helper'
import i18n from './i18n'
export default {
  install(app: App) {
    // app.config.globalProperties.$router = router
    // app.config.globalProperties.$route = router.currentRoute
    app.config.globalProperties.DF = DF
    app.config.globalProperties.$n = i18n.global.n
    app.config.globalProperties.vRequired = vRequired
    app.config.globalProperties.vMobilePhone = vMobilePhone
    app.config.globalProperties.subString = subString
    app.config.globalProperties.mobileFormatter = mobileFormatter
  },
}
