export default {
  hello: "Hello!",
};
