import { createI18n } from 'vue-i18n'
const modules = import.meta.glob('./*/*.ts', {
  import: 'default',
  eager: true,
})
let locales: Record<string, any> = {}
Object.keys(modules).map((key) => {
  const [lang, mod] = key.replace(/^\.\/|\.ts$/g, '').split('/')
  locales[lang] = locales[lang] || {}
  locales[lang][mod] = modules[key]
})

const i18n = createI18n({
  legacy: false,
  locale: 'en-US',
  fallbackLocale: 'en-US',
  availableLocales: ['en-US'],
  fallbackWarn: true,
  numberFormats: {
    'en-US': {
      currency: {
        style: 'currency',
        currency: 'USD',
        notation: 'standard',
      },
      decimal: {
        style: 'decimal',
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
      },
      percent: {
        style: 'percent',
        useGrouping: false,
      },
    },
  },
  datetimeFormats: {
    'en-US': {
      mdhm: {
        month: 'short',
        day: 'numeric',
        hour12: true,
        hour: '2-digit',
        minute: '2-digit',
      },
    },
  },
  messages: {
    'en-US': {
      message: locales.en,
    },
  },
})

export default i18n
