import { createApp } from 'vue'
import '@styles/index.scss'
import '@styles/styles.scss'
import '@/plugins'
// import "amfe-flexible";
// 2. Import the components style
import router from './router'
import i18n from './i18n'
import App from './App.vue'
import vuetify from './plugins/vuetify'
import '@/permission'
import { useToastify } from './plugins/vue3-toastify'
// import { setUpNativeBridge } from './plugins/bridge'
import globalComponent from './globalComponent'
import globalProperty from './globalProperty'
import { setClientBeforeInit, setupSiteInfo, setupWebToken } from './before-mount'
import './mock-message-result'
import { startMainMessageListening } from '@gameplus/messenger'
// @ts-ignore
import __wbg_init from '@/util/hello'

// 初始化原生安卓和IOS桥接方法
// setUpNativeBridge()
setClientBeforeInit()

/**
 * @see https://digiplus.sg.larksuite.com/wiki/QxTRwWaQciiXHUkA88NlqpbegbS
 */
startMainMessageListening({
  timeout: 1000,
  debug: !import.meta.env.PROD && true,
})

const afterWasmInit = () => {
  Promise.all([setupWebToken(), fetchUserDetails(), setupSiteInfo()]).finally(() => {
    // console.log('window._dx', window._dx)
    const app = createApp(App)
    app.use(router)
    app.use(i18n)
    app.use(vuetify)
    app.use(globalComponent)
    app.use(globalProperty)
    useToastify(app)
    emitAppEvent('app:beforeMount', app)
    app.mount('#app')
  })
}
// initWasmV2().finally(() => {
//   afterWasmInit()
// })

__wbg_init().finally(afterWasmInit)
