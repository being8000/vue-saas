import { NavigationGuardWithThis } from 'vue-router'

export const fetchNativeUser: NavigationGuardWithThis<undefined> = async (to, from, next) => {
  // if (isHashLogin(to.query)) {
  //   return true
  // }

  return next()
}
