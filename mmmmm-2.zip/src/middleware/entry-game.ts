import { NavigationGuardWithThis } from 'vue-router'

const loggerDescribe = 'entry-game middleware'

export const entryGameMiddleWare: NavigationGuardWithThis<undefined> = async (to, from, next) => {
  const isInfinite =
    to.fullPath === from.fullPath || from.name === 'mini' || from.path.startsWith('/mini')
  const back = isInfinite ? '/' : from.fullPath
  const platformId = (to.params.platformId as string) || ''
  const gameId = (to.params.gameId as string) || ''

  const { $toast } = useNuxtApp()
  const { logger } = useLogger()

  logger.logBusiness('开始', loggerDescribe)
  const { fetchCasinoGames, findAllCasinoGame } = useBlock()
  try {
    await fetchCasinoGames()
    logger.logBusiness('fetchCasinoGames 完成', loggerDescribe)
    const game = findAllCasinoGame(platformId, gameId)
    if (!game) {
      $toast('Game does not found')
      logger.logBusiness('findAllCasinoGame not found', loggerDescribe)
      return next({
        path: back,
        replace: true,
      })
    }

    // await use7daysKyc()
  } catch (error) {
    console.error(loggerDescribe, error)
    console.log(1111)
    return next(false)
  }
  return next({
    path: back,
    replace: true,
  })
}
