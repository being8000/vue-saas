import { NavigationGuardWithThis } from 'vue-router'

export const fetchBlockMiddleware: NavigationGuardWithThis<undefined> = async (to, from, next) => {
  const userStore = useUserStore(true)
  const { fetchCasinoGames } = useBlock()
  const { fetchList } = useFavoriteGame()
  try {
    const promises = [fetchCasinoGames()]
    if (userStore.value.isLogin) {
      promises.push(fetchList())
    }
    await Promise.all(promises)
  } catch (error) {
    console.error('fetch-block middleware', error)
  }
  return next()
}
