import { NavigationGuardWithThis } from 'vue-router'

export const inGameMiddleware: NavigationGuardWithThis<undefined> = async (to, from, next) => {
  // 新增IOS 环境拦截游戏跳转到原生
  const platformId = (to.params.platformId as string) || ''
  const gameId = (to.params.gameId as string) || ''
  const { findAllCasinoGame } = useBlock()
  const { $toast } = useNuxtApp()
  const game = findAllCasinoGame(platformId, gameId)
  if (!game) {
    $toast('Game does not found')
    return next(false)
  }
  try {
    const jsonParam = strToJson(game.jsonParam, {
      vid: '',
      gmType: '',
      jumpParam: {},
    })
    game.vid = jsonParam.vid || ''
    game.gmtype = jsonParam.gmType || ''
    const queryJson = strToJson(to.query.jumpJson as string, {})
    game.jsonParam = JSON.stringify(_Merge(queryJson, jsonParam.jumpParam || {}))
    navigateToGame(JSON.parse(JSON.stringify(game)))
  } catch (error) {}
  return next(false)
}
