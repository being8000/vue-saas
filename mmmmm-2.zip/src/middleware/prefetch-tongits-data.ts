import { NavigationGuardWithThis } from 'vue-router'

export const fetchTongitsMiddleware: NavigationGuardWithThis<undefined> = async (
  to,
  from,
  next
) => {
  const userStore = useUserStore(true)
  const { fetchTongitsMatches } = useTongits()
  try {
    const promises = [
      fetchTongitsMatches(),
    ]
    if (userStore.value.isLogin) {
      // promises.push(fetchFavoriteGames())
    }
    await Promise.all(promises)
  } catch (error) {
    console.error('fetch-block middleware', error)
  }
  return next()
}
