import { postMessage } from '@gameplus/messenger'
import { NavigationGuardWithThis } from 'vue-router'

export const userAuthMiddleware: NavigationGuardWithThis<undefined> = async (to, from, next) => {
  return next(false)
}
