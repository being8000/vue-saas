import { errorRes, registerNativeMockFn } from '@gameplus/messenger'

// 未登录
errorRes(null, 443, 'Not Login in Yet')

registerNativeMockFn('fetchWebtoken', () => {
  return successRes({
    u2token: '972b4bc99dd14bceb3089911a52088b4',
    token:
      '6sNvgv4wu0IA4YpW0QJrjB+P9e9PPKTP6CR0TWeIb4lppPFw7joyQxfItikUmF1VU7CleAOLFSy/vxRvWApd8XE1t9afTu+mfzqD+jVm7+EC+cRcGQ9wcg==',
  })
})

registerNativeMockFn('fetchAppInfo', () => {
  return successRes({
    tenant: 'BP',
  })
})
registerNativeMockFn(
  'fetchUserDetails',
  successRes({
    createdDate: '2024-01-12 09:34:24',
    credit: '0',
    currency: 'PHP',
    customerId: '952499862618767361',
    customerType: 1,
    face: true,
    flag: '1',
    fromType: '',
    gameCredit: 0,
    gameKey: '6bPiDGwaqdP97RMdNxIcgGX3Q==6HP8',
    gameLimit: false,
    login: true,
    loginName: 'bingoplusnw099m',
    mobileNo: '905****015',
    newAccountFlag: 0,
    noLoginDays: 0,
    onlineBet: false,
    parentId: '1002256520',
    phone: '1ckej7L1ypOtSjHCRnMn1OXJw==1qIP',
    productId: 'C66',
    registerMethod: '2',
    siteId: 1,
    starLevel: 0,
    toType: '',
    verifyLoginIp: false,
    loginType: 2,
    activation: true,
    agentFlag: false,
    birthday: '',
    blackFlag: 0,
    branchAddress: '2/F, StarMall, EDSA Cor. Shaw Blvd. Mandaluyong City',
    branchCode: '**6',
    branchName: '**W',
    branchPhone: '+63287272621',
    cashCredit: 0,
    city: '**g',
    customerLevel: 0,
    firstDepositFlag: false,
    firstIdStatus: '-1',
    firstLose: true,
    firstName: '',
    gender: '',
    glife: false,
    headShot: '',
    isLazada: false,
    isPopupWindow: false,
    lastLoginDate: '2025-03-11 12:07:24',
    lastName: '',
    loginNameFlag: 0,
    loginPwdFlag: true,
    loginTimes: '251',
    marginSwitch: false,
    mayaFlag: false,
    nationality: 'Philippines',
    newWalletFlag: 0,
    oddsType: 3,
    perfectInfo: false,
    product: 1,
    registDate: '2024-01-12 09:34:24',
    requireEkyc: false,
    silentPhotoSwitch: false,
    whiteListUser: false,
    withdrewPwd: false,
    firstDepositDate: '',
  })
)
