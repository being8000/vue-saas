import router from '@/router'

router.beforeEach(async (to, from, next) => {
  const { isSupported, isOnline } = useNetwork()
  if (toValue(isSupported) && !toValue(isOnline)) {
    const { $toast } = useNuxtApp()
    $toast('You are currently offline!')
    return next(false)
  }
  if (to.meta.skipGlobalMiddleware) {
    return next()
  }
  emitAppEvent('page:start', {
    to,
    from,
  })
  // if (to.name !== "Login" && !isAuthenticated) next({ name: "Login" });
  next()
})

router.beforeResolve((to, from) => {
  return true
})
router.afterEach((to, from, failure) => {
  emitAppEvent('page:finish', { to, from })
})
router.onError((error, to) => {
  console.log(error)
  if (error.message.includes('Failed to fetch dynamically imported module')) {
    window.location.href = to.fullPath
  }
})
