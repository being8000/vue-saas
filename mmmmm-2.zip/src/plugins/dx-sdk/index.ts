const hooks = useNuxtApp().hooks
let server = 'https://www.dgfpsecservice.com'
let appId = '5ad0af758c8049ef8c77c7e965429e42'
let appSecret = 'df933511216531c67a3f5a6fe1108855'
if (isUat()) {
  server = 'https://rcs-demo.dingxiang-inc.com'
  appId = '4e64081b1c2b3dbe7e389590ffe8b5bd'
  appSecret = '320980eeecfa42afd056fb3937bb35cd'
}

// web:https://www.dgfpsecservice.com/udid/c1
// app:https://www.dgfpsecservice.com/udid/m1
// 小程序:https://www.dgfpsecservice.com/udid/w1
// js文件地址：https://www.dgfpsecservice.com:8443/const-id.js
// ApiId:5ad0af758c8049ef8c77c7e965429e42
// AppSecret:df933511216531c67a3f5a6fe1108855

const testVal = { value: '123' }
export const useDxToken: any = () => {
  // return testVal
  const dxToken = localStorageRef<string>('dx-token', '')
  return dxToken
}

const getConstID = async () => {
  var options = {
    appId, // 唯一标识，必填
    appSecret,
    server: `${server}/udid/c1`, // constId web端服务接口
    timeout: 2000,
    cache: false,
    // userId: '【这里填写 userID】' // 用户标识，可选
  }
  return window._dx.ConstID(options)
}

export function loadConstIdJs() {
  const dxToken = useDxToken()
  if (dxToken.value) return Promise.resolve(dxToken.value)
  let src = 'https://cdn.aisecurius.com/ctu-group/constid-js/dgconstid-js.js'
  const host = window.location.host
  if (host.includes('c66uat.com') || host.includes('uatext66gp.com')) {
    src = 'https://rcs-demo.dingxiang-inc.com/const-id.js'
  }
  const id = 'preset-js-device-constid'
  return new Promise((resolve, rejcect) => {
    ;(function (d, s, id) {
      var js
      var fjs = d.getElementsByTagName(s)[0]
      if (d.getElementById(id)) return
      js = d.createElement(s) as HTMLScriptElement
      js.id = id
      js.async = !0
      js.defer = !0
      js.src = src
      fjs.parentNode?.insertBefore(js, fjs)
    })(document, 'script', id)
    ;(document.querySelector('#' + id) as HTMLElement).onload = () => {
      if (window._dx) {
        getConstID()
          .then((token) => {
            dxToken.value = token
            resolve(token)
          })
          .catch(() => resolve(false))
      } else {
        console.error(src + ' load failed')
        return resolve(false)
      }
    }
    ;(document.querySelector('#' + id) as HTMLElement).onerror = (error) => {
      console.error(src + ' load failed')
      return resolve(false)
    }
  })
}
