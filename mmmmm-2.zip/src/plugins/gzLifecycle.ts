import { DepositOnlineOrder } from '@/api/account'
import { differenceInDays, isToday, parseISO } from 'date-fns'
import { fbTrack } from './fb-track'
import { tuiteTrack } from './tuite-track'
import { $afTrack } from './bridge/af-track'
import { $cora } from "./coraool"
import { checkDepositTransV2 } from '~/api/deposit'

// 记录gamezone 注册 登录 充值等生命周期
const gzLifecycle = {
  register() {
    fbTrack.register()
    tuiteTrack.register()
    $afTrack.register()
    $cora.custom('ACTION_REGISTERATION', {
      palcode: palcodeSession.value,
    })

    // 邀请绑定
    const { bindInviteId } = useInvite()
    bindInviteId()
  },
  login(body: any) {
    fbTrack.login()
    tuiteTrack.login()
    // $afTrack.login()
    const { appEventBus } = useApp()
    appEventBus.emit('onLogin', body)
    $cora.custom('ACTION_LOGIN', {
      palcode: palcodeSession.value,
    })
  },
  // 触发充值 只是触发提交订单接口
  commitDeposit() {
    fbTrack.commitDeposit()
    
  },
  // 存款事件
  deposit(params: DepositOnlineOrder) {
    $afTrack.deposit(params)
    tuiteTrack.deposit(params)
    $cora.custom('ACTION_DEPOSIT', {
      palcode: palcodeSession.value,
      amount: params.amount,
    })
  },
  // 首存
  firstDeposit(params: DepositOnlineOrder) {
    fbTrack.firstDeposit(params)
    $afTrack.firstDeposit(params)
    tuiteTrack.firstDeposit(params)
    $cora.custom('ACTION_FIRSTDEPOSIT', {
      palcode: palcodeSession.value,
      amount: params.amount,
    })
  },
  // 非首存
  noFirstDeposit(params: DepositOnlineOrder) {
    fbTrack.noFirstDeposit(params)
  },
  // 当日注册并且首存
  todayRegisterAndDeposit(params: DepositOnlineOrder) {
    fbTrack.todayRegisterAndDeposit(params)
  },
  // 非当日注册并且首存
  noTodayRegisterAndDeposit(params: DepositOnlineOrder) {
    fbTrack.noTodayRegisterAndDeposit(params)
  },
}

// 生成充值链接后本地存储订单id，支付回调后会回传订单id 匹配是否有此id进行埋点
export const useDepositTrackMap = () => {
  const pondMap = localStorageRef<Map<string, DepositOnlineOrder>>('DepositPond', new Map())
  function has(billNo?: string | null) {
    return !!billNo && pondMap.value.has(billNo)
  }
  function get(billNo?: string | null) {
    return has(billNo) && pondMap.value.get(billNo!)
  }
  function set(item: DepositOnlineOrder) {
    pondMap.value.set(item.billNo, item)
  }
  function remove(billNo?: string | null) {
    has(billNo) && pondMap.value.delete(billNo!)
  }

  function checkPondValid() {
    const today = new Date()
    pondMap.value.forEach((item: DepositOnlineOrder) => {
      const difference = differenceInDays(today, new Date(item.createDate))
      if (Math.abs(difference) > 7) {
        remove(item.billNo)
      }
    })
  }
  return {
    pondMap,
    has,
    get,
    set,
    remove,
    checkPondValid,
  }
}

// 初始化各埋点sdk
const initTrackSdk = async () => {
  await fbTrack.checkInit()
  await tuiteTrack.checkInit()
}
const hooks = useNuxtApp().hooks
hooks.hookOnce('app:beforeMount', async () => {
  const urlParams = new URLSearchParams(useRequestURL().search)
  const { checkPondValid, get, remove } = useDepositTrackMap()
  checkPondValid()
  // 判断是否有支付回调 订单
  const billNo = urlParams.get('payback')
  if (!billNo) return

  await initTrackSdk()
  let findOne = (get(billNo) || {}) as DepositOnlineOrder
  // if (!findOne) return

  const { userDetailStore } = useUserStoreClient()
  const firstDepositFlag = userDetailStore.value.firstDepositFlag || false
  const registDate = userDetailStore.value.registDate || ''
  // 今天注册
  const isTodayRegist = isToday(parseISO(registDate))

  let params = {
    ...findOne,
    currency: 'PHP',
    value: findOne?.amount,
  }

  // 存款事件
  gzLifecycle.deposit(params)

  // firstDepositFlag == false 代表没有首存过
  let newSaveDepositFlag 
  const { success, body } = await checkDepositTransV2({  requestId: billNo })
  if (success) {
    // depositFlag为true代表存款成功
    newSaveDepositFlag = body.depositFlag
  }
  if(!newSaveDepositFlag) return
  // 非首存
  if (firstDepositFlag) {
    gzLifecycle.noFirstDeposit(params)
  } else {
    // 首存埋点
    gzLifecycle.firstDeposit(params)

    // 当日注册并且首存
    if (isTodayRegist) {
      gzLifecycle.todayRegisterAndDeposit(params)
    } else {
      // 非当日注册+首存
      gzLifecycle.noTodayRegisterAndDeposit(params)
    }
  }

  remove(billNo)
})
export default gzLifecycle
