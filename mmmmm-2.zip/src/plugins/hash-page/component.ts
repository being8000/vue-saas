import { Component, createApp } from 'vue'
import PopPage from '~/components/global/PopPage.vue'
import vuetify from '@/plugins/vuetify'
import router from '@/router'
import i18n from '@/i18n'
import globalComponent from '@/globalComponent'
import globalProperty from '@/globalProperty'
/**
 * 该函数用户替换hash component, 通过函数组件弹出对于的模拟页面
 * @returns
 */
export function loadPage<T = any>(component: Component) {
  const app = createApp(
    h(
      PopPage,
      {
        onClose() {
          // instance.unmount()
          // app.unmount()
        },
      },
      {
        default: () => h(component),
      }
    )
  )
  app.use(router)
  app.use(i18n)
  app.use(vuetify)
  app.use(globalComponent)
  app.use(globalProperty)
  const container = document.createElement('div')
  const instance = app.mount(container)
  return instance as ComponentPublicInstance<T>
}
