import { RouteLocationNormalizedGeneric } from 'vue-router'
import { Component, ComponentPublicInstance } from 'vue'
// import LoginPage from '@/components/global/Page/Login.vue'
// import TermsPage from '@/components/global/Page/PrivacyPolicy.vue'
// import DepositPage from '@/components/global/Page/Deposit.vue'
import { loadPage } from './component'
import router from '@/router'
import { routerHistory } from '@/router'
const { hooks } = useNuxtApp()
interface Params {
  to: RouteLocationNormalizedGeneric
  from: RouteLocationNormalizedGeneric
}
export type SystemHashComponent = ''

const hashComponentMaps: Record<SystemHashComponent, Component> = {}
const normalizeComponent: Record<string, Component> = {}
Object.keys(hashComponentMaps).forEach((key) => {
  normalizeComponent[key.toLowerCase()] = hashComponentMaps[key as SystemHashComponent]
})
const normalizeComponentName = (hash: string) =>
  hash.toLowerCase().replace('#', '') as SystemHashComponent
const isSysComponent = (hash: string) => {
  const componentName = normalizeComponentName(hash)
  const component = normalizeComponent[componentName]
  return component
}

const componentInstanceMap = new Map<string, ComponentPublicInstance>()
const getInstance = (path: string, component: Component) => {
  const instance = componentInstanceMap.get(path)
  if (instance) {
    return instance
  } else {
    const instance = loadPage(component)
    componentInstanceMap.set(path, instance)
    return instance
  }
}

interface State {
  back: string
  current: string
  forward: string
  position: number
  replaced: boolean
}
// 用来存储路径堆栈
export const appRouteStack: Params[] = []
hooks.hook('page:finish', ({ to, from }: Params) => {
  const toHash = to.hash && to.hash.startsWith('#')
  const state: State = routerHistory.state as any
  if (!state) {
    return
  }
  const isBackfromComponent = componentInstanceMap.get(state.forward)
  if (isBackfromComponent) {
    ;(isBackfromComponent as any).hide()
  }
  const fromHash = from.hash && from.hash.startsWith('#')
  if (fromHash) {
    if (state.replaced || !toHash) {
      const component = isSysComponent(from.hash)
      if (component) {
        const instance = getInstance(from.fullPath, component)
        instance.hide()
      }
    }
  }

  if (toHash) {
    const component = isSysComponent(to.hash)

    if (component) {
      const instance = getInstance(to.fullPath, component)
      if (component === hashComponentMaps['login']) {
        const isLogin = useUserStore().value.isLogin
        if (!isLogin) {
          blockBodyScroll()
          instance.show()
        }
      } else {
        instance.show()
      }
    }
  } else {
    unblockBodyScroll()
  }
})

export const onAppBack = () => {
  if (Number(routerHistory.state.position) > 1) {
    router.back()
  } else {
    const { isGamezoneV1_0_0 } = useDevice()
    if (isGamezoneV1_0_0) {
      // $gz.closeWebview()
    } else {
      const route = router.currentRoute.value
      router.push(route.path)
    }
  }
}
