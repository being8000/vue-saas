// let isFirstLoading = true;
// export default defineNuxtPlugin({
//   name: 'beforeMount',
//   enforce: 'pre', // or 'post'
//   async setup(nuxtApp) {
//     // this is the equivalent of a normal functional plugin
//   },
//   hooks: {
//     'page:loading:start'() {
//       // loadingInstance.pageStart()
//       console.log(isFirstLoading)
//       const div = document.createElement('div')
//       if (isFirstLoading) {
//         isFirstLoading = false
//         div.classList.add('app-pre-loading-sping')
//         div.appendChild(document.createElement('span'))
//         div.appendChild(document.createElement('span'))
//         div.appendChild(document.createElement('span'))
//         div.appendChild(document.createElement('span'))
//         div.appendChild(document.createElement('span'))
//         document.body.appendChild(div)
//       }
//     },
//     'page:loading:end'() {
//       // loadingInstance.pageEnd()
//       const loadingInstance = document.querySelector('.app-pre-loading-sping')
//       if (loadingInstance) {
//         loadingInstance.remove()
//       }
//     },
//     'page:finish'() {},
//     'app:error'(err) {
//       console.log('app:error', JSON.stringify(err))
//     },
//     // You can directly register Nuxt app runtime hooks here
//     // async 'app:beforeMount'(app) {
//     //   const route = useRoute()
//     //   const {
//     //     palcode, // 推荐码
//     //     platformCode, // 游戏厅号
//     //     gameId, // 游戏ID
//     //     isInfo, // token
//     //     loginName, // 登录用户名
//     //     customerId, // 用户ID, unionId / userId 等等
//     //     target, // 默认打开指定特殊功能
//     //     isFrom, // 来源渠道 glife, maya, lazada
//     //   } = route.query || {}
//     //   if (isFrom && palcode && isInfo && loginName && customerId) {
//     //   } else {
//     //     const { setToken } = useApp()
//     //     await setToken()
//     //   }
//     //   // do something in the hook
//     // },
//   },
//   env: {
//     // Set this value to `false` if you don't want the plugin to run when rendering server-only or island components.
//     islands: true,
//   },
// })
