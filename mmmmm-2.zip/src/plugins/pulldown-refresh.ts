import router from '@/router'
const refreshEventBus = useEventBus<'onRefresh'>('gamezone-refresh-event-bus')

const hooks = useNuxtApp().hooks

type DoneCallback = () => void

interface PageRefreshEvents {
  routePath: string // 当前路由
  unsubcriberFn: Function
}
let refresherStore: PageRefreshEvents[] = []
export const onPulldownRefresh = (fn: (done: DoneCallback) => void) => {
  refresherStore.push({
    routePath: router.currentRoute.value.path,
    unsubcriberFn: refreshEventBus.on((event, done) => {
      if (event === 'onRefresh') {
        fn(done)
      }
    }),
  })
}

hooks.hook('page:finish', () => {
  const currentRoute = router.currentRoute.value
  const unsubscrubStore = refresherStore.filter((el) => el.routePath !== currentRoute.path)
  refresherStore = refresherStore.filter((el) => el.routePath === currentRoute.path)
  unsubscrubStore.forEach((el) => {
    el.unsubcriberFn()
  })
})

export const emitAppPulldownRefresh = (done: DoneCallback) => {
  refreshEventBus.emit('onRefresh', done)
}
