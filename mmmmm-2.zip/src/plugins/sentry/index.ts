// import * as Sentry from '@sentry/vue'
// import { App } from 'vue'
// import router from '@/router'
// const hooks = useNuxtApp().hooks
// const uatDsn = 'https://8cd3de7c406ec7c61976bf89fe24d819@sentryuat.bssrvc66.com/13'
// const prodDsn = 'https://e6022b155f9e6cef56418d2111345a03@sentry-pro.bssrvc66.com/3'
// hooks.hookOnce('app:beforeMount', async (app: App) => {
//   const { getCurrentClientConfig } = useAppClientVar()
//   const environment = getCurrentClientConfig({
//     [AppClientEnum.H5]: 'H5',
//     [AppClientEnum.PC]: 'PC',
//     [AppClientEnum.Maya]: 'MAYA',
//     [AppClientEnum.Glife]: 'GLIFE',
//     [AppClientEnum.Lazada]: 'LAZADA',
//     [AppClientEnum.Android]: 'Android',
//     [AppClientEnum.Ios]: 'iOS',
//   })
//   Sentry.init({
//     app,
//     dsn: isUat() ? uatDsn : prodDsn,
//     integrations: [
//       Sentry.browserTracingIntegration({ router }),
//       // Sentry.replayIntegration(),
//     ],
//     environment,
//     // Set tracesSampleRate to 1.0 to capture 100%
//     // of transactions for tracing.
//     // We recommend adjusting this value in production
//     tracesSampleRate: 1.0,
//     // Set `tracePropagationTargets` to control for which URLs trace propagation should be enabled
//     tracePropagationTargets: ['_glaxy_c66_', '_front_api_', 'staticJs'].map(
//       (path) => `${location.origin}/${path}`
//     ),
//     denyUrls: [/openinstall\.com/, /zohopublic\.com/, /zohu\.com/],
//     ignoreErrors: [
//       // Promise reject
//       'UnhandledRejection',
//       // 请求超时
//       /timeout of \d.+ms/,
//       // 取消请求
//       /^AbortError/,
//       'Failed to fetch',
//     ],
//     // Capture Replay for 10% of all sessions,
//     // plus for 100% of sessions with an error
//     replaysSessionSampleRate: 0.1,
//     replaysOnErrorSampleRate: 1.0,
//     beforeSend(event, hint) {
//       // 检查错误是否来自 iframe
//       const isIframe = window !== window.top
//       if (isIframe) {
//         // 如果是 iframe 中的错误，则不上报
//         return null
//       }
//       return event
//     },
//   })
// })
