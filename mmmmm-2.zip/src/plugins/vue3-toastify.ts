import Vue3Toastify, { toast, type Content, type ToastOptions } from 'vue3-toastify'
import 'vue3-toastify/dist/index.css'
import '@styles/toastify.scss'
import { App } from 'vue'

export const useToastify = function (app: App) {
  app.use(Vue3Toastify, {
    autoClose: 2000,
    theme: 'dark',
    // closeButton: false,
    toastStyle: {
      top: '200px',
    },
    position: 'top-center',
    transition: toast.TRANSITIONS.SLIDE,
    limit: 1,
    hideProgressBar: true,
    closeButton: defineComponent({
      render() {
        return h(
          'div'
          // {
          //   style: {
          //     width: '40px',
          //   },
          // },
          // h(CloseSVG)
        )
      },
    }),
  })
}
