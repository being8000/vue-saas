import Adapter from "@date-io/date-fns";
import enUS from "date-fns/locale/en-US/index.js";

export const enabled = true;
export const isDev = true;
export const i18n = true;
export const adapter = "date-fns";

export function dateConfiguration() {
  const options = {
    adapter: new Adapter({ locale: enUS }),
  };
  return options;
}
