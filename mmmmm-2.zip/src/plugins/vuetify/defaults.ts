export default {
  IconBtn: {
    icon: true,
    color: 'default',
    variant: 'text',
  },
  RectIconBtn: {
    flat: true,
    class: 'v-btn--react',
    size: 'x-small',
  },
  VBtn: {
    ripple: false,
    size: 'large',
  },
  PrimaryBtn: {
    ripple: false,
    color: 'primary',
    size: 'small',
  },
  SearchTextField: {
    class: 'v-field--variant-search',
    clearable: true,
    clearIcon: 'custom-close-circle',
    prependInnerIcon: 'custom-search',
    density: 'compact',
    variant: 'solo',
    singleLine: true,
    hideDetails: true,
  },
}
