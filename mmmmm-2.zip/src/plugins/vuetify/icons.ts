import type { IconAliases, IconProps, VuetifyOptions } from 'vuetify'

const all = defineAsyncIconComponent(() => import('@images/svg/all.svg'))
const arrowRight = defineAsyncIconComponent(() => import('@images/svg/arrow-right.svg'))
const arrowLeft = defineAsyncIconComponent(() => import('@images/svg/arrow-left.svg'))
const arrowLeft2 = defineAsyncIconComponent(() => import('@images/svg/arrow-left2.svg'))
const arrowLeft3 = defineAsyncIconComponent(() => import('@images/svg/arrow-left3.svg'))
const arrowUp = defineAsyncIconComponent(() => import('@images/svg/arrow-up.svg'))
const arrowDown = defineAsyncIconComponent(() => import('@images/svg/arrow-down.svg'))
const arrowDownNew = defineAsyncIconComponent(() => import('@images/svg/arrow-down-new.svg'))
const close = defineAsyncIconComponent(() => import('@images/svg/close.svg'))
const arrowDownFill = defineAsyncIconComponent(() => import('@images/svg/arrow-down-fill.svg'))
const arrowLeftCircle = defineAsyncIconComponent(() => import('@images/svg/arrow-left-circle.svg'))
const maintenance = defineAsyncIconComponent(() => import('@images/svg/maintenance.svg'))
const arrowRightCircle = defineAsyncIconComponent(
  () => import('@images/svg/arrow-right-circle.svg')
)

const customIcons: Record<string, unknown> = {
  'custom-close': close,
  'custom-all': all,
  'custom-arrow-right': arrowRight,
  'custom-arrow-left': arrowLeft,
  'custom-arrow-left2': arrowLeft2,
  'custom-arrow-left3': arrowLeft3,
  'custom-arrow-left-circle': arrowLeftCircle,
  'custom-arrow-right-circle': arrowRightCircle,
  'custom-arrow-up': arrowUp,
  'custom-arrow-down': arrowDown,
  'custom-arrow-down-new': arrowDownNew,
  'custom-arrow-down-fill': arrowDownFill,
  'custom-maintenance': maintenance,
}
console.log(customIcons, 'accountIcon123')
/** ANCHOR 定义Vuetify内置组件使用的图标 */
const aliases: Partial<IconAliases> = {
  complete: '',
  cancel: '',
  close: 'custom-close',
  delete: '',
  clear: 'custom-close-circle',
  success: '',
  info: 'custom-info',
  warning: 'custom-warning',
  error: '',
  prev: 'custom-arrow-left',
  next: 'custom-arrow-right',
  checkboxOn: '',
  checkboxOff: '',
  checkboxIndeterminate: '',
  delimiter: '',
  sortAsc: '',
  sortDesc: '',
  expand: '',
  menu: '',
  subgroup: '',
  dropdown: '',
  radioOn: '',
  radioOff: '',
  edit: '',
  ratingEmpty: '',
  ratingFull: '',
  ratingHalf: '',
  loading: '',
  first: '',
  last: '',
  unfold: '',
  file: '',
  plus: '',
  minus: '',
  calendar: '',
}

export const iconify = {
  component: (props: IconProps) => {
    if (typeof props.icon === 'string') {
      const iconComponent = customIcons[props.icon]

      if (iconComponent) {
        return h(iconComponent)
      }
    }

    return h(props.tag, {
      ...props,
      class: [props.icon],
      tag: undefined,
      icon: undefined,
    })
  },
}

export const icons = {
  defaultSet: 'iconify',
  aliases,
  sets: {
    iconify,
    mdi: false as any,
  },
}
