import { deepMerge } from '@antfu/utils'
import 'vuetify/styles'
import { createVuetify, type VuetifyOptions } from 'vuetify'
import themes from './theme'
import { icons } from './icons'
import { VBtn } from 'vuetify/components/VBtn'
import defaults from './defaults'
import { VTextField } from 'vuetify/components/VTextField'
import { dateConfiguration } from './date'

const cookieThemeValues = {
  defaultTheme: 'light',
  themes: {
    light: {},
    dark: {},
  },
}

const optionTheme = deepMerge({ themes }, cookieThemeValues)

const options: VuetifyOptions = {
  aliases: {
    RectIconBtn: VBtn,
    IconBtn: VBtn,
    PrimaryBtn: VBtn,
    SearchTextField: VTextField,
  },
  defaults,
  icons,
  theme: optionTheme,
  date: dateConfiguration(),
}

export default createVuetify(options)
