import type { ThemeDefinition } from 'vuetify'
export const staticPrimaryLightColor2 = '#FFC972'
export const staticPrimaryColor = '#FFC972'
export const staticPrimaryLightColor = '#FF8A00'
export const staticPrimaryDarkenColor = '#FF3F00'
export const staticPrimaryDarkenColor2 = '#ED3A00'
export const staticPrimaryDarkenColor3 = '#FF2E00'
export const staticPrimaryDarkenColor4 = '#1C0A04'
export const staticPrimaryDarkenColor5 = '#2D2320'
export const staticPrimaryDarkenColor6 = '#55342A'
export const staticPrimaryDarkenColor7 = '#4B464F'

export const staticSecondaryColor = '#17D01A'
export const staticSecondaryLightColor = '#1CD219'
export const staticSecondaryDarkenColor = '#17D01A'
export const staticSecondaryDarkenColor2 = '#17D01A'
export const staticSecondaryDarkenColor3 = '#59473b'

export const staticToolbarContentHeight = '60px'
export const staticToolbarExtensionHeight = '77px'

export const staticTopNavbarHeight = '56px'
export const staticBottomNavbarHeight = '64px'

export const staticViewMaxWidth = '750px'

export const themes: Record<string, ThemeDefinition> = {
  light: {
    dark: false,
    colors: {
      background: '#f6f6f6',
      primary: '#FF6533',
      black: '#323136', // 定义网站主题黑色 【区块标题】
      gray: '#878689',
      'gray-2': '#666666',
      info: '#000000',
    },
    variables: {
      'view-max-width': staticViewMaxWidth,
    },
  },
  dark: {
    dark: true,
    colors: {
      primary: staticPrimaryColor,
      'on-primary': '#fff',
      'on-secondary': '#fff',
      success: '#28C76F',
      'on-success': '#fff',
      'success-darken-1': '#24B364',
      'success-darken-2': '#2FF29E',
      info: '#000000',
      'on-info': '#fff',
      warning: '#FFC700',
      'on-warning': '#fff',
      'warning-darken-1': '#E68F3C',
      error: '#FF0F00',
      'on-error': '#fff',
      'error-light-1': '#FF0000',
      'on-error-light-1': '#FF0000',
      background: '#252328',
      'on-background': '#FFFFFF',
      surface: '#181515',
    },
    variables: {
      'scrollbar-color': '#EAECF3',
      'scrollbar-border-radius': '.25rem',
      'view-max-width': staticViewMaxWidth,
      'overlay-scrim-background': '#000000',
      'overlay-scrim-opacity': 0.4,
      'border-color': '#342C29',
      'border-opacity': 1,
      'high-emphasis-opacity': 1,
      'medium-emphasis-opacity': 0.7,
      'toolbar-content-height': staticToolbarContentHeight,
      'toolbar-extension-height': staticToolbarExtensionHeight,
      'top-navbar-height': staticTopNavbarHeight,
      'bottom-navbar-height': staticBottomNavbarHeight,
      'container-view-height': `calc(100vh - ${staticToolbarContentHeight} - ${staticBottomNavbarHeight})`,
      'container-view-height-2': `calc(100vh - ${staticToolbarContentHeight})`,
      'layout-mt': '10px',
      'layout-padding': '12px',
    },
  },
}

export default themes
