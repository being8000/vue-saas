import { RouteRecordRaw } from 'vue-router'
import DefaultLayout from '@/layouts/default.vue'

export const debugRoutes: RouteRecordRaw = {
  path: '/debug',
  name: 'debug',
  component: DefaultLayout,
  meta: {},
  children: [
    {
      path: 'component',
      name: 'debug-component',
      component: () => import('@/views/debug/component.vue'),
      meta: {
        showJackportWidget: true,
      },
    },
    {
      path: 'component',
      name: 'debug-component',
      component: () => import('@/views/debug/component.vue'),
      meta: {
        showJackportWidget: true,
      },
    },
    {
      path: 'bridge',
      name: 'debug-bridge',
      component: () => import('@/views/debug/bridge.vue'),
    },
    {
      path: 'messenger',
      name: 'debug-messenger',
      component: () => import('@/views/debug/messenger.vue'),
      meta: {
        hideTopNavbar: true,
        hideFooter: true,
      },
    },
    {
      path: 'api',
      name: 'debug-messenger',
      component: () => import('@/views/debug/m-api.vue'),
      meta: {
        hideTopNavbar: true,
        hideFooter: true,
      },
    },
  ],
}
