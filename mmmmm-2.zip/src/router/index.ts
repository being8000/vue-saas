import DefaultLayout from '@/layouts/default.vue'
import { createRouter, RouteRecordRaw } from 'vue-router'
import { debugRoutes } from './debug'
import { createWebHistory } from 'vue-router'
import { inGameMiddleware } from '@/middleware/in-game-middleware'
import { fetchBlockMiddleware } from '@/middleware/fetch-block'
import { fetchTongitsMiddleware } from '@/middleware/prefetch-tongits-data'
const routes: RouteRecordRaw[] = [
  // { path: "/:pathMatch(.*)*", name: "NotFount", redirect: "/" },
  {
    path: '/',
    component: DefaultLayout,
    meta: {},
    beforeEnter: [fetchBlockMiddleware,fetchTongitsMiddleware],
    children: [
      {
        path: '',
        name: 'index',
        beforeEnter: [],
        // component: () => import('@/views/home/[tab]/index.vue'),
        component: () => import('@/views/home.vue'),
        meta: {},
      },
      {
        path: '/game/:platformId/:gameId',
        name: 'game-id',
        beforeEnter: [inGameMiddleware],
        component: () => h('div'),
        meta: {
          showJackportWidget: true,
        },
      },
    ],
  },
  debugRoutes,
  // will match everything and put it under `route.params.pathMatch`
  { path: '/:pathMatch(.*)*', name: 'NotFound', component: () => import('@/views/error/404.vue') },
  { path: '/test', name: 'test', component: () => import('@/views/error/test.vue') },
]
export const routerHistory = createWebHistory()
export default createRouter({
  history: routerHistory,
  routes: routes,
  scrollBehavior(to, from, savedPosition) {
    if (to.hash) {
      return {
        el: to.hash,
        behavior: 'smooth',
      }
    }
    if (savedPosition) {
      return savedPosition
    } else {
      return { top: 0 }
    }
  },
})
