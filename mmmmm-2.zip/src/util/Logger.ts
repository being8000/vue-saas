/**
 * @zh 日志管理可打印的日志类型
 *
 * @export
 * @enum {number}
 */
export enum LoggerType {
  /**
   * @zh 网络层日志（打印网络请求与响应的原数据）
   */
  Net = 1 << 0,
  /**
   * @zh 数据结构层日志（打印通用数据结构）
   */
  Model = 1 << 1,
  /**
   * @zh 业务逻辑层日志（打印业务逻辑）
   */
  Business = 1 << 2,
  /**
   * @zh 视图层日志（打印视图节点与视图展示数据）
   */
  View = 1 << 3,
  /**
   * @zh 配置日志（打印应用配置项）
   */
  Config = 1 << 4,
  /**
   * @zh 标准日志（打印通用日志）
   */
  Trace = 1 << 5,
}

/**
 * @zh 日志类型对应的名称
 */
const names: Record<LoggerType, string> = {
  [LoggerType.Net]: '网络日志',
  [LoggerType.Model]: '数据日志',
  [LoggerType.Business]: '业务日志',
  [LoggerType.View]: '视图日志',
  [LoggerType.Config]: '配置日志',
  [LoggerType.Trace]: '标准日志',
}

/**
 * @zh 日志管理
 *
 * @export
 * @class Logger
 *
 * @example
 * logger.trace("默认标准日志");
 * logger.logConfig("灰色配置日志");
 * logger.logNet("橙色网络日志");
 * logger.logModel("紫色数据日志");
 * logger.logBusiness("蓝色业务日志");
 * logger.logView("绿色视图日志");
 */
export class Logger {
  private _tags: number = 0
  private _badgePrefix: string = 'Library'
  private _badgeSuffix: string = 'Net(Client)'
  private _badgeColor: string = '#42b784'

  public constructor() {
    this._tags =
      LoggerType.Net |
      LoggerType.Model |
      LoggerType.Business |
      LoggerType.View |
      LoggerType.Config |
      LoggerType.Trace
  }

  /**
   * @zh 设置显示的日志类型，默认值为不显示任何类型日志
   *
   * @param {LoggerType} [tag=null!] 设置为null不再显示后续打印日志
   * @memberof Logger
   *
   * @example
   * logger.setTags(LoggerType.View|LoggerType.Business)
   */
  public setTags(tag: LoggerType = null!) {
    if (tag) {
      this._tags = tag
    }
  }

  /**
   * @zh 设置徽章前缀内容
   *
   * @param {string} prefix
   * @memberof Logger
   */
  public setBadgePrefix(prefix: string) {
    this._badgePrefix = prefix
  }

  /**
   * @zh 设置徽章后缀内容
   *
   * @param {string} suffix
   * @memberof Logger
   */
  public setBadgeSuffix(suffix: string) {
    this._badgeSuffix = suffix
  }

  /**
   * @zh 设置徽章颜色
   *
   * @param {string} color
   * @memberof Logger
   */
  public setBadgeColor(color: string) {
    this._badgeColor = color
  }

  /**
   * @zh 关闭日志打印
   *
   * @memberof Logger
   */
  public clearTags() {
    this._tags = 0
  }

  /**
   * @zh 记录开始计时
   *
   * @param {string} [describe="Time"] 描述
   * @memberof Logger
   *
   * @example
   * logger.start();
   * ...
   * 省略N行代码
   * ...
   * logger.end();
   */
  public start(describe: string = 'Time'): void {
    console.time(describe)
  }

  /**
   * @zh 打印范围内时间消耗
   *
   * @param {string} [describe="Time"] 描述
   * @memberof Logger
   *
   * @example
   * logger.start();
   * ...
   * 省略N行代码
   * ...
   * logger.end();
   */
  public end(describe: string = 'Time'): void {
    console.timeEnd(describe)
  }

  /**
   * @zh 打印表格
   *
   * @param {*} msg 消息
   * @param {string} [describe] 描述
   * @return {*}
   * @memberof Logger
   *
   * @example
   * var object:any = {uid:1000};
   * logger.table(object);
   */
  public table(msg: any, describe?: string): void {
    if (!this.isOpen(LoggerType.Trace)) {
      return
    }
    console.table(msg)
  }

  /**
   * @zh 打印标准日志（打印通用日志）
   *
   * @param {*} msg 日志消息
   * @param {string} [color="color:#000000;"]
   * @return {*}  {void}
   * @memberof Logger
   */
  public trace(msg: any, color: string = 'color:#000000;'): void {
    // 标记没有打开，不打印该日志
    if (!this.isOpen(LoggerType.Trace)) {
      return
    }
    var backLog = console.log
    backLog.call(null, '%c%s%s', color, this.getDateString(), msg)
  }

  /**
   * @zh 打印网络层日志（打印网络请求与响应的原数据）
   *
   * @param {*} msg 消息
   * @param {string} [describe] 描述
   * @memberof Logger
   */
  public logNet(msg: any, describe?: string): void {
    this.orange(LoggerType.Net, msg, describe)
  }

  /**
   * @zh 打印数据结构层日志（打印通用数据结构）
   *
   * @param {*} msg 消息
   * @param {string} [describe] 描述
   * @memberof Logger
   */
  public logModel(msg: any, describe?: string): void {
    this.violet(LoggerType.Model, msg, describe)
  }

  /**
   * @zh 打印业务逻辑层日志（打印业务逻辑）
   *
   * @param {*} msg 消息
   * @param {string} [describe] 描述
   * @memberof Logger
   */
  public logBusiness(msg: any, describe?: string): void {
    this.blue(LoggerType.Business, msg, describe)
  }

  /**
   * @zh 打印视图层日志（打印视图节点与视图展示数据）
   *
   * @param {*} msg 消息
   * @param {string} [describe] 描述
   * @memberof Logger
   */
  public logView(msg: any, describe?: string): void {
    this.green(LoggerType.View, msg, describe)
  }

  /**
   * @zh 打印配置日志（打印应用配置项）
   *
   * @param {*} msg
   * @param {string} [describe]
   * @memberof Logger
   */
  public logConfig(msg: any, describe?: string): void {
    this.gray(LoggerType.Config, msg, describe)
  }

  /**
   * @zh 打印橙色日志
   *
   * @private
   * @param {LoggerType} tag 日志类型
   * @param {*} msg 消息
   * @param {string} [describe] 描述
   * @memberof Logger
   */
  private orange(tag: LoggerType, msg: any, describe?: string): void {
    this.print(tag, msg, 'color:#ee7700;font-weight:bold;', describe)
  }

  /**
   * @zh 打印紫色日志
   *
   * @private
   * @param {LoggerType} tag 日志类型
   * @param {*} msg 消息
   * @param {string} [describe] 描述
   * @memberof Logger
   */
  private violet(tag: LoggerType, msg: any, describe?: string): void {
    this.print(tag, msg, 'color:Violet;font-weight:bold;', describe)
  }

  /**
   * @zh 打印蓝色日志
   *
   * @private
   * @param {LoggerType} tag 日志类型
   * @param {*} msg 消息
   * @param {string} [describe] 描述
   * @memberof Logger
   */
  private blue(tag: LoggerType, msg: any, describe?: string): void {
    this.print(tag, msg, 'color:#3a5fcd;font-weight:bold;', describe)
  }

  /**
   * @zh 打印绿色日志
   *
   * @private
   * @param {LoggerType} tag 日志类型
   * @param {*} msg 消息
   * @param {string} [describe] 描述
   * @memberof Logger
   */
  private green(tag: LoggerType, msg: any, describe?: string): void {
    this.print(tag, msg, 'color:green;font-weight:bold;', describe)
  }

  /**
   * @zh 打印灰色日志
   *
   * @private
   * @param {LoggerType} tag 日志类型
   * @param {*} msg 消息
   * @param {string} [describe] 描述
   * @memberof Logger
   */
  private gray(tag: LoggerType, msg: any, describe?: string): void {
    this.print(tag, msg, 'color:gray;font-weight:bold;', describe)
  }

  /**
   * @zh 判断是否可以打印对应tag日志
   *
   * @private
   * @param {LoggerType} tag 日志类型
   * @return {*}  {boolean}
   * @memberof Logger
   */
  private isOpen(tag: LoggerType): boolean {
    return (this._tags & tag) != 0
  }

  /**
   * @zh 输出日志
   *
   * @private
   * @param {LoggerType} tag 日志类型
   * @param {*} msg 日志内容
   * @param {string} color 日志文本颜色
   * @param {string} [describe] 日志标题描述
   * @memberof Logger
   */
  private print(tag: LoggerType, msg: any, color: string, describe?: string) {
    // 标记没有打开，不打印该日志
    if (!this.isOpen(tag)) {
      return
    }
    var backLog = console.log
    var type = names[tag]
    if (describe) {
      // #42b784 #FF6533
      backLog.call(
        null,
        `%c${this._badgePrefix}%c${this._badgeSuffix}%c%s%s%s:%c%s%o`,
        'background:#34495e;color:white;padding:1px 4px;border-start-start-radius:2px;border-end-start-radius:2px;font-weight:bold;',
        `background:${this._badgeColor};color:white;padding:1px 4px;border-start-end-radius:2px;border-end-end-radius:2px;font-weight:bold;`,
        color,
        this.getDateString(),
        '[' + type + ']',
        this.stack(5),
        'border:1px dashed;font-weight:bold;padding:1px 4px;border-radius:2px;',
        describe,
        msg
      )
    } else {
      backLog.call(
        null,
        `%c${this._badgePrefix}%c${this._badgeSuffix}%c%s%s%s:%o`,
        'background:#34495e;color:white;padding:1px 4px;border-start-start-radius:2px;border-end-start-radius:2px;font-weight:bold;',
        `background:${this._badgeColor};color:white;padding:1px 4px;border-start-end-radius:2px;border-end-end-radius:2px;font-weight:bold;`,
        color,
        this.getDateString(),
        '[' + type + ']',
        this.stack(5),
        msg
      )
    }
  }

  private stack(index: number): string {
    var e = new Error()
    var lines = e.stack!.split('\n')
    var result: Array<any> = []
    lines.forEach((line) => {
      line = line.substring(7)
      var lineBreak = line.split(' ')
      if (lineBreak.length < 2) {
        result.push(lineBreak[0])
      } else {
        result.push({ [lineBreak[0]]: lineBreak[1] })
      }
    })

    var list: string[] = []
    var splitList: Array<string> = []
    if (index < result.length - 1) {
      var value: string
      for (var a in result[index]) {
        var splitList = a.split('.')

        if (splitList.length == 2) {
          list = splitList.concat()
        } else {
          value = result[index][a]
          var start = value!.lastIndexOf('/')
          var end = value!.lastIndexOf('.')
          if (start > -1 && end > -1) {
            var r = value!.substring(start + 1, end)
            list.push(r)
          } else {
            list.push(value)
          }
        }
      }
    }

    if (list.length == 1) {
      return '[' + list[0] + '.ts]'
    } else if (list.length == 2) {
      return '[' + list[0] + '.ts->' + list[1] + ']'
    }
    return ''
  }

  /**
   * @zh 打印日志的时间
   *
   * @private
   * @return {*}  {string}
   * @memberof Logger
   */
  private getDateString(): string {
    let d = new Date()
    let str = d.getHours().toString()
    let timeStr = ''
    timeStr += (str.length == 1 ? '0' + str : str) + ':'
    str = d.getMinutes().toString()
    timeStr += (str.length == 1 ? '0' + str : str) + ':'
    str = d.getSeconds().toString()
    timeStr += (str.length == 1 ? '0' + str : str) + ':'
    str = d.getMilliseconds().toString()
    if (str.length == 1) str = '00' + str
    if (str.length == 2) str = '0' + str
    timeStr += str

    timeStr = '[' + timeStr + ']'
    return timeStr
  }
}

export const logger = new Logger()
