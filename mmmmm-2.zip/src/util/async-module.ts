import type videojs from 'video.js/dist/alt/video.core.novtt'

let videoJs: typeof videojs
export default {
  Fuse: async () => (await import('fuse.js')).default,
  jose: async () => await import('jose'),
  VideoJs: async () => {
    if (videoJs) {
      return videoJs
    } else {
      videoJs = (await import('video.js/dist/alt/video.core.novtt')).default
      return videoJs
    }
  },
}
