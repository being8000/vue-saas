import { Utf8 } from 'crypto-es/lib/core'
import { Pkcs7 } from 'crypto-es/lib/cipher-core'
import { AES } from 'crypto-es/lib/aes'
import { CBC } from 'crypto-es/lib/cipher-core'
import { ECB } from 'crypto-es/lib/mode-ecb'

/**
 * @zh AES加密
 */
export function aesEncrypt(word: string, keyWord: string = 'WAigad9uQa2Vbpta', ivWord: string = 'Rmt3AZ+8/gG40SPN'): string {
  const key = Utf8.parse(keyWord)
  const iv = Utf8.parse(ivWord);
  const srcs = Utf8.parse(word)
  const encrypted = AES.encrypt(srcs, key, { iv, mode: CBC, padding: Pkcs7 })
  return encrypted.toString()
}

/**
 * @zh 验证码AES加密
 */
export function aesCaptchaEncrypt(word: string, keyWord: string = 'WAigad9uQa2Vbpta'): string {
  const key = Utf8.parse(keyWord)
  const srcs = Utf8.parse(word)
  const encrypted = AES.encrypt(srcs, key, { mode: ECB, padding: Pkcs7 })
  return encrypted.toString()
}

/**
 * @zh AES解密
 */
export function aesDecrypt(word: string, keyWord: string = 'WAigad9uQa2Vbpta', ivWord: string = 'Rmt3AZ+8/gG40SPN') {
  const key = Utf8.parse(keyWord)
  const iv = Utf8.parse(ivWord)
  const srcs = word
  const decrypted = AES.decrypt(srcs, key, { iv, mode: CBC, padding: Pkcs7 })
  return decrypted.toString(Utf8)
}
