import { Utf8 } from 'crypto-es/lib/core'
import { Base64 } from 'crypto-es/lib/enc-base64'

export function base64Encode(str: string): string {
  const words = Utf8.parse(str)
  return Base64.stringify(words)
}

export function base64Decode(base64: string): string {
  const words = Base64.parse(base64)
  return Utf8.stringify(words)
}
