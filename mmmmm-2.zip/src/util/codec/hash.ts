import { MD5 as CryptoMD5 } from 'crypto-es/lib/md5';
import { SHA1 as CryptoSHA1 } from 'crypto-es/lib/sha1'
import { SHA3 as CryptoSHA3 } from 'crypto-es/lib/sha3'
import { SHA256 as CryptoSHA256 } from 'crypto-es/lib/sha256'
import { SHA512 as CryptoSHA512 } from 'crypto-es/lib/sha512'
import { RIPEMD160 as CryptoRIPEMD160 } from 'crypto-es/lib/ripemd160'

export function MD5(str: string) {
  return CryptoMD5(str).toString()
}

export function SHA1HEX(str: string) {
  return CryptoSHA1(str).toString()
}

export function SHA3HEX(str: string) {
  return CryptoSHA3(str).toString()
}

export function SHA256HEX(str: string) {
  return CryptoSHA256(str).toString()
}

export function SHA512HEX(str: string) {
  return CryptoSHA512(str).toString()
}

export function RIPEMD160HEX(str: string) {
  return CryptoRIPEMD160(str).toString()
}

