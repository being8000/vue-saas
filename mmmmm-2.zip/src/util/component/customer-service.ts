/**
 * 新增客服入口
 */
export const toCustomerService = (username?: string) => {
  // TODO 调用BP 客服按钮
}
