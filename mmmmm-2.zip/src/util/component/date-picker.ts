import { createApp } from 'vue'
import vuetify from '@/plugins/vuetify'
import type { VDatePicker } from 'vuetify/components'
import i18n from '@/i18n'
import router from '@/router'
import SelectorDate from '~/components/global/Selector/Date.vue'
import type { SelectOptionsExpose } from '~/components/global/Selector/Selectors'
import globalComponent from '@/globalComponent'
import globalProperty from '@/globalProperty'

let instance: ComponentPublicInstance<any> | null = null
function getSelectorInstance(props = {}) {
  if (!document) {
    return null
  }
  if (instance) {
    return instance
  }
  const app = createApp(h(SelectorDate, props))
  app.use(router)
  app.use(i18n)
  app.use(vuetify)
  app.use(globalComponent)
  app.use(globalProperty)
  const container = document.createElement('div')
  instance = app.mount(container)
  return instance
}

export const $datePicker = {
  setOptions<T = any>(params: any, props: VDatePicker['$props'] = {}) {
    const instance = getSelectorInstance(props) as SelectOptionsExpose<any>
    return instance.setOptions(params)
  },
}
