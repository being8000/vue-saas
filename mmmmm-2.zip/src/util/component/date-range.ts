import { createApp } from 'vue'
import vuetify from '@/plugins/vuetify'
import SelectorDateRange from '~/components/global/Selector/DateRange.vue'
import type { SelectOptionsExpose } from '~/components/global/Selector/Selectors'
import i18n from '@/i18n'
import router from '@/router'
import globalComponent from '@/globalComponent'
import globalProperty from '@/globalProperty'
let instance: ComponentPublicInstance<any> | null = null
function getSelectorInstance(props = {}) {
  if (!document) {
    return null
  }
  if (instance) {
    return instance
  }
  const app = createApp(SelectorDateRange, props)
  app.use(vuetify)
  app.use(router)
  app.use(i18n)
  app.use(globalComponent)
  app.use(globalProperty)
  const container = document.createElement('div')
  instance = app.mount(container)
  return instance
}

export const $dateRange = {
  setOptions<T = any>(params: any, props: any = {}) {
    const instance = getSelectorInstance(props) as SelectOptionsExpose<any>
    return instance.setOptions(params)
  },
}
