import { createApp, type App } from 'vue'
import type { VDialog } from 'vuetify/components'
import vuetify from '@/plugins/vuetify'
import i18n from '@/i18n'
import router from '@/router'
import Dialog from '~/components/global/Dialog.vue'
import type { DialigProps } from '~/components/global/Dialog.vue'
import globalComponent from '@/globalComponent'
import globalProperty from '@/globalProperty'
let instance: ComponentPublicInstance<any> | null = null
let app: App<Element> | null = null
let container: HTMLElement | null = null
function getSelectorInstance(component: any) {
  app = createApp(component)
  app.use(router)
  app.use(i18n)
  app.use(vuetify)
  app.use(globalComponent)
  app.use(globalProperty)
  container = document.createElement('div')
  instance = app.mount(container)
  return instance
}
type DialogParams = Partial<
  DialigProps & {
    'data-gtp-b': string
    'data-gtp-c': string
    gtpD: string
    slots: Record<string, () => globalThis.VNode>
  }
>
const setOptions = (props: DialogParams & VDialog['$props']) => {
  if (instance) {
    instance.close()
  }
  const $slots = props?.slots || {}
  const FinalComponent = h(
    Dialog,
    {
      ...(props as any),
      onCancel() {
        instance.close()
      },
      onAfterLeave() {
        instance = null
        container?.remove()
        container = null
        app?.unmount()
      },
    },
    {
      default: () => $slots.default && $slots.default(),
      bottom: () => $slots.bottom && $slots.bottom(),
    }
  )
  instance = getSelectorInstance(FinalComponent)
  if (instance) {
    return instance
  } else {
    return false
  }
}

export const $dialog = {
  pop(props: DialogParams): Awaited<any> {
    const instance = setOptions(props)
    if (instance) {
      return instance.pop()
    } else {
      return false
    }
  },
  // 关闭弹窗事件
  close() {
    if (instance) {
      instance.close()
    }
  },
  setOptions,
}
