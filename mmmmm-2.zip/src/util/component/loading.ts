import { debounce } from "..";
import Loading from "@/components/global/Loading.vue";
import { createApp } from "vue";

interface LoadingInstance {
  show: () => void;
  hide: () => void;
}
let instance: ComponentPublicInstance<any> | null = null;
export function getCustomLoadingInstance() {
  if (!document) {
    return null;
  }

  if (instance) {
    return instance;
  }
  const app = createApp(Loading);
  const container = document.createElement("div");
  instance = app.mount(container);
  return instance;
}

function init() {
  let count = 0;
  function pageStart() {
    instance = getCustomLoadingInstance();
    if (instance) {
      instance.show();
    }
  }
  function pageEnd() {
    instance && instance.hide();
    instance = null;
  }
  function finish() {
    if (count <= 0) {
      count = 0;
      instance && instance.hide();
      instance = null;
    }
  }

  function start() {
    if (count <= 1) {
      instance = getCustomLoadingInstance();
      if (instance) {
        instance.show();
      }
    }
  }
  const dFinish = debounce(finish, 150);
  const dStart = debounce(start, 1000, true);
  return function () {
    return {
      start() {
        count++;
        dStart();
      },
      finish() {
        count--;
        dFinish();
      },
      pageStart,
      pageEnd,
    };
  };
}

export const loadingInstance = init()();
