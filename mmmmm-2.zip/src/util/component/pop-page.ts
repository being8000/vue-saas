import { createApp } from 'vue'
import PopPage from '~/components/global/PopPage.vue'
import vuetify from '@/plugins/vuetify'
import router from '@/router'
import i18n from '@/i18n'
import globalComponent from '@/globalComponent'
import globalProperty from '@/globalProperty'
let instance: ComponentPublicInstance<any> | null = null
/**
 * 该函数用户替换hash component, 通过函数组件弹出对于的模拟页面
 * @param vnode
 * @returns
 */
export function popPage(vnode: globalThis.VNode, hash = false) {
  if (!document) {
    return null
  }
  if (instance) {
    instance.show(hash)
    return instance
  }
  const nuxtApp = useNuxtApp()
  const app = createApp(
    h(
      PopPage,
      {
        onClose() {
          // instance.unmount()
          app.unmount()
          instance = null
        },
      },
      {
        default: () => vnode,
      }
    )
  )
  app.use(router)
  app.use(i18n)
  app.use(vuetify)
  app.use(globalComponent)
  app.use(globalProperty)
  const container = document.createElement('div')
  instance = app.mount(container)
  instance.show(hash)
  return instance
}
