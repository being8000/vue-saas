import { createApp } from 'vue'
import vuetify from '@/plugins/vuetify'
import SelectorOptions from '~/components/global/Selector/Options.vue'
import type { SelectOptionsExpose } from '~/components/global/Selector/Selectors'
import i18n from '@/i18n'
import router from '@/router'
import globalComponent from '@/globalComponent'
import globalProperty from '@/globalProperty'
let instance: ComponentPublicInstance<any> | null = null
function getSelectorInstance() {
  if (!document) {
    return null
  }
  if (instance) {
    return instance
  }
  const app = createApp(SelectorOptions)
  app.use(vuetify)
  app.use(router)
  app.use(i18n)
  app.use(globalComponent)
  app.use(globalProperty)
  const container = document.createElement('div')
  instance = app.mount(container)
  return instance
}

export const $selector = {
  setOptions<T = any>(...params: Parameters<SelectOptionsExpose<T>['setOptions']>) {
    const instance = getSelectorInstance() as SelectOptionsExpose<any>
    return instance.setOptions(...params)
  },
}
