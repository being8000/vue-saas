import { AsyncComponentLoader } from 'vue'
import LoadingComponent from '@/assets/images/svg/loading/style-1.svg'
export const defineAsyncIconComponent = (loader: AsyncComponentLoader<globalThis.Component>) => {
  return defineAsyncComponent({
    // the loader function
    loader: loader,
    // A component to use while the async component is loading
    loadingComponent: LoadingComponent as any,
    // Delay before showing the loading component. Default: 200ms.
    delay: 0,

    // A component to use if the load fails
    errorComponent: h(LoadingComponent),
    // The error component will be displayed if a timeout is
    // provided and exceeded. Default: Infinity.
    timeout: 3000,
  })
}
