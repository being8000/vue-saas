const item = (value: any, label: string) => ({ value, label })
export const SignUpIDs = [
  item('4', "Driver's License"),
  item('1', 'Unified Multi-Purpose ID (UMID)'),
  item('17', 'PhilHealth ID'),
  item('2', 'Tax Identification (TIN)'),
  item('21', 'Philippine National ID'),
  item('6', `Voter's ID`),
  item('5', 'Passport'),
  item('3', 'Social Security System (SSS)'),
  item('7', 'Postal ID'),
]
export const SourceOfIncome = [
  item('Employment Income', 'Employment Income'),
  item('Bank Interest', 'Bank Interest'),
  item('Rental Income', 'Rental Income'),
  item('Pension Income', 'Pension Income'),
  item('Self Employment Income', 'Self Employment Income'),
  item('Other', 'Other'),
]

export const GenderOptions = [
  item('M', 'Male'),
  item('F', 'Female'),
]
export const GetGenderLabel = (v: string | undefined): string => GenderOptions.find(el => el.value == v)?.label || ''

// 'Deposit', 'Withdraw', 'Promo Received', 'Game Win-loss'
export const TransactionTypeList = [
  item('0', 'Deposit'),
  item('1', 'Withdraw'),
  item('2', 'Promo Received'),
  item('3', 'Game Win-loss'),
  item('11', 'Tournament'),
  item('12,13', 'Others'),
]
export const TransactionAllTypeList = [
  item('0,1,2,3,11,12,13', 'All'),
  ...TransactionTypeList
]

// ['Completed', 'Failed', 'Pending']
export const TransactionStatusList = [
  item('0', 'Completed'),
  item('1', 'Failed'),
  item('2', 'Pending'),
  // item('3', 'Pending'),
]
// 子单状态
export const TransationStatusExpendDetailList = [
  item('3', 'Completed'),
  item('-7', 'Failed'),
]

export const TransactionAllStatusList = [
  item('0,1,2,3', 'All'),
  ...TransactionStatusList
]