import { set } from 'date-fns'

export const getSpecificHourOfDay = (hour: number) => {
  const now = new Date() // 当前时间
  // 设置当前时间为今天的某个小时
  const specificHour = set(now, { hours: hour, minutes: 0, seconds: 0, milliseconds: 0 })
  return specificHour
}
