export enum SignTypeEnum {
  SignIn = 'Sign In',
  SignUp = 'Sign Up',
}

export enum PageEnum {
  SignIn = 'SignIn',
  SignUp = 'SignUp',
  ResetPassword = 'ResetPassword',
  PrivacyPolicy = 'PrivacyPolicy',
}
/**
 * 系统公用跳转类型
 */
export enum LinkToEnum {
  None = 'None',
  Internal = 1, //  站内页面
  External = 2, // 站外页面
  ToGame = 3, // 跳转游戏
  Jackpot = 4 //打开jackpot弹框
}

export enum StateEnum {
  STORE_WEBSITE_EVENT_JSON = 'STORE_WEBSITE_EVENT_JSON', // 获取Promotions列表
}

export enum WalletTypeEnum {
  Deposit = 'Deposit',
  Withdraw = 'Withdraw',
}

export enum SetChangeEnum {
  Set = 'Not Set',
  Change = 'Change',
  Modify = 'Modify',
}

export enum DIalogDayShow {
  Jnh = 'Jnh-dialog-date',
  qrj = 'qrj-dialog-date',
}