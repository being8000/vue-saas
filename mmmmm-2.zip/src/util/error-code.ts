export enum ErrorCode {
  HighRisk = 'GW_900990', // 高风险用户
}
