import { format } from 'date-fns'
export const withGlaxy = (path: string) => `/_glaxy_c66_${path}`
export const withActivity = (path: string) => `/_activity_api_${path}`.replace(/\/\//g, '/')
export const withFront = (path: string) => `/_front_api_${path}`
export const withStaticJs = (path: string) => `/staticJs${path}`

export const DF = {
  dMy(date: string | number = 0) {
    return date ? format(new Date(date), 'MM-dd-yyyy') : null
  },
  dMyHms(date: string | number = 0) {
    return date ? format(new Date(date), 'MM-dd-yyyy HH:mm:ss') : null
  },
  yMdDot(date: string | number = 0) {
    return date ? format(new Date(date), 'yyyy.MM.dd') : null
  },
  yMdHmsDot(date: string | number = 0) {
    return date ? format(new Date(date), 'yyyy.MM.dd HH:mm:ss') : null
  },
  HmsDot(date: string | number = 0) {
    return date ? format(new Date(date), 'HH:mm:ss') : null
  },
  yMdHms(date: string | number = 0) {
    return date ? format(new Date(date), 'MM/dd HH:mm') : null
  },
  MdHm(date: number) {
    return format(new Date(date), 'MMM dd, hh:mm a')
  },
  Hm(date: number) {
    return format(new Date(date), 'hh:mm a')
  },
}
