import { GameBaseItem } from '@/api/game'
import router from '@/router'
import { AES } from 'crypto-es/lib/aes'
import { CFB } from 'crypto-es/lib/mode-cfb'
import { Latin1 } from 'crypto-es/lib/core'
import { NoPadding } from 'crypto-es/lib/pad-nopadding'
import { isFunction, isObject, random } from 'lodash-es'
export const serialize = (data: any) => {
  const list: string[] = []
  Object.keys(data).forEach((ele) => {
    list.push(`${ele}=${data[ele]}`)
  })
  return list.join('&')
}

/**
 *加密处理
 */
export const encryption = (params: any) => {
  const { data, type, param } = params
  const result = JSON.parse(JSON.stringify(data))
  if (type === 'Base64') {
    param.forEach((ele: string) => {
      result[ele] = btoa(result[ele])
    })
  } else {
    param.forEach((ele: string) => {
      var data = result[ele]
      const key = Latin1.parse(params.key)
      var iv = key
      // 加密
      var encrypted = AES.encrypt(data, key, {
        iv: iv,
        mode: CFB,
        padding: NoPadding,
      })
      result[ele] = encrypted.toString()
    })
  }
  return result
}

export const randomFn = (count = 6) => [...Array(count)].map((_) => random(0, 9, true)).join('')
export const sortString = (str: string) => {
  // 倒序排列字符
  return str.split('').sort().reverse().join('')
}
export function debounce(func: Function, wait: number, immediate?: boolean) {
  let timeout: any, args: any, context: any, timestamp: any, result: any

  const later = function () {
    // 据上一次触发时间间隔
    const last = +new Date() - timestamp
    // 上次被包装函数被调用时间间隔 last 小于设定时间间隔 wait
    if (last < wait && last > 0) {
      timeout = setTimeout(later, wait - last)
    } else {
      timeout = null
      // 如果设定为immediate===true，因为开始边界已经调用过了此处无需调用
      if (!immediate) {
        result = func.apply(context, args)
        if (!timeout) context = args = null
      }
    }
  }

  return function (this: any, ...args: any) {
    context = this
    timestamp = +new Date()
    const callNow = immediate && !timeout
    // 如果延时不存在，重新设定延时
    if (!timeout) timeout = setTimeout(later, wait)
    if (callNow) {
      result = func.apply(context, args)
      context = args = null
    }

    return result
  }
}

export const subString = (str: string = '', len: number = 20) => str.substring(0, len)

export const fixed = (v: string | number, int = 2): string => Number(v).toFixed(int)

// 密码只能输入6 为数字
export const changePsd = (v: string | number, int = 6) =>
  subString(v.toString().replace(/\D/g, ''), int)

export function isPromise<T = any>(val: unknown): val is Promise<T> {
  const _val = val as Promise<T>
  return isObject(val) && isFunction(_val.then) && isFunction(_val.catch)
}

export function promisedTimeout(timeout: number): Promise<void> {
  return new Promise((resolve) => {
    setTimeout(resolve, timeout)
  })
}

export function toAppPath(link: string | undefined | null) {
  if (!link) return
  let A = document.createElement('a')
  A.href = link
  A.click()
}

export const changeZeroPhone = (phone: string) => {
  return phone.slice(phone.startsWith('0') ? 1 : 0)
}

export const isHashLogin = (query: any = {}) => {
  return (query.hashPage + '').toLowerCase() === 'login'
}

export function getBirthDayGap(b: string): number {
  if (!b || b == '') {
    return -1
  }
  let today = new Date()
  let thisYear = today.getFullYear() + ''
  let birthday = b.replace(/^\d\d\d\d/, thisYear)
  let bday = new Date(birthday)
  let td = today.getTime()
  let bd = bday.getTime()
  let d = 0
  if (td > bd) {
    let nextYear = today.getFullYear() + 1 + ''
    let nextYearBithday = b.replace(/^\d\d\d\d/, nextYear)
    bd = new Date(nextYearBithday).getTime()
    d = Math.ceil((bd - td) / (24 * 60 * 60 * 1000)) + 1
  } else {
    d = Math.ceil((bd - td) / (24 * 60 * 60 * 1000))
  }
  return d
}

export function guessSerializerType<
  T extends string | number | boolean | object | null | undefined
>(rawInit: T) {
  return rawInit == null
    ? 'any'
    : rawInit instanceof Set
    ? 'set'
    : rawInit instanceof Map
    ? 'map'
    : rawInit instanceof Date
    ? 'date'
    : typeof rawInit === 'boolean'
    ? 'boolean'
    : typeof rawInit === 'string'
    ? 'string'
    : typeof rawInit === 'object'
    ? 'object'
    : !Number.isNaN(rawInit)
    ? 'number'
    : 'any'
}

export function isOverAge(date: string | Date | number, _age = 21) {
  // 传入的 birthDate 应该是一个有效的 Date 对象
  return getYearsAgo(_age).getTime() > new Date(date).getTime()
}

export function getYearsAgo(years = 21) {
  const today = new Date() // 获取当前日期
  const eighteenYearsAgo = new Date(today) // 创建当前日期的副本

  eighteenYearsAgo.setFullYear(today.getFullYear() - years) // 将年份减少18年
  eighteenYearsAgo.setTime(eighteenYearsAgo.getTime() - 60 * 60 * 24 * 1000)
  return eighteenYearsAgo
}

export function padEnd(str: string, length: number, char = '0') {
  return str + char.repeat(Math.max(0, length - str.length))
}

export function padStart(str: string, length: number, char = '0') {
  return char.repeat(Math.max(0, length - str.length)) + str
}

export function chunk(str: string, size = 1) {
  const chunked: string[] = []
  let index = 0
  while (index < str.length) {
    chunked.push(str.substr(index, size))
    index += size
  }
  return chunked
}

export function has<T extends string>(obj: object, key: T[]): obj is Record<T, unknown> {
  return key.every((k) => obj.hasOwnProperty(k))
}

export function clamp(value: number, min = 0, max = 1) {
  return Math.max(min, Math.min(max, value))
}

/**
 * @zh _UnionBy的替代品，可在Web Worker中使用
 *
 * @template T
 * @param {T[]} arrays
 * @param {string} key
 * @return {*}  {T[]}
 */
export function unionBy<T>(arrays: T[], key: string): T[] {
  const seen = new Set<any>()
  const result: T[] = []

  for (const item of arrays) {
    const k = (item as any)[key]
    if (!seen.has(k)) {
      seen.add(k)
      result.push(item)
    }
  }

  return result
}

/**
 * @zh _Remove的替代品，可在Web Worker中使用
 *
 * @template T
 * @param {T[]} array
 * @param {(value: T) => boolean} predicate
 * @return {*}  {T[]}
 */
export function remove<T>(array: T[], predicate: (value: T) => boolean): T[] {
  const removedElements: T[] = []

  for (let i = array.length - 1; i >= 0; i--) {
    if (predicate(array[i])) {
      removedElements.push(array[i])
      array.splice(i, 1)
    }
  }

  return removedElements
}

/**
 * @zh 非时间段游戏维护状态
 *
 * @export
 * @param {GameBaseItem} game
 * @return {*}  {boolean}
 */
export function isOtherMaintenanceOfGame(game: GameBaseItem): boolean {
  return game.flag === 2 || game.platformStatus !== 1
}

/**
 * @zh 时间段维护状态
 *
 * @export
 * @param {GameBaseItem} game
 * @return {*}  {boolean}
 */
export function isTimeMaintenanceOfGame(game: GameBaseItem): boolean {
  const current = Date.now()
  const start = +new Date(game.maintainStartTime)
  const end = +new Date(game.maintainEndTime)
  return game.flag === 1 && current >= start && current <= end
}

/**
 * @zh 游戏是否在维护中
 *
 * @export
 * @param {GameBaseItem} game
 * @return {*}  {boolean}
 */
export function isMaintenanceOfGame(game: GameBaseItem): boolean {
  return isOtherMaintenanceOfGame(game) || isTimeMaintenanceOfGame(game)
}

export function onRouterBack(router: ReturnType<typeof useRouter>) {
  if (history?.state?.back) {
    router.back()
  } else {
    router.push('/')
  }
}

export function abbreviateNumber(
  number: number,
  removeZero: boolean = true,
  fractionDigits: number = 1
) {
  const SI_SYMBOL = ['', 'k', 'M', 'G', 'T', 'P', 'E']
  // what tier? (determines SI symbol)
  const tier = (Math.log10(Math.abs(number)) / 3) | 0

  // if zero, we don't need a suffix
  if (tier == 0) return number

  // get suffix and determine scale
  const suffix = SI_SYMBOL[tier]
  const scale = Math.pow(10, tier * 3)

  // scale the number
  const scaled = number / scale

  // format number and add suffix
  let num = scaled.toFixed(fractionDigits)
  if (removeZero && num.includes('.')) {
    const numSps = num.split('')
    if (numSps.at(-1) == '0' && numSps.at(-2) == '.') {
      num = numSps.slice(0, -2).join('')
    }
  }
  return num + suffix
}

export function runfps(callback: () => void, fps: number = 1000 / 60) {
  let stop = false
  let lastTime = 0

  function loop(currentTime: number) {
    const elapsed = currentTime - lastTime

    if (elapsed >= fps) {
      lastTime = currentTime - (elapsed % fps)
      callback()
    }
    if (!stop) {
      requestAnimationFrame(loop)
    }
  }

  lastTime = performance.now()
  loop(lastTime)

  return () => {
    stop = true
  }
}

enum ElementPosition {
  None = 'None',
  AboveViewport = 'AboveViewport',
  BelowViewport = 'BelowViewport',
  InViewport = 'InViewport',
}

export function getElementPosition(element?: HTMLElement): ElementPosition {
  if (!element) {
    return ElementPosition.None
  }
  const rect = element.getBoundingClientRect()
  const viewportHeight = window.innerHeight

  if (rect.bottom < 0) {
    return ElementPosition.AboveViewport
  } else if (rect.top >= viewportHeight) {
    return ElementPosition.BelowViewport
  } else {
    return ElementPosition.InViewport
  }
}

export function isElementInAboveView(element?: HTMLElement) {
  return getElementPosition(element) === ElementPosition.AboveViewport
}

export function isElementInView(element?: HTMLElement) {
  return getElementPosition(element) === ElementPosition.InViewport
}

export function isElementInBelowView(element?: HTMLElement) {
  return getElementPosition(element) === ElementPosition.BelowViewport
}
export function getMediaType(url: string): string {
  const imageExtensions = ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.svg', '.webp', '.avif']
  const videoExtensions = ['.mp4', '.mov', '.avi', '.wmv', '.mkv', '.webm', '.ogg', '.m3u8']

  const lowerCaseUrl = url.toLowerCase()
  const extension = lowerCaseUrl.substring(lowerCaseUrl.lastIndexOf('.'))

  if (imageExtensions.includes(extension)) {
    return 'image'
  } else if (videoExtensions.includes(extension)) {
    return 'video'
  } else {
    return 'unknown'
  }
}

export function getVideoType(url: string | undefined) {
  if (!url) {
    return ''
  }
  const videoExtensions: Record<string, string> = {
    '.mp4': 'video/mp4',
    '.mov': 'video/mp4',
    '.avi': 'video/mp4',
    '.wmv': 'video/mp4',
    '.mkv': 'video/mp4',
    '.webm': 'video/mp4',
    '.ogg': 'video/mp4',
    '.m3u8': 'video/mp4',
  }
  const lowerCaseUrl = url.toLowerCase()
  const extension = lowerCaseUrl.substring(lowerCaseUrl.lastIndexOf('.'))
  return videoExtensions[extension] || 'application/octet-stream'
}

export function isVideoUrl(url: string | undefined): boolean {
  if (url) {
    return getMediaType(url) === 'video'
  }
  return false
}

export function isPlayableVideoUrl(url: string): Promise<boolean> {
  return new Promise((resolve) => {
    const video = document.createElement('video')
    video.src = url

    video.addEventListener('loadedmetadata', () => {
      const type = video.canPlayType(getVideoType(video.src))

      resolve(type === 'probably' || type === 'maybe')
    })

    video.addEventListener('error', () => {
      resolve(false)
    })

    video.load()
  })
}

export function blockBodyScroll() {
  let scrollTop = window.scrollY || document.documentElement.scrollTop
  document.querySelector('html')?.style.setProperty('--v-body-scroll-y', `${scrollTop}px`)
  document.querySelector('html')?.classList.add('v-overlay-scroll-blocked')
}
export function unblockBodyScroll() {
  document.querySelector('html')?.classList.remove('v-overlay-scroll-blocked')
}

export interface LinkToGame {
  targetUrl: string
  gameId: string
  platformCode: string
  jsonParam?: string
}

export const gzlinkTo = (type: LinkToEnum, params: LinkToGame) => {
  console.log(type, 'type')
  switch (Number(type)) {
    case LinkToEnum.ToGame:
      router.push({
        name: 'game-id',
        params: {
          platformId: params.platformCode,
          gameId: params.gameId,
        },
        query: { jumpJson: params.jsonParam },
      })
      break
    case LinkToEnum.External:
      break
    case LinkToEnum.Internal:
      let query = {}
      try {
        const url = new URL(window.location.origin + params.targetUrl)
        query = Object.fromEntries(url.searchParams)
      } catch (error) {}
      router.push({
        path: params.targetUrl,
        query,
      })
      break
  }
}

export const strToJson = <T = any>(str: string | undefined, def: T) => {
  try {
    return JSON.parse(str || JSON.stringify(def)) as T
  } catch (error) {
    return def
  }
}
export const jsonToStr = (str: any) => {
  try {
    return JSON.stringify(str)
  } catch (error) {
    return ''
  }
}
