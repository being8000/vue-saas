import { useCustomer } from '@/composables/useCustomer'
import { $dialog } from '../component/dialog'
import { VBtn } from 'vuetify/components/VBtn'
const { show: showCustomer } = useCustomer()
// TODO 去登入
export const tokenExpiredCodes = [
  // 访问凭证过期
  'GW_890203',
  // 凭证不匹配
  'GW_890205',
  // 您长时间未操作，请重新登录
  'GW_890206',
  // 会员未登录
  'GW_890207',
  // 校验token异常
  'GW_890209',
  // 系统用户名不能为空
  'GW_890401',
  // 账号被他人登录
  'GW_801716',
  // 玩家被禁用，24小时后可激活
  'GW_910024',
  // 系统账号被修改
  'GW_806006',
  // 您当前登录到另一个终端
  'GW_890212',
  'GW_910220',
]

export const tokenEmptyCodes = [
  // 会员访问凭证为空
  'GW_890201',
  // 安全token为空
  'GW_890210',
]
export const errHandler: Record<string, Function> = {
  // 这里有特殊处理，不做任何提示
  GW_801623(response: any) {
    const { $toast } = useNuxtApp()
    //Todo && !store.getters.loginName
    const { head } = response.data || {}
    // ingame进游戏未达标投注额度的提示语
    $toast(head.errMsg + '(GW_801623)')
  },
  // GW_899995(response: any) {
  //   return alert('GW_899995')
  //   // return showDialog({
  //   //   allowHtml: true,
  //   //   message:
  //   //     "<textare>" +
  //   //     JSON.stringify(response.config.url) +
  //   //     "\n" +
  //   //     JSON.stringify(response.config.data) +
  //   //     "\n" +
  //   //     JSON.stringify(response.data) +
  //   //     "</textarea>",
  //   // });
  // },
  // reLogin
  GW_801104() {
    $dialog.pop({
      title: 'Tips',
      content:
        'We are sorry for the inconvenience. We are currently coordinating with your payment solution provider to resolve the issue. Thank you for your patience.',
    })
  },
  // 绑卡人脸识别错误码
  GW_898901() {
    $dialog.pop({
      title: 'Tips',
      content: 'Face verification failed. Please contact our customer service!',
    })
  },

  GW_801123() {
    const { $toast } = useNuxtApp()
    $toast('Insufficient balance')
  },
  GW_801102() {
    const { $toast } = useNuxtApp()
    $toast('Your single deposit amount is too large.')
  },
  GW_510517() {
    $dialog.pop({
      title: 'Tips',
      content:
        'Dear GCash user, according to PAGCOR regulation, only 21yrs+ customer can enter GameZone!',
    })
  },
  // 注册 设备指纹拦截
  GW_801657() {
    $dialog.pop({
      title: 'Tips',
      content:
        'You have accedded too many times, please try again later. if you have any questions, please contact customer service.',
      slots: {
        // default: () => h('div', { class: 'tw-p-4 tw-text-align' }, 'You have accedded too many times,please try again later. if you have any questions,please contact customer service.'),
        bottom: () =>
          h(
            VBtn,
            {
              color: 'primary',
              class: 'tw-mb-4 tw-w-[90%] tw-m-auto',
              onClick: () => showCustomer(),
            },
            'Customer Service'
          ),
      },
    })
  },
  // 登录 设备指纹拦截
  GW_801656() {
    $dialog.pop({
      title: 'Tips',
      content:
        'You account has logged in too many times, please try again later. if you have any questions, please contact customer service.',
      slots: {
        bottom: () =>
          h('div', { class: 'tw-flex' }, [
            h(
              VBtn,
              {
                color: 'primary',
                class: 'tw-mb-4 tw-w-[90%] tw-m-auto',
                onClick: () => showCustomer(),
              },
              'Customer Service'
            ),
          ]),
      },
    })
  },
}
