import { withDataEncrypt } from '@/util/request/with-data-encrypt'
import { withLoading } from '@/util/request/with-loading'
import { withSignature } from '@/util/request/with-signature'
import axios, { AxiosError, AxiosResponse } from 'axios'
import { capitalize } from 'vue'
import { errHandler, tokenExpiredCodes } from '~/util/request/error-code-handler'
import { withGlobal } from '~/util/request/with-global'
const axiosInstance = withLoading(
  axios.create({
    timeout: 20000,
    headers: {
      Accept: 'application/json',
      'Content-Type': 'application/json',
    },
  })
)

axiosInstance.interceptors.request.use(async (config) =>
  withSignature(await withDataEncrypt(await withGlobal(config)))
)
let popInstance: any = null
axiosInstance.interceptors.response.use(
  function (response: AxiosResponse) {
    if (popInstance) return response
    const { config } = response
    if (config.blobToJson === true) {
      return response
    }
    // 不做任何处理，立即放回数据
    if (config.original) {
      return response
    } else {
      const { head = {}, body, resultCode } = response.data || {}
      const { $toast } = useNuxtApp()
      if (head.errCode == '0000' || resultCode == '0000') {
        if (config.successTip) {
          const t = setTimeout(() => {
            $toast(config.successTip!)
            clearTimeout(t)
          }, 50)
        }
        response.data.success = true
        return response
      } else {
        console.error('http error', head)
        // const { removeUserStorage } = useUserStoreClient()

        // 黑名单用户
        if (head.errCode === 'GW_801655') {
          popInstance = $dialog.pop({
            title: 'Tips!',
            hideBottom: true,
            hideCloseIcon: true,
            content:
              head.errMsg ||
              'Your account is prohibited from accessing this website due to PAGCOR requirements，We apologize for any inconvenience caused!',
          })
          setTimeout(() => {
            // removeUserStorage()
            popInstance = null
          }, 3000)
          return response
        }
        if (tokenExpiredCodes.includes(head.errCode)) {
          $toast(capitalize(head.errMsg || 'Error' + '(' + head.errCode + ')'))
          // removeUserStorage()
          return response
        }
        response.data.success = false
        // 进入特殊错误码处理
        const handlerFunc = errHandler[head.errCode]
        if (handlerFunc) {
          handlerFunc(response)
          return response
        } else if (config.showToast !== false) {
          $toast(capitalize(head.errMsg || 'Error' + '(' + head.errCode + ')'))
          return response
        }
      }
    }
    return response
  },
  function (error: AxiosError) {
    const { code, status, message, config, response } = error
    const { backupUrls = [] } = (response?.config as any) || { backupUrls: [] }
    if (backupUrls.length) {
      return
    }
    console.log(error)
    const { $toast } = useNuxtApp()
    if (config?.showToast === true) {
      $toast(config?.url + ' ' + message)
    }
    if (config?.url?.startsWith('/staticJs/')) {
      return Promise.resolve({
        data: null,
      })
    } else {
      return Promise.resolve({
        data: {
          body: response,
          head: {
            errMsg: message,
            errCode: code,
          },
          success: false,
        },
      })
    }
  }
)

export default axiosInstance
