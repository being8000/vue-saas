import axios, { AxiosError, AxiosResponse } from 'axios'
/**
 * 比较纯净的http请求，不受内部业务逻辑污染，用于请求静态资源，或cnd资源等
 */
export const pureRequest = withLoading(
  axios.create({
    timeout: 20000,
    headers: {
      Accept: 'application/json',
      'Content-Type': 'application/json',
    },
  })
)
pureRequest.interceptors.response.use(
  function (response: AxiosResponse) {
    return response
  },
  function (error: AxiosError) {
    return Promise.resolve({
      data: null,
    })
  }
)
