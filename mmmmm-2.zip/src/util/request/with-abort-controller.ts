let signalMap = new Map<Symbol, AbortController>()
export function createSignal(symbol: Symbol) {
  const controller = new AbortController()
  signalMap.set(symbol, controller)
  return controller
}

export function abortAllSignals() {
  signalMap.forEach((el) => el.abort())
  signalMap = new Map<Symbol, AbortController>()
}

export function removeSingal(symbol?: Symbol) {
  symbol && signalMap.delete(symbol)
}
