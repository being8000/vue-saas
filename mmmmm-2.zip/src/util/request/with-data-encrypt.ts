import JSEncrypt from 'jsencrypt'
import { InternalAxiosRequestConfig } from 'axios'
export const encryptor = new JSEncrypt() // 新建JSEncrypt对象
const webKey =
  'MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDSu2AZPdT2Fqpqxctx3EbnRuuYdBxFZDYG7MASIgw/DFl3P9FAp7S9WaQjdM1NmgBDgvfUWx1xj72LNz4EP4Euh9EESKceNCeoE4M8ZP4ENUQX0nDMbpmIG3/JCI8B5Iv2FKj2q0gGbE0WsLdrYDzFXTYbZKRJSbMMjHT3HtKD/wIDAQAB'
encryptor.setPublicKey(webKey)
const encryptProps = [
  'password',
  'newPassword',
  'oldPassword',
  'mobileNo',
  'currMobile',
  'phone',
  'newEmail',
  'newPhone',
  'accountNo',
  'withdrawPassword',
  'withdrawalPassword',
  'newWithdrawalPwd',
]

export const withDataEncrypt = async (config: InternalAxiosRequestConfig) => {
  const { isGamezoneAndroid } = useAppClientVar()
  if (config.encrypt !== false) {
    config.data = config.data || {}
    // 加密数据
    for (const index in encryptProps) {
      const prop = encryptProps[index]
      if (config.data[prop]) {
        // if (isGamezoneAndroid()) {
        //   // 在Android 环境中使用了android系统自带的
        //   config.data[prop] = await $gz.encrypt(config.data[prop])
        //   // context.options.body[prop] = await rsaEncrypt(config.body[prop])
        // } else {
        config.data[prop] = encryptor.encrypt(config.data[prop])
        // }
      }
    }
  }
  return config
}
