import { useDxToken } from '@/plugins/dx-sdk'
import { InternalAxiosRequestConfig } from 'axios'

export const withGlobal = async (config: InternalAxiosRequestConfig) => {
  const { productId } = useRuntimeConfig().public
  const userStore = useUserStore(true)
  const dxToken = useDxToken()
  config.method = config.method || 'get'

  if (config.method.toLocaleLowerCase() === 'get') {
    config.params = config.params || {}
    config.params.productId = productId
    config.data = undefined
    // config.params.deviceFingerprintToken = dxToken.value

    if (unref(userStore).isLogin && config.withGlobal !== false) {
      config.params.customerId = unref(userStore).customerId
      config.params.loginName = unref(userStore).loginName

      if (config.needCustomerName) {
        config.params.customerName = unref(userStore).loginName
      }
    }
  } else {
    config.data = config.data || {}
    config.data.productId = productId
    if (unref(userStore).isLogin && config.withGlobal !== false) {
      config.data.customerId = unref(userStore).customerId
      config.data.loginName = unref(userStore).loginName

      if (config.needCustomerName) {
        config.data.customerName = unref(userStore).loginName
      }
    }
  }
  return config
}
