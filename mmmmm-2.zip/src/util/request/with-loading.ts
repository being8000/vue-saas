import { AxiosInstance } from 'axios'
import { loadingInstance } from '../component/loading'

export const withLoading = (instance: AxiosInstance) => {
  instance.interceptors.request.use(function (config) {
    if (config.showLoading) {
      loadingInstance.start()
    }
    return config
  })
  instance.interceptors.response.use(
    function (response) {
      const { config } = response
      if (config.showLoading) {
        loadingInstance.finish()
      }
      return response
    },
    function (response) {
      const { config = {} } = response
      if (config.showLoading) {
        loadingInstance.finish()
      }
      return Promise.reject(response)
    }
  )
  return instance
}
