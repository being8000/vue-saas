import { InternalAxiosRequestConfig } from 'axios'
import * as utils from '../index'
import { MD5 } from 'crypto-es/lib/md5'
import { random } from 'lodash-es'
// 新版签名key
export const KA_7_KEY = '4J3yRx7YJQrEjfCP2%5BKNDSa%Y9@yYgZ38QDgTXlqZjrK51za'
const randomFn = (n: any) => [...Array(n)].map((_) => random(9)).join('')

export const withSignature = (config: InternalAxiosRequestConfig) => {
  const { version } = useRuntimeConfig().public
  const { getAppId, getPlatform, getPackage } = useAppClientVar()
  const appid = getAppId()
  const platform = getPlatform()
  const packageHeader = getPackage()
  const webTokenStore = useWebTokenStore()
  const timenum = Date.now() // 时间戳
  const qid = MD5(timenum + utils.randomFn()).toString()
  const { token = '', u2token = '' } = webTokenStore.value
  let _token = ''
  if (token && u2token) {
    _token = token + u2token
    // 如果token 为空，网关会报 user asscess token is empty 相关错误
    config.headers['token'] = token || ''
  }
  // ka-7， kkz-1，kx-2，ata-5 cnd签名校验
  // config.headers['ka-7'] = ka7
  // config.headers['kkz-1'] = kkz1
  // config.headers['kx-2'] = kx2
  // config.headers['ata-5'] = ata5
  // qid 日志排查
  config.headers['qid'] = qid
  // 网关gateway-api签名
  config.headers['sign'] = MD5(
    utils.sortString(JSON.stringify(config.data || {})) + qid + appid + version + _token
  ).toString()
  config.headers['appId'] = appid
  config.headers['v'] = version
  // domainName这个签名maya小程序那边支付的时候用到，但是这个签名会影响网关的图片上传接口
  if (config.domainName !== false) {
    config.headers['domainName'] = window.location.hostname
  }

  /**
   * ANDROID,IOS,MINIAPP,H5,PC
   */
  platform && (config.headers['platformFlag'] = platform)
  // packageHeader && (config.headers['package'] = packageHeader)

  const siteInfoStore = useSiteInfoStore()
  config.headers['deviceId'] = siteInfoStore.value.clientIp
    ? getUserOnlyId(siteInfoStore.value.clientIp)
    : getUserOnlyId('0.0.0.0')

  return config
}
