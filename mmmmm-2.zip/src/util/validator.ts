export const vMobilePhone = (value: string = '') => {
  value = value || ''
  const isValid = value.startsWith('09') && value.length == 11
  if (!value || !isValid) {
    return 'Please enter the correct mobile'
  } else {
    return true
  }
}

export const vRequired = (errorMessage: string) => {
  return function (value: string) {
    if (!!value) {
      return true
    } else {
      return errorMessage
    }
  }
}

export const vConfirmPassword = (password: string, errorMessage: string) => {
  return function (value: string) {
    if (!!value && password == value) {
      return true
    } else {
      return errorMessage
    }
  }
}
export function mobileFormatter(value: string = '') {
  return value
    .replace(/^[1-8]/, '')
    .replace(/^0[1-8]/, '0')
    .replace(/^9/, '09')
    .substring(0, 11)
}

/**
 * 密码强制去除特殊字符
 * @param value
 * @returns
 */

export function passwordFormatter(value: string = '', max = 16) {
  return value.replace(/\s/g, '').substring(0, max)
}

// 名字字母 空格
export function nameFormatter(value: string = '', max = 20) {
  return value.replace(/[^a-zA-Z\s]/g, '').substring(0, max)
}

// 校验银行卡号  8-20
export const validBankNo = (errorMessage = 'Bank account number must be 8-20 numbers') => {
  return function (value: string) {
    if (!!/^\d{8,20}$/.test(value)) {
      return true
    } else {
      return errorMessage
    }
  }
}
