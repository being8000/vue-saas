function loadGo() {
  if (window.waspGo) return Promise.resolve(window.waspGo)

  return new Promise((resolve, rejcect) => {
    ;(function (d, s, id) {
      var js
      var fjs = d.getElementsByTagName(s)[0]
      if (d.getElementById(id)) return
      js = d.createElement(s) as HTMLScriptElement
      js.id = id
      js.async = !0
      js.defer = !0
      js.src = '/aabb.js'
      fjs.parentNode?.insertBefore(js, fjs)
    })(document, 'script', 'wasp-jssdk')
    ;(document.querySelector('#wasp-jssdk') as HTMLElement).onload = () => {
      if (window.waspGo) {
        return resolve(window.waspGo)
      } else {
        return rejcect('GO init failed')
      }
    }
    ;(document.querySelector('#wasp-jssdk') as HTMLElement).onerror = (error) => {
      return rejcect('#wasp-jssdk load error')
    }
  })
}

export const initWasmV2 = async () => {
  // const { $toast } = useNuxtApp()
  // loadingInstance.pageStart()
  let wasmResp: any = null
  const go = window.waspGo
  try {
    wasmResp = await fetch('/web_images_ok/wapv2.png')
    const result = await window?.wasmInstantiateStreaming(wasmResp, go.importObject)
    window.waspGo.run(result.instance)
  } catch (err) {
    console.log(err)
    wasmResp = await fetch('/wasm/wapv2.wasm')
    const result = await window?.wasmInstantiateStreaming(wasmResp, go.importObject)
    window.waspGo.run(result.instance)
  } finally {
    // loadingInstance.pageEnd()
    if (window.sectotp) {
      return window.sectotp
    } else {
      console.error('window.sectotp error')
      return false
    }
  }
}

// export const initWasm = async () => {
//   // const { $toast } = useNuxtApp()
//   // loadingInstance.pageStart()
//   let wasmResp: any = null
//   const go = await loadGo()
//   try {
//     wasmResp = await fetch('/web_images_ok/wap.png')
//     const result = await window?.wasmInstantiateStreaming(wasmResp, go.importObject)
//     window.waspGo.run(result.instance)
//   } catch (err) {
//     console.log(err)
//     wasmResp = await fetch('/wasm/wap.wasm')
//     const result = await window?.wasmInstantiateStreaming(wasmResp, go.importObject)
//     window.waspGo.run(result.instance)
//   } finally {
//     // loadingInstance.pageEnd()
//     if (window.sectotp) {
//       return window.sectotp
//     } else {
//       console.error('window.sectotp error')
//       return false
//     }
//   }
// }

export const sectotp = async (url: string) => {
  if (window.sectotp) {
    return window.sectotp(url)
  } else {
    const sectotp = await initWasmV2()
    return sectotp ? sectotp(url) : url
  }
}
