<template>
  <div class="grid grid-rows-2 grid-flow-col gap-1">
    <button @click="onClikAF">获取af数据</button>
    <button @click="onJIami">加密手机号</button>
    <v-btn color="primary" @click="onTest"> Test </v-btn>
    <v-btn color="primary" @click="getCurrentClient"> 当前appClient </v-btn>
    <v-btn color="primary" @click="nativeGoogleAuth"> googleAuth: H5获取原生google授权信息 </v-btn>
    <v-btn color="primary" @click="nativeCustomerService">
      customerService: H5通过原生打开客服信息
    </v-btn>
    <v-btn color="primary" @click="onLoginSuccess">onLoginSuccess: 通知原生登入成功 </v-btn>
    <v-btn color="primary" @click="onLogout">onLogout: 通知原生用户登出 </v-btn>
    <v-btn color="primary" @click="onUserAgent">查看当前onUserAgent </v-btn>
    <div>
      <v-text-field
        v-model="linkUrl"
        variant="solo"
        baseColor="on-background"
        placeholder="外部浏览器打开网址"
        :clearable="false"
        class="tw-my-1"
      >
        <template #append-inner="{}">
          <v-btn color="primary" size="small" style="font-weight: 400" @click="toExternalWebview"
            >跳转</v-btn
          >
        </template>
      </v-text-field>
    </div>
    <div class="tw-px-2 tw-my-1">
      <v-text-field
        v-model="webview.title"
        variant="solo"
        baseColor="on-background"
        placeholder="webview标题"
        :clearable="false"
      ></v-text-field>
      <v-text-field
        v-model="webview.url"
        variant="solo"
        baseColor="on-background"
        placeholder="请输入webview地址"
        :clearable="false"
      >
        <template #append-inner="{}">
          <v-btn color="primary" size="small" style="font-weight: 400" @click="openWebview"
            >Open Webview</v-btn
          >
        </template>
      </v-text-field>
    </div>
    <v-btn color="primary" @click="sendMessage"> SendMessage模拟 </v-btn>
    <v-btn color="primary" @click="exitApp"> exitApp：关闭APP </v-btn>
    <v-btn color="primary" @click="onShare"> onShare：分享链接 </v-btn>
    <v-btn color="primary" @click="onShare"> onShare：分享链接 </v-btn>
  </div>
</template>

<script setup lang="ts">

const exitApp = () => {
  // $gz.exitApp()
}
const onShare = () => {
  // $gz.onShare({
  //   link: window.location.href,
  // })
}

const onUserAgent = () => {
  const { userAgent} = useDevice()
  alert(userAgent)
}
// const encrypt = () => {
//   rsaEncrypt('qwer1234')
// }
const onTest = async () => {
  const res = await window.$gz.call({
    method: 'test',
  })
  console.log('res', res)
  alert(JSON.stringify(res))
}

const onClikAF = async ()=>{
  // const res = await $afTrack.getAppAfParams()
  // console.log(res)
}
const onJIami = async ()=>{
  // const res = await $gz.encrypt('9000000000');
  // console.log(res)
}

const getCurrentClient = () => {
  const { getClient } = useAppClientVar()
  alert(getClient())
}

const nativeGoogleAuth = async () => {
  const res = await window.$gz.call({
    method: 'googleAuth',
  })
  alert(JSON.stringify(res))
}

const nativeCustomerService = async () => {
  const res = await window.$gz.call({
    method: 'customerService',
  })
  alert(JSON.stringify(res))
}
const linkUrl = ref('')
const toExternalWebview = async () => {
  console.log(linkUrl.value)
  const res = await window.$gz.call({
    method: 'toExternal',
    data: {
      url: linkUrl.value,
    },
  })
}

const sendMessage = () => {
  // const data: Bridge.SendMessageParams = {
  //   method: 'fetchLoginUser',
  // }
  // window.$gz.sendMessage(base64Encode(JSON.stringify(data)))
}

const onLoginSuccess = async () => {
  const res = await window.$gz.call({
    method: 'onLoginSuccess',
  })
  alert(JSON.stringify(res))
}
const onLogout = async () => {
  const res = await window.$gz.call({
    method: 'onLogout',
  })
  alert(JSON.stringify(res))
}
const encryptText = ref('')
const onEncrypt = async () => {
  // const res = await $gz.encrypt(encryptText.value)
  // alert(JSON.stringify(res))
}
const webview = ref({
  url: '',
  title: ''
})
const openWebview = async () => {
  // const res = await $gz.openWebview(webview.value.url, {
  //   title: webview.value.title,
  //   from: 'deposit'
  // })
  // alert(JSON.stringify(res))
}
</script>

<style></style>
