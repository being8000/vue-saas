<template>
  <div>
    {{ value }}
    <VResponsive :aspectRatio="366 / 140">
      <VideoPlayer
        :options="{
          autoplay: 'muted',
          controls: false,
          playsinline: true,
          fluid: true,
          loop: true,
          sources: [
            {
              type: 'video/mp4',
              src: '/video/livestream-entrance.mp4?v3',
            },
          ],
          fit: 'cover',
        }"
      />
    </VResponsive>
    <VBtn @click="toLogin">Sign In</VBtn>
    <VBtn @click="showSelect">showSelect</VBtn>
    <VBtn @click="showDatePicker">showDate</VBtn>
    <VBtn @click="showToast">toast</VBtn>
    <VBtn @click="showDialog">showDialog</VBtn>
    <VBtn @click="testEventBus.emit('hehehe', { a: 1 })">testEventBus</VBtn>
    <!-- <SelectorDate></SelectorDate> -->
    <div class="custom-gradient"></div>
    <div class="tw-border tw-p-1">
      tailwindcss
      <div class="tw-bg-red-100 tw-w-5 tw-h-5"></div>
    </div>
    <div class="tw-border tw-p-1 tw-flex tw-flex-col tw-gap-2">
      <p>VBtn</p>
      <VBtn color="primary" @click="captcha = !captcha">Sign up / Sign in</VBtn>
      <VBtn color="primary" :disabled="true">Sign up / Sign in</VBtn>
      <VBtn color="primary" size="large">Sign up / Sign in</VBtn>
      <VBtn color="primary" size="x-large">Sign up / Sign in3</VBtn>
      <VBtn color="secondary" width="6rem">59s</VBtn>
      <VBtn color="surface-light-4">Cancel</VBtn>
      <VBtn color="surface-light-4 on-surface" :disabled="true">Sign up / Sign in</VBtn>
    </div>
    <div class="tw-border tw-p-1 tw-flex tw-flex-col tw-gap-2">
      <p>VInputField</p>
      <VTextField
        :clearable="false"
        clearIcon="custom-close-circle"
        prependInnerIcon="custom-phone"
        variant="solo"
        baseColor="on-background"
        placeholder="Phone"
      ></VTextField>
      <VTextField
        :clearable="false"
        :type="showPwd ? 'text' : 'password'"
        clearIcon="custom-close-circle"
        prependInnerIcon="custom-pwd"
        :appendInnerIcon="showPwd ? 'custom-eye-open' : 'custom-eye-close'"
        variant="solo"
        baseColor="on-background"
        placeholder="Password"
        @click:appendInner="showPwd = !showPwd"
      ></VTextField>
    </div>
    <div class="tw-border tw-p-1 tw-flex tw-flex-col tw-gap-2">
      <p>图标</p>
      <div class="tw-flex tw-items-center tw-gap-2">
        <span>自定义svg图标</span>
        <VIcon icon="custom-check" />
      </div>
      <VDatePicker />
    </div>
  </div>
</template>

<script lang="ts" setup>
import VideoPlayer from '@/components/global/App/VideoPlayer.vue'
import { $datePicker } from '~/util/component/date-picker'
import { $selector } from '~/util/component/selector'
import { getYearsAgo } from '~/util'

const showPwd = ref(false)
///end
const testEventBus = useEventBus('test-test-test')

testEventBus.on((listenEvent, data) => {
  console.log('on', listenEvent, data)
})
testEventBus.once((listenEvent, data) => {
  console.log('once', listenEvent, data)
})
// import { ErrorCode } from '~/types/error-code'
const siteInfoStore = useSiteInfoStore()
// $api('/_glaxy_c66_/webToken', {
//   retry: 0,
//   method: 'POST',
//   loading: true,
//   jahahahahahLL: 'zzzz',
//   body: {
//     b: 'b',
//   },
// })

const toLogin = () => {
  // const { toHashComponent } = useHashComponent()
  // toHashComponent('terms')
}
const { $toast } = useNuxtApp()
const router = useRouter()
const showToast = () => {
  $toast(
    'failed to obtain the game URLfailed to obtain the game URLfailed to obtain the game URLfailed to obtain the game URL',
    {
      autoClose: false,
    }
  )
}
const value = ref()
const showDatePicker = () => {
  $datePicker.setOptions(
    {
      modelValue: value,
      defaultValue: getYearsAgo(),
    },
    {
      allowedDates: (date: any) => {
        return isOverAge(date)
      },
    }
  )
}

const dialogVisible = ref(false)
const showDialog = async () => {
  const res = await $dialog.pop({
    title: '你好',
    cancelButtonText: 'asd',
    content:
      'Dear GCash user, according to PAGCOR regulation, only 21yrs+ customer can enter GameZone!',
    // slots: {
    //   default: () => h('div', '手动阀打发撒旦'),
    // },
  })
  if (res) {
  }
}
const showSelect = () => {
  $selector.setOptions({
    options: [
      {
        label: 'zzzzz1',
        value: '1',
      },
      {
        label: 'zzzzz2',
        value: '2',
      },
      {
        label:
          'zzzzz3zzzzz3zzzzz3zzzzz3zzzzz3zzzzz3zzzzz3zzzzz3zzzzz3zzzzz3zzzzz3zzzzz3zzzzz3zzzzz3zzzzz3zzzzz3',
        value: '3',
      },
      {
        label: 'zzzzz4',
        value: '4',
      },
    ],
    autoClose: true,
    title: 'zzz',
    onChange(val) {
      console.log(val)
    },
  })
}
// const googleLogin = async (ticket: string) => {
//   const googleInfo = await getGoogleInfo()
//   thirdPartyLogin(ticket, googleInfo)
// }
</script>

<style>
.custom-gradient {
  width: 100vw;
  height: 150px;
  background: radial-gradient(
    50% 50% at 50% 50%,
    rgba(255, 101, 51, 0.3) 0%,
    rgba(172, 70, 36, 0.3) 30%,
    rgba(255, 101, 51, 0) 100%
  );
}
</style>
