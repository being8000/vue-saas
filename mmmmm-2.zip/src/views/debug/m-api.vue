<template>
  <div>
    <button class="tw-w-full" @click="fetchAPI('fetchWebtoken')">获取webtoken fetchWebtoken</button>
    <button class="tw-w-full" @click="fetchAPI('fetchUserDetails')">获取用户详情 fetchUserDetails</button>
    <button class="tw-w-full" @click="fetchAPI('fetchAppInfo')">获取APP父站信息 fetchAppInfo</button>
    <button class="tw-w-full" @click="fetchAPI('navigateToLogin')">打开登录页 </button>
    <button class="tw-w-full" @click="fetchAPI('navigateToEKYC')">打开EKYC页面 </button>
    <button class="tw-w-full" @click="navigateToGame">跳转游戏</button>
    <button class="tw-w-full" @click="fetchAPI('fetchEKYCFlag')">获取EKYC fetchEKYCFlag</button>
    <button class="tw-w-full" @click="fetchAPI('toCustomerService')">打开客服 toCustomerService</button>
    <div>
      该页面默认回自动注册监听父站的emitIframeEvent事件，只要触发了就会有对应的弹框
    </div>
  </div>
</template>

<script setup lang="ts">
import { emitIframeEvent, postMessage, hooks } from '@gameplus/messenger'
const fetchAPI = async (method: string) => {
  const res = await postMessage({
    method: method
  })
  alert(JSON.stringify(res))
}

const navigateToGame = () => {
  postMessage({
    method: 'navigateToGame',
    payload: {
      videoId: '',
      jumpParam: '{}',
      gameType: '3',
      gdGameId: '4',
      platformId: '175',
      gameId: 'tongits',
      gameName: 'Tongits Go',
    },
  })
}


hooks.hook('onLogin', () => {
  console.log('poker onLogin')
  fetchUserDetails()
  alert('onLogin')
  return {}
})
hooks.hook('onLogout', () => {
  console.log('poker onLogout')
  const userDetailStore = useUserDetailStore()
  const userStore = useUserStore()
  userDetailStore.value = {}
  userStore.value = {
    isLogin: false,
  }
  alert('onLogout')
  return {}
})
</script>

<style lang="scss">
button {
  background-color: rgb(173, 198, 207);
  margin-bottom: 1px;
  padding: 4px 0px;
  font-size: 14px;
}
</style>
