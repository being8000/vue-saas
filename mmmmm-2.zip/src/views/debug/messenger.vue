<template>
  <div class="tw-h-screen tw-overflow-hidden tw-relative">
    <VTextField
      v-model="url"
      required
      :clearable="false"
      clearIcon="custom-close-circle"
      variant="outlined"
      baseColor="on-background"
      class="clear-fillcolor"
      placeholder="Please input"
    >
    </VTextField>
    <button @click="onClick" style="border: 1px solid; border-radius: 5px;padding: 3px;">fetchDataFromIframe</button>
    <iframe
      ref="iframeEl"
      class="tw-w-full tw-size-full scrollbar-width-none tw-object-scale-down"
      :src="url"
      frameborder="0"
      allowfullscreen="allowfullscreen"
      allow="fullscreen"
    />
  </div>
</template>

<script setup lang="ts">
import { errorRes, emitIframeEvent, registerMessage, startIframeMessageListening, successRes } from '@gameplus/messenger'

const url = ref('http://127.0.0.1:5500/packages/messenger/gamezone.html')
const iframeEl = ref()
const onClick = async () => {
  const res1 = await emitIframeEvent('fetchDataFromIframe', { count: 0 })
  alert(JSON.stringify(res1))
  // notifyIframeMessage('updateValentineInfo1', { a: 222 })
}
registerMessage('helloWorld', (data: any) => {
  console.log('helloWorld', data)
  return successRes({
    a: 'helloWorld'
  })
})
registerMessage('helloWorld2', (data: any) => {
  console.log('helloWorld', data)
  return errorRes({
    a: 'helloWorld'
  }, 300, 'test')
})
onMounted(() => {
  startIframeMessageListening({
    iframeEL: iframeEl.value,
  })
})
</script>
