<template>
  <div class="tw-w-full tw-h-screen tw-flex tw-items-center tw-justify-center tw-flex-col">
    <ErrorSvg />
    <div class="tw-text-on-surface-light-1 tw-text-sm tw-my-1">
      {{ $route.path }}
    </div>
    <div class="tw-text-sm tw-my-1">404 Page Not Found</div>
    <v-btn color="primary" :to="'/'" replace class="tw-mt-5">Go to Home Page</v-btn>
  </div>
</template>

<script setup lang="ts">
import ErrorSvg from '@images/svg/error.svg'
import {toCustomerService} from '@/util/component/customer-service'
</script>

<style></style>
