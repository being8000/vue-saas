<template>
  <div class="tw-w-full tw-h-screen tw-flex tw-items-center tw-justify-center tw-flex-col">
    <ErrorSvg />
    <div class="tw-text-on-surface tw-text-sm tw-my-1">
      {{ $route.query.code }}
    </div>
    <div class="tw-text-base tw-my-1 tw-px-5" v-if="$route.query.message">{{ $route.query.message }}</div>
    <v-btn v-else color="primary" class="tw-mt-5" @click="toCustomerService('')"
      >Customer Service</v-btn
    >
  </div>
</template>

<script setup lang="ts">
import ErrorSvg from '@images/svg/error.svg'
import {toCustomerService} from '@/util/component/customer-service'
</script>

<style></style>
