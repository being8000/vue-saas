<script setup lang="ts">
let appInfo = ref()
const onClikAF = async ()=>{
  console.log(appInfo.value)
}
let data = ref()
const onJIami = async ()=>{
  console.log(data.value)
}

let isAndroid = ref(false)
const onCheckAndroid = async ()=>{
  const { isGamezoneAndroid } = useAppClientVar()
  console.log(isGamezoneAndroid())
  isAndroid.value = isGamezoneAndroid()
}

</script>
<template>
  <button @click="onClikAF">获取af数据</button>
  {{ appInfo }}
  <button @click="onJIami">加密手机号</button>
  {{ data }}
  <button @click="onCheckAndroid">是否是安卓</button>
  {{ isAndroid }}
</template>