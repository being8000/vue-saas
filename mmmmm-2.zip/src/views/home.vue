<template>
  <!-- 顶部marquee -->
  <TopTongitsMarqeen />
  <!-- 顶部tongits游戏 -->
  <TopTongitsCardBox />
  <LazyCardTournamentList></LazyCardTournamentList>
  <!-- hotgame区块 -->
  <!-- <PokerHotGames /> -->
  <!-- <leaderboard /> -->
  <HomeChannelCategory />
</template>

<script setup lang="ts">
import TopTongitsMarqeen from '@/components/home/TopTongitsBox/marqueen.vue'
import TopTongitsCardBox from '@/components/home/TopTongitsBox/TopTongitsCard.vue'
import PokerHotGames from '@/components/home/PokerHotGames.vue'
import LazyCardTournamentList from '@/components/home/TournamentList.vue'
// import leaderboard from '@/components/home/leaderboard.vue'
// getUserInfo().then((el) => {
//   console.log(el)
// })
</script>

<style>
::-webkit-scrollbar {
  width: 5px;
  height: 5px;
  background-color: transparent;
}
</style>
