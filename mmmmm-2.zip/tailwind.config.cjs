
import { themes } from './src/plugins/vuetify/theme'
/** @type {import('tailwindcss').Config} */
export default {
  prefix: "tw-",
  darkMode: "class",
  content: [
    "./index.html",
    "./src/**/*.{vue,js,ts,jsx,tsx,svg}",
  ],
  theme: {
    fontFamily: {
      payone: 'PAY ONE, Open Sans, -apple-system, Framedcn, Helvetica Neue, Condensed, DisplayRegular, Helvetica, Arial, PingFang SC, Hiragino Sans GB, WenQuanYi Micro Hei, Microsoft Yahei, sans-serif',
      impact: 'impact, Open Sans, -apple-system, Framedcn, Helvetica Neue, Condensed, DisplayRegular, Helvetica, Arial, PingFang SC, Hiragino Sans GB, WenQuanYi Micro Hei, Microsoft Yahei, sans-serif',
      arial: 'ARIAL, Open Sans, -apple-system, Framedcn, Helvetica Neue, Condensed, DisplayRegular, Helvetica, Arial, PingFang SC, Hiragino Sans GB, WenQuanYi Micro Hei, Microsoft Yahei, sans-serif',
      inter: 'INTER,ARIAL, Open Sans, -apple-system, Framedcn, Helvetica Neue, Condensed, DisplayRegular, Helvetica, Arial, PingFang SC, Hiragino Sans GB, WenQuanYi Micro Hei, Microsoft Yahei, sans-serif',
      tr: "TR IMPACT, Open Sans, -apple-system, Framedcn, Helvetica Neue, Condensed, DisplayRegular, Helvetica, Arial, PingFang SC, Hiragino Sans GB, WenQuanYi Micro Hei, Microsoft Yahei, sans-serif",
      'din': 'DIN, Open Sans, -apple-system, Framedcn, Helvetica Neue, Condensed, DisplayRegular, Helvetica, Arial, PingFang SC, Hiragino Sans GB, WenQuanYi Micro Hei, Microsoft Yahei, sans-serif',
    },
    extend: {
      colors: themes.light.colors,
      animation: {
        "loading2-1": "loading2-1 .6s infinite",
        "loading2-2": "loading2-2 .6s infinite",
        "loading2-3": "loading2-3 .6s infinite",
        fadeInUp: "fadeInUp .5s both",
      },
      keyframes: {
        "loading2-1": {
          "0%": { transform: "scale(.4) translate(28.57%)", opacity: "0.3" },
          "100%": { transform: "scale(1) translate(0)", opacity: "1" },
        },
        "loading2-2": {
          "0%": { transform: "translate(0)" },
          "100%": { transform: "translate(28.57%)" },
        },
        "loading2-3": {
          "0%": { transform: "scale(1) translate(0)", opacity: "1" },
          "100%": { transform: "scale(.4) translate(-28.57%)", opacity: "0.3" },
        },
        fadeInUp: {
          "0%": { transform: "translate3d(0, 30px, 0)", opacity: "0" },
          "100%": { transform: "translate3d(0, 0, 0)", opacity: "1" },
        },
      },
    },
  },
  plugins: [],
}