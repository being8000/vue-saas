import "axios";
export enum AlertType {
  None = "None",
  Toast = "Toast",
  Confirm = "Confirm",
}
declare module "axios" {
  export interface AxiosRequestConfig {
    showLoading?: boolean; // 是否全局加载loading, 默认为 false
    signature?: boolean; // 设置是否请求需要带上签名, 默认为true
    encrypt?: boolean; // 设置是否对默认数据加密, 默认为true
    withGlobal?: boolean; // 是否带上全局数据, 默认为true
    needCustomerName?: boolean; // 是否需要customerName参数（等于loginName）, 默认为false
    original?: boolean; // 不经过拦截器直接放回response.data, 默认为 false
    skipCheck?: boolean; // 不经过拦截器直接放回 { body } = response.data, 中的Body, 默认为 false
    alertType?: AlertType; // 是否需要全局提示错误信息, 默认为 Toast 类型
    formData?: boolean; // 默认false, 是否为表单提交
    auth?: boolean; // 默认false , 检查当前环境是否已经登入，如果没有会弹出登录页面
    blobToJson?: boolean; // 默认false, 将返回的blob转成json并输出
    showToast?: boolean; // 默认true, 默认如果接口返回错误码 toast提示
    successTip?: string; // 接口成功后示文案 默认Successed
    symbol?: Symbol;
    domainName?: boolean; // 是否设置 header domainName 默认true, 传图的时候需要去掉，否则接口会报错
  }

  export interface AxiosResponse {
    config: AxiosRequestConfig;
  }
}
