import type { Bridge } from "~/plugins/bridge/gp-bridge";
import { CoraSDK } from "../plugins/coraool/cora";
export declare global {
  interface Window {
    google?: any;
    $zoho: {
      salesiq: any;
      ready: boolean;
    };
    wasmInstantiateStreaming: typeof WebAssembly.instantiateStreaming;
    wasmInstantiate: typeof WebAssembly.instantiate;
    sectotp: Function;
    waspGo: any;
    _dx: any;
    fbq: Function;
    twq: Function;
    CORA_SDK: CoraSDK;
    History: any;
    webkit: any;
    handler: any;
    $gz: Bridge.Instance;
    eruda: {
      init: () => void;
    };
    cookieStore: CookieStore;
  }

  type BaseResponseType<T = any> = {
    head: {
      errCode: string;
      errMsg: string;
    };
    body: T;
    success: boolean;
  };

  type PaginationServerResponse<T> = {
    pageNo: number;
    pageSize: number;
    totalPage: number;
    totalPage: number;
    data: T[];
  };

  type PaginationResponse<T> = BaseResponseType<{
    pageNo: number;
    pageSize: number;
    totalPage: number;
    totalPage: number;
    data: T[];
  }>;
  // 系统登录用户响应体
  interface AppUser {
    loginName?: string; // 用户名
    customerId?: string; // 用户ID
    palcode?: string; // 用户ID
    isFrom?: string; // 用户ID
    isLogin?: boolean;
    createdDate?: string; // 注册时间
    credit?: string;
    currency?: string;
    customerType?: string;
    face?: string;
    flag?: string;
    fromType?: string;
    gameCredit?: string;
    gameKey?: string;
    gameLimit?: string;
    login?: string;
    mobileNo?: string;
    newAccountFlag?: string;
    noLoginDays?: string;
    onlineBet?: string;
    parentId?: string;
    phone?: string;
    productId?: string;
    registerMethod?: string;
    siteId?: string;
    starLevel?: string;
    toType?: string;
    verifyLoginIp?: string;
    isShowgfStatus?: any;
    balance?: number;
  }

  // getById 接口响应体，用户个人信息显示，KYC等其他
  interface AppUserDetail {
    needFaceCapture: boolean; //绑卡取款是否开启人脸识别
    activation: boolean;
    agentFlag: boolean;
    birthday: string; // Brithday
    blackFlag: number;
    cashCredit: number;
    city: string;
    customerId: string; // 用户ID
    nickName?: string; // 用户nickname
    customerLevel: number;
    customerType: number;
    firstDepositFlag: boolean; // false 没有首存过 / true 首存过
    firstIdStatus: string; // 判断kyc是否完成 0 Review 1 Approved 2/3 Failed
    firstName: string; // First Name
    gameCredit: number;
    gender: string;
    glife: boolean;
    headShot: string;
    isBlackList: number; // 是否是黑名单，如果是黑名单不让进入游戏，提示 Maintenance in progress
    isLazada: boolean;
    lastLoginDate: string;
    lastName: string; // Last Name
    loginName: string;
    middleName: string;
    loginNameFlag: number;
    loginPwdFlag: boolean;
    marginSwitch: boolean;
    mayaFlag: boolean;
    mobileNo: string;
    nationality: string; // Nationality
    newWalletFlag: number;
    oddsType: number;
    onlineBet: boolean;
    personalInfoTag: boolean;
    product: number;
    registDate: string;
    registerMethod: string;
    silentPhotoSwitch: boolean;
    vipLevel: number;
    whiteListUser: boolean;
    withdrewPwd: boolean;
    permanentAddress: string;
    work: string;
    employerName: string;
    sourceOfIncome: string;
    birthPlace: string;
    presentAddress: string;

    bindFacebook: {
      accessToken: string;
      bindStatus: string;
      bindType: string;
      createdBy: string;
      createdDate: string;
      id: string;
      infoPhone: string;
      lastUpdate: string;
      lastUpdatedBy: string;
      loginName: string;
      nickName: string;
      productId: string;
      unionId: string;
    };

    bindGoogle: {
      accessToken: string;
      bindStatus: string;
      bindType: string;
      createdBy: string;
      createdDate: string;
      id: string;
      infoPhone: string;
      lastUpdate: string;
      lastUpdatedBy: string;
      loginName: string;
      nickName: string;
      productId: string;
      unionId: string;
    };
    ekycStatus: number;// -1待提交,0待审核，1通过，2自动拒绝，3手动拒绝,4待查询zoloz结果
    canKycTime: number;
    oldKycStatus: number;
    rejectReason: string;
    refuseInitFlag: boolean;
    phoneModifyFlag: boolean; // 是否可以修改手机号
    requireEkyc: boolean; //只有开启认证Ekyc的情况才返回该字段，如果返回true，代表需要做ekyc认证 
    isPopupWindow: boolean; //只有开启认证Ekyc的情况才返回该字段，true:强弹窗   false:弱弹窗
  }

  /**
   * 完整注册请求体
   */
  interface FullyRegisterUserVo {
    /** 手持证件照片 */
    faceId: string;
    /** 证件类型 */
    firstIdType: string;
    /** 证件号码 */
    firstIdNo?: string;
    /** 证件照片 */
    firstIdScan: string;
    activate: number;
    reserve3?: string;
    firstName: string;
    middleName: string;
    lastName: string;
    birthday: string;
    customerName?: string;
    password?: string;
    phone: string;
    smsCode: string;
    /** 当前居住地 */
    address: string;
    nationality: string;
    sourceOfIncome: string;
    occupation: string; // Work
    /** Employer Name 雇主名字 */
    reserve2: string;
    /** 出生地 */
    province: string;
    /** 永久居住地 */
    reserve4: string;
    /** 推荐人 */
    reference: string;
    /** 性别 */
    gender: string;
  }
}
