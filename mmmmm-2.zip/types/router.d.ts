// This can be directly added to any of your `.ts` files like `router.ts`
// It can also be added to a `.d.ts` file. Make sure it's included in
// project's tsconfig.json "files"
import { CoraPageEnum } from '@/plugins/coraool/cora'
import 'vue-router'

// To ensure it is treated as a module, add at least one `export` statement
export {}
declare module 'vue-router' {
  interface RouteMeta {
    sideBanner?: boolean
    skipGlobalMiddleware?: boolean // 存静态页面，跳过全局中间件
    title?: string // 页面标题
  }
}
