import { DF } from '@/util/helper'
import router from '@/router'
import i18n from '@/i18n'
declare module '@vue/runtime-core' {
  interface ComponentCustomProperties {
    DF: typeof DF
    $router: typeof router
    $route: typeof router.currentRoute.value
    $n: typeof i18n.global.n
    $d: typeof i18n.global.d
    vRequired: typeof vRequired
    vMobilePhone: typeof vMobilePhone
    subString: typeof subString
    mobileFormatter: typeof mobileFormatter
  }
}

export {} // Important! See note.
