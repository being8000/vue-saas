import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import AutoImport from 'unplugin-auto-import/vite'
import Components from 'unplugin-vue-components/vite'
import type { ManualChunkMeta, ModuleInfo } from 'rollup'
import path from 'path'
import IconsResolver from 'unplugin-icons/resolver'
import { createSvgIconsPlugin } from 'vite-plugin-svg-icons'
import LodashImports from 'lodash-imports'
import { fileURLToPath } from 'url'
import vuetify from 'vite-plugin-vuetify'
import svgLoader from 'vite-svg-loader'
import { VuetifyResolver } from 'unplugin-vue-components/resolvers'
// UAT域名
const proxyUrl = 'https://bppoker.uatext66gp.com'
// const proxyUrl = 'http://c66-frontend-gameplus-gamezone.dgfat.com'
// https://vitejs.dev/config/
export default defineConfig({
  css: {
    preprocessorOptions: {
      // SCSS 的编译 API 防止出现错误语法提示
      scss: {
        api: 'modern-compiler', // or "modern"
      },
    },
  },
  plugins: [
    vue(),
    vuetify({
      styles: {
        configFile: 'src/assets/styles/variables/_vuetify.scss',
      },
    }),
    svgLoader({
      svgoConfig: {
        multipass: true,
        plugins: [
          {
            name: 'preset-default',
            params: {
              overrides: {
                // viewBox is required to resize SVGs with CSS.
                // @see https://github.com/svg/svgo/issues/1128
                removeViewBox: false,
                cleanupIds: false,
              },
            },
          },
        ],
      },
    }),
    AutoImport({
      resolvers: [
        IconsResolver({
          prefix: 'Icon',
        }),
      ],
      imports: [
        'vue',
        'vue-router',
        '@vueuse/core',
        LodashImports({
          prefix: '_',
          upperAfterPrefix: true,
        }),
      ],
      //配置后会自动扫描目录下的文件
      dirs: ['src/composables/**', 'src/util/**', 'src/api/**'],
      eslintrc: {
        enabled: true, // Default `false`
        filepath: './eslintrc/.eslintrc-auto-import.json', // Default `./.eslintrc-auto-import.json`
        globalsPropValue: true, // Default `true`, (true | false | 'readonly' | 'readable' | 'writable' | 'writeable')
      },
      dts: './types/auto-imports.d.ts',
    }),
    createSvgIconsPlugin({
      iconDirs: [path.resolve(process.cwd(), 'src/icons')],
      symbolId: 'icon-[dir]-[name]',
    }),
    Components({
      dirs: ['src/components', 'src/icons'],
      extensions: ['vue'],
      deep: true,
      dts: './types/components.d.ts',
      types: [],
      resolvers: [VuetifyResolver()],
      // 修复vite-plugin-components组件命名相同 内部读取文件名
      directoryAsNamespace: true,
    }),
  ],
  resolve: {
    alias: {
      '@': fileURLToPath(new URL('./src', import.meta.url)),
      '~': fileURLToPath(new URL('./src', import.meta.url)),
      '@images': fileURLToPath(new URL('./src/assets/images', import.meta.url)),
      '@styles': fileURLToPath(new URL('./src/assets/styles', import.meta.url)),
    },
  },
  build: {
    chunkSizeWarningLimit: 300,
    rollupOptions: {
      treeshake: 'recommended',
      output: {
        banner: '/** GameZone */',
        footer: '/** GameZone */',
        minifyInternalExports: true,
        noConflict: true,
        sourcemap: false,
        experimentalMinChunkSize: 10 * 1024,
        manualChunks(id: string, meta: ManualChunkMeta) {
          const svg = '/assets/images/svg/'
          if (id.includes(svg)) {
            // return 'gamezone_svg'
            return 'svg_' + id.split(svg)[1].split('.')[0].split('/').join('_')
          } else {
            // const dependencies = packages.dependencies
            // const packageNames = Object.keys(dependencies)
            const packageNames = [
              'vue3-lottie', // 314.38 kB │ gzip:  81.23 kB
              'video.js', // 244.68 kB │ gzip:  69.92 kB
              'vuetify', // 204.79 kB │ gzip:  64.84 kB
              '@sentry/vue', // 116.20 kB │ gzip:  40.16 kB
              'vue', // 默认
              'date-fns', // 85.67 kB │ gzip:  33.86 kB
              'jsencrypt', // 55.91 kB │ gzip:  17.34 kB
              'vue-i18n', // 默认
              'swiper',
              'file-saver',
              'vue-router', // 默认
              'fuse.js',
              'driver.js',
              'sockjs-client',
              'embla-carousel-vue',
              // '@vueuse/core',
            ]
            const isNpmModules = packageNames.find((name) => id.includes(`/node_modules/${name}/`))
            if (isNpmModules) {
              return `pkg_${isNpmModules.replace(/[.|\/]/g, '-')}`
            }
          }
        },
      },
    },
  },
  define: { 'process.env': {}, global: 'globalThis' },
  server: {
    host: '0.0.0.0',
    proxy: {
      '/_glaxy_c66_': {
        target: proxyUrl,
        changeOrigin: true,
        //  rewrite: (path) => path.replace(/^/, ''),
      },
      '/_activity_api_': {
        target: proxyUrl,
        changeOrigin: true,
        //  rewrite: (path) => path.replace(/^/, ''),
      },
      '/_front_api_': {
        target: proxyUrl,
        changeOrigin: true,
        //  rewrite: (path) => path.replace(/^/, ''),
      },
      '/staticJs': {
        target: proxyUrl,
        changeOrigin: true,
        //  rewrite: (path) => path.replace(/^/, ''),
      },
      '/externals': {
        target: proxyUrl,
        changeOrigin: true,
        //  rewrite: (path) => path.replace(/^/, ''),
      },
      '/web_images_ok': {
        target: proxyUrl,
        changeOrigin: true,
        //  rewrite: (path) => path.replace(/^/, ''),
      },
    },
    port: 8080,
  },
})
