package com.gz.main.platform;

public class Constants {

    public static class CallbackMethods {

        public static final String TEST = "test";
        public static final String error = "error";
        public static final String GOOGLE_AUTH = "googleAuth";
        public static final String CUSTOMER_SERVICE = "customerService";
        public static final String TO_EXTERNAL = "toExternal";
        public static final String TO_INTERNAL = "TO_INTERNAL";
        public static final String CORA_TRACK = "coraTrack";
        public static final String ON_LOGIN_SUCCESS = "onLoginSuccess";
        public static final String ON_LOGOUT = "onLogout";
        public static final String ON_MESSAGE = "onMessage";
        public static final String ENCRYPT = "encrypt";
        public static final String EXIT_APP = "exitApp";
        public static final String ON_SHARE = "onShare";
        public static final String APPS_FLYER = "appFlyer";
        public static final String AF = "af";
        public static final String AF_DATA = "afData";
        public static final String AF_UID = "afUID";
        public static final String GET_ENGAGE_LAB_RID = "getEngageLabRid";

        public static final String OPEN_WEBVIEW = "openWebview";
        public static final String GET_PACKAGE_NAME = "getPackageName";
        public static final String GET_APP_INFO = "getAppInfo";
        public static final String GET_GAID = "getGAID";
    }

    public static class SendMessageMethods {

        public static final String FETCH_USER_DETAIL = "fetchUserDetail";

        public static final String FETCH_LOGIN_USER = "fetchLoginUser";

    }

    public static class Environment {
        /**
         * UAT环境
         */
        public static final String GameZone_UAT = "UAT";
        /**
         * 开发环境
         */
        public static final String GameZone_DEV = "DEV";
        /**
         * 正式环境
         */
        public static final String GameZone_PRO = "PRO";

    }

    public static enum HttpErrorType {
        FORBIDDEN,
        NETWORK_ERROR,
    }

    public static class ResultCode {

        public static final int WEBVIEW_RESULT = 8888;

    }
}
