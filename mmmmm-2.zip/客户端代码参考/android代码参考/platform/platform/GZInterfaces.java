package com.gz.main.platform;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.MutableContextWrapper;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
 import android.text.TextUtils;
import android.util.Log;
import android.widget.Toast;

import com.alibaba.fastjson.JSONObject;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.gz.main.GZWebActivity;
import com.gz.main.R;
import com.gz.main.platform.model.AppUser;
import com.gz.main.platform.model.AppUserDetail;
import com.gz.main.platform.model.BindFacebookModel;
import com.gz.main.platform.model.BindGoogleModel;
import com.gz.main.platform.model.EmptyModel;
import com.gz.main.platform.model.GoogleAuthModel;
import com.gz.main.platform.model.MethodModel;
import com.gz.main.platform.model.ResponseModel;
import com.gz.main.sdk.appsflyer.AppsFlyer;
import com.gz.main.sdk.google.GoogleAdvertisingId;
import com.gz.main.sdk.google.GoogleAuth;
import com.gz.main.sdk.google.GoogleLoginCallback;
import com.gz.main.sdk.push.EngageLabPush;
import com.gz.main.sdk.zoho.Zoho;
import com.gz.main.utils.AppUtils;
import com.gz.main.utils.LogUtils;
import com.gz.main.utils.RSAUtils;
import com.gz.main.utils.ShareUtils;

import java.nio.charset.StandardCharsets;
import java.util.Base64;

public class GZInterfaces {

    private String mGoogleAccountInfo = "";

    enum ScriptType {
        CALLBACK,
        SEND_MESSAGE,
    }

    private static final String TAG = GZInterfaces.class.getName();

    private static final String SHARED_PREFERENCES_KEY = "GZ-8k5qpqs1dd";
    private MutableContextWrapper mContext = null;

    private GZView mGZView = null;

    public GZInterfaces(MutableContextWrapper context, GZView gzView) {
        this.mContext = context;
        this.mGZView = gzView;
    }

    public void setContext(MutableContextWrapper context) {
        this.mContext = context;
    }

    public void h5Call(String params) {
        if (TextUtils.isEmpty(params)) {
            LogUtils.w(TAG,"h5Call", "参数params为空");
            return ;
        }

        JSONObject jsonObject = JSONObject.parseObject(params);
        String methodName = jsonObject.getString("method");
        String messageId = jsonObject.getString("messageId");
        String fromMethod = jsonObject.getString("fromMethod");
        JSONObject data = jsonObject.getJSONObject("data");

        LogUtils.d(TAG, "methodName: " + methodName);
        LogUtils.d(TAG, "data: " + data.toJSONString());
        LogUtils.d(TAG, "messageId: " + messageId);

        switch (methodName) {
            case "test":
                ResponseModel<EmptyModel> responseEntity = new ResponseModel<>();
                responseEntity.setCode(200);
                responseEntity.setMessage("success");
                responseEntity.setData(new EmptyModel());

                this.callH5(methodName, messageId, responseEntity.toString());
                break;
            case Constants.CallbackMethods.TO_EXTERNAL:
                // 使用浏览器打开外部链接
                this.toExternal(messageId, data);
                break;
            case Constants.CallbackMethods.TO_INTERNAL:
                // 使用浏览器打开外部链接
                this.toInternal(messageId, data);
                break;
            case Constants.CallbackMethods.GOOGLE_AUTH:
                // 谷歌授权
                this.googleAuth(messageId, data);
                break;
            case Constants.CallbackMethods.CUSTOMER_SERVICE:
                // 打开客服
                this.customerService(messageId, data);
                break;
            case Constants.CallbackMethods.ON_LOGIN_SUCCESS:
                // 通知原生用户登入成功
                this.onLoginSuccess(messageId, data);
                break;
            case Constants.CallbackMethods.ON_LOGOUT:
                // 通知原生用户登出
                this.onLogout(messageId, data);
                break;
            case Constants.CallbackMethods.ON_MESSAGE:
                LogUtils.d(TAG, "fromMethod: " + fromMethod);
                this.onMessage(fromMethod, data);
                break;
            case Constants.CallbackMethods.ENCRYPT:
                this.encrypt(messageId, data);
                break;
            case Constants.CallbackMethods.EXIT_APP:
                this.exitApp(messageId, data);
                break;
            case Constants.CallbackMethods.ON_SHARE:
                this.onShare(messageId, data);
                break;
            case Constants.CallbackMethods.APPS_FLYER:
                this.appFlyer(messageId, data);
                break;
            case Constants.CallbackMethods.AF:
                this.af(messageId, data);
                break;
            case Constants.CallbackMethods.AF_DATA:
                this.afData(messageId, data);
                break;
            case Constants.CallbackMethods.AF_UID:
                this.afUID(messageId, data);
                break;
            case Constants.CallbackMethods.GET_ENGAGE_LAB_RID:
                this.getEngageLabRid(messageId, data);
                break;
            case Constants.CallbackMethods.OPEN_WEBVIEW:
                this.openWebView(messageId, data);
                break;
            case Constants.CallbackMethods.GET_PACKAGE_NAME:
                this.getPackageName(messageId, data);
                break;
            case Constants.CallbackMethods.GET_APP_INFO:
                try {
                    this.getAppInfo(messageId, data);
                } catch (PackageManager.NameNotFoundException e) {
                    throw new RuntimeException(e);
                }
                break;
            case Constants.CallbackMethods.GET_GAID:
                this.getGAID(messageId, data);
                break;
            default:
                break;
        }
    }

    /**
     * Android回调h5
     */
    private void callH5(String method, String messageId, String jsonData) {
        if (TextUtils.isEmpty(method)) {
            return ;
        }
        MethodModel entity = new MethodModel();
        entity.setMethod(method);
        entity.setMessageId(messageId);
        entity.setJsonData(jsonData);

        LogUtils.w(TAG, jsonData);

        this.evaluateJavascript(entity.toString(), ScriptType.CALLBACK);
    }

    /**
     * Android主动调用h5
     * @param method
     * @param jsonData
     */
    private void sendMessage(String method, String jsonData) {
        if (TextUtils.isEmpty(method)) {
            return ;
        }
        MethodModel entity = new MethodModel();
        entity.setMethod(method);
        entity.setJsonData(jsonData);
        this.evaluateJavascript(entity.toString(), ScriptType.SEND_MESSAGE);
    }

    /**
     * 执行js
     * @param data
     * @param type
     */
    private void evaluateJavascript(String data, ScriptType type) {
        if (this.mGZView == null) {
            return;
        }
        String script;
        if (type == ScriptType.CALLBACK) {
            script = "window.$gz.callback('" + data + "')";
        } else if (type == ScriptType.SEND_MESSAGE) {
            script = "window.$gz.sendMessage('" + data + "')";
        } else {
            script = "";
        }
        if (TextUtils.isEmpty(script)) {
            return ;
        }
        ((Activity) this.mContext.getBaseContext()).runOnUiThread(() -> {
            this.mGZView.evaluateJavascript(script, null);
        });
    }

    /**
     * 打开外部浏览器
     * @param data
     */
    private void toExternal(String messageId, JSONObject data) {
        String url = data.getString("url");
        if (TextUtils.isEmpty(url)) {
            Toast.makeText(this.mContext, "The url is empty.", Toast.LENGTH_SHORT).show();
        } else {
            AppUtils.openURL(this.mContext, url);
        }
    }

    /**
     * 打开内部浏览器
     * @param data
     */
    private void toInternal(String messageId, JSONObject data) {
        String url = data.getString("url");
        if (TextUtils.isEmpty(url)) {
            Toast.makeText(this.mContext, "The url is empty.", Toast.LENGTH_SHORT).show();
        } else {
            Intent intent = new Intent(mContext, GZWebActivity.class);
            intent.putExtra("url", url);
            mContext.startActivity(intent);
        }
    }

    /**
     * 打开内部webView
     * @param data
     */
    private void openWebView(String messageId, JSONObject data) {
        String url = data.getString("url");
        JSONObject option = data.getJSONObject("option");
        String title = option.getString("title");

        if (TextUtils.isEmpty(url)) {
            Toast.makeText(this.mContext, "The url is empty.", Toast.LENGTH_SHORT).show();
        } else {
            Intent intent = new Intent(mContext, GZWebActivity.class);
            intent.putExtra("url", url);
            intent.putExtra("title", title);
            ((Activity) this.mContext.getBaseContext()).startActivityForResult(intent, Constants.ResultCode.WEBVIEW_RESULT);
        }
    }

    /**
     * 谷歌授权
     * @param data
     */
    private void googleAuth(String messageId, JSONObject data) {
//        if (true) {
//            GoogleAuthEntity googleAuthEntity = new GoogleAuthEntity();
//            googleAuthEntity.setId("110419084660759967342");
//            googleAuthEntity.setName("test");
//            googleAuthEntity.setEmail("test@gmail.com");
//            googleAuthEntity.setPicture("https://lh3.googleusercontent.com/a/ACg8ocKFc5C7VTDx_X6SNgsp91RNYHEA53ZglfEVKdtA_t3UretBWT_h=s96-c");
//
//            ResponseEntity<GoogleAuthEntity> responseEntity = new ResponseEntity<>();
//            responseEntity.setCode(200);
//            responseEntity.setData(googleAuthEntity);
//
//            callH5(Constants.CallbackMethods.GOOGLE_AUTH, messageId, responseEntity.toString());
//            return ;
//        }


        String serverClientId = this.mContext.getString(R.string.google_client_id);
        GoogleAuth.get().init((Activity) this.mContext.getBaseContext(), serverClientId);
        GoogleAuth.get().login(new GoogleLoginCallback() {
            @Override
            public void onSuccess(GoogleSignInAccount account) {
                GoogleAuthModel googleAuthEntity = new GoogleAuthModel();
//                googleAuthEntity.setId(account.getId());
                googleAuthEntity.setId(RSAUtils.encode(account.getId()));
                googleAuthEntity.setName(account.getDisplayName());
                googleAuthEntity.setEmail(account.getEmail());
                googleAuthEntity.setPicture(account.getPhotoUrl() == null ? "" : account.getPhotoUrl().toString());

                ResponseModel<GoogleAuthModel> responseEntity = new ResponseModel<>();
                responseEntity.setCode(200);
                responseEntity.setData(googleAuthEntity);
                Log.d(TAG,"googleAuth:"+responseEntity.toString());
                callH5(Constants.CallbackMethods.GOOGLE_AUTH, messageId, responseEntity.toString());

                mGoogleAccountInfo = JSONObject.toJSONString(googleAuthEntity);
            }

            @Override
            public void onFailed(int code) {
                ResponseModel<GoogleAuthModel> responseEntity = new ResponseModel<>();
                responseEntity.setCode(code);
                Toast.makeText(mContext, "googleAuth onFailed" + code, Toast.LENGTH_SHORT).show();
                callH5(Constants.CallbackMethods.GOOGLE_AUTH, messageId, responseEntity.toString());
            }
        });
    }

    private void customerService(String messageId, JSONObject data) {
        try {
            Zoho.get().openChat((Activity) this.mContext.getBaseContext());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * h5侧登录成功
     * @param data
     */
    private void onLoginSuccess(String messageId, JSONObject data) {
        // 登录成功后，获取一下h5的玩家信息，保存到本地
        this.sendMessage(Constants.SendMessageMethods.FETCH_USER_DETAIL, "{}");
        this.sendMessage(Constants.SendMessageMethods.FETCH_LOGIN_USER, "{}");
    }

    /**
     * h5侧登录失败
     * @param data
     */
    private void onLogout(String messageId, JSONObject data) {
        SharedPreferences sharedPreferences = this.mContext.getSharedPreferences(SHARED_PREFERENCES_KEY, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("app_user_detail", "");
        editor.putString("app_user", "");
        editor.apply();
    }

    /**
     * 原生发给h5消息回复
     * @param data
     */
    private void onMessage(String fromMethod, JSONObject data) {
        LogUtils.d(TAG, data.toJSONString());


        if (fromMethod.equals(Constants.SendMessageMethods.FETCH_LOGIN_USER)) {
            // 获取登录玩家
            AppUser appUser = data.getObject("data", AppUser.class);
            if (appUser != null) {
                // 保存信息到本地
                String strBase64 = Base64.getEncoder().encodeToString(appUser.toString().getBytes(StandardCharsets.UTF_8));
                SharedPreferences sharedPreferences = this.mContext.getSharedPreferences(SHARED_PREFERENCES_KEY, Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString("app_user", strBase64);
                editor.apply();
                // 更新一下客服信息
                Zoho.get().setUserInfo(appUser.getLoginName(), appUser.getCustomerId());
            } else {
                LogUtils.w(TAG, "AppUser is null.");
            }
        } else if (fromMethod.equals(Constants.SendMessageMethods.FETCH_USER_DETAIL)) {
            // 获取用户信息
            AppUserDetail appUserDetail = data.getObject("data", AppUserDetail.class);
            if (appUserDetail != null) {
//                appUserDetail.setBindFacebookModel(data.getJSONObject("data").getObject("bindFacebook", BindFacebookModel.class));
//                appUserDetail.setBindGoogleModel(data.getJSONObject("data").getObject("bindGoogle", BindGoogleModel.class));
                // 保存信息到本地
                String strBase64 = Base64.getEncoder().encodeToString(appUserDetail.toString().getBytes(StandardCharsets.UTF_8));
                SharedPreferences sharedPreferences = this.mContext.getSharedPreferences(SHARED_PREFERENCES_KEY, Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString("app_user_detail", strBase64);
                editor.apply();
            } else {
                LogUtils.w(TAG, "AppUserDetail is null.");
            }
        }
    }

    /**
     * 加密串
     * @param data
     */
    private void encrypt(String messageId, JSONObject data) {
        String text = data.getString("text");
        if (TextUtils.isEmpty(text)) {
            LogUtils.w(TAG, "Encrypt text is empty.");
            return ;
        }

        String strEncrypt = RSAUtils.encode(text);

        JSONObject obj = new JSONObject();
        obj.put("text", strEncrypt);

        ResponseModel<JSONObject> responseEntity = new ResponseModel<>();
        responseEntity.setCode(200);
        responseEntity.setData(obj);

        callH5(Constants.CallbackMethods.ENCRYPT, messageId, responseEntity.toString());
    }

    private void exitApp(String messageId, JSONObject data) {
        System.exit(0);
    }

    private void onShare(String messageId, JSONObject data) {
        ShareUtils.shareText(this.mContext, data.getString("link"), "");
    }

    private void appFlyer(String messageId, JSONObject data) {
        AppsFlyer.get().reportEvent(data.getString("event"), data.getJSONObject("data").toString());
    }

    private void af(String messageId, JSONObject data) {
        AppsFlyer.get().reportEvent(data.getString("event"), data.getJSONObject("data").toString());
    }

    private void afData(String messageId, JSONObject data) {
        ResponseModel<JSONObject> responseEntity = new ResponseModel<>();
        responseEntity.setCode(200);
        responseEntity.setData(JSONObject.parseObject(AppsFlyer.get().getConversionData()));
        callH5(Constants.CallbackMethods.AF_DATA, messageId, responseEntity.toString());
    }

    private void afUID(String messageId, JSONObject data) {
        JSONObject obj = new JSONObject();
        obj.put("uid", AppsFlyer.get().getUID());

        ResponseModel<JSONObject> responseEntity = new ResponseModel<>();
        responseEntity.setCode(200);
        responseEntity.setData(obj);
        callH5(Constants.CallbackMethods.AF_UID, messageId, responseEntity.toString());
    }

    private void getEngageLabRid(String messageId, JSONObject data) {
        ResponseModel<JSONObject> responseEntity = new ResponseModel<>();
        JSONObject obj = new JSONObject();
        obj.put("rid", EngageLabPush.get().getRegistrationId());
        responseEntity.setData(obj);
        callH5(Constants.CallbackMethods.GET_ENGAGE_LAB_RID, messageId, responseEntity.toString());
    }

    private void getPackageName(String messageId, JSONObject data) {
        ResponseModel<JSONObject> responseEntity = new ResponseModel<>();
        JSONObject obj = new JSONObject();
        obj.put("package", AppUtils.getPackageName(mContext));
        responseEntity.setData(obj);
        callH5(Constants.CallbackMethods.GET_PACKAGE_NAME, messageId, responseEntity.toString());
    }

    private void getAppInfo(String messageId, JSONObject data) throws PackageManager.NameNotFoundException {
        JSONObject appInfo = JSONObject.parseObject(AppUtils.getAppInfo(mContext));

        // AppsFlyer
        JSONObject appsFlyerObj = new JSONObject();
        appsFlyerObj.put("uid", AppsFlyer.get().getUID());
        appsFlyerObj.put("conversionData", AppsFlyer.get().getConversionData());
        appInfo.put("appsflyer", appsFlyerObj);

        // 极光
        JSONObject engageLabObj = new JSONObject();
        engageLabObj.put("rid", EngageLabPush.get().getRegistrationId());
        appInfo.put("engageLab", engageLabObj);

        // Google
        JSONObject googleAccountObj = JSONObject.parseObject(this.mGoogleAccountInfo);
        appInfo.put("google", googleAccountObj);

        ResponseModel<JSONObject> responseEntity = new ResponseModel<>();
        responseEntity.setData(appInfo);
        callH5(Constants.CallbackMethods.GET_APP_INFO, messageId, responseEntity.toString());
    }

    private void getGAID(String messageId, JSONObject data) {
        JSONObject obj = new JSONObject();
        obj.put("gaid", GoogleAdvertisingId.get().getGAID());

        ResponseModel<JSONObject> responseEntity = new ResponseModel<>();
        responseEntity.setData(obj);
        callH5(Constants.CallbackMethods.GET_GAID, messageId, responseEntity.toString());
    }
}
