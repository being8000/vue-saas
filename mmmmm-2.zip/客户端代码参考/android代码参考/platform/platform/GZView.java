package com.gz.main.platform;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.net.Uri;
import android.net.http.SslError;
import android.util.AttributeSet;
import android.webkit.ConsoleMessage;
import android.webkit.PermissionRequest;
import android.webkit.SslErrorHandler;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.gz.main.BuildConfig;
import com.gz.main.R;
import com.gz.main.sdk.photopicker.PhotoPickerSdk;
import com.gz.main.utils.GZUtils;
import com.gz.main.utils.LogUtils;
import com.gz.photopicker.PhotoPickerCallback;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Objects;

public class GZView extends WebView {

    private static final String TAG = GZView.class.getName();

    private ValueCallback<Uri[]> mUMA;

    private final static int FCR = 1;

    private GZInterfaces eventHandler = null;

    private GZViewCallback gzViewCallback = null;

    private boolean isError = false;

    private Constants.HttpErrorType errorType;

    private boolean isAddEruda = false;

    private WebViewHandler webViewHandler = null;

    public GZView(@NonNull Context context) {
        super(context);
        this.initialize();
    }

    public GZView(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        this.initialize();
    }

    public GZView(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        this.initialize();
    }

    public GZView(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        this.initialize();
    }

    public GZInterfaces getEventHandler() {
        return eventHandler;
    }

    public void setEventHandler(GZInterfaces handler) {
        this.eventHandler = handler;
    }

    public GZViewCallback getGzViewCallback() {
        return gzViewCallback;
    }

    public void setGzViewCallback(GZViewCallback gzViewCallback) {
        this.gzViewCallback = gzViewCallback;
    }

    public boolean getIsError() {
        return isError;
    }

    public Constants.HttpErrorType getErrorType() { return errorType; }

    public WebViewHandler getWebViewHandler() {
        return this.webViewHandler;
    }

    public void setWebViewHandler(WebViewHandler handler) {
        this.webViewHandler = handler;
    }

    @SuppressLint({"SetJavaScriptEnabled"})
    private void initialize() {

        // this.setBackgroundColor(0);
        // 可以开启软件加速，但是会导致cocos项目运行不了
        // this.setLayerType(View.LAYER_TYPE_SOFTWARE, null);

        WebSettings settings = this.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setUseWideViewPort(true);
        settings.setAllowFileAccessFromFileURLs(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        // settings.setAllowContentAccess(true);
        // settings.setAllowFileAccess(true);
        // settings.setAllowUniversalAccessFromFileURLs(true);
        // 开启缓存
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        // 允许使用定位，部分游戏可能需要开启防作弊
        settings.setGeolocationEnabled(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);

        WebChromeClient webChromeClient = new WebChromeClient(){
            @Override
            public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
                LogUtils.d("CONSOLE", consoleMessage.message() + ", level: " + consoleMessage.messageLevel() + ", sourceId: " + consoleMessage.sourceId() + ", lineNum: " + consoleMessage.lineNumber());
                return true;
            }

            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                super.onProgressChanged(view, newProgress);
            }

            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback, FileChooserParams fileChooserParams) {
                // return super.onShowFileChooser(webView, filePathCallback, fileChooserParams);
                if (mUMA != null) {
                    mUMA.onReceiveValue(null);
                }
                mUMA = filePathCallback;
                PhotoPickerSdk.get().selectPicture(false, new PhotoPickerCallback() {
                    @Override
                    public void onSelectCallback(Uri uri) {
                        if (uri != null) {
                            mUMA.onReceiveValue(new Uri[]{uri});
                        } else {
                            mUMA.onReceiveValue(null);
                        }
                        mUMA = null;
                    }
                });
                return true;
            }

            @Override
            public void onPermissionRequest(PermissionRequest request) {
                request.grant(request.getResources());
            }
        };

        WebViewClient webViewClient = new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                LogUtils.d(TAG, "onPageStarted");
                if (webViewHandler != null && webViewHandler.onPageStarted(view, url, favicon)) {
                    return ;
                }
                super.onPageStarted(view, url, favicon);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                LogUtils.d(TAG, "onPageFinished");

//                String title = view.getTitle();
//                if (title != null && title.contains("Attention Required!")) {
//                    isError = true;
//                    if (gzViewCallback != null) {
//                        gzViewCallback.onHttpError();
//                    }
//                    return ;
//                }

                if (!isAddEruda && BuildConfig.DEBUG) {
                    String script = "(function() {" +
                            "if(window.eruda)return;" +
                            "let define;" +
                            "if(window.define){" +
                            "define=window.define;" +
                            "window.define=null;" +
                            "}" +
                            "let script=document.createElement('script');" +
                            "script.src='//cdn.jsdelivr.net/npm/eruda';" +
                            "document.body.appendChild(script);" +
                            "script.onload=()=>{" +
                            "eruda.init();if(define){window.define=define;}" +
                            "}" +
                            "})()";
                    view.evaluateJavascript(script, null);
                    isAddEruda = true;
                }

                super.onPageFinished(view, url);
            }

            @Override
            public void onPageCommitVisible(WebView view, String url) {
                LogUtils.d(TAG, "onPageCommitVisible");
                super.onPageCommitVisible(view, url);
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                LogUtils.w(TAG, "onReceivedError");
//                String url = request.getUrl().toString();
//                if (url.equals(view.getContext().getString(R.string.domain_1))
//                        || url.equals(view.getContext().getString(R.string.domain_2))) {
//                    if (error.getErrorCode() < 0) {
//                        isError = true;
//                        errorType = Constants.HttpErrorType.NETWORK_ERROR;
//                        if (gzViewCallback != null) {
//                            gzViewCallback.onHttpError();
//                        }
//                        return;
//                    }
//                }
                super.onReceivedError(view, request, error);
            }

            @Override
            public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                LogUtils.w(TAG, "onReceivedSslError");
                super.onReceivedSslError(view, handler, error);
            }

            @Override
            public void onReceivedHttpError(WebView view, WebResourceRequest request, WebResourceResponse errorResponse) {
                LogUtils.w(TAG, "onReceivedHttpError");
                String url = request.getUrl().toString();
                if (url.equals(view.getContext().getString(R.string.domain_1))
                    || url.equals(view.getContext().getString(R.string.domain_2))) {
                    if (errorResponse.getStatusCode() == 403) {
                        isError = true;
                        errorType = Constants.HttpErrorType.FORBIDDEN;
                        if (gzViewCallback != null) {
                            gzViewCallback.onHttpError();
                        }
                        return;
                    }
                }
                super.onReceivedHttpError(view, request, errorResponse);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                LogUtils.d(TAG, "shouldOverrideUrlLoading url -> " + url);
                LogUtils.d(TAG, "shouldOverrideUrlLoading scheme -> " + request.getUrl().getScheme());

                if (webViewHandler != null && webViewHandler.shouldOverrideUrlLoading(view, request)) {
                    return true;
                }

                String scheme = request.getUrl().getScheme();
                if (getContext().getString(R.string.scheme_gameplus).equals(scheme)) {
                    return true;
                }

                if (Objects.equals(request.getUrl().getScheme(), getContext().getString(R.string.scheme_gamezone))) {
                    String encodeData = request.getUrl().getQueryParameter("data");
                    byte[] bytes =Base64.getDecoder().decode(encodeData);
                    String decodeData = new String(bytes, StandardCharsets.UTF_8);
                    if (getEventHandler() != null) {
                        getEventHandler().h5Call(decodeData);
                    }
                    return true;
                }
                return super.shouldOverrideUrlLoading(view, request);
            }
        };

        this.setWebViewClient(webViewClient);
        this.setWebChromeClient(webChromeClient);
    }

    public interface WebViewHandler {

        boolean onPageStarted(WebView view, String url, Bitmap favicon);

        boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request);
    }
}
