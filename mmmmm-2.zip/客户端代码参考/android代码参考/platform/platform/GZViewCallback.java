package com.gz.main.platform;

public interface GZViewCallback {

    void onHttpError();

}
