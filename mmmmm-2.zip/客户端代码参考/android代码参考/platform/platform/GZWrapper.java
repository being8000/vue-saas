package com.gz.main.platform;

import android.content.Intent;

public class GZWrapper {

    private GZView gzView = null;
    private static GZWrapper mInstance = null;
    private GZInterfaces mGzInterfaces = null;

    public static GZWrapper get() {
        if (mInstance == null) {
            mInstance = new GZWrapper();
        }
        return mInstance;
    }

    public GZView getGzView() {
        return gzView;
    }

    public void setGzView(GZView gzView) {
        this.gzView = gzView;
    }
}
