package com.gz.main.platform.model;

import androidx.annotation.NonNull;

import com.alibaba.fastjson.JSONObject;

public class AppUser {

    private String loginName;

    private String customerId;

    private String palcode;

    private boolean isLogin;

    private String createdDate;

    private String credit;

    private String currency;

    private String face;

    private String flag;

    private String fromType;

    private String gameCredit;

    private String gameKey;

    private String gameLimit;

    private String login;

    private String mobileNo;

    private String newAccountFlag;

    private String noLoginDays;

    private String onlineBet;

    private String parentId;

    private String phone;

    private String productId;

    private String registerMethod;

    private String siteId;

    private String starLevel;

    private String toType;

    private String verifyLoginIp;

    private boolean isShowgfStatus;

    private float balance;

    public String getLoginName() {
        return loginName;
    }

    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getPalcode() {
        return palcode;
    }

    public void setPalcode(String palcode) {
        this.palcode = palcode;
    }

    public boolean isLogin() {
        return isLogin;
    }

    public void setLogin(boolean login) {
        isLogin = login;
    }

    public String getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    public String getCredit() {
        return credit;
    }

    public void setCredit(String credit) {
        this.credit = credit;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getFace() {
        return face;
    }

    public void setFace(String face) {
        this.face = face;
    }

    public String getFlag() {
        return flag;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }

    public String getFromType() {
        return fromType;
    }

    public void setFromType(String fromType) {
        this.fromType = fromType;
    }

    public String getGameCredit() {
        return gameCredit;
    }

    public void setGameCredit(String gameCredit) {
        this.gameCredit = gameCredit;
    }

    public String getGameKey() {
        return gameKey;
    }

    public void setGameKey(String gameKey) {
        this.gameKey = gameKey;
    }

    public String getGameLimit() {
        return gameLimit;
    }

    public void setGameLimit(String gameLimit) {
        this.gameLimit = gameLimit;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getMobileNo() {
        return mobileNo;
    }

    public void setMobileNo(String mobileNo) {
        this.mobileNo = mobileNo;
    }

    public String getNewAccountFlag() {
        return newAccountFlag;
    }

    public void setNewAccountFlag(String newAccountFlag) {
        this.newAccountFlag = newAccountFlag;
    }

    public String getNoLoginDays() {
        return noLoginDays;
    }

    public void setNoLoginDays(String noLoginDays) {
        this.noLoginDays = noLoginDays;
    }

    public String getOnlineBet() {
        return onlineBet;
    }

    public void setOnlineBet(String onlineBet) {
        this.onlineBet = onlineBet;
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getRegisterMethod() {
        return registerMethod;
    }

    public void setRegisterMethod(String registerMethod) {
        this.registerMethod = registerMethod;
    }

    public String getSiteId() {
        return siteId;
    }

    public void setSiteId(String siteId) {
        this.siteId = siteId;
    }

    public String getStarLevel() {
        return starLevel;
    }

    public void setStarLevel(String starLevel) {
        this.starLevel = starLevel;
    }

    public String getToType() {
        return toType;
    }

    public void setToType(String toType) {
        this.toType = toType;
    }

    public String getVerifyLoginIp() {
        return verifyLoginIp;
    }

    public void setVerifyLoginIp(String verifyLoginIp) {
        this.verifyLoginIp = verifyLoginIp;
    }

    public boolean isShowgfStatus() {
        return isShowgfStatus;
    }

    public void setShowgfStatus(boolean showgfStatus) {
        isShowgfStatus = showgfStatus;
    }

    public float getBalance() {
        return balance;
    }

    public void setBalance(float balance) {
        this.balance = balance;
    }

    @NonNull
    @Override
    public String toString() {
        return JSONObject.toJSONString(this);
    }
}
