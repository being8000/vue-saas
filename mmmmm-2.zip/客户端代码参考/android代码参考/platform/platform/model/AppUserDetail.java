package com.gz.main.platform.model;

import androidx.annotation.NonNull;

import com.alibaba.fastjson.JSONObject;

public class AppUserDetail {

    private boolean activation;
    private boolean agentFlag;
    private String birthday; // Brithday
    private int blackFlag;
    private int cashCredit;
    private String city;
    private String customerId; // 用户ID
    private String nickName; // 用户nickname
    private int customerLevel;
    private int customerType;
    private boolean firstDepositFlag;
    private String firstIdStatus; // 判断kyc是否完成 0 Review 1 Approved 2/3 Failed
    private String firstName; // First Name
    private int gameCredit;
    private String gender;
    private boolean glife;
    private String headShot;
    private int isBlackList; // 是否是黑名单，如果是黑名单不让进入游戏，提示 Maintenance in progress
    private boolean isLazada;
    private String lastLoginDate;
    private String lastName; // Last Name
    private String loginName;
    private String middleName;
    private int loginNameFlag;
    private boolean loginPwdFlag;
    private boolean marginSwitch;
    private boolean mayaFlag;
    private String mobileNo;
    private String nationality; // Nationality
    private int newWalletFlag;
    private int oddsType;
    private boolean onlineBet;
    private boolean personalInfoTag;
    private int product;
    private String registDate;
    private String registerMethod;
    private boolean silentPhotoSwitch;
    private int vipLevel;
    private boolean whiteListUser;
    private boolean withdrewPwd;
    private String permanentAddress;
    private String work;
    private String employerName;
    private String sourceOfIncome;
    private String birthPlace;
    private String presentAddress;
    private BindFacebookModel bindFacebookModel;
    private BindGoogleModel bindGoogleModel;

    public boolean isActivation() {
        return activation;
    }

    public void setActivation(boolean activation) {
        this.activation = activation;
    }

    public boolean isAgentFlag() {
        return agentFlag;
    }

    public void setAgentFlag(boolean agentFlag) {
        this.agentFlag = agentFlag;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public int getBlackFlag() {
        return blackFlag;
    }

    public void setBlackFlag(int blackFlag) {
        this.blackFlag = blackFlag;
    }

    public int getCashCredit() {
        return cashCredit;
    }

    public void setCashCredit(int cashCredit) {
        this.cashCredit = cashCredit;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public int getCustomerLevel() {
        return customerLevel;
    }

    public void setCustomerLevel(int customerLevel) {
        this.customerLevel = customerLevel;
    }

    public int getCustomerType() {
        return customerType;
    }

    public void setCustomerType(int customerType) {
        this.customerType = customerType;
    }

    public boolean isFirstDepositFlag() {
        return firstDepositFlag;
    }

    public void setFirstDepositFlag(boolean firstDepositFlag) {
        this.firstDepositFlag = firstDepositFlag;
    }

    public String getFirstIdStatus() {
        return firstIdStatus;
    }

    public void setFirstIdStatus(String firstIdStatus) {
        this.firstIdStatus = firstIdStatus;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public int getGameCredit() {
        return gameCredit;
    }

    public void setGameCredit(int gameCredit) {
        this.gameCredit = gameCredit;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public boolean isGlife() {
        return glife;
    }

    public void setGlife(boolean glife) {
        this.glife = glife;
    }

    public String getHeadShot() {
        return headShot;
    }

    public void setHeadShot(String headShot) {
        this.headShot = headShot;
    }

    public int getIsBlackList() {
        return isBlackList;
    }

    public void setIsBlackList(int isBlackList) {
        this.isBlackList = isBlackList;
    }

    public boolean isLazada() {
        return isLazada;
    }

    public void setLazada(boolean lazada) {
        isLazada = lazada;
    }

    public String getLastLoginDate() {
        return lastLoginDate;
    }

    public void setLastLoginDate(String lastLoginDate) {
        this.lastLoginDate = lastLoginDate;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getLoginName() {
        return loginName;
    }

    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public int getLoginNameFlag() {
        return loginNameFlag;
    }

    public void setLoginNameFlag(int loginNameFlag) {
        this.loginNameFlag = loginNameFlag;
    }

    public boolean isLoginPwdFlag() {
        return loginPwdFlag;
    }

    public void setLoginPwdFlag(boolean loginPwdFlag) {
        this.loginPwdFlag = loginPwdFlag;
    }

    public boolean isMarginSwitch() {
        return marginSwitch;
    }

    public void setMarginSwitch(boolean marginSwitch) {
        this.marginSwitch = marginSwitch;
    }

    public boolean isMayaFlag() {
        return mayaFlag;
    }

    public void setMayaFlag(boolean mayaFlag) {
        this.mayaFlag = mayaFlag;
    }

    public String getMobileNo() {
        return mobileNo;
    }

    public void setMobileNo(String mobileNo) {
        this.mobileNo = mobileNo;
    }

    public String getNationality() {
        return nationality;
    }

    public void setNationality(String nationality) {
        this.nationality = nationality;
    }

    public int getNewWalletFlag() {
        return newWalletFlag;
    }

    public void setNewWalletFlag(int newWalletFlag) {
        this.newWalletFlag = newWalletFlag;
    }

    public int getOddsType() {
        return oddsType;
    }

    public void setOddsType(int oddsType) {
        this.oddsType = oddsType;
    }

    public boolean isOnlineBet() {
        return onlineBet;
    }

    public void setOnlineBet(boolean onlineBet) {
        this.onlineBet = onlineBet;
    }

    public boolean isPersonalInfoTag() {
        return personalInfoTag;
    }

    public void setPersonalInfoTag(boolean personalInfoTag) {
        this.personalInfoTag = personalInfoTag;
    }

    public int getProduct() {
        return product;
    }

    public void setProduct(int product) {
        this.product = product;
    }

    public String getRegistDate() {
        return registDate;
    }

    public void setRegistDate(String registDate) {
        this.registDate = registDate;
    }

    public String getRegisterMethod() {
        return registerMethod;
    }

    public void setRegisterMethod(String registerMethod) {
        this.registerMethod = registerMethod;
    }

    public boolean isSilentPhotoSwitch() {
        return silentPhotoSwitch;
    }

    public void setSilentPhotoSwitch(boolean silentPhotoSwitch) {
        this.silentPhotoSwitch = silentPhotoSwitch;
    }

    public int getVipLevel() {
        return vipLevel;
    }

    public void setVipLevel(int vipLevel) {
        this.vipLevel = vipLevel;
    }

    public boolean isWhiteListUser() {
        return whiteListUser;
    }

    public void setWhiteListUser(boolean whiteListUser) {
        this.whiteListUser = whiteListUser;
    }

    public boolean isWithdrewPwd() {
        return withdrewPwd;
    }

    public void setWithdrewPwd(boolean withdrewPwd) {
        this.withdrewPwd = withdrewPwd;
    }

    public String getPermanentAddress() {
        return permanentAddress;
    }

    public void setPermanentAddress(String permanentAddress) {
        this.permanentAddress = permanentAddress;
    }

    public String getWork() {
        return work;
    }

    public void setWork(String work) {
        this.work = work;
    }

    public String getEmployerName() {
        return employerName;
    }

    public void setEmployerName(String employerName) {
        this.employerName = employerName;
    }

    public String getSourceOfIncome() {
        return sourceOfIncome;
    }

    public void setSourceOfIncome(String sourceOfIncome) {
        this.sourceOfIncome = sourceOfIncome;
    }

    public String getBirthPlace() {
        return birthPlace;
    }

    public void setBirthPlace(String birthPlace) {
        this.birthPlace = birthPlace;
    }

    public String getPresentAddress() {
        return presentAddress;
    }

    public void setPresentAddress(String presentAddress) {
        this.presentAddress = presentAddress;
    }

    public BindFacebookModel getBindFacebookModel() {
        return bindFacebookModel;
    }

    public void setBindFacebookModel(BindFacebookModel bindFacebookModel) {
        this.bindFacebookModel = bindFacebookModel;
    }

    public BindGoogleModel getBindGoogleModel() {
        return bindGoogleModel;
    }

    public void setBindGoogleModel(BindGoogleModel bindGoogleModel) {
        this.bindGoogleModel = bindGoogleModel;
    }

    @NonNull
    @Override
    public String toString() {
        return JSONObject.toJSONString(this);
    }
}
