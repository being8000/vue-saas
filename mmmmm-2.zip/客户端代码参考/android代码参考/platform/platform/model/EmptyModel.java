package com.gz.main.platform.model;

public class EmptyModel {
}
