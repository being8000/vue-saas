package com.gz.main.platform.model;

import androidx.annotation.NonNull;

import com.alibaba.fastjson.JSONObject;
import com.gz.main.utils.LogUtils;

import java.nio.charset.StandardCharsets;
import java.util.Base64;

public class MethodModel {

    private static final String TAG = MethodModel.class.getName();

    /**
     * 方法名
     */
    private String method;

    /**
     * 参数
     */
    private String jsonData;

    /**
     * 消息ID
     */
    private String messageId;

    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method;
    }

    public String getJsonData() {
        return jsonData;
    }

    public void setJsonData(String jsonData) {
        this.jsonData = jsonData;
    }


    public String getMessageId() {
        return messageId;
    }

    public void setMessageId(String messageId) {
        this.messageId = messageId;
    }

    @NonNull
    @Override
    public String toString() {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("method", this.method);
        jsonObject.put("messageId", this.messageId);

        try {
            JSONObject dataObject = JSONObject.parseObject(this.jsonData);
            jsonObject.put("data", dataObject);
        } catch (Exception e) {
            e.printStackTrace();
            LogUtils.e(TAG, "method: " + method, "数据非法，应为json串");
        }

        String data = jsonObject.toString();
        return Base64.getEncoder().encodeToString(data.getBytes(StandardCharsets.UTF_8));
    }
}
