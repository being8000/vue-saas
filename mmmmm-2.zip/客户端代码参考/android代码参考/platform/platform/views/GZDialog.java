package com.gz.main.platform.views;

import android.app.Activity;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;

import androidx.annotation.NonNull;

import com.gz.main.R;

public class GZDialog {

    private GZDialogListener gzDialogListener = null;

    private Activity activity = null;

    private ViewGroup viewGroup = null;

    private View view = null;
    public GZDialog(@NonNull Activity activity) {
        this.activity = activity;
        this.onCreate();
    }

    private void onCreate() {
        viewGroup = activity.findViewById(R.id.layout_main);
        view = activity.getLayoutInflater().inflate(R.layout.gz_dialog, null);

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
        view.setLayoutParams(params);

        view.findViewById(R.id.btn_confirm).setOnClickListener(v -> {
            if (gzDialogListener != null) {
                gzDialogListener.onBtnConfirmClicked(this);
            }
        });

        view.findViewById(R.id.btn_cancel).setOnClickListener(v -> {
            if (gzDialogListener != null) {
                gzDialogListener.onBtnCancelClicked(this);
            }
        });
    }

    public void setOnClickEventListener(GZDialogListener gzDialogListener) {
        this.gzDialogListener = gzDialogListener;
    }

    /**
     * 设置确认按钮文本
     * @param text
     */
    public void setConfirmText(String text) {
        if (view == null) {
            return;
        }
        if (TextUtils.isEmpty(text)) {
            return ;
        }
        Button btn = view.findViewById(R.id.btn_confirm);
        btn.setText(text);
    }

    /**
     * 设置取消按钮文本
     * @param text
     */
    public void setCancelText(String text) {
        if (view == null) {
            return;
        }
        if (TextUtils.isEmpty(text)) {
            return ;
        }
        Button btn = view.findViewById(R.id.btn_cancel);
        btn.setText(text);
    }

    public void show(){
        if (view == null) {
            return ;
        }

        if (viewGroup == null) {
            return ;
        }

        if (view.getParent() == viewGroup) {
            return ;
        }

        viewGroup.addView(view);

        Animation animation = AnimationUtils.loadAnimation(this.activity, R.anim.anim_zoom_in);
        view.findViewById(R.id.dialog_bg).startAnimation(animation);
    }

    public void dismiss() {
        if (view != null) {
            viewGroup.removeView(view);
            view = null;
        }
    }
}
