package com.gz.main.platform.views;

import android.view.View;

public interface GZDialogListener {

    void onBtnConfirmClicked(GZDialog view);

    void onBtnCancelClicked(GZDialog view);

}
