package com.gz.main.platform.views;

import android.app.Activity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.TextView;

import com.gz.main.R;

public class GZErrorView {

    private Activity activity = null;

    private ViewGroup viewGroup = null;

    private View view = null;

    private TextView tvTitle;

    private TextView tvContent;

    public GZErrorView(Activity activity) {
        this.activity = activity;

        this.onCreate();
    }

    private void onCreate() {
        viewGroup = this.activity.findViewById(R.id.layout_main);
        view = this.activity.getLayoutInflater().inflate(R.layout.gz_error, null);

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
        view.setLayoutParams(params);

        tvTitle = view.findViewById(R.id.tv_error_title);
        tvContent = view.findViewById(R.id.tv_error_content);
    }

    public void show() {
        this.show(null, null);
    }

    public void show(String title, String content) {
        if (view == null) {
            return;
        }

        if (view.getParent() == viewGroup) {
            return;
        }

        if (title == null) {
            title = this.activity.getString(R.string.load_error_title);
        }

        if (content == null) {
            content = this.activity.getString(R.string.load_error_content);
        }

        tvTitle.setText(title);
        tvContent.setText(content);

        viewGroup.addView(view);
    }

    public void dismiss() {
        if (viewGroup == null) {
            return;
        }
        if (view != null) {
            viewGroup.removeView(view);
            view = null;
        }
    }

}
