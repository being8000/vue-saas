import request from "./lib/request"
import {
  withActivity,
  withGlaxy ,
  withFront
} from "./lib/utils"

// 查询活动是否存在
export const getActivityState = async (params = {}) => {
  return request(withActivity('/valentine/available/query'), {
    body: params,
  })
}
//查询用户活动数据(签到状态，卡包数量，各卡片数量)
export const customerDailyState = async (params = {}) => {
  return request(withActivity('/valentine/userdata/query'), {
    body: params,
  })
}

// 签到
export const customerCheckin = async (params = {}) => {
  return request(withActivity('/valentine/checkin'), {
    body: params,
  })
}

// 打开卡包
export const openAllpackage = async (params = {}) => {
  return request(withActivity('/valentine/package/open'), {
    body: params,
  })
}

// 卡牌兑换
export const exchangeGift = async (params = {}) => {
  return request(withActivity('/valentine/gift/exchange'), {
    body: params,
  })
}

// 查询卡包发放记录
export const getPackageRecord = async (params = {}) => {
  return request(withActivity('/valentine/package/record/page'), {
    body: params,
  })
}


// 查询卡牌发放记录
export const getCardRecord = async (params = {}) => {
  return request(withActivity('/valentine/card/record/page'), {
    body: params,
  })
}

// 查询卡牌兑换记录
export const getChangeRecord = async (params = {}) => {
  return request(withActivity('/valentine/gift/record/page'), {
    body: params,
  })
}
/**  存款活动 **/
// 查询存款列表
export const getdepositList = async (params = {}) => {
  return request(withGlaxy('/deposit/queryPayWays'), {
    body: params,
  })
}
// 存款活动参数配置
export const getdepositConfig = async (params = {}) => {
  return request(withActivity('/deposit/config'), {
    body: params,
  })
}
// 获取转盘参数配置
export const getSpinConfig = async (params = {}) => {
  return request(withActivity('/spin/config'), {
    body: params,
  })
}
// 抽奖
export const startSpin = async (params = {}) => {
  return request(withActivity('/spin/spin'), {
    body: params,
  })
}
export const depositActivityClaim = async (params = {}) => {
  return request(withActivity('/deposit/claim'), {
    body: params,
  })
}
// 剩余可领取奖励
export const getDepositUserInfo = async (params = {}) => {
  return request(withActivity('/deposit/userInfo'), {
    body: params,
  })
}
export const getSpinProgressConfig = async (params = {}) => {
  return request(withActivity('/spin/progressConfig'), {
    body: params,
  })
}

// 查询活动是否存在
export const getMachList = async (params = {}) => {
  return request(withFront('/tiptopMatch/positionList'), {
    body: params,
  })
}

// 查询赛事爆奖初始化数据
export const getTopprize = async (params = {}) => {
  return request(withFront('/prizeCache/tiptopPrize'), {
    body: params,
  })
}
// 查询一般赛事爆奖初始化诗句
export const getAllpool= async (params = {}) => {
  return request(withFront('/prizeCache/jackpotPrize'), {
    body: params,
  })
}
// 获取用户报名数据
export const getUserSgin = async (params = {}) => {
  return request(withActivity('/tiptopMatch/signUp'), {
    body: params,
  })
}