import request from "./lib/request"
import {
  withGlaxy
} from "./lib/utils"
// bp-bonus-popup
export const getBonusInfoApi = async (params = {}) => {
  return request(withGlaxy('/customerTask/deposit/bounds/statistics'), {
    body: params,
  })
}

export const getClaimApi = async (params = {}) => {
  return request(withGlaxy('/customerTask/deposit/bounds/receive'), {
    body: params,
  })
}

// bp-bonus-details
export const getBonusDetailsApi = async (params = {}) => {
  return request(withGlaxy('/customerTask/deposit/bounds/statistics/details'), {
    body: params,
  })
}

// bp-bonus-deposit-details-popup
export const getRulesApi = async (params = {}) => {
  return request(withGlaxy('/customerTask/deposit/homePage/rules'), {
    body: params,
  })
}

// bp-bonus-deposit-popup
export const getDepositConditionsApi = async (params = {}) => {
  return request(withGlaxy('/customerTask/deposit/depositPage/page'), {
    body: params,
  })
}


//获取活动的接口
export const customerTaskStatus = async (params = {}) => {
  return request(withGlaxy('/customerTask/deposit/homePage/status'), {
    body: params,
  })
}