import request from "./lib/request"
import {
  withGlaxy
} from "./lib/utils"
const app = getApp();
/**
 * 获取嘉年华入口
 * @param {*} params 
 */
export const getCarnivalStatus = async (params = {}) => {
  const {
    success,
    body
  } = await request(withGlaxy('/carnival/status'), {
    body: params,
  })
  if (success) {
    return body
  } else {
    return false
  }
}

/** withGlaxy
 * 获取嘉年列表
 * @param {*} params 
 */
export const getCarnivalList = async (params = {}) => {
  const {
    success,
    body
  } = await  request(withGlaxy('/carnival/list'), {
    body: params,
    showLoading: false
  })
  console.log(body, 'body34324535')
  if (success) {
    return body
  } else {
    return false
  }
}


/**
 * 嘉年签到 
 * @param {*} params 
 */
export const getCarnivalSign = async (params = {}) => {
  const {
    success,
    body
  } = await  request(withGlaxy('/carnival/signIn'), {
    body: params,
  })
  if (success) {
    return body
  } else {
    return false
  }
}
/**
 * 嘉年签到
 * @param {*} params 
 */
export const getCarnivalReceive = async (params = {}) => {
  const {
    success,
    body
  } = await  request(withGlaxy('/carnival/receive'), {
    body: params,
  })
  if (success) {
    return body
  } else {
    return false
  }
}