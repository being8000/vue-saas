import request from "./lib/request"
import {
  withFront,
  withGlaxy
} from "./lib/utils"
import {
  findGameByGameIdAndPlatformId
} from "./service/game"


/**
 * 收藏游戏
 * @param {{
 *  gameId: string,
 *  platformCode: string
 * }} data 
 */
export const requestAddFavoritesGame = (data = {}) => {
  return request(withGlaxy('/game/like'), {
    body: data,
  })
}

/**
 * 取消收藏
 * @param {{
 *  gameId: string,
 *  platformCode: string
 * }} data 
 */
export const requestRemoveFavorateGame = (data = {}) => {
  return request(withGlaxy('/game/cancleLike'), {
    body: data,
  })
}


/**
 * 获取最爱游戏列表
 * @returns {Promise<import('./stasticJs').GameBaseItem[]>} 
 */
export const fetchFavoriteGames = async () => {
  const {
    success,
    body
  } = await request(withFront('/game/likeList'))
  if (success && body) {
    console.log('fetchFavoriteGames', (body || []).map(fg => findGameByGameIdAndPlatformId(fg.gameId, fg.platformCode)).filter(Boolean))
    return (body || []).map(fg => findGameByGameIdAndPlatformId(fg.gameId, fg.platformCode)).filter(Boolean)
  } else {
    return []
  }
}
/**
 * @type {{
 *  platformId: string,
 *  platformName: string,
 *  platformCode: string,
 *  platformDisplayName: string,
 *  imgUrl: string,
 *  gameLogoUrl: string
 * }[]}
 */
export let gameProviders = []
/**
 * 获取
 */
export const fetchgameProviders = async (params = {}) => {
  const {
    success,
    body
  } = await request(withFront('/gameProviders'), {
    body: params,
    auth: false
  })
  if (success) {
    gameProviders = body.map((el) => {
      providersMap[el.platformId] = el
      return {
        platformId: el.platformId,
        platformName: el.platformName,
        platformCode: el.platformId,
        platformDisplayName: el.platformDisplayName,
        imgUrl: el.logoUrl,
        gameLogoUrl: el.gameLogoUrl
      }
    })
    return gameProviders
  }
  return []
}
let disabledProviders = []

// 获取游戏禁用供应商标签列表
export const fetchDisableLobbyLabel = async () => {
  const {
    body,
    success
  } = await request(withFront('/disableLobbyLabel'), {
    method: 'GET',
    body: {},
    auth: false
  })
  if (success) {
    disabledProviders = body.map((item) => item.lobbyCode)
  } else {
    disabledProviders = []
  }
}
export const providersMap = {}
export function normalizedProvider() {
  return gameProviders.filter(el => !disabledProviders.find(providerId => providerId === el.providerId))
}


/**
 * 获取最近玩过的游戏
 * @returns {Promise<import('./stasticJs').GameBaseItem[]>} 
 */
export const fetchRecentlyGames = async () => {
  const {
    success,
    body
  } = await request(withFront('/game/historyList'))
  if (success && body) {
    return body
  } else {
    return []
  }
}

