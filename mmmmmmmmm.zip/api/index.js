import request from './lib/request'
import {
  withFront,
  withGlaxy
} from './lib/utils'
import {
  StorageKey
} from '/utils/const'
import Base64 from "Base64";
import pick from 'lodash/pick';

// 获取前置的webtoken
export let latestWebtoken = null
export const fetchWebtoken = async () => {
  const {
    success,
    body
  } = await request(withGlaxy('/webToken'), {
    auth: false
  })
  console.log('fetchwebtoken', body)
  if (success) {
    latestWebtoken = body.info
  }
  return Promise.resolve(success)
}

export const updateWebtokenStorage = (token) => {
  console.log('更新最新的token')
  if (token) {
    my.setStorageSync({
      key: "isInfo",
      data: token,
    });
    my.setStorageSync({
      key: StorageKey.WEB_TOKEN,
      data: JSON.parse(Base64.atob(token))
    })
    // NODE 兼容旧token
    my.setStorageSync({
      key: 'token',
      data: JSON.parse(Base64.atob(token))
    })
  }

}

export let isValidToken = false
/**
 * 检查webtoken是否有效
 */
export const verifyToken = async () => {
  const token = my.getStorageSync({
    key: StorageKey.WEB_TOKEN
  }).data
  if (token) {
    // 检查token的登录状态的有效性
    const {
      success
    } = await request(withGlaxy('/applets/checkToken'), {
      showToast: false,
      auth: false
    })
    if (success) {
      isValidToken = true
    } else {
      // 清除授权后的用户信息
      my.removeStorageSync({
        key: 'userInfo', // 缓存数据的key
      })
      isValidToken = false
    }
  } else {
    // 清除授权后的用户信息
    my.removeStorageSync({
      key: 'userInfo', // 缓存数据的key
    })
    isValidToken = false
  }
  return isValidToken
}

// 获取前置的 Siteinfo 站点配置
export const fetchSiteInfo = async () => {
  const {
    success,
    body
  } = await request(withFront('/front/siteinfo'), {
    auth: false
  })
  if (success) {
    const data = pick(body, [
      'GLIFE_JUMP_TIP_SWITCH', // 跳出Gcash是否需要弹窗提醒开关
      'GLIFE_PERSONAL_INFO_SWITCH', // 是否KYC验证开关
      'GAMEPLUS_GAME_JSON', // H5 游戏列表接口地址
      'HOT_GAME_JSON', // 热门游戏
      'PROMOTION_JSON', //promotion banner
      'TCC_MATCH_ENTRY_JSON', //TTC入口
      'BLOCK_CONFIG_JSON', // 首页区块json
      'GAME_JSON', // 所有基础游戏KEY
      'BANNER_JSON', // 系统关于所有tab的banner配置
      'STORE_WEBSITE_EVENT_JSON', // 弃用，老板活动列表json
      'GLIFE_AGE_CONFIRM_SWITCH', // 跳转h5时是否改为年龄提示的弹窗
      'GLIFE_SENSORS_URL', //神策接收地址
      'ENDORSER_JSON', //代言人信息
    ])
    my.setStorageSync({
      key: StorageKey.SITE_INFO,
      data: data
    })
    return data
  } else {
    return false
  }
}


export let loadingConfig = null

// 获取前置的 loading 加载图配置 站点配置
export const fetchLoadingConfig = async () => {
  const {
    success,
    body
  } = await request(withFront('/startpageConfig'))
  const emptyConfig = {
    basemapPic: '',
    materiaPic: '',
    iconPic: '',
  }
  if (success) {
    console.log(success, body)
    if (body.length > 0) {
      let currentTime = Date.now();
      let config = body.find(el => {
        let start = +new Date(el.startTime)
        let end = +new Date(el.endTime)
        return el.clientType.includes(5) && currentTime >= start && currentTime <= end;
      })
      if (config) {
        loadingConfig = config
        return config
      }
    }
  }
  loadingConfig = emptyConfig
  return emptyConfig
}