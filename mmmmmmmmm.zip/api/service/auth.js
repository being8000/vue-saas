import {
  authLogin
} from "../user"
import {
  getCurrentEnv,
  glifeToken
} from "/env"
import {
  getCurrentCtx
} from "/utils"
import {
  APP_TYPE,
  StorageKey
} from "/utils/const"
import {
  ENV,
  getAccId
} from "/utils/env"
import {
  $cora
} from "/api/service/cora";
import {
  $dialog
} from "/components/v4-dialog"
export let authCode = null
/**
 * js-api 获取AuthCode
 */
export const getAuthCode = () => {
  return new Promise((resolve, reject) => {
    if (authCode) {
      return resolve(authCode)
    }
    my.getAuthCode({
      scopes: 'auth_user',
      success: async (res) => {
        if (res && res.authCode) {
          authCode = res.authCode
          resolve(res.authCode)
        } else {
          resolve(false)
          console.error('auth_user', res)
          // PENDING VERIFIED
          const ctx = getCurrentCtx()
          const result = await $dialog.confirm({
            hideCancelButton: true,
            content: 'GCash Authcode error, please try again.'
          })
          if (result) {
            ctx.relunchApp()
          }
        }
      },
      failed: (res) => {
        resolve(false)
        console.error('auth_user', res)
        my.alert({
          content: res,
        });
      },
    })
  })
}

const log = (...str) => {
  // return // 关闭日志
  console.log('auth', ...str)
}
export const fetchAccessTokenViaAuthCode = () => {
  return new Promise(async (resolve, reject) => {
    let res = false
    let authCode = null
    // debugger
    if (ENV.isLocal()) {
      log('开始获取AuthCode:本地调试')
      res = glifeToken
      authCode = 'local-test'
      resolve(res)
    } else {
      log('开始获取AuthCode')
      authCode = await getAuthCode()
      if (!authCode) {
        log('获取AuthCode失败')
        return resolve(false)
      }
      res = await authLogin({
        authCode: authCode,
        grantType: 'AUTHORIZATION_CODE', //获取token（需要authCode）
      })
    }
    if (res === false) {
      return resolve(false)
      // return false
    }
    /**
     * @type {import("../user").AccessToken['resultBody']['result']}
     */
    const result = !!res ? res.resultBody.result : {}
    if (result.resultStatus === 'S') {
      res.resultBody.authCode = authCode
      res.resultBody.writeTime = Date.now() // 缓存写入时间戳
      log(res)

      setAccessTokenStorage(res)
      resolve(res)
    } else {
      my.showToast({
        type: 'none',
        content: result.resultMessage,
        duration: 3000,
      })
      resolve(false)
    }
  })
}

/**
 * 使用refreshToken刷新accessToken
 * @param {string} refreshToken 
 */
const refreshAccessToken = async (refreshToken = '') => {
  const res = await authLogin({
    refreshToken: refreshToken,
    grantType: 'REFRESH_TOKEN', //获取token（需要authCode）
  })
  if (res === false) {
    return
  }
  /**
   * @type {import("../user").AccessToken['resultBody']['result']}
   */
  const result = !!res ? res.resultBody.result : {}
  if (result.resultStatus === 'S') {
    res.resultBody.writeTime = Date.now() // 缓存写入时间戳
    setAccessTokenStorage(res)
  } else {
    log('无效的refreshToken: 清除现有token缓存')
    removeAccessTokenStorage(res)
    my.showToast({
      type: 'none',
      content: result.resultMessage,
      duration: 3000,
    })
    return false
  }
}

/**
 * @returns { import("../user").AccessToken | false }
 */
export const getAccessTokenFromStore = () => {
  const key = StorageKey.ACCESS_TOKEN + '_' + getCurrentEnv()
  const {
    success,
    data: tokenStorage
  } = my.getStorageSync({
    key: key
  })
  if (success) {
    return tokenStorage
  } else {
    return false
  }
}


export const fetchLatestAccessToken = async () => {
  const accessToken = getAccessTokenFromStore()
  log('accessToken', accessToken)
  log('accessToken', accessToken.resultBody)
  if (accessToken) {
    // 判断缓存是否超过7天，如果超过7天需要重新获取
    const t = accessToken.resultBody.writeTime || 0
    const oneDay = 1000 * 60 * 60 * 24; //一天的毫秒数
    // const oneDay = 2000; //一天的毫秒数
    const compareTimestamp = Number(t) + oneDay * 7
    log('缓存日期', t, new Date(t))
    log('7天后', new Date(compareTimestamp))
    log('是否超过7天', Date.now() > compareTimestamp)
    const expiryTime = new Date(accessToken.resultBody.refreshTokenExpiryTime).getTime()
    log('token过期时间', expiryTime, accessToken.resultBody.refreshTokenExpiryTime)
    if (expiryTime > Date.now()) {
      if (Date.now() > compareTimestamp) {
        log('缓存时间超过7天, token没有过期')
        // 刷新accessToken
        return await refreshAccessToken(accessToken.resultBody.refreshToken)
      } else {
        log('缓存时间小于7天，token没有过期，无需重新获取最新token')
        return true
      }
    } else {
      // 如果refreshtoken过期，直接重新获取
      log('refreshtoken过期，直接重新获取')
      return await fetchAccessTokenViaAuthCode()
    }
  } else {
    // 缓存中没有accessToken 走authCode获取token的流程
    log('缓存中没有accessToken 走authCode获取token的流程')
    return await fetchAccessTokenViaAuthCode()
  }

}


export const setAccessTokenStorage = (data) => {
  const key = StorageKey.ACCESS_TOKEN + '_' + getCurrentEnv()
  my.setStorageSync({
    key: key,
    data: data
  })
}
export const removeAccessTokenStorage = () => {
  const key = StorageKey.ACCESS_TOKEN + '_' + getCurrentEnv()
  my.removeStorageSync({
    key: key,
  })
}