export const $cora = {
  afterLogin(body) {
    const app = getApp()
    my.CORA_SDK.setUserId({
      userId: body.customerId, // 用户的userId
      afId: "", // 额外信息 - 用户的afId
    });
    try {
      let allUrlParams = app && app.allUrlParams || ''
      let customerId = body && body.customerId || ''
      let actionLaunchParams = {
        eventType: 'CUSTOM',
        pageURL: 'pages-start-start', //  必填，如带有附加参数，需要无截断透传 
        launchURL: 'gcash://com.mynt.gcash/app/006300000800?appId=2170020194511181&pid=GLife&' + allUrlParams, // BP链接仅供参考，需要改成自己业务对应的链接
        container: 'MINIAPP',
        bizType: 'GAME_PLUS', // BP链接仅供参考，需要改成自己业务对应的链接
        platform: 'MINIAPP',
        package: 'MINI_GLIFE',
        afAppId: 'com.gp_miniapp', // BP链接仅供参考，需要改成自己业务对应的链接
        packageFullName: 'com.gameplus.miniapp.glife', // BP链接仅供参考，需要改成自己业务对应的链接
        customerId: customerId,
        isGP: true
      }
      my.CORA_SDK.track("ACTION_LAUNCH", actionLaunchParams);
    } catch (e) {
      console.error(e)
    }
  }
}