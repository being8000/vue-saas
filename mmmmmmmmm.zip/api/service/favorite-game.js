import {
  fetchFavoriteGames
} from "../game"
import { createMicroApi } from "/utils/micro-api"

/**
 * @returns {{
 *  startFetch: () => void
 *  isFavorite: (id: Number) => Promise[void]
 *  remove: (id: Number) => Promise[void]
 *  add: (game: import('../stasticJs').GameBaseItem>) => Promise[void]
 * }}
 */
function FavoriteGameFacotry() {
  let resolver = null
  let isFetched = false
  let favoriteGames = new Promise((resolve) => {
    resolver = resolve
  })

  function startFetch() {
    if (!isFetched) {
      fetchFavoriteGames().then((games) => {
        isFetched = true
        resolver(games)
      })
    }
  }
  async function isFavorite(id) {
    const games = await favoriteGames
    return games.findIndex(el => el.id == id) > -1
  }

  async function remove(id) {
    const games = await favoriteGames
    const index = games.findIndex(el => el.id === id)
    if (index > -1) {
      games.splice(index, 1)
      favoriteGames = Promise.resolve(games)
    }
  }
  async function add(game) {
    const games = await favoriteGames
    const index = games.findIndex(el => el.id === game.id)
    if (index === -1) {
      games.splice(index, 0, game)
      favoriteGames = Promise.resolve(games)
    }
  }
  return {
    startFetch,
    isFavorite,
    remove,
    add,
    games: favoriteGames
  }

}

export const favoritor = FavoriteGameFacotry()