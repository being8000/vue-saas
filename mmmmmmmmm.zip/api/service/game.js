import {
  StorageKey
} from '/utils/const';
import {
  useEventBus
} from "/utils/use-event-bus"

/**
 * @zh 游戏是否在维护中
 *
 * @export
 * @param {import('../stasticJs').GameBaseItem} game
 * @return {boolean}  {boolean}
 */
export function isMaintenanceOfGame(game) {
  if (isOtherMaintenanceOfGame(game)) {
    game.maintainStatus = 1 // 常规维护
  } else if (isTimeMaintenanceOfGame(game)) {
    game.maintainStatus = 2; // 区间维护
    setMaintainceDate(game)
  } else {
    game.maintainStatus = 0; // 不维护
  }
}

/**
 * @zh 非时间段游戏维护状态
 *
 * @export
 * @param {import('../stasticJs').GameBaseItem} game
 * @return {*}  {boolean}
 */
function isOtherMaintenanceOfGame(game) {
  return game.flag === 2 || game.platformStatus !== 1
}

/**
 * @zh 时间段维护状态
 *
 * @export
 * @param {import('../stasticJs').GameBaseItem} game
 * @return {*}  {boolean}
 */
function isTimeMaintenanceOfGame(game) {
  const current = Date.now()
  const start = +new Date(game.maintainStartTime)
  const end = +new Date(game.maintainEndTime)
  return current >= start && current <= end
}


/**
 * 根据游戏ID集合找到对应游戏
 * @param {number[]} ids
 * @returns {import('../stasticJs').GameBaseItem[]} 
 */
export const filterGamesByIds = (ids = []) => {
  const allGames = my._jsData[StorageKey.ALL_GAME] || []
  const games = ids.map(id => allGames.find(g => g.id === id)).filter(g => !!g)
  return games
}

/**
 *  获取所有游戏
 * @returns {import('../stasticJs').GameBaseItem[]} 
 */
export const getBaseAllGamse = () => {
  return my._jsData[StorageKey.ALL_GAME] || []
}


/**
 *  根据gameId和platformId查询具体游戏信息
 * @returns {import('../stasticJs').GameBaseItem} 
 */
export const findGameByGameIdAndPlatformId = (gameId = '', platformId = '') => {
  /**
   * @type {import('../stasticJs').GameBaseItem[]} 
   */
  const games = my._jsData[StorageKey.ALL_GAME] || []
  return games.find(game => game.gameId == gameId && game.platformId == platformId)
}

/**
 * 
 * @param {import('../stasticJs').GameBaseItem[]} game 
 */
export const updateGameData = (game) => {
  /**
   * @type {import('../stasticJs').GameBaseItem[]} 
   */
  const allGames = my._jsData[StorageKey.ALL_GAME]
  const index = allGames.findIndex(el => el.id === game.id)
  if (index > -1) {
    my._jsData[StorageKey.ALL_GAME][index] = game
  }
}


function convertArrayToColumns(arr, numRows) {
  const numColumns = Math.ceil(arr.length / numRows); // 计算列数
  const result = Array.from({
    length: numRows
  }, () => []);

  // 按列填充数据
  for (let i = 0; i < arr.length; i++) {
    const row = i % numRows; // 当前行
    result[row].push(arr[i]); // 按行添加元素
  }

  return result;
}
/**
 * 区块显示函数小于3行时
 * @param {import('../stasticJs').GameBaseItem[]} games 
 * @param {number} row 
 */
export function resortingGames(games = [], row) {
  const transformedArray = convertArrayToColumns(games, row)
  return transformedArray
}

/**
 * 如果有维护结束时间，则转换格式
 * @param {*} game
 * @returns
 */
export const setMaintainceDate = (game) => {
  if (!game.maintainEndTime) {
    return;
  }
  const date = new Date(game.maintainEndTime);
  const monthNames = [
    "Jan",
    "Feb",
    "Mar",
    "Apr",
    "May",
    "Jun",
    "Jul",
    "Aug",
    "Sep",
    "Oct",
    "Nov",
    "Dec",
  ];
  const month = monthNames[date.getMonth()];
  const day = date.getDate();
  const hours = date.getHours();
  const minutes = date.getMinutes();
  const ampm = hours >= 12 ? "PM" : "AM";
  const hours12 = hours % 12 === 0 ? 12 : hours % 12;

  game.maintainceDateStr = `${month} ${day} ${hours12}:${minutes
      .toString()
      .padStart(2, "0")} ${ampm}`;
}