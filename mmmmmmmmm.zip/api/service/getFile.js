import pureRequest from '/api/lib/pure-request';
const chacheObj = {}
import parse from "mini-html-parser2";
import {
  processNodes
} from '/utils/index'
export default function (url) {
  return new Promise((resolve, reject) => {
    if (chacheObj[url]) {
      return resolve(chacheObj[url])
    }
    if (!url) {
      return resolve('')
    }
    pureRequest(url, {
        dataType: 'text'
      })
      .then(data => {
        console.log(data)
        parse(data, (err, nodes) => {
          if (err) {
            console.log(err);
          } else {
            const processedNodes = processNodes(nodes);
            console.log('processedNodes', processedNodes)
            chacheObj[url] = processedNodes
            resolve(processedNodes)
          }
        });
      })
  })
}