import {
  filterGamesByIds, resortingGames
} from './game';
import flat from 'loadsh/flatten'
import {
  StorageKey
} from '/utils/const';
import { layoutCodeMap } from '../stasticJs';

// 不能存Storage 数据大概率超过 200K
function mockStorageFn() {
  let storage = {}
  return function () {
    return {
      set(key, data) {
        storage[key] = data
      },
      get(key) {
        return storage[key]
      }
    }
  }
}


export const normalizeHomeTabJSON = () => {
  const blockList = my._jsData[StorageKey.BLOCK_CONFIG]
  // console.log('blockList', blockList)
  const promiseAllFn = []
  if (blockList && blockList.length > 0) {
    my._jsData[StorageKey.NORMALIZED_BLOCK_CONFIG] = blockList.map((el, idx1) => {
      let code = el.pagination.toLowerCase()
      const blockConfig = el.blockConfig || []
      el.blockConfig = blockConfig.map((config, idx2) => {
        if(config.type == 1){
          const _games = filterGamesByIds(config.gameIndexIds || [])
          const normalGames = _games.filter(game => !game.isMaintaining)
          const maintainingGames = _games.filter(game => game.isMaintaining)
          config._games = [...normalGames, ...maintainingGames]
          const promiseFn = () => {
            return new Promise((resolve, reject) => {
              const _games = filterGamesByIds(config.gameItemsIds || [])
              const normalGames = _games.filter(game => !game.isMaintaining)
              const maintainingGames = _games.filter(game => game.isMaintaining)
              my._jsData[StorageKey.NORMALIZED_BLOCK_CONFIG][idx1].blockConfig[idx2]._viewAllGames = [...normalGames, ...maintainingGames]
              resolve()
            })
          }
          promiseAllFn.push(promiseFn)
        }
        layoutCodeMap[code] = config
        return config
      })
      return el
    })
    // my.setStorageSync({
    //   key: StorageKey.NORMALIZED_BLOCK_CONFIG,
    //   data: newList
    // })
    // 异步填充更新viewAll数据
    const t = setTimeout(() => {
      clearTimeout(t)
      Promise.all(promiseAllFn.map(fn => fn()))
    }, 100)
    my._jsData[StorageKey.BLOCK_CONFIG] = blockList
  }
}
/**
 * @typedef {{
 *   blockConfig: {
 *   blockName: string
 *   blockPic: string
 *   themePic: string
 *   clientType: string
 *   endTime: string
 *   gameIndexIds: number[]
 *   gameItemsIds: number[]
 *   games: CasinoGame[]
 *   id: number
 *   pagination: string
 *   productId: string
 *   productName: string
 *   remark: string
 *   rowStyle: number
 *   columnStyle: number
 *   showViewAll: number // 是否显示view all 按钮 1否 2是 
 *   sort: number
 *   startTime: string
 *   status: number
 *   updateTime: string
 *   updater: string
 *   _games: import('../stasticJs').GameBaseItem[] // 处理过后的游戏列表
 *   _viewAllGames: import('../stasticJs').GameBaseItem[] // 处理过后的ViewAll游戏列表
 *  }[]
 *   categoryIdFirst: number
 *   conH5: string
 *   conPc: string
 *   conPcHide: string
 *   pagination: string
 *   sortH5: number
 *   type: number // 0 游戏区块 1 banner区块 3 自定义组件区块
 * }} BlockConfig
 */
/**
 * @returns {BlockConfig[]}
 */
export const getNormalizedBlockData = () => {
  return my._jsData[StorageKey.NORMALIZED_BLOCK_CONFIG]
}

/**
 * @return {{
 *  GLIFE_JUMP_TIP_SWITCH: string, // 跳出Gcash是否需要弹窗提醒开关
 *  GLIFE_PERSONAL_INFO_SWITCH: string,  // 是否KYC验证开关
 *  GAMEPLUS_GAME_JSON: string,  // H5 游戏列表接口地址
 *  HOT_GAME_JSON: string, // 热门游戏
 *  PROMOTION_JSON: string, //promotion banner
 *  TCC_MATCH_ENTRY_JSON: string,  //TTC入口
 *  BLOCK_CONFIG_JSON: string, // 首页区块json
 *  GAME_JSON: string, // 所有基础游戏KEY
 *  BANNER_JSON: string, // 系统关于所有tab的banner配置
 *  STORE_WEBSITE_EVENT_JSON: string, // 弃用，老板活动列表json
 *  GLIFE_AGE_CONFIRM_SWITCH: string, // 跳转h5时是否改为年龄提示的弹窗
 *  GLIFE_SENSORS_URL: string, //神策接收地址
 * }}
 */
export const getSiteInfoFromStorage = () => {
  return my.getStorageSync({
    key: StorageKey.SITE_INFO,
  }).data || {}
}


/**
 * @returns {import('../stasticJs').PromotionItem[]}
 */
export const getTCCInfo = () => {
  return my._jsData[StorageKey.TCC_INFO] || []
}

/**
 * @returns {import('../stasticJs').PromotionItem[]}
 */
export const getPromotions = () => {
  return my._jsData[StorageKey.PROMOTIONS] || []
}

/**
 * @returns {import('../stasticJs').PromotionItem[]}
 */
export const getBannerList = () => {
  return my._jsData[StorageKey.BANNER_JSON] || []
}

/**
 * @returns {import('../stasticJs').PromotionItem[]}
 */
export const getSpokesperson = () => {
  return my._jsData[StorageKey.SPOKESPERSON_JSON] || []
}

/**
 * 获取 Banner All 分页
 * @returns {import('../stasticJs').PromotionItem[]}
 */
export const getHomeTopBanner = () => {
  return my._jsData[StorageKey.BANNER_JSON] || []
}

/**
 * 
 * @param {*} tab 
 */
export const findAllGamesOfTab = (tab) => {
  const blockInfo = getNormalizedBlockData()
  const currentBlock = blockInfo.find(block => String(block.pagination).toLowerCase() === String(tab).toLowerCase())
  if (currentBlock) {
    const allGames = [...new Set(flat(currentBlock.blockConfig.map(item => item.gameItemsIds)))]
    return filterGamesByIds(allGames)
  }
  return []
}

/**
 * @returns {import('../stasticJs').PromotionItem[]}
 */
export const getAllGames = () => {
  return my._jsData[StorageKey.ALL_GAME] || []
}
