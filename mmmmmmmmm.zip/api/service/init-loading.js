/**
 * 首次加载请求的接口顺序服务类
 */

import {
  fetchSiteInfo,
  fetchWebtoken
} from "..";
import {
  fetchAppAllGames,
  fetchDisableLobbyLabel,
  fetchHomeBlockConfig,
  fetchHomePromotion,
  fetchHomeTopBanner,
  fetchTCCInfo
} from "../stasticJs";
import {
  fetchLatestAccessToken
} from "./auth";
import {
  normalizeHomeTabJSON
} from "./home-block-config";
import {
  setUpDeviceId
} from "/utils/device-id";
import {
  getAuthCode
} from "/utils/env";
import {
  useEventBus
} from "/utils/use-event-bus";

/**
 * progress  0-100 标识加载百分比进度
 * on
 */
export const loadingBus = useEventBus('app-init-data-fetching-progress')

export const LoadingError = {
  AuthFailed: 'AuthFailed'
}

export const LoadingBusType = {
  STEP2: 'STEP2'
}


// 加载进度
let loadingPercentage = 0
let progressMap = {
  step1: false,
  step2
}

function updateProgress(percent = 0) {
  loadingPercentage = percent
  loadingBus.emit('progress', loadingPercentage)
}
/**
 * 第一步为全局必要数据处理
 *  - 获取AuthCode
 * - 获取webtoken
 * - webtoken校验
 * - 获取设备指纹ID
 * - 获取 SiteInfo
 */
export function startStep1() {
  return new Promise((resolve) => {
    updateProgress(20)
    Promise.all([
      getAuthCode(),
      setUpDeviceId(),
      fetchSiteInfo(),
      fetchWebtoken(isValidToken),
    ]).then(([authCode]) => {
      console.log('startStep1', authCode)
      if (!authCode) {
        loadingBus.emit('onError', LoadingError.AuthFailed)
        return resolve(false)
      }
      setp1Res = true
      updateProgress(50)
      loadingBus.emit('onStep1', 'DONE')
      return resolve(true)
    }).finally(el => {
      // 兼容如果 p1全部没有resove
      loadingBus.emit('onStep1', 'DONE')
      return resolve(true)
    })
  })
}
/**
 * Promise.all([
    fetchLatestAccessToken(),
    fetchHomeBlockConfig(),
    fetchAppAllGames(),
    fetchHomeTopBanner(),
    fetchTCCInfo(),
    fetchHomePromotion(),
    fetchDisableLobbyLabel()
  ])
 */
let step2PromiseEvents = Promise.resolve()
function startStep2() {
  let step2Res = false
  updateProgress(60)
  step2PromiseEvents.then(el => {
    step2Res = true
    // normalizeHomeTabJSON()
    updateProgress(80)
    loadingBus.emit('onStep2', 'DONE')
  }).finally(el => {
    // if (!step2Res) {
    //   normalizeHomeTabJSON()
    // }
    updateProgress(80)
    loadingBus.emit('onStep2', 'DONE')
  })
}


export function startHomeLoading() {

}
function isPromise(value) {
  return value && typeof value.then === 'function';
}
// 绑定页面对象到Loading
export function gzLoaindBind(page, configEventsPromise, callback) {
  if(isPromise(configEventsPromise)){
    step2PromiseEvents = configEventsPromise
  }
  if (page) {
    page.setData({
      loadingCover_Visible: true,
      loadingCover_Progress: loadingPercentage,
    })
  }
}