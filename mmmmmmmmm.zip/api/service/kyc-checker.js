
import { fetchUserDetails } from "../user"
import { getSiteInfoFromStorage } from "./home-block-config"
import { $dialog } from "/components/v4-dialog"
import { navigateToH5 } from "./navigate-to-h5"
import { getUserInfo } from "/utils"

export const typeMaps = { // 定义检查Kyc用户交互操作类型集合
  Game: 0, // 点击游戏
  Withdraw: 1, // 点击提现
  Deposit: 2, // 点击充值
}

// 返回是否是7天内注册的用户
export function is7days(now) {
  const {
    createdDate
  } = getUserInfo()
  const oneDayTimestamp = 1000 * 60 * 60 * 24
  console.log(createdDate, '注册日期')
  return (Number(now) - 7 * oneDayTimestamp) < new Date(createdDate).getTime()
}

let isKycStore = false // 用来存储KYC认证状态，如果认证过的用户后续无需再次请求

export let isFirstDepositFlag = true // 是否首存 false代表没有首存
export const refreshIsFirstDepositFlag = async () => {
  if (isFirstDepositFlag) return Promise.resolve()
  const {
    firstDepositFlag
  } = await fetchUserDetails(true)
  isFirstDepositFlag = firstDepositFlag
}
export const setFirstDepositFlag = (flag) => {
  isFirstDepositFlag = flag
}
/** 
 * 判断用户是否KYC认证过
 */
export async function isKYC() {
  if (isKycStore) {
    return isKycStore
  }
  const userDetail = await fetchUserDetails()
  const {
    firstName,
    // middleName,
    lastName,
    birthday,
    nationality,
    birthPlace,
    presentAddress,
    permanentAddress,
    sourceOfIncome,
    work,
    employerName,
    firstDepositFlag
  } = userDetail
  isFirstDepositFlag = firstDepositFlag
  const bool = !!firstName &&
    !!lastName &&
    !!birthday &&
    !!nationality &&
    !!birthPlace &&
    !!presentAddress &&
    !!permanentAddress &&
    !!sourceOfIncome &&
    !!work &&
    !!employerName
  isKycStore = bool
  // 检查用户是否完成KYC认证：除了 middlename 其他字段有一个为空就是未完成
  return bool
}

/**
 * 返回是否需要进行 游戏/充值/提现 的弹窗提示
 * @param {*} type 
 * @return { Promise<boolean> } true 要 , false 不用
 */
export async function checkKycPop(type) {
  const _isKyc = await isKYC()
  // kyc 优先级最高，如果已经验证，则无需进行后续判断
  if (_isKyc) {
    return false
  }
  const siteInfo = getSiteInfoFromStorage()
  // 获取开关 1 需要认证， 不等 1 不需要
  if (siteInfo.GLIFE_PERSONAL_INFO_SWITCH == 1) {
    if (type == typeMaps.Game) {
      // 注册时间小于7天可以进行游戏和充值
      return is7days() ? false : true
    } else if (type == typeMaps.Deposit) {
      // 注册时间小于7天可以进行游戏和充值
      return is7days() ? false : true
    } else if (type == typeMaps.Withdraw) {
      // 需要KYC认证才能提现
      return true
    } else {
      return true
    }
  } else {
    return false
  }

}

export async function beforeGameCheck() {
  const show = await checkKycPop(typeMaps.Game)
  if (show) {
    const res = await $dialog.confirm({
      content: 'You must complete KYC to continue playing!'
    })
    if (res) {
      //  跳转H5个人中心
      navigateToH5('/account')
      return false
    }
  }
  return true
  // return {
  //   show,
  //   text: 'You must complete KYC to continue playing!'
  // }
}
export async function beforeDepositCheck() {
  const show = await checkKycPop(typeMaps.Deposit)
  if (show) {
    const res = await $dialog.confirm({
      content: 'You must complete KYC to continue playing!'
    })
    if (res) {
      //  跳转H5个人中心
      navigateToH5('/account')
      return false
    }
  }
  return true
  // return {
  //   show,
  //   text: 'You must complete KYC to continue playing!'
  // }
}
export async function beforeWithdrawCheck() {
  const show = await checkKycPop(typeMaps.Withdraw)
  return {
    show,
    text: ''
  }
}