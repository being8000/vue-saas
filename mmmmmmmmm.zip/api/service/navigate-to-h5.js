import {
  jsonToStr,
  strToJson,
} from "../../utils"
import {
  CUSTOM_APP_ID,
  FROM_MINI,
  MINI_APP_ID
} from "../../utils/const";
import {
  getAccId,
  getBaseUrl
} from "../../utils/env";
import { getUserInfo } from "../user";
import {
  getSiteInfoFromStorage
} from "./home-block-config";
import {
  beforeGameCheck
} from "./kyc-checker";
import {
  $dialog
} from "/components/v4-dialog";
import {
  $ageDialog
} from "/components/v4-dialog-age-confirm";


const withPublicNavigateParams = (params = {}) => {
  const {
    customerId,
    loginName
  } = getUserInfo();
  const tokenInfo = my.getStorageSync({
    key: 'isInfo'
  }).data
  const urlParams = {
    ...params,
    isInfo: tokenInfo,
    loginName: loginName,
    customerId: customerId,
    palcode: getAccId(),
    isFrom: 'Glife',
    fromMini: FROM_MINI,
  }
  let url = getBaseUrl()
  const urlPramsStr = Object.keys(urlParams).map(key => `${key}=${urlParams[key]}`).join('&')
  url = url + `/mini?${urlPramsStr}`
  const res = my.CORA_SDK.getJumpH5Params()
  if (res) {
    url += "&" + res;
  }
  console.log('navigate-to-h5', url)
  return url
}

const leavingPopUp = async () => {
  const siteInfo = getSiteInfoFromStorage()
  if (siteInfo.GLIFE_JUMP_TIP_SWITCH == '1') {
    if (siteInfo.GLIFE_AGE_CONFIRM_SWITCH == '1') {
      return $ageDialog.confirm()
    } else {
      return $dialog.confirm({
        content: 'You are now leaving the GCash app. GCash is not responsible for any content or transactions on this website. We advise you to never share your GCash MPIN and OTP'
      })
    }
  } else {
    return true
  }
}
/**
 * 跳转到H5指定游戏
 * @param {{
 *  gameId: string, // 游戏ID
 *  platformId: string, // 厅方ID
 *  jumpJson?: string // 进厅额外json参数
 * }} params 
 * }
 */
export const navigateToGame = async function (params = {}) {
  const {
    gameId = '',
    platformId = '',
    jumpJson = '',
  } = params
  if (!gameId || !platformId) {
    return console.error('gameId 和 platformId不能为空')
  }
  const valid = await beforeGameCheck()
  if (valid) {
    // 跳转Gcash外部之前，弹框确认
    const leaveingConfirm = await leavingPopUp()
    if (!leaveingConfirm) {
      return
    }
    if (jumpJson) {
      const jsonStr = jsonToStr(strToJson(jumpJson, {}), '{}')
      params.jumpJson = jsonStr
    }
    const url = withPublicNavigateParams({
      gameId,
      platformCode: platformId,
      jumpJson: encodeURIComponent(params.jumpJson)
    })
    my.call("navigateToLink", {
      targetLink: url,
      appId: MINI_APP_ID,
      success: (res) => {
        // my.alert({ content: JSON.stringify(res) });
        // NOTE 这里无需将游戏添加到历史记录，H5那边已经处理了
        // if (params && params.gameId && params.platformId) {
        //   _this.addGameToHistory(params);
        // }
      },
      fail: async (res) => {
        my.alert({
          content: JSON.stringify(res),
        });
      },
    });
  }

}


/**
 * 跳转到H5指定页面或打开功能
 * @param { string } path 跳转路径
 * / 首页
 * /vip 
 * /promotion
 * /account
 * /accout/kyc
 * CS  客服
 */
export const navigateToH5 = async function (path = '/') {
  // 跳转小程序内部页
  // 后台配置地址需要以 mini:/pages/carnival/carnival
  if (path.startsWith('mini:')) {
    console.log(path.replace(/^mini:/, '').replace(/\s/g, ''))
    my.navigateTo({
      url: path.replace(/^mini:/, '').replace(/\s/g, '')
    })
    return
  }
  // 跳转Gcash外部之前，弹框确认
  const leaveingConfirm = await leavingPopUp()
  if (!leaveingConfirm) {
    return
  }
  const url = withPublicNavigateParams({
    target: path
  })
  my.call("navigateToLink", {
    targetLink: url,
    appId: MINI_APP_ID,
    success: (res) => { },
    fail: async (res) => {
      my.alert({
        content: JSON.stringify(res),
      });
    },
  });
}