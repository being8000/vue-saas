import { fetchSiteInfo } from "/api"

let app = null

export const ensureApp = () => {
  return app ? app : (app = getApp())
}



/**
 * 读取站点配置信息
 */
let siteInfo = null
export const getSiteInfo = async () => {
  if (siteInfo != null) {
    return siteInfo
  }
  const _siteInfo = await fetchSiteInfo()
  if(_siteInfo){
    const {
      GLIFE_JUMP_TIP_SWITCH = '', // 跳出Gcash是否需要弹窗提醒开关
      GLIFE_PERSONAL_INFO_SWITCH = '', // 是否KYC验证开关
      GAMEPLUS_GAME_JSON = '', // H5 游戏列表接口地址
      // GAME_JSON = '', // H5 游戏列表接口地址
      HOT_GAME_JSON = '', // 热门游戏
      BANNER_JSON = '', // banner
      PROMOTION_JSON='',//promotion banner
      TCC_MATCH_ENTRY_JSON = '', //TTC入口
      BLOCK_CONFIG_JSON = '', // block
      GAME_JSON = '', // base
      STORE_WEBSITE_EVENT_JSON = '', // 活动
      GLIFE_AGE_CONFIRM_SWITCH = '', // 跳转h5时是否改为年龄提示的弹窗
    } = _siteInfo || {}
    siteInfo = {
      GLIFE_AGE_CONFIRM_SWITCH,
      GLIFE_JUMP_TIP_SWITCH,
      GLIFE_PERSONAL_INFO_SWITCH,
      TCC_MATCH_ENTRY_JSON,
      GAMEPLUS_GAME_JSON: `staticJs/gpgame/MINI${GAMEPLUS_GAME_JSON}.js`, // 新版游戏获取接口
      HOT_GAME_JSON: `staticJs/gpgame/MINI${HOT_GAME_JSON}.js`, // 新版游戏获取热门游戏
      BANNER_JSON: `staticJs/gpbanner/MINI${BANNER_JSON}.js`, // 新版游戏获取banner
      STORE_WEBSITE_EVENT_JSON: `staticJs/gpstorewebsite/GPStorewebsite_${STORE_WEBSITE_EVENT_JSON}.js`, // v3的banner改成了活动
      PROMOTION_JSON: `MINI_GP_promotion_${PROMOTION_JSON}`,
      // GAME_JSON: `staticJs/gpgame/game_GPh5_all_${GAME_JSON}.js`, // 老板游戏获取接口
      GAME_JSON: `staticJs/gpgame/game_base_all_${GAME_JSON}.js`, // v3 新版base游戏接口
      BLOCK_CONFIG_JSON: `staticJs/gpgame/GP_MINI_block_game_${BLOCK_CONFIG_JSON}.js`, // v3区块游戏接口
      PROMOTION_JSON_NEW: `MINI${PROMOTION_JSON}`,
      BANNER_JSON_NEW: `staticJs/gpbanner/MINI${BANNER_JSON}.js`,
    }
  }
  return siteInfo
}

let bannerList = null
export const getBanner = async ()=>{
  if(bannerList)return bannerList
  let result = await getSiteInfo();
  let url = `${result.BANNER_JSON_NEW}`
  let res = await app._request(
    url, {
      productName: "GP",
    }, {},
    "/",
    "GET"
  )
  let data = Array.isArray(res) ? res : []
  data = data.sort((a, b) => b.sort - a.sort)
    .filter((banner) => {
      if (banner.showPage != 0) return false
      const startTime = +new Date(banner.startTime)
      const endTime = +new Date(banner.endTime)
      const now = Date.now()
      if (!(now >= startTime && now <= endTime)) {
        return false
      }
      return true
    })
  bannerList = data
  return data
}