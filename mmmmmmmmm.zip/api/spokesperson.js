import {
  withActivity
} from './lib/utils'
import request from './lib/request'
/**
 * 取消收藏
 * @param {{
 *  gameId: string,
 *  platformCode: string
 * }} data 
 */
export const requestEndorserStatus = (data = {tenant:'GP'}) => {
  return request(withActivity('/endorser/status'), {
    body: data,
  })
}