import pureRequest from "./lib/pure-request"
import request from './lib/request';
import {
  withStaticJs,
  withFront
} from "./lib/utils"
import {
  isMaintenanceOfGame
} from "./service/game"
import {
  getSiteInfoFromStorage
} from "./service/home-block-config"
import {
  StorageKey
} from "/utils/const"

import {
  getGameImgFullPath
} from "/utils/game"

/**
 * 经过自己调试，发现大部分静态资源js，在真机环境存入缓存会报错，原因未知。所以放弃本地缓存策略 
 */

my._jsData = {
  allGameMap: {}
}
export const getOriginList = () => {
  return my._jsData[StorageKey.BLOCK_CONFIG] || []
}

export const getBaseAllGame = () => {
  return my._jsData[StorageKey.ALL_GAME] || []
}
export let layoutCodeMap = {}
export const getLayoutCodeMap = () => {
  let originList = getOriginList()
  originList.forEach(e => {
    let code = e.pagination.toLowerCase()
    if(e.type == 0){
      e.blockConfig.forEach(e => {
        e.gameIndexIds = e.gameIndexIds.slice(0, 18)
        // e.customBlockGames = e.gameIndexIds.slice(0,18).map(gameId=>(findGameByGameId(gameId)))
      })
    }
    layoutCodeMap[code] = e.blockConfig
  })
  return layoutCodeMap
}

/**
 * @returns {import('./stasticJs').GameBaseItem} 
 */
export const findGameByGameId = (gameId) => {
  return my._jsData.allGameMap[gameId] || {}
}
export const findGameByGame2Ids = (platformId, gameId) => {
  return my._jsData.allGameMap[platformId + '&' + gameId] || {}
}
/**
 * 封装一个公用的请求js资源数据方法, 不暴露
 * 带有backup功能
 * @param {*} url 
 * @param {*} storageKey 
 */
const fetchJsWithBackup = async (url, storageKey = '') => {
  // 先去缓存里面的key找一下是否key有更新，如果没有更新直接从缓存里面拿数据，不需要请求接口
  const version_KEY = storageKey + '_VERSION'
  // if (storageKey) {
  //   const {
  //     success,
  //     data
  //   } = my.getStorageSync({
  //     key: version_KEY
  //   })
  //   if (success && data) {
  //     if (url === data) { // 如果相等说明key值不变，则无需请求接口，从缓存中拉取数据
  //       // const {
  //       //   success,
  //       //   data
  //       // } = my.getStorageSync({
  //       //   key: storageKey
  //       // })
  //       if (success && data) {
  //         console.log('版本一致，从缓存中取数据：', url, data)
  //         return data
  //       }
  //     }
  //   }
  // }
  let data = await pureRequest(withStaticJs(url), {
    method: 'GET'
  })
  if (!data) {
    // siteinfo中的key请求失败，使用bakcupurl请求
    const backurl = url.replace(/(.*)_.*/, '$1.js?t=' + Date.now())
    data = await pureRequest(withStaticJs(backurl), {
      method: 'GET'
    })
  }
  // 如果有数据
  if (data) {
    my.setStorageSync({
      key: version_KEY,
      data: url
    })
  }
  return data
}


/**
 * 获取首页区块展示内容数据
 */
export const fetchHomeBlockConfig = async () => {
  const siteInfo = getSiteInfoFromStorage()
  const key = siteInfo.BLOCK_CONFIG_JSON
  if (key) {
    const url = `/gpgame/GP_MINI_block_game_all_${key}.js`
    const data = await fetchJsWithBackup(url, StorageKey.BLOCK_CONFIG)
    if (data) {
      // 过滤当前时间段
      const validData = data.map(el => {
        el.blockConfig = (el.blockConfig || []).filter(
          (el) =>
          +new Date(el.startTime) < Date.now() &&
          +new Date(el.endTime) > Date.now()
        )
        return el
      })
      my._jsData[StorageKey.BLOCK_CONFIG] = validData
      getLayoutCodeMap()
      return validData
    } else {
      return my._jsData[StorageKey.BLOCK_CONFIG] || []
    }
  }
}


/**
 * 获取首页轮播Promotion数据
 * @returns {PromotionItem[] | undefined}
 */
export const fetchHomePromotion = async () => {
  const siteInfo = getSiteInfoFromStorage()
  const key = siteInfo.PROMOTION_JSON
  if (key) {
    const url = `/gpstorewebsite/MINI${key}.js`
    const data = await fetchJsWithBackup(url, StorageKey.PROMOTIONS)
    if (data) {
      // 过滤当前时间段
      const validData = (data || []).filter(
        (el) =>
        el.status == 1 &&
        +new Date(el.startTime) < Date.now() &&
        +new Date(el.endTime) > Date.now()
      ).sort(function (a, b) {
        return b.sort - a.sort
      })
      my._jsData[StorageKey.PROMOTIONS] = validData
      return validData
      // my.setStorageSync({
      //   key: StorageKey.PROMOTIONS,
      //   data: JSON.parse(JSON.stringify(validData))
      // });
    } else {
      return my._jsData[StorageKey.PROMOTIONS] || []
    }
  } else {
    return false
  }
}
/**
 * @typedef {{
 * id: any //主键id
 * title: string //Promo标题
 * clientType: string //应用端 1.PC 2.H5 3.ANDROID 4.IOS 5.小程序
 * status: number //选择该配置是否启用 1.启用 2.禁用 3.删除
 * startTime: string //开始时间
 * endTime: string //结束时间
 * sort: number //排序
 * imgUrl: string //上传该Promo的 封面资源图片
 * content: string //正文内容
 * buttonContent: string //按钮文案
 * skipType: LinkToEnum //1.站内页面 2.站外页面 3.进入游戏
 * skipUrl: string //跳转链接
 * platformCode: string //厅方编号
 * gameId: string //游戏编号
 * remark: string //备注
 * jsonParam: string //跳转参数
 * seoTitle: string //SEO标题
 * seoDescribe: string //SEO描述
 * seoKeyword: string //SEO关键词
 * productId: string //产品id
 * productName: string //产品编号
 * updateName: string //更新用户
 * createTime: Date //创建时间
 * updateTime: Date //更新时间
 * parsecontent: object
 *} PromotionItem
 */

/**
 * @typedef {{
 * flag: number // 游戏状态 2 维护中
 * gameDesc: string
 * gameId: string // 调用inGame接口 gameId 参数
 * gameImage: string // 游戏图片
 * gameImageNew: string // 新版游戏图片
 * gameImageBig: string // 游戏大图
 * gameType: string // 游戏类型
 * gdGameId: string
 * id: number
 * jsonParam: string // 调用inGame接口 jumpParam 参数
 * maintainEndTime: string // 维护开始时间
 * maintainStartTime: string // 维护结束时间
 * nameEn: string // 游戏英文名
 * nameZh: string
 * operatingTime: string
 * operator: string
 * overlayColor: string
 * platformId: string // 平台/厅方/游戏提供商ID， 调用inGame接口 platformCode参数
 * platformName: string // 平台/厅方/游戏提供商名称
 * platformStatus: number //（平台/厅方/游戏提供商）维护状态， 不等1的时候为维护中
 * screenFlag: number
 * sortNo: number // 排序号，查询游戏的时候默认需要降序处理
 * vid?: string
 * gmtype?: string
 * jackpotShowFlag: number // 是否在游戏页面显示luckySpin（jackport转盘）挂件，
 * isFavorite: number // 是否收藏游戏 1 是 0 否
 * jackpotFlag: number // 是否jackport 1 是 0 否
 * pvpFlag: number // 是否为PVP 游戏 1 是 0否
 * hotFlag: number // 是否为热门游戏  1: 是 0 否
 * newFlag: number // 是否为新游戏 1: 是 0 否
 * ggr: number // 游戏热度统计值
 * isMaintaining: number // true 维护中 1 正常状态
 * }} GameBaseItem 
 */


export let allGames = []
/**
 * 获取所有基础游戏数据
 *
 */
export const fetchAppAllGames = async () => {
  const siteInfo = getSiteInfoFromStorage()
  const key = siteInfo.GAME_JSON
  if (key) {
    const url = `/gpgame/game_base_all_${key}.js`
    // const res = await fetchJsWithBackup(url, StorageKey.ALL_GAME)
    const res = await fetchJsWithBackup(url, StorageKey.ALL_GAME)
    console.log('res', res)
    res.data = (res.data || []).map(game => {
      isMaintenanceOfGame(game)
      game._gamePreImage = getGameImgFullPath(game)
      my._jsData.allGameMap[game.id] = game
      my._jsData.allGameMap[game.platformId + '&' + game.gameId] = game
      return game
    })
    if (res && res.data) {
      allGames = res.data
      my._jsData[StorageKey.ALL_GAME] = res.data
      return res
    } else {
      return my._jsData[StorageKey.ALL_GAME] || []
      // return my.getStorageSync({
      //   key: StorageKey.ALL_GAME,
      // }).data;
    }
  } else {
    return false
  }
}

/**
 * 获取首页banner的第一张 ，用于首页顶部显示
 */
export const fetchHomeTopBanner = async () => {
  const siteInfo = getSiteInfoFromStorage()
  const key = siteInfo.BANNER_JSON
  if (key) {
    const url = `/gpbanner/MINI${key}.js`
    const data = await fetchJsWithBackup(url, StorageKey.BANNER_JSON)
    if (data) {
      // 过滤当前时间段
      let validData = Array.isArray(data) ? data : []
      validData = validData.filter((banner) => {
        if (banner.showPage != 0) return false
        const startTime = +new Date(banner.startTime)
        const endTime = +new Date(banner.endTime)
        const now = Date.now()
        if (!(now >= startTime && now <= endTime)) {
          return false
        }
        return true
      }).sort((a, b) => b.sort - a.sort)
      my._jsData[StorageKey.BANNER_JSON] = validData
      console.log(validData, 'validData')
      my.setStorageSync({
        key: StorageKey.BANNER_JSON,
        data: JSON.parse(JSON.stringify(validData))
      });
    } else {
      return my._jsData[StorageKey.BANNER_JSON]
    }
  } else {
    return false
  }
}

/** @enum */
export const LinkToEnum = {
  None: 'None',
  Internal: 1, //  站内页面
  External: 2, // 站外页面
  ToGame: 3, // 跳转游戏
}


/**
 * 获取TCC赛事 JS数据
 * @returns {PromotionItem[] | undefined}
 */
export const fetchTCCInfo = async () => {
  const siteInfo = getSiteInfoFromStorage()
  const key = siteInfo.TCC_MATCH_ENTRY_JSON
  if (key) {
    const url = `/gpstorewebsite/MINI${key}.js`
    const data = await fetchJsWithBackup(url, StorageKey.BANNER_JSON)
    if (data) {
      // 过滤当前时间段
      let validData = Array.isArray(data) ? data : []
      validData = validData.filter((item) => {
        const startTime = +new Date(item.startTime)
        const endTime = +new Date(item.endTime)
        const now = Date.now()
        if (!(now >= startTime && now <= endTime)) {
          return false
        }
        return true
      }).sort((a, b) => b.sort - a.sort)
      my._jsData[StorageKey.TCC_INFO] = validData
      return validData
    } else {
      return my._jsData[StorageKey.TCC_INFO]
    }
  } else {
    return false
  }
}

/**
 * 获取代言人js的文件
 * @returns {PromotionItem[] | undefined}
 */
export const fetchSpokespersonInfo = async () => {
  const siteInfo = getSiteInfoFromStorage()
  const key = siteInfo.ENDORSER_JSON
  if (key) {
    const url = `/gpbanner/MINI${key}.js`
    const data = await fetchJsWithBackup(url, StorageKey.SPOKESPERSON)
    if (data) {
      console.log(data, 'data112233')
      my._jsData[StorageKey.SPOKESPERSON_JSON] = data
    }
  } else {
    return false
  }
}