import request from "./lib/request"
import {
  withGlaxy,
  withFront
} from "./lib/utils"
import {
  StorageKey
} from "/utils/const"

/** 
 *  @typedef {{
 *  resultBody: {
 *    accessTokenExpiryTime: string,
 *    result: {
 *      resultStatus: 'S' | 'U' | 'F',
 *      resultCode: string,
 *      resultMessage: string,
 *    },
 *    refreshTokenExpiresIn: string,
 *    accessTokenExpiresIn: string,
 *    customerId: string, // 用户唯一ID
 *    accessToken: string, // accessToken
 *    extendInfo: string, // accessToken
 *    refreshTokenExpiryTime: string, // accessToken
 *    accessToken: string, // accessToken
 *    refreshToken: string // refreshToken
 *    writeTime: number // 添加缓存写入时间戳，用于下次判断是否超过7天，如果超过需重新获取
 *    authCode?: string // 手动加上的authCode， 接口中用于checkBindV4中新用户注册的使用用到
 *  }} AccessToken 
 **/
/**
 * 用户授权登入
 * @return { Promise<AccessToken | false>}
 */
export const authLogin = async (params = {}) => {
  /**
   * @type {{
   *  body: AccessToken
   * }}
   */
  const {
    success,
    body,
    head
  } = await request(withGlaxy('/applets/auth'), {
    body: params,
    auth: false
  })
  if (success) {
    return body
  }
  return false
}


/**
 * 用户授权登入
 */
export const checkBindV4 = async (params = {}) => {
  return request(withGlaxy('/applets/checkBindV4'), {
    body: params,
    auth: false
  })
}


/**
 * @typedef {{
 *   activation: boolean;
 *   agentFlag: boolean;
 *   birthday: string; // Brithday
 *   blackFlag: number;
 *   cashCredit: number;
 *   city: string;
 *   customerId: string; // 用户ID
 *   nickName?: string; // 用户nickname
 *   customerLevel: number;
 *   customerType: number;
 *   firstDepositFlag: boolean; // false 没有首存过 / true 首存过
 *   firstIdStatus: string; // 判断kyc是否完成 0 Review 1 Approved 2/3 Failed
 *   firstName: string; // First Name
 *   gameCredit: number;
 *   gender: string;
 *   glife: boolean;
 *   headShot: string;
 *   isBlackList: number; // 是否是黑名单，如果是黑名单不让进入游戏，提示 Maintenance in progress
 *   isLazada: boolean;
 *   lastLoginDate: string;
 *   lastName: string; // Last Name
 *   loginName: string;
 *   middleName: string;
 *   loginNameFlag: number;
 *   loginPwdFlag: boolean;
 *   marginSwitch: boolean;
 *   mayaFlag: boolean;
 *   mobileNo: string;
 *   nationality: string; // Nationality
 *   newWalletFlag: number;
 *   oddsType: number;
 *   onlineBet: boolean;
 *   personalInfoTag: boolean;
 *   product: number;
 *   registDate: string;
 *   registerMethod: string;
 *   silentPhotoSwitch: boolean;
 *   vipLevel: number;
 *   whiteListUser: boolean;
 *   withdrewPwd: boolean;
 *   permanentAddress: string;
 *   work: string;
 *   employerName: string;
 *   sourceOfIncome: string;
 *   birthPlace: string;
 *   presentAddress: string;
 *   bindFacebook: {
 *     accessToken: string;
 *     bindStatus: string;
 *     bindType: string;
 *     createdBy: string;
 *     createdDate: string;
 *     id: string;
 *     infoPhone: string;
 *     lastUpdate: string;
 *     lastUpdatedBy: string;
 *     loginName: string;
 *     nickName: string;
 *     productId: string;
 *     unionId: string;
 *   };
 *   bindGoogle: {
 *     accessToken: string;
 *     bindStatus: string;
 *     bindType: string;
 *     createdBy: string;
 *     createdDate: string;
 *     id: string;
 *     infoPhone: string;
 *     lastUpdate: string;
 *     lastUpdatedBy: string;
 *     loginName: string;
 *     nickName: string;
 *     productId: string;
 *     unionId: string;
 *   };
 *   ekycStatus: number;// -1待提交,0待审核，1通过，2自动拒绝，3手动拒绝,4待查询zoloz结果
 *   canKycTime: number;
 *   oldKycStatus: number;
 *   rejectReason: string;
 *   refuseInitFlag: boolean;
 *   phoneModifyFlag: boolean; // 是否可以修改手机号
 * }} UserDetail
 */

/**
 * 获取用户详情
 * @param {boolean} forceUpdate 如果为true, 则强制刷新获取最新的用户详情，否则会从内存中获取
 * @returns {UserDetail}
 */
export const fetchUserDetails = async (forceUpdate = false) => {
  const userDetail = my._jsData[StorageKey.USER_DETAILS]
  if (!forceUpdate && userDetail) {
    return userDetail
  }
  const {
    success,
    body
  } = await request(withGlaxy('/customer/getById'), {
    body: {}
  })
  if (success) {
    my._jsData[StorageKey.USER_DETAILS] = body
    my.setStorageSync({
      key: 'userInfo',
      data: body
    })
    return body
  }
  return my._jsData[StorageKey.USER_DETAILS]
}


/** 
 * 获取提现金额列表
 * @param {*} params 
 */
export const getBetAmount = async (params = {}) => {
  const {
    success,
    body
  } = await request(withGlaxy('/stake/balance'), {
    body: params,
    showLoading: false
  })
  if (success) {
    return body
  } else {
    return false
  }
}


/**
 * 从缓存中读取 用户信息
 */
export const getUserInfo = () => {
  const userInfo = my.getStorageSync({
    key: 'userInfo', // 缓存数据的key
  }).data
  const {
    avatar = '',
      bindFlag = null,
      createdDate = null,
      currency = null,
      customerId = null,
      face = null,
      flag = null,
      fromType = null,
      gameLimit = null,
      loginName = null,
      mobileNo = null,
      noLoginDays = null,
      onlineBet = null,
      parentId = null,
      productId = null,
      unionId = null
  } = userInfo || {}
  return {
    avatar, // 头像
    bindFlag,
    createdDate, //注册时间
    currency,
    customerId,
    face,
    flag,
    fromType,
    gameLimit,
    loginName,
    mobileNo,
    noLoginDays,
    onlineBet,
    parentId,
    productId,
    unionId
  }
}

