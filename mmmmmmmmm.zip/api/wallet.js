import request from "./lib/request"
import {
  withGlaxy
} from "./lib/utils"

/**
 * 提现
 * @param {*} body 
 */
export const requestWithdraw = (body = {}) => {
  return request(withGlaxy('/applets/createGLifeWithdrawalRequest'), {
    body: body,
  })
}


/**
 * 获取提现常量
 * @param {*} params 
 */
export const fetchWithdrawConst = async (params = {}) => {
  const {
    success,
    body
  } = await request(withGlaxy('/constant/query'), {
    body: params,
  })
  if (success) {
    return body
  } else {
    return false
  }
}


/**
 * 获取提现金额列表
 * @param {*} params 
 */
export const fetchWithdrawSwitch = async (params = {}) => {
  const {
    success,
    body
  } = await request(withGlaxy('/withdraw/withdrawSwitchV2'), {
    body: params,
  })
  if (success) {
    return body
  } else {
    return false
  }
}