import {
  fetchLoadingConfig,
  fetchSiteInfo,
  fetchWebtoken,
  isValidToken,
  latestWebtoken,
  updateWebtokenStorage,
  verifyToken
} from "./api"
import {
  fetchDisableLobbyLabel,
  fetchFavoriteGames,
  fetchgameProviders,
  gameProviders,
  normalizedProvider
} from "./api/game";
import {
  fetchAccessTokenViaAuthCode,
  getAccessTokenFromStore
} from "./api/service/auth"
import {
  $cora
} from "./api/service/cora";
import {
  normalizeHomeTabJSON
} from "./api/service/home-block-config";
import {
  checkBindV4
} from "./api/user";
import {
  $dialog
} from "./components/v4-dialog";
import { loginEmitter } from "./plugin/proxy/login-emitter";
import {
  APP_TYPE
} from "./utils/const";
import {
  setUpDeviceId
} from "./utils/device-id"
import {
  getAccId
} from "./utils/env";
import {
  createMicroApi
} from "./utils/micro-api";
import {
  fetchAppAllGames,
  fetchHomeBlockConfig,
  fetchHomePromotion,
  fetchHomeTopBanner,
  fetchTCCInfo,
  fetchSpokespersonInfo
} from "/api/stasticJs";

/**
 * 全局配置，以及静态资源相关
 */
let step1Checker = false
export let step1Promiser = new Promise((resolve, reject) => {
  return Promise.all([
    // fetchLoadingConfig(),
    fetchSiteInfo(),
  ]).then(() => {
    step1Checker = true
    step2MicroApi.startFetch()
    resolve()
  }).finally(() => {
    if (step1Checker) {
      return
    }
    step2MicroApi.startFetch()
    resolve()
  })
})


function afterUserAuthResolved(resolve) {
  const data = getAccessTokenFromStore()
  console.log('step', isValidToken, latestWebtoken, data)
  if (!isValidToken && latestWebtoken) {
    updateWebtokenStorage(latestWebtoken)
  }
  // 调用登录功能
  loginMircorApi.startFetch(isValidToken)
  userAuthPromiser = Promise.resolve(isValidToken)
  resolve(isValidToken)
}
/**
 * 用户登录相关的请求操作
 */
let userAuthChecker = false
let userAuthPromiser = new Promise((resolve, reject) => {
  return Promise.all([
    setUpDeviceId(),
    verifyToken(),
    fetchWebtoken(),
    fetchAccessTokenViaAuthCode()
  ]).then(() => {
    userAuthChecker = true
    afterUserAuthResolved(resolve)
  }).finally(() => {
    if (userAuthChecker) {
      return
    }
    afterUserAuthResolved(resolve)
    userAuthChecker = true
  })
})



/**
 * 供应商数据
 */
let providerChecker = false
export const providerPromiser = new Promise(async (resolve) => {
  Promise.all([
    fetchgameProviders(),
    fetchDisableLobbyLabel(),
  ]).then(() => {
    providerChecker = true;
    normalizedProvider();
    resolve(gameProviders);
  }).finally(() => {
    if (providerChecker) {
      return;
    }
    normalizedProvider();
    resolve(gameProviders);
    providerChecker = true;
  });
})




const step2HomePromiseFn = function () {
  return new Promise((resolve, reject) => {
    Promise.all([
      fetchHomeBlockConfig(),
      fetchAppAllGames(),
      fetchHomeTopBanner(),
      // fetchTCCInfo(),
      fetchSpokespersonInfo(),
      fetchHomePromotion(),
    ]).then(() => {
      // normalizeHomeTabJSON()
      resolve(true)
    }).finally(() => {
      // normalizeHomeTabJSON()
      resolve(true)
    })
  })
}

export const step2MicroApi = createMicroApi(step2HomePromiseFn)


export const afterLoginFunctions = () => {
  // fetchFavoriteGames()
}


export const systemInfoPromiser = new Promise((resolve, reject) => {
  my.getSystemInfo({
    success: (res) => {
      resolve(res)
    },
    fail: () => {
      resolve({})
    }
  })
})

export const LoginError = {
  RISK_USER: 'RISK_USER',
  GCASH_ERROR: 'GCASH_ERROR'
}

async function toLogIn() {
  return new Promise(async (resolve, reject) => {
    const data = getAccessTokenFromStore()
    if (data != false) {
      updateWebtokenStorage(latestWebtoken)
      const acsToken = data.resultBody
      const {
        success,
        body,
        head
      } = await checkBindV4({
        type: APP_TYPE, //Glife
        unionId: acsToken.customerId,
        externalToken: acsToken.accessToken,
        reference: getAccId(), //glife市场palcode
        authCode: acsToken.authCode, // 字段确认没有用到
      })
      if (success) {
        body.unionId = acsToken.customerId
        my.setStorageSync({
          key: 'userInfo',
          data: body
        });
        $cora.afterLogin(body)
        afterLoginFunctions()
        loginMircorApi.manualResolve(body)
        // this.startDown(100)
      } else {
        // 高风险用户
        if (head.errCode == 'GW_900990') {
          // TODO 新版需要确认功能 需要确认高风险用户
          // PENDING VERIFIED
          const ctx = getCurrentCtx()
          ctx.setData({
            mask: body.mask || '',
            token: body.token,
            customerId: body.customerId,
            showSecurityDialog: true,
          })
        } else if (head.errCode == 'GW_910145') {
          const result = await $dialog.confirm({
            hideCancelButton: true,
            content: 'The current GLife ystem is unstable, please try again later'
          })
          const ctx = getCurrentCtx()
          if (result) {
            ctx.relunchApp()
          }
          if (result) {
            ctx.relunchApp()
          }
        }
      }
    }

  })
}
async function checkAndLoginIn(isValid) {
  if (!isValid) {
    return toLogIn()
  } else {
    const userInfo = my.getStorageSync({
      key: 'userInfo'
    }).data
    if (userInfo && userInfo.customerId) {
      $cora.afterLogin(userInfo)
      afterLoginFunctions()
      return Promise.resolve(userInfo)
    } else {
      return toLogIn()
    }
  }
}

export const loginMircorApi = createMicroApi(checkAndLoginIn)


export async function reLogin (){
  loginMircorApi.reset()
  loginMircorApi.promiser.then(() => {
    loginEmitter.emitLoginEvent()
  })
  await fetchWebtoken()
  updateWebtokenStorage()
  checkAndLoginIn(false)

}