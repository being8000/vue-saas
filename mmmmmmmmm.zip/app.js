import "./track-2.3.0.js";
import { $sensors } from "./plugin/sensors.js";
import "/plugin/proxy/page-proxy";
import "/plugin/proxy/component-proxy";
import "/app-before-init"
import miniStomp from "./plugin/mini-stomp";
my.CORA_SDK.initialize({
  AppId: "81375", // 目前传测试值，后续在coraool申请
  AppKey: "veg1aufUItFj9lUB4h8bp0",
  AppSec: "1zrU0VwDhkTqU3fMnyYpuwBgIN6BkkPG",
  abTest: false, // true 去请求abTest接口，false不请求
});
// setTimeout(() => {
//   step1PromiseFn()
// }, 100)
App({
  allUrlParams: "",
  appQuery: {},
  allGameMap: {},
  async onLaunch(options) {
    miniStomp.connect()
    console.log('------------------ app.js --- options -----------------')
    console.log(options.query)
    this.appQuery = options.query || {}
    this.allUrlParams = my.CORA_SDK.getAllUrlParams(this.appQuery);
    $sensors.init()
  },    
  // 获取当前页面的this
  getCurrentCtx() {
    const pages = getCurrentPages() || [];
    const ctx = pages[pages.length - 1] || {};
    return ctx;
  },

  onShow(options) {
    // options.query == {number:1}
    
  },
});
