Component({
  mixins: [],
  data: {
    imagesList: [
      {
        imageUrl: 'https://gzone.ph/images/home/tongits/about1.webp?v1',
        title: 'PVP Mode Tongits, Pusoy',
        text: `GameZone exclusively features PVP (Player VS Player) online mode Filipino classic poker games like Tongits and Pusoy.
              GameZone members can have fun with real human opponents rather than boring and even cheating AI robots on other platforms.`,
      },
      {
        imageUrl: 'https://gzone.ph/images/home/tongits/about2.webp?v1',
        title: 'GameZone 2025 Reform',
        text: `GameZone revamps its look and upgrades its interface. Gamezone sets its ambitious brand plans for 2025, 
              including famous brand ambassadors, operating a national tournament, and national brand campaigns for a broader reach and growing market.`,
      },
      {
        imageUrl: 'https://gzone.ph/images/home/tongits/about3.webp?v1',
        title: 'GameZone Under Digiplus',
        text: `Digiplus is the most innovative and successful digital entertainment brand in the Philippines. <br/>
        Digiplus owns 3 brands: GameZone, Bingoplus, and Arenaplus. GameZone is the most pioneering brand that focuses on table games.
            `,
      },
      {
        imageUrl: 'https://gzone.ph/images/home/tongits/about4.webp?v1',
        title: 'Responsible Gaming',
        text: `GameZone is a PAGCOR-licensed, legal, fair online casino with a diverse selection of games and interactive features. Please read the terms of use before registering. Clicking confirm means that you fully understand your individual responsibilities.
        `,
      },
    ]
  },
  props: {},
  didMount() {},
  didUpdate() {},
  didUnmount() {},
  methods: {},
});
