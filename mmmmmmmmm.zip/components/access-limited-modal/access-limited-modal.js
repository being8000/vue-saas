import { navigateToH5 } from "/api/service/navigate-to-h5";

const app = getApp();

Component({
  mixins: [],
  data: {},
  props: {
    errorCode: 'GW_0006',
    title: 'Access Limited',
    visible: false,
    onConfirm: Function,
    onCancel: Function,
    confirmText: 'Support',
    cancelText: 'Cancel',
    showCancelButton: false,
    showCloseButton: false,
    showCancelButton: false,
    showConfirmButton: true,
    contentStyle: '',
    btnStyle: '',
    accessLimitedContent: `Your access has been limited. If you're a
    valid user, please click on "Support" to
    connect with our customer service. They
    will help restore your access promptly.
    We apologize for any inconvenience this
    may cause.`
  },
  didMount() {},
  didUpdate() {},
  didUnmount() {},
  methods: {
    // onConfirmTap() {
    //   this.props.onConfirm && this.props.onConfirm()
    // },
    onCancelTap() {
      this.props.onCancel && this.props.onCancel()
    },
    onConfirmTap() {
      if (this.props.errorCode == 403) {
        const ctx = app.getCurrentCtx();
        if (!ctx.setData) return;
        ctx.setData({
          showAccessLimited: false,
        })
      } else {
        navigateToH5('CS')
      }

    }
  },
});