Component({
  mixins: [],
  data: {},
  props: {
    prizeType: Number,
    prizeSubType: Number,
    width:Number,
    height:Number,
    imgSrc:''
  },
  didMount() {
    this.getImgSrc()
  },
  didUpdate() {},
  didUnmount() {},
  methods: {
    getImgSrc(){
      let src = ''
    }
  },
});
