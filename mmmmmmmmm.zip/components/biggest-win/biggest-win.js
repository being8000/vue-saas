import { getBetAmount } from '/api/user'
import { navigateToH5 } from '/api/service/navigate-to-h5'
Component({
  mixins: [],
  data: {
    chipsBalance: 0,
    boundsBalance:0
  },
  props: {},
  async didMount() {
    await this.fetchGameBalance()
  },
  didUpdate() {},
  didUnmount() {
   
  },
  methods: {
    async fetchGameBalance() {
      const { boundsBalance, chipsBalance } = await getBetAmount()
      this.setData({boundsBalance:  boundsBalance, chipsBalance: chipsBalance  })
    },
    goLinkBet () {
      navigateToH5('/betting-rebate?pageName=betting')
    },
    goLinkRebate() {
      navigateToH5('/betting-rebate?pageName=rebate')
    },
    toWinMore() {
      navigateToH5('/betting-rebate')
    }
  },
});
