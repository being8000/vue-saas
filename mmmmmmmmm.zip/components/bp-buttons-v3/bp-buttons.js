const app = getApp();
import {
  normalizedPaymentData
} from '../../utils/index'
const sensors = require("../../sensorsdata.esm.js");
import {
  getStorageCache,
  formatPrice
} from '../../mixins';

//prettier-ignore
Component({
  mixins: [],
  data: {
    showPopup: false,
    amountList: [
      '100', '200', '500', '1000', '3000', '5000',
      '8000', '10000', '15000', '20000', '50000', '100000'
    ],
    withdrawList: [
      '200', '500', '1000', '3000', '5000', '8000',
      '10000', '15000', '20000', '30000', '50000', '100000'
    ],
    formattedBalance: '',
    isAmount: null,
    isFlag: true,
    isUserInfo: {
      loginName: '- -'
    },
    tokenInfo: null,

    isAmountInput: false,
    keyboardHide: true
  },
  props: {
    isNewClass:false,
    label: String,
    icon: String,
    style: String,
    popupType: String,
    currentBalance: 0,
    onPopupShow: Function,
    onConfirmSubmit: Function,
    onSuccessOperation: data => console.log(data),
    historyList: {}
  },
  didMount() {
    this.setData({
      isUserInfo: getStorageCache('userInfo'),
      tokenInfo: getStorageCache('isInfo'),
    })
  },
  didUpdate() {},
  didUnmount() {},
  methods: {
    onPopupShow(e) {
      // if (this.props.popupType === 'deposit') {
      // }
      sensors.track('transactionClick', {
        b_id:'home_page',
        page_b_name:'首页',
        c_id:'transaction',
        page_c_name:'transaction',
      })
      this.props.onPopupShow(e)

      this.setData({
        showPopup: true,
        formattedBalance: formatPrice(this.props.currentBalance)
      });

      if (this.props.popupType === 'playgame') {
        this.jumpBingo();
      }
    },

    onPopupClose() {
      this.setData({
        showPopup: false,
        isAmount: null,
        isAmountInput: false
      })
    },

    chooseAmount(e) {
      this.setData({
        isAmountInput: true,
        isAmount: e.target.dataset.attr
      })
    },

    withdrawAllBalance(e) {
      this.setData({
        isAmount: parseInt(e.target.dataset.balance)
      })
    },

    onAmountInput(e) {
      const value = e.detail.value

      this.setData({
        isAmount: value
      })
    },

    onAmountFocus() {
      this.setData({
        keyboardHide: false,
        isAmountInput: true
      })
    },

    onAmountBlur(e) {
      this.setData({
        keyboardHide: true
      })

      if (!e.detail.value) {
        this.setData({
          isAmountInput: false
        })
      }
    },

    verifyAmountInput(value) {
      const reg = /^[0-9]*$/;
      const isValid = reg.test(value);
      let errMessage = '';
      let minMax;

      // 如果输入 test = false 显示错误 / if input test = false show error
      if (!isValid) {
        app.toast('Invalid input')
        this.setData({
          isAmount: null
        })
        return
      }

      // 设置 minMax 值和错误信息 / Set minMax value and error message
      if (this.props.popupType === 'deposit') {
        minMax = value < 100 || value > 100000
        errMessage = 'Please enter 100 to 100,000'
      } else {
        minMax = value < 200 || value > 3000000
        errMessage = 'Please enter 200 to 3,000,000'
      }

      // 如果值不为空并且 minMax 不匹配则抛出错误
      // If value is not empty and did minMax did not match throw error
      if (value && minMax) {
        app.toast(errMessage)
        this.setData({
          isAmount: null
        })
      }
    },

    //存款
    submint_deposit(e) {
      this.props.onConfirmSubmit(e)

      // 如果失败则验证输入的金额 set isAmount = null
      // Verify entered amount if failed set isAmount = null
      this.verifyAmountInput(this.data.isAmount)

      // 如果 isAmount null 返回 / If isAmount null return
      if (!this.data.isAmount) return


      app._request('applets/createOnlineOrder', {
        amount: this.data.isAmount,
        miniProgramId: '2170020194511181'
      }).then(
        res => {
          console.log(res)
          if (res.errMsg) {
            app.toast(res.errMsg)
          } else {
            //调用Gcash api
            my.tradePay({
              paymentUrl: res,
              success: (suc) => {
                // my.alert({
                //   content: JSON.stringify(suc),
                // });
                this.props.onSuccessOperation('success')
                this.onPopupClose()
              },
              fail: (err) => {
                my.alert({
                  content: JSON.stringify(err),
                });
              }
            });
          }
        },
        () => {}
      );
    },
    //取款
    submint_withdraw() {
      // const glifeToken = my.getStorageSync({
      //   key: 'glifeToken', // 缓存数据的key
      // }).data.resultBody

      // 如果失败则验证输入的金额 set isAmount = null
      // Verify entered amount if failed set isAmount = null
      this.verifyAmountInput(this.data.isAmount)

      // 如果 isAmount null 返回 / If isAmount null return
      if (!this.data.isAmount) return

      // Verify if amount has no decimal
      if (!this.data.isFlag) return
      this.setData({
        isFlag: false
      })
      console.log('存款确定')
      app._request('applets/createGLifeWithdrawalRequest', {
        amount: this.data.isAmount,
        ...normalizedPaymentData()
        // glifeAccountId: JSON.parse(glifeToken).customerId,
      }).then(
        res => {
          if (res.errMsg) {
            app.toast(res.errMsg)
          } else {
            app.toast('Withdrawal request successful')
            this.props.onSuccessOperation('success')
            this.onPopupClose()
          }
          this.setData({
            isFlag: true
          })
        },
        (err) => {
          this.setData({
            isFlag: true
          })
        }
      );
    },

    jumpBingo() {
      // my.navigateTo({
      //   // 跳转到webview页面
      //   url: `/pages/bingo/bingo`,
      // });

      let url = app.getBingoUrl();
      url = url + '&isInfo=' + this.data.tokenInfo + '&loginName=' + this.data.isUserInfo.loginName
      my.call('navigateToLink', {
        targetLink: url,
        appId: '2170020194511181',
        success: (res) => {
          // my.alert({ content: JSON.stringify(res) });
        },
        fail: (res) => {
          my.alert({
            content: JSON.stringify(res)
          });
        }
      });
    },
  },
});