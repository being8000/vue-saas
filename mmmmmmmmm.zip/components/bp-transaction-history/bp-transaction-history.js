const app = getApp();
import {
  getStorageCache,
  formatPrice
} from '/mixins'

Component({
  mixins: [],
  data: {
    // historyList: [],
    //historyList: {"body":{"data":[{"amount":1000.00,"billDate":"05/04/2022 15:31:33","billType":"1","businessId":"C66012205041532AA01","businessType":"Bank account deposit","lang":"en","status":1},{"amount":1000.00,"billDate":"05/04/2022 15:31:33","billType":"0","businessId":"C66012205041532AA01","businessType":"Bank account deposit","lang":"en","status":0},{"amount":6765.00,"billDate":"05/04/2022 10:33:40","billType":"0","businessId":"C66012205041034AA01","businessType":"Bank account deposit","lang":"en","status":2},{"amount":6765.00,"billDate":"05/04/2022 10:33:40","billType":"0","businessId":"C66012205041034AA01","businessType":"Bank account deposit","lang":"en","status":2}],"pageNo":1,"pageSize":3,"totalPage":3,"totalRow":8},"head":{"cost":0,"errCode":"0000","errMsg":"successful operation"}},
    isUserInfo: {
      loginName: '- -'
    },
    showMorePopup: false
  },
  props: {
    historyList: {}
  },
  didMount() {
    // this.setData({
    //   historyList: this.formatHistoryAmount(this.data.historyList.body.data)
    // });

    this.setData({
      isUserInfo: getStorageCache('userInfo')
    });

    // this.getHistory();
  },
  didUpdate() {},
  didUnmount() {},
  methods: {
    //获取交易记录数据 / Get Transaction History
    getHistory() {
      app._request('applets/queryCustBill', {
        status: 0, //0成功，1失败，2，等待
      }).then(
        res => {
          this.setData({
            historyList: this.formatHistoryAmount(res.data)
          })
        },
        () => {}
      );
    },

    // 格式化历史金额 / Format history amount
    formatHistoryAmount(data) {
      data.map(item => {
        item.amount = `${formatPrice(item.amount)}`;
      });

      return data;
    },

    onShowMore() {
      this.setData({
        showMorePopup: true
      });
    },

    onCloseMore() {
      this.setData({
        showMorePopup: false
      });
    }
  },
});