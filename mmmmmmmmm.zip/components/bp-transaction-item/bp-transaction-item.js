Component({
  mixins: [],
  data: {},
  props: {
    itemData: {}
  },
  didMount() {},
  didUpdate() {},
  didUnmount() {},
  methods: {},
});
