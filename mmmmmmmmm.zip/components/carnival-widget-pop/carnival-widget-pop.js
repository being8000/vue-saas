import { navigateToH5 } from '/api/service/navigate-to-h5'
import { getCarnivalList } from '/api/carnival'
Component({
  mixins: [],
  data: {
    visiblePopup: 0
  },
  props: {
   // visiblePopup: Number
  },
  didMount() {
    this.initCarnivalList()
  },
  didUpdate() {},
  didUnmount() {},
  methods: {
    goLink() {
      navigateToH5('/jnh')
    },
    async initCarnivalList () {
      const { carnivalTasks  } = await getCarnivalList()
      this.setData({visiblePopup:carnivalTasks.length})
      console.log(carnivalTasks.length, 'datagetCarnivalList')
    } 
  },
});
