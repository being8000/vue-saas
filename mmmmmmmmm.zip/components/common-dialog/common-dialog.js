Component({
  mixins: [],
  data: {
    // visible: false,
  },
  props: {
    title: String,
    confirmButtonText: String,
    cancelButtonText: String,
    onConfirm:Function,
    onCancel:Function
  },
  didMount() {},
  didUpdate() {},
  didUnmount() {},
  methods: {
    onConfirm(){
      this.props.onConfirm && this.props.onConfirm()
    },
    onCancel(){
      this.props.onCancel() && this.props.onCancel()
    },
  },
});
