function formateTime(time) {
  const hours = Math.floor(time / 3600)
  const minutes = Math.floor((time % 3600) / 60)
  const seconds = Math.floor(time % 60)
  return {
    hours,
    minutes,
    seconds,
    formattedHours: `${hours}`.padStart(2, '0'),
    formattedMinutes: `${minutes}`.padStart(2, '0'),
    formattedSeconds: `${seconds}`.padStart(2, '0'),
  }
}
let isMounted = false;
Component({
  mixins: [],
  data: {
    formattedHours: '00',
    formattedMinutes: '00',
    formattedSeconds: '00',
    countdowntime: 0,
    timer: undefined,
    timerId: 0,
  },
  
  props: {
    withclass: String,
    countdowntime: Number,
    popitem:Object
  },
  didMount() {
    this.createTimer()
    isMounted = true;
  },
  didUpdate(){
    isMounted = true;
    if(this.props.countdowntime > 0 && this.data.countdowntime <= 0){ 
      this.setData({
        countdowntime: this.props.countdowntime
      })
    }
  },
  didUnmount() {
    isMounted = false;
    clearTimeout(this.data.timerId)
    // this.clear()
  },
  methods: {
    createTimer(){
      if (!isMounted) {
        return
      }
      this.data.timerId = setTimeout(() => {
        clearTimeout(this.data.timerId)
        const duration = this.data.countdowntime || this.props.countdowntime
        const time = formateTime(duration)
        const newTime = Number(duration) - 1
          // this.data.countdowntime = newTime;
          this.setData({
            ...time,
            countdowntime: newTime
          })
        
        if(newTime >= 0){
          this.createTimer()
        }
      }, 1000)
    },
  }
});