import {
  gameIsntance
} from ".";
import {
  navigateToGame
} from "/api/service/navigate-to-h5";
import {
  findGameByGameId
} from "/api/stasticJs";
import {
  step2MicroApi
} from "/app-before-init";
Component({
  mixins: [],
  data: {
    isFavorite: '',
    game: {}
  },
  props: {
    id: Number,
    width: String
  },
  didMount() {
    this.data.instance = gameIsntance(this)
    this.data.instance.bind()
  },
  didUpdate(prevProps, prevData) {
    if (prevProps.id != this.props.id) {
      this.data.instance.unbind()
      this.data.instance = gameIsntance(this)
      this.data.instance.bind()
    }
  },
  didUnmount() {
    this.data.instance.unbind()
  },
  methods: {
    update() {},
    toggleFavorite() {

    },
    async toGame() {
      await step2MicroApi.promiser
      const game = findGameByGameId(this.props.id)
      navigateToGame(game)
    },
    onMaintain() {}
  },
});