import {
  providersMap,
  requestAddFavoritesGame,
  requestRemoveFavorateGame
} from "/api/game"
import {
  favoritor
} from "/api/service/favorite-game"
import {
  navigateToGame
} from "/api/service/navigate-to-h5"
import {
  findGameByGameId
} from "/api/stasticJs"
import {
  providerPromiser,
  step2MicroApi
} from "/app-before-init"
import {
  debounce
} from "/utils"
import {
  getOriginUrl
} from "/utils/env"
import {
  useEventBus
} from "/utils/use-event-bus"

/**
 *  step2MicroApi.promiser.then(el => {
    const game = findGameByGameId(gamePrimaryId)
    if(isMounted){
      instance.setData({
        game: formatGameImage(game, 'gameImage')
      })
    }
    providerPromiser.then(el => {
      let platformLogo = (providersMap[game.platformId] || {}).gameLogoUrl
      if(isMounted){
        instance.setData({
          platformLogo: platformLogo
        })
      }
    })
    isFavorite(instance)
  })
 */
const formatGameImage = (game) => {
  const imgUrl = game.gameImageNew || game.gameImage
  if (!imgUrl) {
    return game
  }
  if (imgUrl.startsWith('http')) {
    game.gameImage = imgUrl
  } else {
    game.gameImage = `https://${getOriginUrl()}/externals/C66FM/img/_wms/_l/electronicgames/${imgUrl}`
  }
  return game
}

// 用来存储挂载的游戏实例
let gameInstance = {}

export const gameCardBus = useEventBus('game-card-event-bus')
async function isFavorite(instance) {
  const gameId = instance.props.id
  const isFavor = await favoritor.isFavorite(gameId)
  if (isFavor) {
    instance.setData({
      isFavorite: true
    })
  } else {
    instance.setData({
      isFavorite: false
    })
  }
}
export function gameIsntance(instance) {
  let subscriber = null
  let isMounted = true
  const gamePrimaryId = instance.props.id
  step2MicroApi.promiser.then(el => {
    const game = findGameByGameId(gamePrimaryId)
    if (isMounted) {
      instance.setData({
        game: formatGameImage(game, 'gameImage')
      })
    }
    providerPromiser.then(el => {
      let platformLogo = (providersMap[game.platformId] || {}).gameLogoUrl
      if (isMounted) {
        instance.setData({
          platformLogo: platformLogo
        })
      }

    })
    isFavorite(instance)
  })

  function bindGameCardComponentIsntance() {
    const onFavoriteChange = gamePrimaryId + '_favorite'
    instance.toggleFavorite = debounce(async function () {
      await step2MicroApi.promiser
      const game = findGameByGameId(instance.props.id)
      const result = !instance.data.isFavorite
      let success = null
      if (result) {
        const res = await requestAddFavoritesGame({
          gameId: game.gameId,
          platformCode: game.platformId
        })
        success = res.success
      } else {
        const res = await requestRemoveFavorateGame({
          gameId: game.gameId,
          platformCode: game.platformId
        })
        success = res.success
      }
      if (success) {
        instance.setData({
          isFavorite: result
        })
        if (result) {
          favoritor.add(game)
        } else {
          favoritor.remove(gamePrimaryId)
        }
        gameCardBus.emit(onFavoriteChange, result)
      }
    }, 500, true)
    subscriber = gameCardBus.on((event, payload) => {
      if (event === onFavoriteChange) {
        instance.setData({
          isFavorite: payload
        })
      }
    })
  }

  function unbindGameCardComponentIsntance(instance) {
    isMounted = false
    subscriber && subscriber()
    subscriber = undefined
  }
  return {
    bind: bindGameCardComponentIsntance,
    unbind: unbindGameCardComponentIsntance
  }
}