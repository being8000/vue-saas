Component({
  mixins: [],
  data: {
    current: [],
    progress: 0,
    pageNo: 1
  },
  props: {
    pageSize: null,
    games: Array,
  },
  didMount() {
    this.updatePage()
  },
  didUpdate(props, n) {
    if(props.games != this.props.games){
      this.setData({
        pageNo: 1
      })
      this.updatePage()
    }
  },
  didUnmount() {
    
  },
  methods: {
    updatePage(){
      const games = this.props.games || []
      if(games.length === 0){
        this.setData({
          current: [],
          progress: 0,
        })
        return 
      }
      const pageSize = this.props.pageSize || 4
      const paginatedGames = games.slice(0, this.data.pageNo * pageSize)
      const progress = Math.round(paginatedGames.length / games.length * 100)

      this.setData({
        current: paginatedGames,
        progress,
      })
    }, 
    add(){
      if(this.data.current.length >= this.props.games.length){
        this.setData({
          process: 100
        })
        return
      }
      this.setData({
        pageNo: this.data.pageNo + 1
      })
      this.updatePage()
    }
  },
});
