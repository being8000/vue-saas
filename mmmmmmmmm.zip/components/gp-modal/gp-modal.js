Component({
  mixins: [],
  data: {},
  props: {
    title: String,
    visible: Boolean,
    onConfirm: Function,
    onCancel: Function,
    confirmText: 'Confirm',
    cancelText: 'Cancel',
    showCancelButton: false,
    showCloseButton: false,
  },
  didMount() {},
  didUpdate() {},
  didUnmount() {},
  methods: {
    onConfirmTap() {
      this.props.onConfirm && this.props.onConfirm()
    },
    onCancelTap() {
      this.props.onCancel && this.props.onCancel()
    }
  },
});