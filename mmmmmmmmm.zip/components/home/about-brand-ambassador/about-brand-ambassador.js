Component({
  mixins: [],
  data: {
    controls: false,
    current: 0,
    iconList: [
      {
        icon: '../../assets/image/brand-ambassador/height-icon.png',
        text: 'Height',
        subText: '5’11 ft',
      },
      {
        icon: '../../assets/image/brand-ambassador/birthday-icon.png',
        text: 'Birthday',
        subText: 'March 31,1976',
      },
      {
        icon: '../../assets/image/brand-ambassador/zodiac-icon.png',
        text: 'Zodiac',
        subText: 'aries',
      },
      {
        icon: '../../assets/image/brand-ambassador/favourite-icon.png',
        text: 'Favourite color',
        subText: 'pink',
      },
    ],
    bannerList: [
      {
        img: '../../assets/image/brand-ambassador/banner01.webp',
      },
      {
        img: '../../assets/image/brand-ambassador/banner01.webp',
      },
    ],
  },
  props: {
    spokenPerson: Array,
    text: String
  },
  didMount() {
    // console.log(this.props.spokenPerson, 'spokenPerson111')
  },
  didUpdate() {},
  didUnmount() {
    console.log(this.props.spokenPerson, 'spokenPerson111')
  },
  methods: {
    onChange(e) {
      this.setData({current: e.detail.current })
    }
  },
  clickOpenVideo(e) {
    console.log(e, 'index123')
    // const videoContext = wx.createVideoContext('videoPlayRef');
    // if (this.data.controls) {
    //   videoContext.pause();
    // } else {
    //   videoContext.play();
    // }
    // this.setData({
    //   controls: !this.data.controls,
    // });
  },
});
