
import {
  navigateToGame, navigateToH5
} from "/api/service/navigate-to-h5";

Component({
  mixins: [],
  data: {
    current: 0,
  },
  props: {
    config: Object
  },
  didMount() {},
  didUpdate() {

  },
  didUnmount() {},
  methods: {
    onChange(e) {
      this.setData({
        current: e.detail.current
      })
      //this.current = e.detail.current
    },
    onClick(e) {
      const item = e.target.dataset.item || {}
      if(item.subCategory == '3'){
        const params = {
          targetUrl: item.redirectLink,
          gameId: item.gameId,
          jumpJson: item.jumpJson,
          platformId: item.platformCode
        }
        navigateToGame(params)
      } else {
        navigateToH5(item.redirectLink)
      }
    }
  },
});
/**
 * appGroup: "2"
blockConfigId: 257
category: "9"
createDate: null
createdBy: null
endTime: "2027-05-13 00:00:00"
featured: null
flag: null
gameCode: "0"
gameId: null
gameName: null
gameType: null
id: 453
isNew: null
jsonParam: null
jumpJson: ""
picCacheUrl: null
picId: "https://uatimgscache.com/compic/7489496b-11de-4079-85ce-165c9cd55b2e.webp"
platformCode: null
productId: "C66"
productName: "GP"
promotion: null
redirectLink: "/gtcc"
remark: ""
showPage: "0"
sort: null
startTime: null
subCategory: "1"
title: "mtt"
topBackground: ""
updateDate: null
updatedBy: null
urlSaveDate: null
1: {appGroup: "2", blockConfigId: 257, category: "9", createDate: null, createdBy: null,…}
2: {appGroup: "2", blockConfigId: 257, category: "9", createDate: null, createdBy: null,…}
3: {appGroup: "2", blockConfigId: 257, category: "9", createDate: null, createdBy: null,…}
blockName: "Banner"
blockParam: ""
blockPic: "xxx"
carousel: 1
clientType: "5"
columnStyle: 0
endTime: "2026-05-28 00:00:00"
gameCategoryJSRsp: null
gameIndexIds: null
gameItemsIds: null
id: 257
jumpBlock: ""
pagination: "0"
productId: "C66"
productName: "GP"
remark: ""
rowStyle: 0
showViewAll: 1
sort: 3
startTime: "2025-04-09 00:00:00"
status: 1
themePic: ""
type: 1
updateTime: "2025-04-10 16:28:07"
updater: "elon"
 */