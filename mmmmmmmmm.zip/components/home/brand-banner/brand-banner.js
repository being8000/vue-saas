import { navigateToGame, navigateToH5 } from "/api/service/navigate-to-h5";

Component({
  mixins: [],
  data: {
    current: 0
  },
  props: {
    list: Array
  },
  methods: {
    onChange(e) {
      this.setData({current: e.detail.current })
      //this.current = e.detail.current
    },
    onClick(e) {
      const item = e.target.dataset.item || {}
      if(item.subCategory == '3'){
        const params = {
          targetUrl: item.redirectLink,
          gameId: item.gameId,
          jumpJson: item.jumpJson,
          platformId: item.platformCode
        }
        navigateToGame(params)
      } else {
        navigateToH5(item.redirectLink)
      }
    }
  },
});
