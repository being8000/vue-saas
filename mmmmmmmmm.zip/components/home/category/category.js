import {
  getOriginList
} from '/api/stasticJs'
import { step2MicroApi } from '/app-before-init';
import { navigateToH5 } from '/api/service/navigate-to-h5'
Component({
  mixins: [],
  data: {
    category: [],
    allConf: {
      name: 'All&nbsp;Games',
      code: 'all',
      icon2: '/assets/tab/all-category.png',
      sortH5: 0
    },
    tongitsConf: {
      name: 'tongits',
      code: 'tongits',
      icon2: '/assets/tab/tongits-tab.png',
      sortH5: 0
    }
  },
  props: {},
  didMount() {
    this.getTabList()
  },
  didUpdate() {},
  didUnmount() {},
  methods: {
    // 获取赛事列表
    async getTabList() {
      await step2MicroApi.promiser
      const originList = getOriginList()
      console.log('originList', originList)
      let categoryList = originList.map(e => {
        const code = e.pagination.toLowerCase()
        if (code != 'all' && code != 'tongits') {
          return {
            name: e.pagination,
            code,
            icon2: e.iconH5V2,
            sortH5: e.sortH5,
          }
        }
      }).filter(Boolean)
      categoryList = categoryList.sort((a, b) => b.sortH5 - a.sortH5)
      this.setData({
        category: categoryList,
        allConf: this.data.allConf,
        tongitsConf: this.data.tongitsConf
      })
    },
    ToSearchGame(e) {
      const item = e.currentTarget.dataset.value
      if(item == 'tongits'){
         // 去h5的tongits
         navigateToH5('/tongits')
      }else{
        my.navigateTo({
          url: `/pages/tab/tab?tab=${item}`
        });
      }
    }
  },
});