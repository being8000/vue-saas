Component({
  mixins: [],
  data: {},
  props: {
    title:String,
    icon:String,
    showAll:true,
    onRight:Function,
    item:Object
  },
  didMount() {},
  didUpdate() {},
  didUnmount() {},
  methods: {
    onRight(){
      // 跳转到指定的tab 页面
      let jumpTab = this.props.item.jumpBlock
      if(jumpTab){
        my.navigateTo({
          url:'/pages/tab/tab?tab='+jumpTab
        })
      }else{
        let idList = this.props.item.gameItemsIds
        // 去所有游戏页面
        my.navigateTo({
          url:'/pages/more-games/more-games?items=' + idList
        })
      }
      // this.props.onRight && this.props.onRight()
    }
  },
});
