import {findGameByGameId,getLayoutCodeMap,layoutCodeMap} from '/api/stasticJs';
import { step2MicroApi } from '/app-before-init';

Component({
  mixins: [],
  data: {
    layoutCodeMap:{},
    allBlockLayout:[]
  },
  props: {
    tab: ''
  },
  async didMount() {
    await step2MicroApi.promiser
    this.setData({
      layoutCodeMap:layoutCodeMap
    })
  },
  didUnmount() {},
  ref(){
    return {
      change:(tab)=>{
        // this.generateTabLayout(tab)
      }
    }
  },
  methods: {
    async generateTabLayout(tab){
      await step2MicroApi.promiser
      let layout = getLayoutCodeMap(tab)
      if(!layout){
        console.error(`未找到${tab} 布局`)
        return
      }
      this.setData({
        allBlockLayout:layout.blockConfig
      })
    }
  },
});
