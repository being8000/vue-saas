import { getAllpool } from '/api/activity'
import miniStomp from "../../../plugin/mini-stomp";
import {findGameByGameId} from '/api/stasticJs';
let unscribeFnId = null
Component({
  mixins: [],
  data: {
    jackportList:[],
    ifClearinterval:null,
    index: 0,
    animation:'',
  },
  props: {
    title:String,
    icon:String
  },
  didMount() {
    this.data.animation = my.createAnimation({
      duration: 500,
      timingFunction: 'ease'
    });
    var _that = this
    _that.getHistorylist()
    if(unscribeFnId){
      miniStomp.unsubscribe(unscribeFnId)
      unscribeFnId= null
    }
    let url = `/topic/big_prize_match_winner`
    unscribeFnId = miniStomp.subscribe(url)
    miniStomp.hook(url, (data) => {
      // console.log('/topic/tiptopMatchWinner',data)
      const game = findGameByGameId(data.id)
      if(!game) {
        return 
      }
      var itemtype = Object.assign({}, data, game)
      if (itemtype.type == '0') {
        itemtype.subCategory = 3
      } else {
        itemtype.nameEn = 'Lucky Spin'
        itemtype.subCategory = 4
        itemtype.gameImage = luckyspin
      }
      _that.setData({
        jackportList: [itemtype]
      })
    })
  },
  didUpdate() {
     // 获取爆浆数据
    // /topic/big_prize_match_winner
  },
  didUnmount() {
    this.clearfunc()
    clearInterval(this.data.interval);
  },
  methods: {

    // 获取赛事列表
    async getHistorylist() {
      var _that = this
      const { success, body } = await getAllpool({})
        if(success){
          if(_that.body == null){
            this.setData({
              jackportList:[]
            })
          }else{
            this.setData({
              jackportList:[JSON.parse(body[0])]
            })
            _that.createAnimation()
          }
        }
      },
      clearfunc(){
        if (this.data.ifClearinterval) {
          clearInterval(this.data.ifClearinterval)
        }
      },
    },
});