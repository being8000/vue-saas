import { providerPromiser } from "/app-before-init";
import {
  getAllGames
} from '/api/service/home-block-config'
import {
  StorageKey
} from "/utils/const"
Component({
  mixins: [],
  data: {
    list: []
  },
  props: {
  },
  async didMount() {
    const gameProviders = await providerPromiser
    const groupSize = 2;
    const groupedList = gameProviders.reduce((result, item, index) => {
      const groupIndex = Math.floor(index / groupSize);
      if (!result[groupIndex]) {
        result[groupIndex] = [];
      }
      result[groupIndex].push(item);
      return result;
    }, []);
    this.setData({
      list: groupedList
    })
  },
  didUpdate() {},
  didUnmount() {},
  methods: {
    goGameProvider(e) {
      const platformId = e.target.dataset.value.platformId;
      const games = getAllGames() || []
      const filterList = games.filter(e=> e.platformId == platformId)
      const gameList = []
      const result = filterList.map(item => item.id).join(',');
      my.navigateTo({
        url:'/pages/more-games/more-games?items=' + result
      })
  
    },
  },
});
