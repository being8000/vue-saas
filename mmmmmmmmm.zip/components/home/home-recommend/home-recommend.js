import { fetchRecentlyGames } from '/api/game'
import { removeDuplicateGames }  from '/utils/game'
import {
  StorageKey
} from "/utils/const"
Component({
  mixins: [],
  data: {
    rencentList: [{},{},{},{},{},{},{}]
  },
  props: {},
  didMount() {
    this.getFetchList()
  },
  didUpdate() {},
  didUnmount() {},
  methods: {
    async getFetchList () {
     let recentGames = [];
     const data =  await fetchRecentlyGames()
     console.log(data, 'data123')
     const games = my._jsData[StorageKey.ALL_GAME] || []
     data.forEach((recentGame) => {
      games.forEach((baseGame) => {
        if (
          recentGame.gameId === baseGame.gameId &&
          recentGame.platformCode === baseGame.platformId
        ) {
          recentGames.push(baseGame);
        }
      });
    });
    console.log(removeDuplicateGames(recentGames),'game123')
    const gameIds = []
    removeDuplicateGames(recentGames).forEach((item)=> {
      gameIds.push(item.id)
    })
    console.log(gameIds, 'gameIds')
    this.setData({rencentList: gameIds})
    }
  },
});
