const SIZE = 8
Component({
  mixins: [],
  data: {
    originList:[],
    renderList:[],
    size:SIZE,
    ratio:0
  },
  props: {
    games:Array,
    gameSize:Number,
    needLoadMore:true,
    onMoreGame:Function
  },
  didMount() {
   this.init(this.props.games)
  },
  didUpdate() {
    // this.init(this.props.games)
  },
  didUnmount() {
  },
  ref(){
    return {
      reset:(_games)=>{
        // this.data.size = SIZE
        // this.init(_games)
      }
    }
  },

  methods: {
    init(_games){
      // if(_games.length)return
      this.setData({
        originList:_games,
        renderList:_games.slice(0,this.data.size)
      })
      this.setRatio()
    },
    setRatio(){
      // let ratio = Number(Math.floor(this.data.renderList.length / (this.data.originList.length || 1) * 100).toFixed(0))
      // let ratio = Number(Math.floor(games.slice(0,size).length / (games.length || 1) * 100).toFixed(0))
      // this.setData({
      //   ratio
      // })
    },
    onMore(){
      this.props.onMoreGame && this.props.onMoreGame()
      return
      // this.data.size += 8
      this.setData({
        size: this.data.size+8
        // renderList: this.data.originList.slice(0,this.data.size)
      })
      // this.setRatio()
    }
  },
});
 