import { getTopprize } from '/api/activity'
import miniStomp from "../../../plugin/mini-stomp";
let unscribeFnId = null
Component({
  mixins: [],
  data: {
    winnerList:[],
    ifClearinterval:null,
    index: 0,
    animation:'',
  },
  props: {
    title:String,
    icon:String
  },
  didMount() {
    this.data.animation = my.createAnimation({
      duration: 500,
      timingFunction: 'ease'
    });
    var _that = this
    _that.getHistorylist()
    if(unscribeFnId){
      miniStomp.unsubscribe(unscribeFnId)
      unscribeFnId= null
    }
    let url = `/topic/tiptopMatchWinner`
    unscribeFnId = miniStomp.subscribe(url)
    miniStomp.hook(url, (data) => {
      // console.log('/topic/tiptopMatchWinner',data)
      const newwinner = JSON.parse(data.winners).map((items) => {
        items.amount = items.rewardMoney / 1000
        items.winningTime = items.endTimeStr
        items.gameImage = '../../assets/tongits/tongits.webp'
        items.nameEn = 'Tongits'
        return items
      }).filter(Boolean) || [];
      let WinnerListBefore = _that.data.winnerList != false ?_that.data.winnerList:[];
      _that.setData({
        winnerList: [...newwinner, ...WinnerListBefore]
      })
      _that.createAnimation()
    })
  },
  didUpdate() {
     // 获取爆浆数据
    // /topic/big_prize_match_winner
  },
  didUnmount() {
    this.clearfunc()
    clearInterval(this.data.interval);
  },
  methods: {

    // 获取赛事列表
    async getHistorylist() {
      var _that = this
      const { success, body } = await getTopprize({})
        if(success){
          if(_that.body == null){
            this.setData({
              winnerList:[]
            })
          }else{
            this.setData({
              winnerList:body
            })
            _that.createAnimation()
          }
        }
      },
      clearfunc(){
        if (this.data.ifClearinterval) {
          clearInterval(this.data.ifClearinterval)
        }
      },
      createAnimation() {
        this.data.ifClearinterval = setInterval(() => {
            const index = this.data.index + 1;
            const translateY = -64 * index;
            this.data.animation.translateY(translateY+'rpx').step();
            this.setData({
              animationData: this.data.animation.export(),
              index: index >= this.data.winnerList.length ? 0 : index
            });
            if (index >= this.data.winnerList.length -1) {
              clearInterval(this.data.ifClearinterval)
            }
          }, 3000);
        },
    },
});