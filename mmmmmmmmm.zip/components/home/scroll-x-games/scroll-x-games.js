Component({
  mixins: [],
  data: {},
  props: {
    games: Array,
    typefrom:'game',
    width:'228rpx'
  },
  didMount() {},
  didUpdate() {},
  didUnmount() {},
  methods: {
  },
});
