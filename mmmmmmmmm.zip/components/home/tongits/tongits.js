import { getMachList } from '/api/activity'
import miniStomp from "../../../plugin/mini-stomp";
import {
  navigateToGame
} from "/api/service/navigate-to-h5";
let unscribeFnId = null
Component({
  mixins: [],
  data: {
    tongitsitem:[],
    subId:null
  },
  props: {
    title:String,
    icon:String
  },
  didMount() {
    var _that = this
    _that.getMrchList()
    if(unscribeFnId){
      miniStomp.unsubscribe(unscribeFnId)
      unscribeFnId= null
    }
    let url = `/topic/tiptopMatchListChange`
    unscribeFnId = miniStomp.subscribe(url)
    miniStomp.hook(url, (data) => {
      // console.log(_that.data.subId)
      // console.log('hook', '/topic/tiptopMatchListChange', data)
      const NewTongitsArry = JSON.parse(data.matchList).map((items) => {
        items.countdowntime = items.startTime - items.serverTime
        items.entertime = items.earlyEnterTime - items.serverTime
        if (items.cycleTimeItem && items.cycleTimeItem.length > 0) {
          const findCycle = items.cycleTimeItem.find(
            (TimeItem) =>
              items.serverTime >= TimeItem.startTimeSec &&
              items.serverTime <= TimeItem.finishTimeSec
          )
          if (findCycle) {
            items.delaySeconds = findCycle.intervalSec / 60
          } else {
            items.delaySeconds = 0
          }
        } else {
          items.delaySeconds = 0
        }
        items = _that.manualSetMatchesPrize(items)
        if(items.signType ==  0 || items.signType ==  1 ){
          return items
        }
      }).filter(Boolean) || [];
      _that.setData({
        tongitsitem:NewTongitsArry
      })
      _that.getnewlist()
    })
  },
  didUpdate() {},
  didUnmount() {
    if(unscribeFnId){
      miniStomp.unsubscribe(unscribeFnId)
      unscribeFnId= null
    }
  },
  methods: {
    // 获取赛事列表
    async getMrchList() {
      var _that = this
      const { success, body } = await getMachList({})
        if(success){
          if(body == null){
            return
          }
          const listArray = body.map((item) =>{
            item.countdowntime = item.startTime - item.serverTime
            item.entertime = item.earlyEnterTime - item.serverTime
            if (item.cycleTimeItem && item.cycleTimeItem.length > 0) {
              const findCycle = item.cycleTimeItem.find(
                (TimeItem) =>
                  item.serverTime >= TimeItem.startTimeSec &&
                  item.serverTime <= TimeItem.finishTimeSec
              )
              if (findCycle) {
                item.delaySeconds = findCycle.intervalSec / 60
              } else {
                item.delaySeconds = 0
              }
            } else {
              item.delaySeconds = 0
            }
            item = _that.manualSetMatchesPrize(item)
            if(item.signType ==  0 || item.signType ==  1 ){
              return item
            }
          })
          _that.setData({
            tongitsitem:listArray
          })
          _that.getnewlist()
        }
      },
      manualSetMatchesPrize(match){
        // 金额等于0的时候需要手动写死
        if (Number(match.totalPrizeNum) <= 0) {
          // 每日当场设置 12888
          if (match.repeatType == 1) {
            match.totalPrizeNum = 12888 * 1000
          } else if (match.repeatType == 2) {
            match.totalPrizeNum = 188 * 1000
          }
        }
        return match
      },
      //筛选出免费赛跟付费赛赛事
    getnewlist(){
      if(!this.data.tongitsitem) return
      // 免费
     const onegamelist = this.data.tongitsitem
        .filter((item) => {
          return item.signType == 1
        })
        .sort((a, b) => a.startTime - b.startTime)
      // 付费
      let twogamelist = this.data.tongitsitem
        .filter((item) => {
          return item.signType == 0
        })
        .sort((a, b) => a.startTime - b.startTime)
        if(onegamelist.length > 0){
          twogamelist = [...[onegamelist[0]],...twogamelist]
         } else{
          twogamelist = [...twogamelist]
        }
        this.setData({
          tongitsitem:twogamelist
        })
    },
    onRight(){
      const params ={
        targetUrl:'',
         gameId: 'tongits',
         platformId: '175'
     }
       navigateToGame(params)
    }
  },
});
