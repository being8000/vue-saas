Component({
  mixins: [],
  data: {
  },
  props: {
    text: String,
    style: String,
    systemInfo: Object
  },
  async didMount() {
    // const res = await systemInfoPromiser
    // if(res){
    //   this.setData({
    //     'statusBarHeight': Number(res.statusBarHeight), //状态栏高度
    //     'titleBarHeight': Number(res.titleBarHeight), //标题栏高度         
    //   })
    // }
  },
  didUpdate() {},
  didUnmount() {},
  methods: {
    back() {
      my.navigateBack()
    }
  },
});
