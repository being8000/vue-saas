Component({
  mixins: [],
  data: {
    closing: false
  },
  props: {
    visible: Boolean
  },
  didMount() {},
  didUpdate(preProps) {},
  didUnmount() {},
  methods: {

  },
});