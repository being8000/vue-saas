Component({
  mixins: [],
  data: {
    paddingTop: '100%'
  },
  props: {
    aspectRatio: Number,
    width: String,
    styles: String,
    onTap: Function
  },
  didMount() {
    // const aspectRatio = this.props.aspectRatio || 1
    // const paddingTop = `${aspectRatio * 100}%`;
    // this.setData({
    //   paddingTop
    // });
  },
  didUpdate() {},
  didUnmount() {},
  methods: {
    onTap(e){
      this.props.onTap && this.props.onTap(e)
    }
  },
});