import getFile from '../../api/service/getFile.js';

Component({
  mixins: [],
  data: {
    // visible: false,
    htmlContent: ''
  },
  props: {
    title: String,
    confirmButtonText: String,
    cancelButtonText: String,
    onConfirm: Function,
    onCancel: Function,
    showRulesDialog: String,
    rulesLink: String
  },
  didMount() {
  },
  didUpdate() {
    this.getData()
  },
  didUnmount() {},
  methods: {
    onConfirm() {
      this.props.onConfirm && this.props.onConfirm()
    },
    onCancel() {
      this.props.onCancel() && this.props.onCancel()
    },
    async getData() {
      const rule = this.props.rulesLink
      const htmlContent = await getFile(rule)
      this.setData({
        htmlContent
      })
    }
  },
});