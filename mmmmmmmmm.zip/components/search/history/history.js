import {
  bindSearchPopular,
  historySearch
} from "../history";
import useSearch from "../useSearch";
import {
  $dialog
} from "/components/v4-dialog";

Component({
  mixins: [],
  data: {
    searchGames: [],
    onDeleteConfirmVisible: false
  },
  props: {},
  didMount() {
    bindSearchPopular(this)
  },
  didUpdate() {},
  didUnmount() {},
  methods: {
     onDelete() {
      this.setData({
        onDeleteConfirmVisible: true
      })
    },
    onRemove(e) {
      const item = e.currentTarget.dataset.value
      historySearch.removeItem(item)
    },
    onHistoryClick(e) {
      const item = e.currentTarget.dataset.value
      const { setText } = useSearch()
      setText(item)
    },
    onButtonTap(buttonItem){
      console.log('点击的按钮: ', buttonItem);
      this.setData({
        onDeleteConfirmVisible: false
      })
      if(buttonItem.text === 'Yes'){
        historySearch.removeAll()
      } 
    }
  },
});