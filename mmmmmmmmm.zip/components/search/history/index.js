let searchPopularInstance = null
const POPULAR_STAORE = 'POPULAR_STAORE'
const setPopularStore = (data = []) => {
  if(searchPopularInstance){
    searchPopularInstance.setData({
      searchGames: data
    })
  }
  my.setStorageSync({
    data,
    key: POPULAR_STAORE
  })
}

const getPopularStore = () => {
  return my.getStorageSync({
    key: POPULAR_STAORE
  }).data || []
}

const addItem = (item) => {
  if (item) {
    const data = getPopularStore()
    const index = data.findIndex(el => el == item)
    if (index > -1) {
      data.splice(index, 1)
    }
    data.unshift(item)
    if (data.length > 8) {
      data.pop()
    }
    setPopularStore(data)
  }
}

const removeAll = () => {
  setPopularStore([])
}

const removeItem = (item) => {
  if (item) {
    const data = getPopularStore()
    const index = data.findIndex(el => el == item)
    if (index > -1) {
      data.splice(index, 1)
      setPopularStore(data)
    }
  }

}
export function bindSearchPopular(instance) {
  searchPopularInstance = instance
  const data = getPopularStore()
  console.log('getPopularStore', data)
  searchPopularInstance.setData({
    searchGames: data
  })
}

export const historySearch = {
  addItem,
  removeItem,
  removeAll
}