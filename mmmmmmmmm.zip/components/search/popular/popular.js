import useSearch from "../useSearch";

Component({
  mixins: [],
  data: {
    list: [
      'GameZone',
      'Tongits',
      'Pusoy',
      'Mines',
      'Fortune Ace',
    ]
  },
  props: {},
  didMount() {
  },
  didUpdate() {},
  didUnmount() {},
  methods: {
    onPopularClick(e) {
      const item = e.currentTarget.dataset.value
      const { setText } = useSearch()
      setText(item)
    }
  },
});
