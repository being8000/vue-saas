import { emitGZInputChange } from "../ui/gz-input"

let searchInput = null

export default function(){
  function bindInstance(instance){
    searchInput = instance
  }
  function setText(text){
    if(searchInput){
      searchInput.setData({
        text: text
      })
      const props = searchInput.props
      if(props && props.onInput){
        props.onInput(text)
      }
      emitGZInputChange(text)
    }
  }
  return  {
    bindInstance,
    setText
  }
}
