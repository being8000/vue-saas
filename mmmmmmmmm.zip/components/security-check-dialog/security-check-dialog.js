const app = getApp();

const InputStatus = {
  Focus: 'focus',
  Error: 'error',
  None: '',
  Maximum: 'maximum-limit'
}

Component({
  mixins: [],
  data: {
    errorMessage: '',
    password: "", // 密码输入值
    inputStatus: InputStatus.None,
    loading: false
  },
  props: {
    mask: "",
    customerId: "",
    token: "",
    visible: false, // 是否显示
    maxlength: 4, // 密码最大输入长度
    onSuccess: () => {}, // 验证成功
  },
  didUpdate() {
    if (!this.props.token) {
      this.setData({
        inputStatus: InputStatus.Maximum
      })
    }
  },

  deriveDataFromProps(nextProps) {},
  didUnmount() {},
  methods: {
    // 外层盒子点击事件
    popClick() {
      this.setData({
        inputStatus: InputStatus.None
      })
    },
    // 关闭按钮点击事件
    onClose() {
      this.props.onClose();
    },
    // 输入框输入监听
    onInput(password) {

      if (password.length > 4) {
        return
      }
      const inputStatus = password.length == 4 ? InputStatus.None : InputStatus.Focus
      this.setData({
        password,
        inputStatus
      });
    },

    // 输入密码点击事件
    // payClick() {
    //   this.setData({
    //     focus: true
    //   })
    // },

    // 密码输入框失去焦点监听
    onBlur() {
      this.setData({
        inputStatus: InputStatus.None
      })
    },
    onClose() {

    },
    // 密码输入框获取焦点监听
    onFocus() {
      this.setData({
        inputStatus: InputStatus.Focus
      });
    },
    // 点击键盘完成时触发
    onKeyConfirm() {
      // my.hideKeyboard();
      // this.setData({
      //   focus: false
      // });
    },
    // 提交验证码
    sumbit() {
      this.setData({
        loading: true
      })
      const {
        password,
      } = this.data;
      const {
        customerId,
        token
      } = this.props
      // TODO 手机号掩码校验接口
      app._request('applets/verifyPhoneMask', {
        customerId,
        token,
        mask: password,
      }).then((res) => {
        // failReason 错误原因 0无错误,1 mask错误 2 token超时或TOKEN错误 3到达最大次数
        // loseTryTimes 还可以尝试的次数,token错误不减少该次数
        const {
          head,
          body
        } = res || {}
        if (head && head.errCode) {
          const {
            failReason,
            loseTryTimes
          } = body || {}
          let errorMessage = ''
          let inputStatus = InputStatus.None
          if (failReason == undefined) {
            my.showToast({
              type: 'none',
              content: 'failReason is empty',
              duration: 3000,
            })
            return
          } else if (failReason == 0) { // 0无错误
            errorMessage = ''
            inputStatus = InputStatus.None
          } else if (failReason == 1) { // ,1 mask错误 
            errorMessage = `Incorrect, ${loseTryTimes} attempts left.`
            inputStatus = InputStatus.Error
          } else if (failReason == 2) { // token超时或TOKEN错误
            errorMessage = `Operation timed out, login again please（3）`
            inputStatus = InputStatus.Error
          } else if (failReason == 3) { // 3到达最大次数
            inputStatus = InputStatus.Maximum
          }

          this.setData({
            errorMessage,
            inputStatus,
            loading: false
          })
        } else {
          this.props.onSuccess(res)
        }

      }).catch(() => {
        this.setData({
          loading: false
        })
      })

    },


    toCustomerService() {

      const apiUrl = app.getBaseUrl({
        route: '',
        queryParams: {
          target: 'CS'
        }
      })
      const {
        appId
      } = app.globalData
      my.call('navigateToLink', {
        targetLink: apiUrl,
        appId: appId,
        success: (res) => {
          // my.alert({ content: JSON.stringify(res) });
        },
        fail: (res) => {
          my.alert({
            content: JSON.stringify(res)
          });
        }
      });
    },
    // 弱提示警告
    warnToast(text, time = 2000) {
      my.showToast({
        type: "none",
        content: text,
        duration: time
      });
    }
  }
});