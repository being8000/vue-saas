// import {
//   requestEndorserStatus
// } from "/api/spokesperson"
Component({
  mixins: [],
  data: {
    myVideo: null,
    status: 0
  },
  props: {
    spokenPerson: Array
  },
  async didMount() {
      // const {
      //   body
      // } = await requestEndorserStatus()
      // this.setData({status:body.status})
      // console.log(body, 'status123')
  },
  didUpdate() {},
  didUnmount() {
    this.setData({
      myVedio: my.createVideoContext('#myVideo') // 绑定视频 ID
    })
  },
  methods: {
    handleLoop() {
      console.log(this,'this')
     setTimeout(()=> {
      this.data.myVideo.seek(0); // 跳转到起点
      this.data.myVideo.play();  // 重新播放
     },500)
    }
  },
});
