import {
  navigateToGame
} from "/api/service/navigate-to-h5";
Component({
  mixins: [],
  data: {
  },
  props: {
    item: Object,
    width: '250px'
  },
  didMount() {
  },
  didUpdate() {},
  didUnmount() {
  },
  methods: {
    // 进入游戏大厅
      tongitsGameLobby(e){
      const item = e.currentTarget.dataset.value
      const params ={
         targetUrl:item.redirectLink,
          gameId: 'tongits',
          jumpJson: {"activity":'tournament_'+item.listId},
          platformId: '175'
      }
        navigateToGame(params)
      }
  },
});
