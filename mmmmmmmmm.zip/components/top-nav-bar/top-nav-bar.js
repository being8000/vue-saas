Component({
  mixins: [],
  data: {
    titleBarHeight: 44
  },
  props: {
    style: String,
    systemInfo: Object
  },
  didMount() {},
  didUpdate() {},
  didUnmount() {},
  methods: {
    toSearch() {
      my.navigateTo({
        url: '/pages/search/search'
      });
    }
  },
});
