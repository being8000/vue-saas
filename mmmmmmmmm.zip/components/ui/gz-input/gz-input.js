import { emitGZInputChange } from ".";

Component({
  mixins: [],
  data: {
    text: ''
  },
  props: {
    onInput: Function,
    onFocus: Function,
    onBlur: Function,
    enableNative: Boolean,
    placeholder: String,
    style: String,
    maxLength: Number,
    onRef: Function
  },
  didMount() {
    this.props.onRef && this.props.onRef(this)
  },
  didUpdate() {},
  didUnmount() {},
  methods: {
    onInput(e){
      emitGZInputChange(e.detail.value)
      this.props.onInput && this.props.onInput(e.detail.value)
    },
    onFocus(e){
      this.props.onFocus && this.props.onFocus(e.detail.value)
    },
    onBlur(e){
      this.props.onBlur && this.props.onBlur(e.detail.value)
    },
  },
});
