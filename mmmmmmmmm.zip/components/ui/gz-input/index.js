import {
  useEventBus
} from "/utils/use-event-bus";

const inputBus = useEventBus('ui-input-change-event-bus')


export function onGZInputChange(callbackFn) {
  return inputBus.on((listenEvent, data) => {
    if ('onInput' === listenEvent) {
      callbackFn && callbackFn(data)
    }
  })
}

export function emitGZInputChange(data) {
  inputBus.emit('onInput', data)
}