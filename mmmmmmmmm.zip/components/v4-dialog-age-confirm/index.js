import {
  useEventBus
} from "/utils/use-event-bus";
import { getCurrentCtx } from "/utils";

const dialogBus = useEventBus('dialog-age-confirm-event-bus')
const dialogBusType = {
  VisibilityUpdate: 'VisibilityUpdate',
  EventBack: 'EventBack'
}
const eventMap = new WeakMap()
export const $ageDialog = {
  /** 
   * @param {DialogOptions} options 
   */
  confirm(options = {}) {
    const ctx = getCurrentCtx()
    const pageId = ctx.$id
    return new Promise((resolve) => {
      eventMap.set(options, resolve)
      dialogBus.emit({
        type: dialogBusType.VisibilityUpdate,
        data: options,
        pageId: pageId
      })
    })
  }
}

export const onDialogVisibleUpdate = (componentInstance) => {
  const ctx = getCurrentCtx()
  const currentPageId = ctx.$id
  dialogBus.on(({
    type,
    data
  }) => {
    if (type === dialogBusType.VisibilityUpdate && pageId === currentPageId) {
      if (componentInstance) {
        componentInstance.setData({
          visible: true,
          ...data,
          resolveFn: eventMap.get(data)
        })
      }
    }
  })
}