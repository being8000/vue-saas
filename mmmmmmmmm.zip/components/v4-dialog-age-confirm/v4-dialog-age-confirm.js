import {  onDialogVisibleUpdate } from "."
Component({
  data: {
    isNoMore: false,
  },
  props: {
    visible: false,
    resolveFn: null,
  },
  didMount() {
    onDialogVisibleUpdate(this)
  },
  methods: {
    onConfirm(e) {
      this.setData({
        visible: false
      })
      const resolveFn = this.data.resolveFn 
      resolveFn && resolveFn(true)
    },
    onPopupClose() {
      this.setData({
        visible: false
      })
      const resolveFn = this.data.resolveFn 
      resolveFn(false)
    },
  }
})