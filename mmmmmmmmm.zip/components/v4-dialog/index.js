import { getCurrentCtx } from "/utils";
import {
  useEventBus
} from "/utils/use-event-bus";
let dialogBus = useEventBus('dialog-event-bus')
const dialogBusType = {
  VisibilityUpdate: 'VisibilityUpdate',
  EventBack: 'EventBack'
}
/**
 * @typedef {{
 * title: string, // 标题， 默认Notice
 * content: string, // 消息提示内容
 * confirmButtonText: string, // 确认按钮文字内容
 * cancelButtonText: string, // 取消按钮文字内容
 * confirmButtonVisible: boolean // 是否显示确认按钮
 * cancelButtonVisible: boolean // 是否显示取消按钮
 * hideCancelButton: boolean
 * }} DialogOptions 
 */
const eventMap = new WeakMap()
export const $dialog = {
  /** 
   * @param {DialogOptions} options 
   */
  confirm(options = {}) {
    const ctx = getCurrentCtx()
    const pageId = ctx.$id
    return new Promise((resolve) => {
      eventMap.set(options, resolve)
      dialogBus.emit({
        type: dialogBusType.VisibilityUpdate,
        data: options,
        pageId: pageId
      })
    })
  }
}

export const onDialogVisibleUpdate = (componentInstance) => {
  const ctx = getCurrentCtx()
  const currentPageId = ctx.$id
  dialogBus.on(({
    type,
    data,
    pageId
  }) => {
    if (type === dialogBusType.VisibilityUpdate && pageId === currentPageId) {
      if (componentInstance) {
        componentInstance.setData({
          visible: true,
          ...data,
          resolveFn: eventMap.get(data),
          hideCancelButton: data.hideCancelButton || false
        })
      }
    }
  })
}