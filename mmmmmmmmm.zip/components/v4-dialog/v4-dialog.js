import {  onDialogVisibleUpdate } from "."

Component({
  data: {
    content: '',
    visible: false,
    resolveFn: null,
    cancelButtonVisible: true,
    confirmButtonVisible: true,
    hideCancelButton: false
  },
  didMount() {
    onDialogVisibleUpdate(this)
  },
  methods: {
    onConfirm() {
      this.setData({
        visible: false
      })
      const resolveFn = this.data.resolveFn 
      resolveFn && resolveFn(true)
    },
    onClose() {
      this.setData({
        visible: false
      })
      const resolveFn = this.data.resolveFn 
      resolveFn(false)
    }
  }
})