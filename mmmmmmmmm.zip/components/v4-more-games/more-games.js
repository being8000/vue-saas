import {navigateToH5} from '/api/service/navigate-to-h5'
Component({
  data: {
    showSearchPopup: false,
  },
  props: {
    onExploreGamesTap: Function,
  },
  methods: {
    onKf(){
      navigateToH5('CS')
    },
    onMore() {
      this.props.onExploreGamesTap();
      console.log('YYUUUU')
      my.sensors.track('moreGamesClick', {
        b_id:'home_page',
        page_b_name:'首页',
        c_id:'more',
        page_c_name:'More',
      })
      // 测试一下路由跳转
      // const objData = {
      //   title: 'deposit successful! deposit successful! dep osit successful!deposit successful! deposit successful! ',
      //   startTime: '2025',
      //   endTime: '2024',
      //   bannerContentNodes:'One Casino with the intention to create the best pos sible online casino. We used our combined expert e',
      //   buttonContent:'Go Jump',
      //   url: 'abc'
      // }
      // const jsonData = JSON.stringify(objData)
      // console.log(encodeURIComponent(jsonData),'路由参数====');
      // const url = `/pages/details/details?data=${encodeURIComponent(jsonData)}`;
      // my.navigateTo({ url });
    }
  }
})

