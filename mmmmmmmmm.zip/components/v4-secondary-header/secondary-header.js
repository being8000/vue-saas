Component({
  mixins: [],
  data: {
    statusBarHeight: 0,
    titleBarHeight: 0,
  },
  props: {
    onJumpLink: Function,
    text: String,
    icon: '../../assets/back-icon.png' || String,
  },
  didMount() {
    my.getSystemInfo({
      success: (res) => {
        this.setData({
          'statusBarHeight': Number(res.statusBarHeight), //状态栏高度
          'titleBarHeight': Number(res.titleBarHeight), //标题栏高度         
        })
      }
    })
  },
  methods: {
    jumpLink() {
      this.props.onJumpLink()    
    }
  }
})