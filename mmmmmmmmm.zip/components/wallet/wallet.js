import request from '/api/lib/request';
import {
  withFront,
  withGlaxy
} from '/api/lib/utils';
import {
  normalizedPaymentData,
  addNumber
} from "/utils";
import {
  formatPrice,
  formatAmount
} from "/mixins";
import {
  customerTaskStatus
} from "/api/bonus";
import {
  getBetAmount
} from '/api/user'
const sensors = require("../../sensorsdata.esm.js");
import {
  beforeDepositCheck
} from "/api/service/kyc-checker";
import { loginEmitter } from '/plugin/proxy/login-emitter.js';
Component({
  mixins: [],
  data: {
    balance: "- -",
    nickName: "***",
    isShowNickNameAll: false,
    isUserInfo: {
      loginName: "- -",
    },
  },
  props: {},
  didMount() {
    this.refreshBalance();
    const userInfo = my.getStorageSync({
      key: "userInfo", // 缓存数据的key
    }).data;

    this.setData({
      isUserInfo: userInfo,
    })
    this.hideAvailableNickName();

  },
  didUpdate() {},
  didUnmount() {},
  onReLogin(){
    this.refreshBalance();
    const userInfo = my.getStorageSync({
      key: "userInfo", // 缓存数据的key
    }).data;

    this.setData({
      isUserInfo: userInfo,
    })
  },
  methods: {
    onTest(){
      console.log(111)
      loginEmitter.emitLoginEvent()
    },
    async refreshBalance(type) {
      const params = {
        flag: 1,
        type: type,
      };

      if (type !== 0) {
        request(
          withGlaxy("/applets/refreshBalance"), {
            showLoading: false
          }
        ).then(() => {
          params.type = 0;
        });
      }

      this.getBalance(params);
      this.getBalanceList()
    },
    //获取余额数据
    async getBalance(params) {
      const data = this.data;
      // // 是否參加活動
      this.isAttendActivty(params)

      this.setData({
        refreshFlag: true,
        isBalanceReloading: true,
      });
      const res = (await request(
        withGlaxy("/applets/getBalanceV2"), {
          body: {
            params
          },
          showLoading: false
        }
      ))
      console.log('getBalanceV2', res)
      // .then((res) => {
      // 如果 balanceFlag = 0 或有错误尝试调用 api 8 次
      // if balanceFlag = 0 or has err try call api 8 times
      if ((res.body.balanceFlag == 0 && data.balFlag <= 8) || res.body.errCode) {
        /**
         * if balFlag = 8 显示 toast else
         * 重复这个过程直到 balanceFlag = 1
         * if balFlag = 8 show toast else
         * repeat the process until balanceFlag = 1
         */
        if (data.balFlag == 3) {
          app.toast(
            "Account limit has timed out, Please click the button to refresh"
          );

          this.setData({
            isBalanceReloading: false,
          });

          this.setData({
            refreshFlag: false,
            balFlag: 1,
            balancePopupActive: false,
          });
        } else {
          this.setData({
            balFlag: data.balFlag + 1,
          });

          // 调用 get balance 延迟 2 秒 / 2 seconds delay for calling get balance
          clearTimeout(this.data.balanceDelay);
          let setBalanceDelay = setTimeout(() => {
            this.getBalance(params);
          }, 2000);

          this.setData({
            balanceDelay: setBalanceDelay,
          });
        }
      } else {
        const [integerPart, decimalPart] = res.body.withdrawBal.toFixed(2).toString().split('.');
        this.setData({
          isBalance: res.body,
          balance: formatAmount(integerPart),
          balanceDecimal: decimalPart,
          platformBalances: res.body.platformBalances,

          refreshFlag: false,
          isBalanceLoaded: true,
          balFlag: 1,
          isBalanceReloading: false,
        });
        // app.toast('Balance refresh successfully')
      }
      // });
    },
    async getBalanceList() {
      const res = await getBetAmount()
      this.setData({
        'getBetAmountSub': formatPrice(addNumber(res.boundsBalance || 0, res.chipsBalance || 0))
      })
    },
    async isAttendActivty(params) {
      const {
        success,
        body
      } = await customerTaskStatus(params)
      if (success) {
        this.setData({
          userStatus: body
        })
      }
    },
  
    getNickName() {
      let isUserInfo = this.data.isUserInfo || {};

      let name = isUserInfo.nickName;
      if (name == null || name == undefined || name.trim() === "") {
        name = isUserInfo.loginName;
      }
      return name;
    },
    async hideAvailableNickName() {
      // my.alert({ content: "Your nickname has been updated successfully!" })
      this.setData({
        nickName: this.getStartNmaeInitials(this.getNickName()),
        isShowNickNameAll: false,
      });
    },
    async showAvailableNickName() {
      this.setData({
        nickName: this.getNickName(),
        isShowNickNameAll: true,
      });
    },
    getStartNmaeInitials(name) {
      if (!name) return "";
      if (name.length > 4) {
        return name.slice(0, 2) + "***" + name.slice(-2);
      } else {
        return name.slice(0, 1) + "***" + name.slice(-2);
      }
    },
    async openBonusDepositPopup(e) {
      sensors.track('depositClick', {
        b_id: 'home_page',
        page_b_name: '首页',
        c_id: 'deposit',
        page_c_name: '存款',
      })
  
      this.submitEvent(e);
      // // 先判断是否完成KYC
      const {
        show,
        text = ""
      } = await beforeDepositCheck();
      if (show) {
        this.setData({
          showConfirmKYCPopup: true,
          showConfirmKYCPopupText: text,
          kycPopType: typeMaps.Deposit,
        });
      } else {
        let isWithdraw =  e.target.dataset.value !== 'Top-up'
        this.setData({
          showTipsPopup: false,
          showRegistrationBonusPoupup: false,
          // showBonusDepositPopup: true,
        });
        console.log('跳转存款');
        my.navigateTo({
          url: '/pages/deposit/ac-deposit?isWithdraw='+isWithdraw
        });
      }
    },
    async submitEvent(e) {
      let event = e;
  
      if (typeof event === "object") {
        event = event.target.dataset.eventType;
      }
  
      // if the user complete the first deposit
      // if(!this.data.isFirstDeposit) {
      //   event = 'depositclick'
      // }
  
      if (event) {
        await request(
          withGlaxy("/applets/eventTracking"), {
            body: {
              event,
              customerId: this.data.isUserInfo.customerId,
            }
          }
        );
      }
    },
  },
});