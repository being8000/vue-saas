import { testTokenMap } from "./env_token";
import { envMap } from "./utils/const";

/**
 * 注意： 设置当前开发环境，打包 UAT 和 生产需要配置对应的环境，
 * 测试机预览需要设置 UAT, 不能设置Local
 * 设置Local环境，可以在编译器中预览，模拟授权环境，前提条件如下：
 * 1. 需要在UAT环境下，通过开发机扫码Debug, 在缓存中获取 infoToken 并复制
 * 2. 将复制的环境信息，赋值到到下面glifetoken，
 * 3. 将当前环境设置为Local 即可
 **/
export const DEFAULT_ENV = envMap.LOCAL;

export const getCurrentEnv = () => {
  return DEFAULT_ENV
}
// 用于模拟Local环境下（Idea环境下Gcash授权）, 
// !!! 如果更换token请记得清理一下缓存s
export const glifeToken = testTokenMap.token6;
