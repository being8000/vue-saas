export const testTokenMap = {
  token1: {
    resultBody: {
      accessTokenExpiryTime: "2026-05-28T11:07:05+08:00",
      result: {
        resultStatus: "S",
        resultCode: "SUCCESS",
        resultMessage: "success.",
      },
      refreshTokenExpiresIn: "0",
      accessTokenExpiresIn: "0",
      customerId: "110700400000000000650040232",
      accessToken:
        "20241202kv8wevjX8fYufAkAFRjX0L0zM0xof3MlvalfJyIWvQf0885000272583",
      extendInfo:
        '{"publicUserId":"110700400000000000650039009","loginId":"63-9****51113","merchantId":"217020000649590709995"}',
      refreshTokenExpiryTime: "2026-05-28T11:07:05+08:00",
      refreshToken:
        "202412022vfX9p8DXN7l7VhwT1ElPcwNx05f9xPMmT9awWGjDR40885000272584",
    },
  },
  token3: { "resultBody": { "accessTokenExpiryTime": "2027-01-02T14:44:53+08:00", "result": { "resultStatus": "S", "resultCode": "SUCCESS", "resultMessage": "success." }, "refreshTokenExpiresIn": "0", "accessTokenExpiresIn": "0", "customerId": "110700400000000000649224291", "accessToken": "20250102gg0ip3irIHPphShbaEhTy02ZFYfFhgojhLXBViN1pPy0881200277456", "extendInfo": "{\"publicUserId\":\"110700400000000000649224291\",\"loginId\":\"63-9****21113\",\"merchantId\":\"217020000649590709995\"}", "refreshTokenExpiryTime": "2027-01-02T14:44:53+08:00", "refreshToken": "20250102OlcepgchgWVsbOoM9Ny1tlPzVP3vIwd10HOFCx7w41Q0881200277457", "authCode": "local-test", "writeTime": 1736151493438 } },
  token2: { "resultBody": { "accessTokenExpiryTime": "2027-01-02T14:44:53+08:00", "result": { "resultStatus": "S", "resultCode": "SUCCESS", "resultMessage": "success." }, "refreshTokenExpiresIn": "0", "accessTokenExpiresIn": "0", "customerId": "110700400000000000649224291", "accessToken": "20250102gg0ip3irIHPphShbaEhTy02ZFYfFhgojhLXBViN1pPy0881200277456", "extendInfo": "{\"publicUserId\":\"110700400000000000649224291\",\"loginId\":\"63-9****21113\",\"merchantId\":\"217020000649590709995\"}", "refreshTokenExpiryTime": "2027-01-02T14:44:53+08:00", "refreshToken": "20250102OlcepgchgWVsbOoM9Ny1tlPzVP3vIwd10HOFCx7w41Q0881200277457" } },
  token4: { "resultBody": { "accessTokenExpiryTime": "2027-03-07T18:15:09+08:00", "result": { "resultStatus": "S", "resultCode": "SUCCESS", "resultMessage": "success." }, "refreshTokenExpiresIn": "0", "accessTokenExpiresIn": "0", "customerId": "110700400000000000650353824", "accessToken": "20250307uSjQFRNrRfCs9UzIiSvQ6GYbbvelLcbh2lnRAhye70r0884500303559", "extendInfo": "{\"publicUserId\":\"110700400000000000650353824\",\"loginId\":\"63-9****93614\",\"merchantId\":\"217020000649590709995\"}", "refreshTokenExpiryTime": "2027-03-07T18:15:09+08:00", "refreshToken": "20250307RIPoY15WpPmAcmxxQ4iQ9imUhT9j09asYaQdpO68oMG0884500303560" } },
  token5: { "resultBody": { "accessTokenExpiryTime": "2027-03-11T13:44:01+08:00", "result": { "resultStatus": "S", "resultCode": "SUCCESS", "resultMessage": "success." }, "refreshTokenExpiresIn": "0", "accessTokenExpiresIn": "0", "customerId": "110700400000000000650353822", "accessToken": "20250311LxMkEbUtJBsM3IZYlmkSdZ983hYqw969RhxGMAOVzHV0884300312656", "extendInfo": "{\"publicUserId\":\"110700400000000000650353822\",\"loginId\":\"63-9****45462\",\"merchantId\":\"217020000649590709995\"}", "refreshTokenExpiryTime": "2027-03-11T13:44:01+08:00", "refreshToken": "20250311IvrPUtUkj3JO31W4u1aOWeYW12MGtVyuBwKCRTaZyWy0884300312657" } },
  token6: { "resultBody": { "accessTokenExpiryTime": "2027-03-11T16:40:25+08:00", "result": { "resultStatus": "S", "resultCode": "SUCCESS", "resultMessage": "success." }, "refreshTokenExpiresIn": "0", "accessTokenExpiresIn": "0", "customerId": "110700400000000000650039008", "accessToken": "20250311zskZDksFbYyoyg1tQHu5fcJUJ0fWlDOWE4WmlWsXJLF0885100305313", "extendInfo": "{\"publicUserId\":\"110700400000000000650039008\",\"loginId\":\"63-9****93617\",\"merchantId\":\"217020000649590709995\"}", "refreshTokenExpiryTime": "2027-03-11T16:40:25+08:00", "refreshToken": "20250311Wd9i3Obd5ddv3LIzoa44dCYg6sUOtqkdq5cIFNDfnyj0885100305314" } }, "head": { "cost": 0, "errCode": "0000", "errMsg": "successful operation" }
}

/**
 * token6 存款活动白名单
 * 
 */