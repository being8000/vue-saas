import CryptoJS from 'crypto-js';

/**
 *
 * Import this mixins to use methods below
 *
 * ========== Example Implementation =========
 *  import { setStorageCache } from '/mixins';
 * ===========================================
 *
 */

export default {
  /*
   *  Set local storage cache
   *  @param string name
   */
  setStorageCache(key, data) {
    my.setStorageSync({
      key: key,
      data: data,
    });
  },

  /*
   *  Get local storage cache
   *  @param string key
   *  @returns object
   */
  getStorageCache(key) {
    const localStorage = my.getStorageSync({
      key: key,
    });

    return localStorage.data;
  },

  /*
   * Remove specific item to local cache
   * @param string key
   */
  removeStorageCache(key) {
    my.removeStorageSync({
      key: key,
    });
  },

  /*
   * Clear all cache data
   */
  clearStorageCache() {
    my.clearStorageSync();
  },

  /*
   * Price formatter
   *
   * @param price 53453
   */
  formatPrice(price) {
    /*
     * Price format with 2 decimal place
     * this will return 53,453.00
     */
    return Number(price).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
  },

  formatAmount(amount) {
    /*
     * Price format without decimal place
     * this will return 53,453
     */
    return amount.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,")
  },
  formatMoneyWithK(value) {
    if (value >= 1000) {
      return (value / 1000).toFixed() + 'k';
    }
    return value;
  },

  /**
   * Use to encrypt parameter pass to the backend
   *
   * @param { string to encrppt } word
   * @param { random string to pass along with word } keyWord
   */
  aesEncrypt(word, keyWord = 'XwKsGlMcdPMEhR1B') {
    var key = CryptoJS.enc.Utf8.parse(keyWord);
    var srcs = CryptoJS.enc.Utf8.parse(word);
    var encrypted = CryptoJS.AES.encrypt(srcs, key, {
      mode: CryptoJS.mode.ECB,
      padding: CryptoJS.pad.Pkcs7,
    });
    return encrypted.toString();
  },
};
