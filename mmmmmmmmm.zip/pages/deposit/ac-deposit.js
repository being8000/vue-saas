import {
  getdepositList,
  getdepositConfig,
  getDepositUserInfo,
  getSpinConfig,
  getSpinProgressConfig,
  depositActivityClaim
} from '/api/activity'
import {
  normalizedPaymentData
} from "../../utils/index";
import request from '/api/lib/request'
import {
  getStorageCache,
  formatPrice,
  formatAmount,
  formatMoneyWithK
} from "/mixins";
import getFile from '../../api/service/getFile.js';
import parse from "mini-html-parser2";
import {
  processNodes
} from '/utils/index'
import {
  withGlaxy
} from '/api/lib/utils'
import {
  isFirstDepositFlag,
  refreshIsFirstDepositFlag,
  setFirstDepositFlag
} from '/api/service/kyc-checker'
import {
  navigateToH5
} from "../../api/service/navigate-to-h5";
import miniStomp from "../../plugin/mini-stomp";
import {
  getUserInfo,
} from "../../utils"
import pureRequest from '/api/lib/pure-request';
import {
  requestWithdraw,
  fetchWithdrawConst,
  fetchWithdrawSwitch
} from "/api/wallet";
const defalutAmountOptions = [{
    title: "200",
    value: 200,
  },
  {
    title: "500",
    value: 500,
  },
  {
    title: "1,000",
    value: 1000,
  },
  {
    title: "5,000",
    value: 5000,
  },
  {
    title: "10,000",
    value: 10000,
  },
  {
    title: "20,000",
    value: 20000,
  },
];
const sensors = require("../../sensorsdata.esm.js");
const app = getApp();
Page({
  data: {
    // showPopup: false,
    activeDepositAmount: null,
    depositAmountOptions_topUP: Array(6).fill({}), // 占位
    depositAmountOptions_withdraw: Array(6).fill({}), // 占位
    redPrice: Array(6).fill({}), // 占位
    formattedBalance: '',
    isAmount: null,
    isFlag: true,
    isUserInfo: {
      loginName: '- -'
    },
    tokenInfo: null,
    depositOptions: ['Top-up', 'Withdraw'],
    isAmountInput: false,
    keyboardHide: true,
    disableSubmit: true,
    isAmountInputError: false, // IOS事件似乎会触发两次，会导致两次错误检验的toast，这个值作为时间间隔

    min: 100, // 充值最小值
    max: 100000, // 充值最大值,
    depositConditions: {},
    up_to_Bonus: 0,
    willGetBonus: 0,
    balance: "- -",
    balanceDecimal: "",
    isBalance: {},
    refreshFlag: false,
    balFlag: 1,
    balancePopupActive: false,
    platformBalances: [],
    isRefresh: false,
    history_list: [], // 历史列表
    config_Array: {
      depositActivityCache: [],
      userDepositResp: []
    },
    activityList: [],
    activitySpinDetailObj: {}, // 活动id对应的转盘详情
    showSpinDialog: false,
    swiperIndexs: 0,
    showRulesDialog: false,
    showClaimDialog: false,
    prizeList: [],
    htmlContent: '',
    spinConfigMap: {},
    currentActivity: {},
    activityId: '', // 当前点击的活动id
    betbons: 0,
    rebatebons: 0,
    spintotal: 0,
    bigMoneySize: '',
    // withdraw 
    minAmount: '',
    withdawalLimit: {
      min: '',
      max: ''
    },
    mobileNumber: "***",
    currentBalance: 0,
    rulesLink: '',
    isWithdraw:false
  },
  onUnload(){
    if(this.data.subId){
      miniStomp.unsubscribe(this.data.subId)
      this.data.subId = null
    }
  },
  onLoad(config) {
    let isWithdraw = config.isWithdraw === 'true'
    if(isWithdraw){
      this.setData({
        isWithdraw
      })
    }
    
    let {loginName} = getUserInfo()
    let url = `/user/${loginName}/topic/gp_activity_prize_distribute`
    this.data.subId = miniStomp.subscribe(url,loginName)
    miniStomp.hook(url, (data) => {
      console.log('hook', '/topic/notifyIncreaseJackpot', data)
      const result = Object.values(data).reduce((acc, item) => {
        if(typeof item !== 'object')return acc
        const key = `${item.prizeType}-${item.prizeSubType || 0}`; // 使用 prizeType 和 prizeSubType 作为唯一标识
        if (!acc[key]) {
          acc[key] = { ...item }; // 初始化整合对象
        } else {
          acc[key].prizeValue += item.prizeValue; // 累加 prizeValue
        }
        return acc;
      }, {});
      // 转换为数组或对象
      const prizeList = Object.values(result);
      if(!prizeList.length)return
      
      this.onSetPrizeData({prizeList,showClaimDialog:true})
    })

  },
  async onShow() {
    await refreshIsFirstDepositFlag()
    this.init()
  },
  // 初始化接口 充值成功回调接口
  async init() {
    this.refreshBalance()
    this.getConfig().then(() => {
      this.getDepositeArry()
      this.getSpinConfig()
    })
  },
  async refreshBalance(type) {
    this.setData({
      isRefresh: true
    });
    const params = {
      flag: 1,
      type: type,
    };

    if (type !== 0) {
      request(
        withGlaxy("/applets/refreshBalance"), {
          showLoading: false
        }
      ).then(() => {
        params.type = 0;
      });
    }

    this.getBalance(params);
    this.setData({
      isUserInfo: getStorageCache('userInfo'),
      tokenInfo: getStorageCache('isInfo'),
    })
    this.setDefaultActiveDepositOption()
    this.getWithdrawList()
    this.checkWithdrawalLimit()
  },
  // 获取余额数据
  async getBalance(params) {
    const data = this.data;

    const res = (await request(
      withGlaxy("/applets/getBalanceV2"), {
        body: {
          params
        },
        showLoading: false
      }
    ))
    console.log('getBalanceV2', res)
    // .then((res) => {
    // 如果 balanceFlag = 0 或有错误尝试调用 api 8 次
    // if balanceFlag = 0 or has err try call api 8 times
    if ((res.body && res.body.balanceFlag == 0 && data.balFlag <= 8) || res.body.errCode) {
      /**
       * if balFlag = 8 显示 toast else
       * 重复这个过程直到 balanceFlag = 1
       * if balFlag = 8 show toast else
       * repeat the process until balanceFlag = 1
       */
      if (data.balFlag == 3) {
        app.toast(
          "Account limit has timed out, Please click the button to refresh"
        );


        this.setData({
          refreshFlag: false,
          balFlag: 1,
          balancePopupActive: false,
        });
      } else {
        this.setData({
          balFlag: data.balFlag + 1,
        });

        // 调用 get balance 延迟 2 秒 / 2 seconds delay for calling get balance
        clearTimeout(this.data.balanceDelay);
        let setBalanceDelay = setTimeout(() => {
          this.getBalance(params);
        }, 2000);

        this.setData({
          balanceDelay: setBalanceDelay,
        });
      }
    } else {
      const money = res.body.withdrawBal
      if (money && money.toString().split('.')[0].length > 6) {
        this.setData({
          bigMoneySize: 'bigMoneySize'
        })
      }
      const [integerPart, decimalPart] = money.toFixed(2).toString().split('.');

      this.setData({
        isBalance: res.body,
        currentBalance: res.body.withdrawBal,
        balance: formatAmount(integerPart),
        balanceDecimal: decimalPart,
        platformBalances: res.body.platformBalances,
        isRefresh: false,
        refreshFlag: false,
        balFlag: 1,
      });
    }
  },
  // 设置默认的存款金额列表
  setDefaultDepositOption() {
    this.setData({
      depositAmountOptions_withdraw: defalutAmountOptions,
    })
  },

  //获取交易记录数据
  getHistory() {
    request(
        withGlaxy("/applets/queryCustBill"), {
          body: {
            status: 0, //0成功，1失败，2，等待
          },
          showLoading: true
        }
      )
      .then(
        (res) => {
          this.setData({
            history_list: res.body.data,
          });
        },
        () => {}
      );
  },
  setDefaultActiveDepositOption() {
    this.showAvailableAccount()
    this.setData({
      activeDepositAmount: this.data.depositAmountOptions_withdraw[0].value
    })
  },
  showAvailableAccount() {
    this.setData({
      mobileNumber: this.getStartNmaeInitials(this.getAccount()),
      isShowAccountAll: false,
    })
  },
  getStartNmaeInitials(name) {
    return name.slice(0, 4) + "***" + name.slice(-3);
  },
  getAccount() {
    let name = this.data.isUserInfo ? this.data.isUserInfo.mobileNo : ''
    if (name == null || name == undefined || name.trim() === '') {
      name = "****"
    }
    return name
  },
  hideAvailableAccount() {
    this.setData({
      mobileNumber: this.getAccount(),
      isShowAccountAll: true,
    })
  },
  setAmount(e) {

    if (this.data.isWithdraw) {
      let value = parseInt(e.target.dataset.value);
      let newValue = value
      if (value < Number(this.data.withdawalLimit.min)) {
        newValue = this.data.withdawalLimit.min
      }

      if (value > +this.data.currentBalance) {
        return
        // newValue = +this.props.currentBalance
      }
      this.setData({
        activeDepositAmount: newValue
      })
    }
    this.setData({
      activeDepositAmount: e.target.dataset.value,
      willGetBonus: e.target.dataset.redPrice,
      disableSubmit: false,
      betbons: e.target.dataset.betbpnes,
      rebatebons: e.target.dataset.rebatebons,
      spintotal: e.target.dataset.sprinnum
    })
  },
  onAmountInput(e) {
    const value = e.detail.value
    const regex = /^\d{0,6}$/;

    if (!regex.test(value)) return
    if (value == '') {
      this.setData({
        disableSubmit: true
      })
    } else {
      this.setData({
        disableSubmit: false
      })
    }
    let newValue = value
    const {
      min,
      max
    } = this.data
    if (+value > max) {
      newValue = max
    }
    const willGetBonus = this.redTagPrice(newValue);
    let inputNumber = {
      value: +newValue
    }
    this.inputComputPrize(inputNumber, 'input')
    this.setData({
      activeDepositAmount: parseInt(newValue),
      willGetBonus: willGetBonus
    })
  },
  // 遍历存款配置
  inputComputPrize(item, type) {
    if (!this.config_Array) return
    item.betbpnes = 0
    item.rebatebons = 0
    item.sprinnum = 0
    if (this.config_Array.depositActivityCache) {
      this.config_Array.depositActivityCache.forEach((taskitem) => {
        if (taskitem.taskReset == 'day') {
          item.prizeamont = this.config_Array.userDepositResp.dayDeposit + item.value
          item.DepositAmount = this.config_Array.userDepositResp.dayDeposit
        }
        if (taskitem.taskReset == 'week') {
          item.prizeamont = this.config_Array.userDepositResp.weekDeposit + item.value
          item.DepositAmount = this.config_Array.userDepositResp.weekDeposit
        }
        if (taskitem.taskReset == 'month') {
          item.prizeamont = this.config_Array.userDepositResp.monthDeposit + item.value
          item.DepositAmount = this.config_Array.userDepositResp.monthDeposit
        }
        if (taskitem.showFlag == 0) {
          return
        }
        if (taskitem.taskList) {
          taskitem.taskList.forEach((tasklistItem) => {
            if (taskitem.activityType == 1) {
              if (item.value >= tasklistItem.conditionMin && item.value <= tasklistItem.conditionMax) {
                if (tasklistItem.taskPrize) {
                  tasklistItem.taskPrize.forEach((prizeitem) => {
                    if (prizeitem.prizeType == 2 && prizeitem.prizeSubType == 1) {
                      item.betbpnes += prizeitem.prizeValue;
                    }
                    if (prizeitem.prizeType == 2 && prizeitem.prizeSubType == 2) {
                      item.rebatebons += prizeitem.prizeValue;
                    }
                    if (prizeitem.prizeType == 4) {
                      item.sprinnum += prizeitem.prizeValue;
                    }
                  })
                }
              }
            } else {
              if (item.prizeamont >= tasklistItem.conditionMin && item.DepositAmount < tasklistItem.conditionMin) {
                if (tasklistItem.taskPrize) {
                  tasklistItem.taskPrize.forEach((prizeitem) => {
                    if (prizeitem.prizeType == 2 && prizeitem.prizeSubType == 1) {
                      item.betbpnes += prizeitem.prizeValue
                    }
                    if (prizeitem.prizeType == 2 && prizeitem.prizeSubType == 2) {
                      item.rebatebons += prizeitem.prizeValue;
                    }
                    if (prizeitem.prizeType == 4) {
                      item.sprinnum += prizeitem.prizeValue;
                    }
                  })
                }
              }
            }
          })
        }
      })
    }
    if (type == 'input') {
      this.setData({
        betbons: item.betbpnes,
        rebatebons: item.rebatebons,
        spintotal: item.sprinnum
      })
    }
  },
  onAmountFocus() {
    this.setData({
      keyboardHide: false,
      isAmountInput: true
    })
  },
  inputTap() {
    this.setData({
      keyboardHide: false,
      isAmountInput: true
    })
  },
  onAmountBlur(e) {
    const value = e.detail.value
    let newValue = value
    const {
      min,
      max
    } = this.data
    if (+value > max) {
      newValue = max
    }
    if (+value < min) {
      newValue = min
    }
    if (newValue != null && newValue != NaN) {
      this.setData({
        disableSubmit: false
      })
    }
    this.setData({
      keyboardHide: true,
      activeDepositAmount: parseInt(newValue),
    })
    if (!value) {
      this.setData({
        isAmountInput: false
      })
    }
  },

  verifyAmountInput(value) {
    const reg = /^[0-9]*$/;
    const isValid = reg.test(value);
    let errMessage = '';
    let minMax;

    const {
      min,
      max
    } = this.data
    minMax = value < min || value > max
    errMessage = `Please enter ${min} to ${formatPrice(max)}`
    // 如果输入 test = false 显示错误 / if input test = false show error
    if (!isValid) {
      if (!this.data.isAmountInputError) {
        // app.toast('Invalid input')
        app.toast(errMessage)

        this.setData({
          isAmountInputError: true
        })
        setTimeout(() => {
          this.setData({
            isAmountInputError: false
          })
        }, 1200)
      }
      this.setData({
        activeDepositAmount: null,
        disableSubmit: false,
        isAmountInputError: true
      })
      return
    }

    // 设置 minMax 值和错误信息 / Set minMax value and error message
    // if (this.props.popupType === 'deposit') {
    // minMax = value < 100 || value > 100000
    // errMessage = 'Please enter 100 to 100,000'
    // } else {
    //   minMax = value < 200 || value > 3000000
    //   errMessage = 'Please enter 200 to 3,000,000'
    // }

    // 如果值不为空并且 minMax 不匹配则抛出错误
    // If value is not empty and did minMax did not match throw error
    // if (value && minMax) { // 2024.0521 解决IOS输入值为0不提示的问题
    if (value <= 0 || (value && minMax)) {
      // app.toast(errMessage)
      if (!this.data.isAmountInputError) {
        app.toast(errMessage)
        this.setData({
          isAmountInputError: true
        })
        setTimeout(() => {
          this.setData({
            isAmountInputError: false
          })
        }, 1200)
      }
      this.setData({
        activeDepositAmount: null,
        disableSubmit: false
      })
    }
  },

  // 存取款按鈕
  fundsTransfer(e) {
    if (e.target.dataset.value === 'Top-up') {
      this.setData({
        isWithdraw: false
      })
    } else {
      this.setData({
        isWithdraw: true
      })
    }
  },

  //存款
  async submint_deposit(e) {
    this.setData({
      disableSubmit: true
    })

    const self = this
    setTimeout(function () {
      // self.props.onConfirmSubmit && self.props.onConfirmSubmit(e)

      // 如果失败则验证输入的金额 set isAmount = null
      // Verify entered amount if failed set isAmount = null
      self.verifyAmountInput(self.data.activeDepositAmount)

      // 如果 isAmount null 返回 / If isAmount null return
      if (!self.data.activeDepositAmount) return
      request(withGlaxy('/applets/createOnlineOrder'), {
        body: {
          ...normalizedPaymentData(),
          amount: self.data.activeDepositAmount,
          miniProgramId: '2170020194511181'
        },
        showLoading: true
      }).then(
        res => {
          const {
            success,
            head,
            body
          } = res
          if (success) {
            if (!body.includes("gcash://com.mynt.gcash/app")) {
              my.alert({
                content: "Unexpected error, please try again later.",
              });

              self.setData({
                disableSubmit: false
              })
            } else {
              //调用Gcash api
              my.tradePay({
                paymentUrl: body,
                success: (payResult) => {
                  if (payResult.resultCode == '9000') {
                    console.log('支付成功')
                    setFirstDepositFlag(true)
                    self.init()
                  }
                },
                fail: (err) => {
                  my.alert({
                    content: JSON.stringify(err),
                  });
                },
                complete: () => {
                  self.setData({
                    disableSubmit: false
                  })
                }
              });
            }
          } else {
            self.setData({
              disableSubmit: false
            })
          }
        },
        () => {}
      );
    }, 1000);
    sensors.track('depositSureClick', {
      b_id: 'home_page',
      page_b_name: '首页',
      c_id: 'deposit',
      page_c_name: '存款',
      amount_confirm: this.data.activeDepositAmount
    })
  },
  // 取款
  async submint_withdraw() {
    sensors.track('withdrawSureClick', {
      b_id: 'home_page',
      page_b_name: '首页',
      c_id: 'withdraw',
      page_c_name: '提款',
      amount_confirm: this.data.activeDepositAmount
    })
    this.setData({
      disableSubmit: true
    })

    if (this.data.activeDepositAmount > this.data.currentBalance) {
      app.toast("Insufficient balance")

      await this.setData({
        activeDepositAmount: parseInt(this.data.currentBalance),
        disableSubmit: false
      })

      return
    }

    // const glifeToken = my.getStorageSync({
    //   key: 'glifeToken', // 缓存数据的key
    // }).data.resultBody

    // 如果失败则验证输入的金额 set isAmount = null
    // Verify entered amount if failed set isAmount = null
    this.verifyAmountInput(this.data.activeDepositAmount)

    // 如果 isAmount null 返回 / If isAmount null return
    if (!this.data.activeDepositAmount) return

    // Verify if amount has no decimal
    if (!this.data.isFlag) return
    this.setData({
      isFlag: false
    })

    requestWithdraw({
      amount: this.data.activeDepositAmount,
      ...normalizedPaymentData()
      // glifeAccountId: JSON.parse(glifeToken).customerId,
    }).then(({
        success,
        body
      }) => {
        this.setData({
          disableSubmit: false
        })
        if (success) {
          // app.toast('Withdrawal request successful')
          this.init()
        }
        this.setData({
          isFlag: true
        })
      },
      (err) => {
        this.setData({
          isFlag: true
        })
      }
    );
  },
  openBonusDepositDetails() {
    this.props.onPopupDetail()
  },
  // 獲取充值頁面條件
  async getDepositConditions(params) {
    let data = {
      "productId": params.productId,
      "customerId": params.customerId,
      "loginName": params.loginName,
      "tenant": "GP"
    }
    let res = await getDepositConditionsApi(data)
    console.log('充值頁面條件', res)
    // up_to_Bonus
    let rules;
    if (res && res.body[0]) {
      rules = res.body[0].rules;
    } else {
      rules = [];
    }
    this.getUpToBonus(rules)
    this.setData({
      depositConditions: res.body[0] || []
    })

  },
  getUpToBonus(value) {
    let max = -Infinity; // 初始化為負無窮大，確保能找出最大值
    for (let i = 0; i < value.length; i++) {
      if (Number(value[i].rightsBornCredit) > max) {
        max = value[i].rightsBornCredit;
        console.log('max', max)
      }
    }
    this.setData({
      up_to_Bonus: max
    })
  },
  redTagPrice(value) {
    let number = 0;
    if (this.data.depositConditions && typeof this.data.depositConditions === 'object' && Object.keys(this.data.depositConditions).length > 0) {
      this.data.depositConditions.rules.forEach(rule => {
        if (!number) {
          if (value >= rule.minAmount && value <= rule.maxAmount) {
            number = rule.rightsBornCredit
          }
        }
      });
    }


    return number >= 10000 ? '10K' : number
  },
  // 获取用户得取款列表
  async getDepositeArry() {
    const {
      success,
      body
    } = await getdepositList({
      terminal: 'GLIFE'
    })
    if (success) {
      console.log('-------------- deposit/queryPayWays -------------')
      console.log('res', body)
      let channel = body.payTypes[0].channels[0]
      console.log('channel', channel)
      let originList = channel.amountList
      console.log('originList', originList)
      console.log('是否首存:', isFirstDepositFlag)
      let list = []
      list = isFirstDepositFlag ? originList : channel.firstAmountList
      console.log('可以存款的列表', list)

      if (!list.length) {
        this.setDefaultDepositOption()
        return
      };
      this.setData({
        min: isFirstDepositFlag ? channel.minAmount : channel.firstMinAmount,
        depositAmountOptions_topUP: list.filter(Number).map(el => ({
          title: formatAmount(el),
          value: +el,
          redTag: this.redTagPrice(+el)
        })),
      })
    } else {
      this.setDefaultDepositOption()
    }
    let depostNewArray = this.data.depositAmountOptions_topUP
    depostNewArray.forEach((item) => {
      this.inputComputPrize(item)
    })
    this.setData({
      depositAmountOptions_topUP: depostNewArray
    })
  },
  // 存款活动参数配置
  async getConfig() {
    const {
      success,
      body
    } = await getdepositConfig()
    if (success) {
      this.config_Array = body;
      this.setData({
        activityList: body.depositActivityCache,
        // showGetBonus: true,
        showGetBonus: body.userDepositResp.claimCount
      })
    }
  },
  // 存款转盘参数配置
  async getSpinConfig() {
    const {
      success,
      body
    } = await getSpinConfig()
    let activitySpinDetailObj = {}
    if (success) {
      let spinConfig = body.spinConfig[0] || {}
      body.spinUserInfo.spinDetail.forEach((item) => {
        activitySpinDetailObj[item.activityId] = item
      })
      this.setData({
        activitySpinDetailObj,
        spinConfigMap: {
          ...this.data.spinConfigMap,
          spinConfig,
          spinUserInfo: body.spinUserInfo,
          spinTimes: body.spinUserInfo.total // spinDetail
        }
      })
    }
  },
  // 点击转盘
  async onClickSpin(e) {

    let currentActivity = e.currentTarget.dataset.value
    let activityId = currentActivity.activityId
    let subTitleUrl = currentActivity.subTitle

    // getFile(subTitleUrl).then((subTitleHtml) => {
    //   currentActivity.subTitleHtml = subTitleHtml
    //   this.setData({
    //     currentActivity,
    //   })
    // })
    // let currentTimes = this.data.activitySpinDetailObj[activityId].count
    // this.data.spinConfigMap.spinTimes = currentTimes
    // this.setData({
    //   currentActivity,
    //   activityId,
    //   spinConfigMap: this.data.spinConfigMap
    // })
    navigateToH5('/', {
      popUpSpin: activityId,
    })
    // 拿到id赋值
    // this.getSpinProgress(activityId) // 点击活动再调这个函数
    // this.onShowSpin()
  },
  // 点击活动 获取转盘任务列表 todo
  async getSpinProgress(activityId) {
    const {
      success,
      body: taskObj
    } = await getSpinProgressConfig({
      spinId: this.data.spinConfigMap.spinConfig.spinId,
      activityId // todo
      // activityId: '1db9e47e12e8437f979ab26da4fe90e9' // todo
    })
    if (!success) return
    console.log(taskObj)
    taskObj.taskData = taskObj.taskData.filter((item) => {
      return item.spinTimes != 0
    })
    taskObj.taskData.forEach(item => {
      item.formatDepositWithK = formatMoneyWithK(item.conditionMin)
    })
    let findIdx = taskObj.taskData.findIndex(e => Boolean(e.amount))
    taskObj.activeTaskIdx = findIdx == -1 ? 0 : findIdx + 1

    this.data.spinConfigMap.taskObj = taskObj
    this.setData({
      spinConfigMap: this.data.spinConfigMap
    })
  },
  // swiper切换的时候。记录index值
  onSwipeStart(e) {
    this.swiperIndexs = e.detail.current;
  },
  onShowActiveRules(activityId) {
    const findAct = this.data.activityList.find(e => e.activityId == activityId)

    const rule = findAct && findAct.activityRule
    if (!rule) return
   
    this.setData({
      rulesLink: rule,
      showRulesDialog: true
    })
    return
    pureRequest(rule, {
        dataType: 'text'
      })
      .then(data => {
        console.log(data)
        parse(data, (err, nodes) => {
          if (err) {
            console.log(err);
          } else {
            const processedNodes = processNodes(nodes);
            console.log('processedNodes', processedNodes)
            this.setData({
              htmlContent: processedNodes,
              showRulesDialog: true
            })
          }
        });
      })
  },
  onClickShowActiveRules(e) {
    let activityId = e.currentTarget.dataset.value.activityId
    // const activityRule = this.swiperIndex != undefined ? this.config_Array.depositActivityCache[this.swiperIndexs].activityRule : this.config_Array.depositActivityCache[this.data.swiperIndexs].activityRule
    this.onShowActiveRules(activityId)
  },
  onCancel() {
    this.setData({
      showRulesDialog: false
    })
  },
  onShowSpin() {
    this.setData({
      showSpinDialog: true
    })
  },
  onHideSpinDialog() {
    this.setData({
      showSpinDialog: false
    })
  },
  onShowClaimDialog() {
    this.setData({
      showClaimDialog: true
    })
  },
  onHideClaimDialog() {
    this.setData({
      showClaimDialog: false
    })
  },
  // {prizeList,showSpinDialog}
  onSetPrizeData(prizeObj) {
    prizeObj.prizeList && prizeObj.prizeList.forEach((item) => {
      item.prizeText = this.getPrizeText(item.prizeType, item.prizeSubType)
    })
    this.setData(prizeObj)
  },

  onConfirmClaimDialog() {
    // const userInfo = my.getStorageSync({
    //   key: "userInfo", // 缓存数据的key
    // }).data;
    // if (userInfo.firstIdStatus != 1) {
    //   this.onShowKycDialog()
    // } else {
    // }
    this.onHideKycDialog()
  },

  onShowKycDialog() {
    this.setData({
      showKycDialog: true
    })
  },
  onHideKycDialog() {
    this.setData({
      showKycDialog: false
    })
  },
  onConfirmKycDialog() {
    // 去h5做kyc
    navigateToH5('/kyc')
    this.setData({
      showKycDialog: false
    })
  },
  async onGetBonus() {

    depositActivityClaim()
    return
    let {
      success,
      body
    } = await getDepositUserInfo()
    if (!success) return
    console.log(body)
    const prizeList = [{
      prizeValue: 12,
      prizeType: 2,
      prizeSubType: 1
    }]
    this.onSetPrizeData({
      prizeList,
      showClaimDialog: true
    })
  },
  getPrizeText(prizeType, prizeSubType) {
    let text = ''
    if (prizeType == 3) {
      text = 'ticket'
    } else if (prizeType == 4) {
      text = 'wheel of fortune'
    } else if (prizeType == 2) {
      if (prizeSubType == 1) {
        text = 'Bonus Credit'
      } else {
        text = 'Wager Rewards'
      }
    }

    return text
  },
  // 获取提现金额列表
  async getWithdrawList() {
    const res = await fetchWithdrawSwitch()
    if (res) {
      let list = res.amountList.split(',')
      console.log('可以存款的列表', list)

      if (!list.length) {
        this.setDefaultDepositOption()
        return
      };

      let depositAmountList = []
      list.forEach((el, i) => {
        let val = +el
        if (!isNaN(val) && i < 6) {
          depositAmountList.push({
            title: formatAmount(el),
            value: val
          })
        }
      })
      this.setData({
        depositAmountOptions_withdraw: depositAmountList
      })
    } else {
      this.setDefaultDepositOption()
    }
  },
  // 获取最大最小提现金额
  async checkWithdrawalLimit() {
    const res = await fetchWithdrawConst({
      keys: ["MIN_WITHDRAW_AMOUNT", "MAX_WITHDRAW_AMOUNT"],
    })
    if (res) {
      if (res.MIN_WITHDRAW_AMOUNT && res.MAX_WITHDRAW_AMOUNT) {
        this.setData({
          minAmount: `Withdraw Amount Min ${res.MIN_WITHDRAW_AMOUNT} P`,
          withdawalLimit: {
            min: res.MIN_WITHDRAW_AMOUNT,
            max: res.MAX_WITHDRAW_AMOUNT
          }
        })
        return
      }
    } else {
      this.setData({
        minAmount: `Withdraw Amount Min 200 P`,
        withdawalLimit: {
          min: 200,
          max: 100000
        }
      })
    }
  },
  // setAmountEqualToCurrentBalance() {
  //   this.setData({
  //     activeDepositAmount: parseInt(this.data.currentBalance)
  //   })
  // },
});