import { navigateToH5, navigateToGame } from '/api/service/navigate-to-h5'
import parse from "mini-html-parser2";
import {jsonToStr} from '/utils/index'
const sensors = require("../../sensorsdata.esm.js");
const app = getApp();
import {  processNodes } from '/utils/index'
import pureRequest from '/api/lib/pure-request';
Page({
  data: {
    richTextData:{},
    getNodes:'',
  },
  onShow() {
    my.hideBackHome();
  },
  async onLoad(query) {
    //console.log(query, 'query123')
    //my.alert('55555555')
    const richTextKey = query.richTextKey;
    //const nodes = query.nodes;
    this.setData({getTime:"richTextKey"})
    if (richTextKey) {
      const { data} = my.getStorageSync({
        key: richTextKey
      })
      console.log(data.content, 'richTextKey')
      my.showLoading()
      pureRequest(data.content, {
        dataType: 'text'
      })
      .then(textContent => {
        parse(textContent, (err, nodes) => {
          my.hideLoading()
          if (err) {
            console.log(err);
          } else {
            console.log(nodes)
            const processedNodes = processNodes(nodes);
            console.log(processedNodes, 'processedNodes')
            this.setData({getNodes: processedNodes})
          }
        });
      })
      .catch((err) => {
        console.log('err', err)
      })
      // const nodes = my.getStorageSync({
      //   key: 'nodes'
      // })
      //this.setData({getNodes: nodes})
      //console.log(nodes, 'data-nodes------')
      this.setData({
        richTextData: data,
      });
      my.removeStorageSync({ key: richTextKey });
    }
  },
  onShow() {

  },
  jumpLink() {
    const { skipType, paramsLink, bannerIndex, title } = this.data.richTextData
    console.log(this.data)
    sensors.track('bannerDetailsClick', {
      b_id:'details',
      page_b_name:'详情',
      c_id:'banner_datails',
      page_c_name:'轮播详情',
      banner_index: bannerIndex,
      banner_name: title
    })
    if (!paramsLink) return
    // skipType 1.站内页面 2.站外页面 3.进入游戏
    if (skipType === '3') {
      console.log(paramsLink, 'paramsLink32423423');
      navigateToGame(paramsLink)
    } else {
      navigateToH5(paramsLink.targetUrl)
    }
  },
});
