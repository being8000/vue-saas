Page({
  onLoad(query) {
    if (query.items) {
      const items = query.items || ''
      let formatItems = items.split(',')
      if(!formatItems.length)return
      this.setData({
        items:formatItems.map(e=>({id:e})),
      });
    }
  },
  data: {
    items: []
  },
});
