import Fuse from 'fuse.js'
import {
  getBaseAllGamse
} from "/api/service/game";
import { step2MicroApi } from '/app-before-init';
import {
  historySearch
} from "/components/search/history";
import useSearch from "/components/search/useSearch";
import {
  onGZInputChange
} from "/components/ui/gz-input";
import {
  debounce
} from "/utils";
let unsubscribe = null


function fuseSearch(searchText) {
  const allGames = getBaseAllGamse()
  const options = {
    // includeScore: true,
    // useExtendedSearch: true,
    includeScore: true,
    minMatchCharLength: 3,
    keys: ['nameEn', 'platformName']
  }
  let fuse = new Fuse(allGames, options)
  const searchedGames = fuse.search(searchText)
  const filteredGames = searchedGames.map(item => item.item)
  return filteredGames
}
Page({
  data: {
    text: '',
    allGames: [],
    filteredGames: [],
    isSearching: false
  },
  onLoad() {
    step2MicroApi.promiser.then(() => {
      this.setData({
        allGames: getBaseAllGamse()
      })
    })
  
    const that = this

    function onTextChange(text) {
      if (text && text.length > 3) {
        historySearch.addItem(text)
        that.setData({
          text: text,
          filteredGames: fuseSearch(text)
        })
      } else {
        that.setData({
          text: text,
          filteredGames: []
        })
      }
    }
    const debounceChange = debounce(onTextChange, 500, false)
    unsubscribe = onGZInputChange((text) => {
      debounceChange(text)
    })
  },
  onHide() {
    unsubscribe && unsubscribe()
    unsubscribe = null
  },
  onTextChange(text) {
    console.log('text', text)
  },
  onInputRef(inputInstance) {
    const {
      bindInstance
    } = useSearch()
    bindInstance(inputInstance)
  },
});