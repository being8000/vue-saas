import {
  getAccId,
} from "../../utils/env";
import {
  loadingConfig,
} from "/api";
import {
  APP_TYPE,
} from "/utils/const";
import {
  checkBindV4
} from "../../api/user";
import {
  getAccessTokenFromStore
} from "/api/service/auth";
import {
  $cora
} from "/api/service/cora";
import {
  afterLoginFunctions,
  step1Promiser,
} from "/app-before-init";

const app = getApp();
Page({
  data: {
    percent: 0,
    // authCode: '20220411DgE002msqzy0881900082379',
    authCode: null,
    mask: '',
    token: '',
    showSecurityDialog: false, // 高风险用户弹窗
    customerId: null,
    showAuthFailed: false, // Gcash 内部授权失败弹窗
    showGcashInnerErrorPop: false,
    showAccessLimited: false,
    pageConfig: {
      basemapPic: '1',
      materiaPic: '1',
      iconPic: '',
    },
    pageQuery: {}
  },
  async onLoad(query) {
    if (query) {
      this.data.pageQuery = query
    }
    this.startDown(30)
    const isValid = await step1Promiser
    this.setData({
      pageConfig: loadingConfig
    })
    this.startDown(80)
    if (!isValid) {
      this.login()
    } else {
      // 如果webtoken登录状态还没失效，从缓存中获取用户信息，模拟执行登录流程
      const userInfo = my.getStorageSync({
        key: 'userInfo'
      }).data
      if (userInfo && userInfo.customerId) {
        $cora.afterLogin(userInfo)
        this.startDown(100)
      } else {
        this.login()
      }
    }
    
  },
  async login() {
    const data = getAccessTokenFromStore()
    if (!data) {
      return
    }
    const acsToken = data.resultBody
    const {
      success,
      body,
      head
    } = await checkBindV4({
      type: APP_TYPE, //Glife
      unionId: acsToken.customerId,
      externalToken: acsToken.accessToken,
      reference: getAccId(), //glife市场palcode
      authCode: acsToken.authCode, // 字段确认没有用到
    })
    if (success) {
      body.unionId = acsToken.customerId
      my.setStorageSync({
        key: 'userInfo',
        data: body
      });
      $cora.afterLogin(body)
      this.startDown(100)
    } else {
      // 高风险用户
      if (head.errCode == 'GW_900990') {
        // TODO 新版需要确认功能 需要确认高风险用户
        this.setData({
          mask: body.mask || '',
          token: body.token,
          customerId: body.customerId,
          showSecurityDialog: true,
        })

      } else if (head.errCode == 'GW_910145') {
        // TODO GW_910145 该标识 Gcash 内部异常， 授权失败返回
        this.setData({
          showGcashInnerErrorPop: true,
        })
      }
    }
  },
  startDown: function (num) {
    const maxPercent = 100
    let self = this
    let t = setInterval(() => {
      self.setData({
        percent: self.data.percent <= maxPercent - 10 ? self.data.percent + 10 : maxPercent,
      })
      if (self.data.percent >= num) {
        clearInterval(t)
      }
    }, 1000)
    if (num == maxPercent) {
      return this.jumpDown()
    }
  },
  async jumpDown() {
    if (this.data.pageQuery.operation == 'deposit') {
      my.redirectTo({
        url: '../deposit/ac-deposit'
      });
      this.data.pageQuery.operation = ''
      return
    }
    afterLoginFunctions()
    my.redirectTo({
      url: '../index/index'
    });
    // my.alert({
    //   title: 'Unexpected error',
    //   content: 'Unexpected error, please try again later.'
    // });


    // } else {
    //   my.navigateTo({ url: '../login/login' });
    // }
  },
  /** 高风险用户验证成功设置 100 */
  onSuccess(body) {
    my.setStorageSync({
      key: 'userInfo',
      data: body
    });
    this.startDown(100)
  },
  /** 高风险用户验证成功设置 100 */
  relunchApp() {
    my.reLaunch({
      url: '/pages/start/start'
    })
  }
});