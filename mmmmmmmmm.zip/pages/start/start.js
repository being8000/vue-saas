import {
  getBannerList
} from '/api/service/home-block-config'
import {
  getSpokesperson
} from '/api/service/home-block-config'
import {
  navigateToH5
} from '/api/service/navigate-to-h5'
import {
  favoritor
} from "/api/service/favorite-game";
import {
  PAGES
} from '/plugin/proxy/page-proxy';
import parse from "mini-html-parser2";
import pureRequest from '/api/lib/pure-request';
import {
  fetchAccessTokenViaAuthCode
} from '/api/service/auth';
import {
  requestEndorserStatus
} from "/api/spokesperson"
import {
  LoginError,
  providerPromiser,
  reLogin,
  step2MicroApi
} from '/app-before-init';
import {
  $dialog
} from '/components/v4-dialog';
import { loginEmitter } from '/plugin/proxy/login-emitter';
import { loginMircorApi } from '/api/lib/request';

Page({
  data: {
    page_name: PAGES.HOME,
    bannerList: [], // banner列表
    gameProviders: [],
    boundsBalance: '',
    chipsBalance: '',
    divStyle: '',
    mask: '',
    token: '',
    spokenPerson: [],
    showSecurityDialog: false, // 高风险用户弹窗
    showAccessLimited: false, // 访问限制
    __accessDetail: {},
    spokespersonStatus: 0
  },
  async onLoad(query) {
    favoritor.startFetch()
    this.checkLoginStatus()
    // 静态资源获取需要等待第二步加载完成
    await step2MicroApi.promiser
    // Page load
    this.setData({
      bannerList: getBannerList(),
    })
    await this.getSpokespersonDeath()
    await this.getFetchSpokenState()
  },
  onReady() {
    // Page loading is complete
  },
  onShow() {
    // Page display
  },
  onHide() {
    // Page hidden
  },
  onReachBottom() {
    // Page is pulled to the bottom
  },
  onShareAppMessage() {
    // Back to custom sharing information
    return {
      title: 'Gamezone',
      desc: `GameZone is a PAGCOR-licensed, fair, and safe official GCash online casino, offering GameZone-exclusive PVP mode Tongits, Tongits Go, Pusoy, GameZone Tongits Free Bonanza, Texas Hold'em poker, and Playtime Bingoplus online slots, which feature a super jackpot for daily lucky draws.`,
      path: 'pages/index/index',
      text:''
    };
  },
  goToGTCC() {
    // console.log('跳转gtcc')
    navigateToH5('/gtcc')
  },
  onPageScroll({
    scrollHeight,
    scrollTop,
  }) {
    // console.log(scrollHeight, 'scrollHeight')
    // console.log(scrollTop, 'scrollTop')
  },
  checkLoginStatus() {
    console.log('loginMircorApi')
    const that = this
    loginMircorApi.promiser.catch(async res => {
      console.log('loginMircorApi', res)
      if (res.type === LoginError.GCASH_ERROR) {

      }
    })
  },
  async getSpokespersonDeath() {
    const data =  getSpokesperson()
    let text = ''
    pureRequest(data[0].resume, {
      dataType: 'text'
    })
    .then(textContent => {
      // console.log(textContent, 'textContent')
      // text = textContent
      this.setData({text: textContent})
    })
    .catch((err) => {
      console.log('err', err)
    })
    const dataSpokenList = data.map((el) => ({
      bannerList: el.photoBookUrls.split(','),
      avatar: el.avatar,
    }))
    console.log(dataSpokenList, 'dataSpokenList123')
    this.setData({
      spokenPerson: dataSpokenList
    })
  },
  async getFetchSpokenState() {
     const {
        body
      } = await requestEndorserStatus()
      this.setData({spokespersonStatus:body.status})
      console.log(body, 'status123')
  },
  async exploreBtn() {
    navigateToH5()
  },
  async relunchApp() {
    reLogin()
  },
  /** 高风险用户验证成功设置 100 */
  onSuccess(body) {
    my.setStorageSync({
      key: 'userInfo',
      data: body
    });
    loginMircorApi.manualResolve(body)
    loginEmitter.emitLoginEvent()
  },
});