import {} from '/api/stasticJs'
import {
  StorageKey
} from "/utils/const"
import {
  getTabList,
  getCurrentTabGameList,
  showGamesTabList,
  showConditionTabList
} from './utils'
import {
  gameProviders
} from '/api/game'
import {
  getBannerList,
  getAllGames
} from '/api/service/home-block-config'
import { step2MicroApi } from '/app-before-init';

Page({
  data: {
    showGamesTabList: showGamesTabList,
    showConditionTabList: showConditionTabList,
    tab: '',
    originList: [],
    tabList: [],
    games: [],
    gameSize: 8,

    tabGameType: 'Hot Games',
    platforVisible: false,
    gameProviders: [],
    selectProviders: ['0'],
    supplyName: 'All',

    currentTabIndex: 0,
    bannerList: [], // banner列表

  },
  onShow() {
    this.getTabList()
  },

  async onLoad(query) {
    await step2MicroApi.promiser
    this.setData({
      gameProviders: [{
          imgUrl: '/assets/tab/provider-all.png',
          platformId: '0'
        },
        ...gameProviders
      ],
      bannerList: getBannerList()
    })
    let tab = query.tab
    if (!tab) return
    tab = tab.toLowerCase()
    const tabIdx = this.data.tabList.findIndex(e => e.code === tab)
    this.onTabItem(tabIdx)
  },
  // onTabItemEvent(e){
  //   const item = e.target.dataset.value
  //   if(item.code === this.data.tab){
  //     return
  //   }
  //   this.onTabItem(item.code)
  // },
  onChangeTab(currentTabIndex) {
    this.setData({
      currentTabIndex
    })
    this.onTabItem(currentTabIndex)
  },
  async onTabItem(currentTabIndex) {
    const tab = (this.data.tabList[currentTabIndex] || {}).code || 'all'
    this.setData({
      tab
    })
    this.setData({
      currentTabIndex,
      supplyName: 'All',
      selectProviders: ['0'],
    })
    let games = await getCurrentTabGameList(tab)
    this.setData({
      games,
      originList: games,
    })
  },
  onShowPlatform() {
    this.setData({
      platforVisible: true
    })
  },
  handlePopupClose() {
    this.setData({
      platforVisible: false
    })
  },
  goGameProvider(e) {
    const platformId = e.target.dataset.value.platformId;
    const games = getAllGames() || []
    const filterList = games.filter(e=> e.platformId == platformId)
    const gameList = []
    console.log(filterList, 'filterList')
    const result = filterList.map(item => item.id).join(',');
    my.navigateTo({
      url:'/pages/more-games/more-games?items=' + result
    })

  },
  onProviderItem(e) {
    const item = e.target.dataset.value
    let list = this.data.selectProviders

    if (list.length == 1 && list[0] == item.platformId) {
      return
    }

    // 点击all
    if (item.platformId == 0) {
      let selectProviders = ['0']
      if (list[0] == 0) {
        selectProviders = []
      }

      this.setData({
        selectProviders
      })
      return
    }

    // 没点击all
    if (list.includes('0')) {
      list = list.filter(e => e !== '0')
    }
    if (list.includes(item.platformId)) {
      list = list.filter(e => e !== item.platformId)
    } else {
      list.push(item.platformId)
    }
    this.setData({
      selectProviders: list
    })
  },
  onProviderConfim() {

    let selectProviders = this.data.selectProviders
    let games = [...this.data.originList]

    let supplyName = this.data.supplyName
    if (selectProviders.length) {
      if (selectProviders.length == 1) {
        if (selectProviders[0] == '0') {
          supplyName = 'All'
        } else {
          supplyName = gameProviders.find(e => e.platformId === selectProviders[0]).platformName
          games = games.filter(e => this.data.selectProviders.includes(e.platformId))
        }
      } else {
        supplyName = `+ ${selectProviders.length}`
        games = games.filter(e => this.data.selectProviders.includes(e.platformId))
      }
    }
    this.handlePopupClose()
    this.setData({
      games,
      supplyName,
      gameSize: 8
    })
  },
  onMoreGame() {
    this.setData({
      gameSize: this.data.gameSize + 8
    })
  },
  getTabList() {
    this.setData({
      tabList: getTabList()
    })
  },
  toSearch() {
    my.navigateTo({
      url: '/pages/search/search'
    });
  }
});