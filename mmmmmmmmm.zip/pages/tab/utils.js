
import {getOriginList,getBaseAllGame,findGameByGame2Ids} from '/api/stasticJs'
import { favoritor } from "/api/service/favorite-game";
import {fetchRecentlyGames} from '/api/game'
export const showGamesTabList = ['all','gz','hot','new','favorite','recent']
export const showConditionTabList = ['all','hot','new','favorite','recent']

let gzGameList = null
export function getGzGameList(){
  if(gzGameList)return gzGameList
  return gzGameList = getBaseAllGame().filter((e)=>e.platformId=='175')
}
let hotGameList = null
export function getHotGameList(){
  if(hotGameList)return hotGameList
  return hotGameList = getBaseAllGame().filter((e)=>e.hotFlag)
}
let newGameList = null
export function getNewGameList(){
  if(newGameList)return newGameList
  return newGameList = getBaseAllGame().filter((e)=>e.newFlag)
}

export async function  getCurrentTabGameList(tab){
  let games = []
  if(tab == 'all'){
    games = getBaseAllGame()
  }else if(tab == 'gz'){
    games = getGzGameList()
  }else if(tab == 'hot'){
    games = getHotGameList()
  }else if(tab == 'favorite'){
    games = await favoritor.games
  }else if(tab == 'recent'){
    let recentGames = await fetchRecentlyGames()
    let formatGames = recentGames.map(e=>{
      return findGameByGame2Ids(e.platformCode,e.gameId)
    })
    games = formatGames
  }else if(tab == 'new'){
    games = getNewGameList()
  }
  return games
}

const defaultList = [
  {
    title:'GZ',
    code:'gz',
    icon:'/assets/tab/gz.png',
    icon2:'/assets/tab/gz-act.png',
    sort:1
  },
  {
    title:`Hot Games`,
    code:'hot',
    icon:'/assets/tab/hot.png',
    icon2:'/assets/tab/hot-act.png',
    sort:2
  },
  {
    title:`Providers`,
    code:'provider',
    icon:'/assets/tab/provider.png',
    icon2:'/assets/tab/provider-act.png',
    sort:5
  },
  {
    title:`Recent Games`,
    code:'recent',
    icon:'/assets/tab/recent.png',
    icon2:'/assets/tab/recent-act.png',
    sort:6
  },
  {
    title:`New Games`,
    code:'new',
    icon:'/assets/tab/new.png',
    icon2:'/assets/tab/new-act.png',
    sort:7
  },
  {
    title:`Favorites`,
    code:'favorite',
    icon:'/assets/tab/favorite.png',
    icon2:'/assets/tab/favorite-act.png',
    sort:8
  },
]
export function getTabList(){
  const originList = getOriginList()
  const tabList = originList.map(e=>{
    const code = e.pagination.toLowerCase()
    if(code=='all'){
      return {
        title:'All Games',
        code,
        icon:'/assets/tab/all.png',
        icon2:'/assets/tab/all-act.png',
        sort:0
      }
    }

    return {
      title:e.pagination,
      code,
      icon:e.iconPcHide,
      icon2:e.iconPc,
      sort:3
    }
  }).filter(Boolean).concat(defaultList)
  return tabList.sort((a,b)=>a.sort-b.sort)
}