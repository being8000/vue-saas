import {
  favoritor
} from "/api/service/favorite-game";

Page({
  data: {
    visible: true
  },
  onLoad() {
    favoritor.startFetch()
    console.log('page onLoad')
    setTimeout(() => {
      this.setData({
        visible: false
      })
    }, 5000)
  },
  onShow() {
    console.log('page onShow')
  },
  onHide() {
    console.log('page onHide')

  },
  onReady() {
    console.log('page onReady')
  },
  onClick() {
    my.navigateTo({
      url: '../start/start'
    })
  }
});