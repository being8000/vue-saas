export const stompMessageFrame = (msg) => {
  return 'MESSAGE\n' +
    msg +
    '\u0000'
}

/** 
 * 建立连接
 */
export const stompConnectFrame = () => {
  return "CONNECT\n" +
    "accept-version:1.2,1.1,1.0\n" +
    "heart-beat:10000,10000\n" +
    "\n\u0000"
}

/**
 * 心跳
 */
export const stompHeardBeatFrame = () => {
  return "\n"
}

/**
 * SUBSCRIBE\nX-Auth-Token:bingoplussn0b3c\nid:sub-4\ndestination:/user/bingoplussn0b3c/notifyPlayerOpportunity\n\n\u0000
 */
/**
 * 订阅
 */
export const stompSubscribeFrame = (subscribeId, destination, token) => {
  const authToken = token ? `X-Auth-Token:${token}\n` : ''
  return "SUBSCRIBE\n" +
    authToken +
    `id:${subscribeId}\n` +
    `destination:${destination}\n` +
    "\n\u0000"
}

/**
 * 订阅
 */
export const stompUnsubscribeFrame = (subscribeId) => {
  return "UNSUBSCRIBE\n" +
    `id:${subscribeId}\n` +
    "\n\u0000"
}

