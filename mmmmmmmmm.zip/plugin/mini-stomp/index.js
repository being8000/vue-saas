import {
  useEventBus
} from '../../utils/use-event-bus'
import {
  stompSubscribeFrame
} from './frame';
import {
  stompUnsubscribeFrame
} from './frame';
import {
  stompConnectFrame
} from './frame';
import {
  parseStompMessage
} from './utils';
import {
  parseStompConnectedMessage
} from './utils';
import {
  MiniWebSocket
} from './websocket';
import {
  ENV,
  getSocketUrl
} from '/utils/env';

/**
 * @typedef {{
 *  connect: () => void;
 *  subscribe: (destination: string, token: string) => string | Promise<any>;
 *  isConnecting(): boolean;
 *  unsubscribe(subId: string): void;
 *  hookOnce(event: string, callbackFn: (body: any) => void): void;
 *  hook(event: string, callbackFn: (body: any) => void): void;
 * }} MiniStompClient
 */
/**
 * 
 * @param {string} url 
 * @returns {MiniStompClient}
 */
function miniStompClient() {
  const socketBus = useEventBus('websocket-event-bus')
  let subId = -1 // 订阅的事件ID
  let subscribedEvents = [] // 用来存储已订阅返回的取消订阅函数
  let heartbeatInterval; // 心跳定时器
  let heartbeatIntervalTime = 10000 // 心跳检查间隔
  let lastHeartbeat; // 最后一次接收到来自服务端的心跳时间
  let heartbeatTimeout = 30000 // 心跳检查阔值，如果超出则重新连接
  let isConnecting = false // 是否是连接的状态
  let socket // socket 实例
  let pendingSubscriberStore = [] // 用来储存在stomp建立连接之前就提前订阅的事件
  let historySubscribersFn = {} // 用户存放历史订阅的事件，socket关闭重连后自动订阅
  let firstConnecting = true // 判断是否是首次连接或者重连
  function getSubId() {
    subId++
    return `sub-${subId}`
  }

  function connect() {
    socket = new MiniWebSocket(getSocketUrl());
    socket.onopen = () => {
      sendMessage(stompConnectFrame());
    };
    socket.onmessage = (event) => {
      const message = event.data;
      //CONNECTED\nversion:1.2\nheart-beat:10000,10000\n\n\u0000
      // 解析消息头和体
      if (message.replace(/\n/g, '') === '') {
        return resetHeartbeat()
      }
      // 首先检查是否包含 MESSAGE 帧头
      if (message.startsWith('MESSAGE')) {
        const parsedMessage = parseStompMessage(message);
        const {
          headers,
          body
        } = parsedMessage
        if (headers.destination) {
          socketBus.emit(headers.destination, body)
        }
        return resetHeartbeat()
      }
      // 发生错误
      if (message.includes('ERROR')) {
        console.error(message)
        return
      }
      if (message.includes('CONNECTED')) {
        isConnecting = true
        const {
          clientHeartbeat = 10000
        } = parseStompConnectedMessage(message)
        console.log('Connected to server!', clientHeartbeat);
        heartbeatIntervalTime = clientHeartbeat
        startHeartbeating()
        if (firstConnecting) {
          pendingSubscriberStore.forEach(el => el && el())
        } else {
          Object.values(historySubscribersFn).forEach(el => el && el())
        }
        firstConnecting = false
      }

    }

    socket.onerror = function (error) {
      console.error('WebSocket 错误:', error);
    };

    socket.onclose = function (event) {
      console.log('WebSocket 连接已关闭', event);
      isConnecting = false
      socket = null
      clearAllSubscribtions()
    };
    socket.connect()
  }

  function sendMessage(m) {
    if (socket && socket.connected) {
      socket && socket.send(m); // 发送空消息
    }
  }
  // 检查心跳是否超时
  function checkHeartbeat() {
    // console.log('checkHeartbeat')
    if (lastHeartbeat && (Date.now() - lastHeartbeat) > heartbeatTimeout) {
      console.log('Heartbeat timeout, attempting to reconnect');
      stopHeartbeating()
      connect()
    }
  }

  function startHeartbeating() {
    lastHeartbeat = Date.now()
    // 启动心跳机制，每秒发送一次空消息作为心跳
    stopHeartbeating()
    heartbeatInterval = setInterval(() => {
      checkHeartbeat()
      sendMessage("\n"); // 发送空消息
    }, heartbeatIntervalTime);
  }

  function stopHeartbeating() {
    console.log('socket', 'stopHeartbeating')
    // 启动心跳机制，每秒发送一次空消息作为心跳
    clearInterval(heartbeatInterval); // 清理心跳定时器
    heartbeatInterval = null
  }

  function resetHeartbeat() {
    lastHeartbeat = Date.now();
  }

  const subscribe = (destination, token) => {
    let resolver
    const subId = getSubId()
    const fn = function () {
      console.log('subscribe', this)
      sendMessage(stompSubscribeFrame(subId, destination, token));
    }
    historySubscribersFn[subId] = fn
    if (isConnecting && socket) {
      fn()
    } else {
      pendingSubscriberStore.push(fn)
      return new Promise((resolve) => {
        resolver = resolve
      })
    }
    return subId
  }
  const clearAllSubscribtions = () => {
    subscribedEvents.forEach(el => el && el())
    subscribedEvents = []
  }
  return {
    connect,
    subscribe,
    isConnecting() {
      return isConnecting
    },
    unsubscribe(subId) {
      if (isConnecting && socket) {
        sendMessage(stompUnsubscribeFrame(subId));
      }
      if (historySubscribersFn[subId]) {
        delete historySubscribersFn[subId]
      }
    },
    hookOnce(event, callbackFn) {
      const unsub = socketBus.on((listenEvent, data) => {
        if (event === listenEvent) {
          callbackFn(data)
          unsub()
        }
      })
    },
    hook(event, callbackFn) {
      socketBus.on((listenEvent, data) => {
        if (event === listenEvent) {
          callbackFn(data)
        }
      })
    },
  }
}

export default miniStompClient()