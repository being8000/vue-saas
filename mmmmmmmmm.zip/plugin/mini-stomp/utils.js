import {
  stompConnectFrame
} from "./frame";

const sendMessage = (message) => {
  return new Promise((resolve, reject) => {
    my.sendSocketMessage({
      data: message,
      success: (res) => {
        resolve(true)
      },
      fail: (err) => {
        console.error('sendSocketMessage', err);
        resolve(false)
      }
    });
  })
}


export function parseStompMessage(message) {

  // 提取消息头和内容部分
  const parts = message.split('\n\n');

  if (parts.length < 2) {
    console.error("无效的 STOMP 消息格式");
    return null;
  }

  // 消息头（包括destination, message-id 等）
  const headerSection = parts[0];

  // 消息正文部分
  const body = parts[1].trim(); // 去除正文的多余空白符

  // 解析消息头
  const headers = parseHeaders(headerSection);

  // 尝试将正文转换为对象（假设它是 JSON 格式）
  let parsedBody;
  try {
    parsedBody = JSON.parse(body.replace(/\u0000/, ''));
  } catch (error) {
    console.error("无法解析消息正文为 JSON:", error);
    parsedBody = body; // 如果解析失败，则返回原始文本
  }

  // 返回包含解析后的消息头和正文的对象
  return {
    headers,
    body: parsedBody
  };
}



// 解析消息头部分
function parseHeaders(headerSection) {
  const headers = {};

  // 分割每一行（按行分隔）
  const lines = headerSection.split('\n');

  lines.forEach(line => {
    const [key, value] = line.split(':');
    if (key && value) {
      headers[key.trim()] = value.trim();
    }
  });

  return headers;
}

// 解析 Heartbeat 配置
export function parseStompConnectedMessage(message) {
  // 将消息按行分割
  const lines = message.split('\n');

  // 初始化心跳时间
  let serverHeartbeat = null;
  let clientHeartbeat = null;
  // 遍历每一行，查找 HEARTBEAT 字段
  lines.forEach(line => {
    // 检查是否包含 HEARTBEAT 信息
    if (line.toLowerCase().startsWith('heart-beat:')) {
      const heartbeatConfig = line.split(':')[1].trim(); // 获取心跳配置部分（去除前后空格）
      const [server, client] = heartbeatConfig.split(',').map(Number); // 分割并转换为数字

      serverHeartbeat = server;
      clientHeartbeat = client;
    }
  });

  return {
    serverHeartbeat,
    clientHeartbeat
  };
}