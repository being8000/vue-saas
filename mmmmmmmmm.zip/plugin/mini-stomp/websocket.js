export class MiniWebSocket {
  connected = false
  opened = false
  readyState = ''
  url = ''
  OPEN = 'OPEN'
  constructor(url) {
    this.url = url
    const webSocket = this
    my.onSocketOpen(() => {
      console.log('socket', 'onSocketOpen')
      webSocket.opened = true
      webSocket.readyState = webSocket.OPEN
      webSocket.onopen && webSocket.onopen()
    })
    my.onSocketClose(function (res) {
      console.log('socket', 'onSocketClose')
      webSocket.opened = false
      webSocket.connected = false
      webSocket.onclose && webSocket.onclose(res)
    })
    my.onSocketError(function (res) {
      console.log('socket', 'onSocketError')
      webSocket.onerror && webSocket.onerror(res)
    });
    my.onSocketMessage(function (res) {
      // console.log('socket', 'onSocketMessage')
      webSocket.onmessage && webSocket.onmessage(res)
    })
  }
  onopen() {}
  onclose(res) {}
  onerror(res) {}
  onmessage(res) {}
  connect() {
    const webSocket = this
    my.connectSocket({
      url: webSocket.url,
      data: {},
      header: {
        'content-type': 'application/json'
      },
      success() {
        webSocket.connected = true
        console.log('socket', 'connectSocket', 'success')
      },
      fail() {
        console.log('socket', 'connectSocket', 'failed')
        webSocket.connected = false
      }
    });
  }
  send(msg) {
    // console.log('send message', msg)
    my.sendSocketMessage({
      data: msg, // The data to be sent
      success: (res) => {},
      fail() {
        console.error('sned faild!', msg)
      }
    });
  }
  close() {
    my.closeSocket()
  }
}