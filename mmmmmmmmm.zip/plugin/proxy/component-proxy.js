import { loginEmitter } from "./login-emitter"

let _Component = Component
Component = function (obj) {  
   _Component({
    ...obj,
    didMount(params) {
      // console.log('proxy didMount', this)
      if(obj.onReLogin){
        this.onReLogin = obj.onReLogin
        loginEmitter.addItem(this, this)
      }
      obj.didMount && obj.didMount.call(this, params)
    },
    didUnmount(params) {
      loginEmitter.removeItem(this)
      obj.didUnmount && obj.didUnmount.call(this, params)
    },
  })
}

