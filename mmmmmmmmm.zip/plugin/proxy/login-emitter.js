const createInstanceBox = function () {
  const miniInstanceMap = new WeakMap();
  const keys = new Set(); // 用于存储 WeakMap 的键引用

  function emitLoginEvent(type = 'page') {
    keys.forEach((key) => {
      const instance = miniInstanceMap.get(key);
      if (instance && instance.onReLogin) {
        instance.onReLogin.call(instance)
      }
    });
  }

  function addItem(key, instance) {
    if (typeof key === 'object' && key !== null) {
      if (instance && instance.onReLogin) {
        miniInstanceMap.set(key, instance);
        keys.add(key); // 同时将键添加到引用集合中
      }
    } else {
      throw new Error('Key must be an object');
    }
  }

  function removeItem(key) {
    miniInstanceMap.delete(key);
    keys.delete(key); // 从引用集合中移除键
  }

  return {
    addItem,
    removeItem,
    emitLoginEvent,
  };
};

export const loginEmitter = createInstanceBox()