import {
  loginEmitter
} from "./login-emitter"
import {
  step2MicroApi,
  systemInfoPromiser
} from "/app-before-init"
import {
  useEventBus
} from "/utils/use-event-bus"

const pageBus = useEventBus('on-page-life-eventbus')
export const PAGES = {
  HOME: 'HOME'
}

let _Page = Page
Page = function (obj) {
  _Page({
    ...obj,
    async onLoad(params) {
      my.hideLoading()
      // console.log('proxy onLoad', this)
      if(obj.onReLogin){
        this.onReLogin = obj.onReLogin
        loginEmitter.addItem(this, this)
      }
      systemInfoPromiser.then(sys => {
        this.setData({
          _SystemInfo: {
            ...sys,
            pageTop: Number(sys.statusBarHeight) + Number(sys.titleBarHeight)
          }
        })
      })
      if (this.data.page_name === PAGES.HOME) {
        my.hideBackHome()
        await step2MicroApi.promiser
      }
      pageBus.emit('onLoad', this)
      obj.onLoad && obj.onLoad.call(this, params)
    },
    onHide(params) {
      pageBus.emit('onHide', this)
      // console.log('proxy onHide')
      obj.onHide && obj.onHide.call(this, params)
    },
    onShow(params) {
      pageBus.emit('onShow', this)
      loginEmitter.removeItem(this)
      // console.log('proxy onShow')
      obj.onShow && obj.onShow.call(this, params)
    },
    onReady(params) {
      pageBus.emit('onReady', this)
      // console.log('proxy onReady')
      obj.onReady && obj.onReady.call(this, params)
    },
  })
}

const navigateTo = my.navigateTo

my.navigateTo = function (args) {
  my.showLoading()
  navigateTo(args)
}