const sensors = require("../sensorsdata.esm.js");
import { getSensorsUrl } from '../utils/env.js'
import { StorageKey } from "../utils/const.js";
import { getUserInfo } from '/api/user.js';
console.log(StorageKey.SITE_INFO, 'info34234')
let sensors_url =  my.getStorageSync({ key: StorageKey.SITE_INFO }).data || {GLIFE_SENSORS_URL: getSensorsUrl()}
console.log(sensors_url)
const config = { 
  name: 'sensors',
  server_url: sensors_url.GLIFE_SENSORS_URL, //数据接收地址
  // 预置事件采集配置开关，默认为 true
  autoTrack:{
    appLaunch: true,   //是否采集 $MPLaunch 小程序冷启动事件，true 代表采集，false 不采集。
    appShow: true,    //是否采集 $MPShow 小程序热启动事件，true 代表采集，false 不采集。
    appHide: true,    //是否采集 $MPHide 小程序进入后台事件，true 代表采集，false 不采集。
    pageShow: true,   //是否采集 $MPViewScreen 页面浏览事件，true 代表采集，false 不采集。
    mpClick: true,    //是否采集 $MPClick 点击事件，true 代表采集，false 不采集。
    pageLeave: true  //是否采集 $MPPageLeave 页面离开事件， true 代表采集，false 不采集
  },
  show_log: true,  //设置 true 后会在网页控制台打 logger，会显示发送的数据,设置 false 表示不显示。
};


/**
 * @typedef {Object} Sensors
 * @property {function(): void} init - 启动方法
 * @property {function(): void} login - 登录事件采集
 * @property {function(): void} quick - 初始化第一个页面预览
 * @property {function(): void} autoTrack - 自动采集页面预览
 * @property {function(eventName: string, properties?: { [key: string]: any }) => void} track   -事件采集方法
 * @property {functon(c?: any): void} deleteProfile //删除用户画像
 */

export const $sensors = {
  async init() {
    const { loginName } = getUserInfo()
    sensors.init(config);
    sensors.login(loginName)
    // console.log(my.getStorageSync({ key: StorageKey.SITE_INFO }).data, '44444')
    sensors.registerApp({
      product_line: "GameZone",
      custom_device_id:  my.getStorageSync({ key: StorageKey.DX_SDK_TOKEN }).data || ''
    })
    if(loginName) {
      sensors.track('loginSucceed', {
        user_id: loginName,
        login_method:'手机号'
      })
    }
  }
};




/**
 * @returns {Sensors}
 */
export function getSensor(){
  return sensors
}


//挂载到全局
my.sensors = getSensor()




