export const APP_TYPE = "3"; // glife

// 小程序APPID
export const MINI_APP_ID = "2170020194511181";

export const FROM_MINI = "GP"

// 新版签名key
export const KA_7_KEY = "4J3yRx7YJQrEjfCP2%5BKNDSa%Y9@yYgZ38QDgTXlqZjrK51za";

// 自定义的APPID 估计是系统标识，目前不知道用途
export const CUSTOM_APP_ID = "C66GPGLIFE08";

export const envMap = {
  PROD: "prod",
  UAT: "uat",
  LOCAL: "local",
};

// v3新增的游戏类型背景色
export const gameTypeColorMap = {
  Poker: {
    value: "3",
    color: "#ED3A00",
  },
  Slot: {
    value: "5",
    color: "#FF9900",
  },
  Live: {
    value: "",
    color: "",
  },
  Fishing: {
    value: "8",
    color: "#01B1FF",
  },
  Bingo: {
    value: "27",
    color: "#E4BD12",
  },
  Perya: {
    value: "99",
    color: "#02BA00",
  },
  // SPORT(1, "Sport","Sport"),
  // POKER(3, "Poker","Poker"),
  // SLOT(5, "Slot","Slot"),
  // BINGO(27, "Bingo","Bingo"),
  // BINGO_BOOM(21, "Bingo Boom","Bingo Boom"),
  // FISHING(8, "Fishing","Fishing"),
  // CASINO(17, "Casino","Casino"),
  // PERYA(99, "Perya","Perya");
};

const prefix = 'GZ'

export const StorageKey = {
  WEB_TOKEN: `${prefix}-WEBTOKEN`, // webtoken key
  SITE_INFO: `${prefix}-SITE_INFO`, //站点信息
  ALL_GAME: `${prefix}-ALL_GAME_JSON`, // 所有游戏
  PROMOTIONS: `${prefix}-PROMOTION_JSON`, // 活动Promotion
  TCC_INFO: `${prefix}-TCC_INFO`, // 活动Promotion
  BLOCK_CONFIG: `${prefix}-BLOCK_CONFIG_JSON`, // 区块配置
  BANNER_JSON: `${prefix}-BANNER_JSON`, // 区块配置
  NORMALIZED_BLOCK_CONFIG: `${prefix}-NORMALIZED_BLOCK_CONFIG`, // 处理过后的区块配置
  ACCESS_TOKEN: `${prefix}-ACCESS_TOKEN`, // ACCESSTOKEN
  DX_SDK_TOKEN: `${prefix}-DX_SDK_TOKEN`, // 顶象sdk 设备指纹
  USER_DETAILS: `${prefix}-USER_DETAILS`, // 用户详情
  LOGIN_USER: `${prefix}-LOGIN_USER`, // 用户详情
  SPOKESPERSON:`${prefix}-SPOKESPERSON`, //代言人
  SPOKESPERSON_JSON: `${prefix}-SPOKESPERSON_JSON`
}