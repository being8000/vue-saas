
import { getDxParams } from "../utils/env.js";
import { StorageKey } from "./const.js";
const ConstId = require('../dx-sdk.js')

export function setUpDeviceId() {
  return new Promise((resolve) => {
    let cache = my.getStorageSync({ key: StorageKey.DX_SDK_TOKEN })
    if (cache.data && cache.data.length == 40) {
      return resolve(cache.data)
    }
    const dxParams = getDxParams()
    // 设备指纹sdk接入
    new ConstId(dxParams, (e, id) => {
      if (e) {
        console.log('dx sdk error', e)
        resolve(false)
      }
      if (id) {
        console.log('dx sdk constId:', id)
        my.setStorageSync({
          key: StorageKey.DX_SDK_TOKEN,
          data: id
        });
  
        resolve(id)
      } else {
        resolve(false)
      }
    })
  })
}