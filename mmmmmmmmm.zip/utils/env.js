import {
  DEFAULT_ENV,
  glifeToken
} from "../env";
import {
  envMap
} from "./const";

const {
  PROD,
  UAT,
  LOCAL
} = envMap

function initENV() {
  let currentEnv = DEFAULT_ENV;
  return function () {
    return {
      UAT: UAT,
      PROD: PROD,
      LOCAL: LOCAL,
      setPROD() {
        currentEnv = PROD;
      },
      setUAT() {
        currentEnv = UAT;
      },
      setLocal() {
        currentEnv = LOCAL;
      },
      isUAT() {
        return currentEnv == UAT || currentEnv == LOCAL;
      },
      isLocal() {
        return currentEnv == LOCAL;
      },
    };
  };
}

export const ENV = initENV()();
export const getOriginUrl = () => {
  if (ENV.isUAT()) {
    return "glife.uatext66gp.com"; // 沙盒请求的地址 glife.uatext66gp.com  gameplus-gamezone.uatext66gp.com
  } else {
    return "glife.gzone.ph"; // 生产请求的地址
  }
};

export const getSocketUrl = () => {
  // wss://gp-websocket-uat.uatextback66.com/ws/websocket
  if (ENV.isUAT()) {
    return "wss://gp-websocket.xinba66.com/ws/websocket";
  } else {
    return "wss://gp-websocket.xinba66.com/ws/websocket"; // 生产请求的地址
  }
}

export const getSensorsUrl = () => {
  if (ENV.isUAT()) {
    return "https://dev-8106.digiplus-bigdata.com/sa?project=GamePlus"; // 沙盒请求的地址
  } else {
    return "https://8106.digiplus-bigdata.com/sa?project=GamePlus"; // 生产请求的地址
  }
}
// 获取dx设备参数
export const getDxParams = () => {
  let params = {
    timeout: 2000,
    cache: false,
    excludeKeys: ['bluetoothDevices', 'gps', 'wifiList'], // 启动不弹授权地址弹窗
  }
  if (ENV.isUAT()) {
    params.appId = '4e64081b1c2b3dbe7e389590ffe8b5bd'
    params.server = 'https://rcs-demo.dingxiang-inc.com/udid/w1'
  } else {
    params.appId = '5ad0af758c8049ef8c77c7e965429e42'
    params.server = 'https://www.dgfpsecservice.com/udid/w1'

  }
  return params
};

export const getAccId = () => {
  return ENV.isUAT() ? "1005768135" : "967821219124477953";
};

export const getBaseUrl = () => {
  return "https://" + getOriginUrl();
};


export function isUAT() {
  return ENV.isUAT();
}

export function getAuthCode(data = {}) {
  const {
    success,
    failed
  } = data || {};
  if (typeof success === "function") {
    if (ENV.isLocal()) {
      success({
        authCode: "local",
      });
    } else {
      return my.getAuthCode(data);
    }
  } else {
    if (typeof failed === "function") {
      failed("custom error info");
    }
  }
}

export function getGcashToken(promise = new Promise()) {
  if (ENV.isLocal()) {
    return Promise.resolve(glifeToken);
  } else {
    return promise;
  }
}