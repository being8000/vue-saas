  import {
    getNormalizedBlockData
  } from '/api/service/home-block-config'
  import {
    filterGamesByIds
  } from '/api/service/game'
  import flatMap from "lodash/flatMap";
  import {
    fetchgameProviders
  } from "/api/user";
  import {
    getOriginUrl
  } from './env';

  let app = getApp();
   /**
   * 维护中分三种状态：0 未维护，1 维护中无时间，2 维护中有时间
   * @param {*} game
   * @returns
   */
  export const setMaintainanceStatus = (game) =>{
    if (game.platformStatus === 1 && game.flag === 1) {
      game.maintainStatus = 0;
    } else {
      if (game.maintainStartTime && game.maintainEndTime) {
        let now = Date.now();
        let startTime = new Date(game.maintainStartTime).getTime();
        let endTime = new Date(game.maintainEndTime).getTime();
        if (now >= startTime && now <= endTime) {
          game.maintainStatus = 2;
        } else {
          game.maintainStatus = 1;
        }
      } else {
        game.maintainStatus = 1;
      }
    }
  }

  /**
   * 如果有维护结束时间，则转换格式
   * @param {*} game
   * @returns
   */
  export const setMaintainceDate = (game) => {
    if (!game.maintainEndTime) {
      return;
    }
    const date = new Date(game.maintainEndTime);
    const monthNames = [
      "Jan",
      "Feb",
      "Mar",
      "Apr",
      "May",
      "Jun",
      "Jul",
      "Aug",
      "Sep",
      "Oct",
      "Nov",
      "Dec",
    ];
    const month = monthNames[date.getMonth()];
    const day = date.getDate();
    const hours = date.getHours();
    const minutes = date.getMinutes();
    const ampm = hours >= 12 ? "PM" : "AM";
    const hours12 = hours % 12 === 0 ? 12 : hours % 12;

    game.maintainceDateStr = `${month} ${day} ${hours12}:${minutes
      .toString()
      .padStart(2, "0")} ${ampm}`;
  }

  // // 过滤游戏图片
  // export const setImgUrl = (game) => {
  //   let img = game.gameImage;
  //   game._gamePreImage = img.startsWith("http") ?
  //     img :
  //     `https://${app.getUrl()}/externals/C66FM/img/_wms/_l/electronicgames/${img}?isFrom=Glife`;
  // }

  /**
   * 获取游戏封面图完整路径
   * @param {*} game 
   * @returns 
   */
  export const getGameImgFullPath = (game) => {
    if (!app) {
      app = getApp();
      // const app = getApp();
      // console.log('app: ', app)
    }
    const img = game.gameImage;
    return img.startsWith("http") ?
      img :
      `https://${getOriginUrl()}/externals/C66FM/img/_wms/_l/electronicgames/${img}?isFrom=Glife`;
  }

  /**
   * 获取一个分类下面所有区块的游戏列表
   * 这个方法由于搜索页面
   * type  all slot bingo..
   */
  export const getList = async(type) => {
    let blockGames = [];
    let res = getNormalizedBlockData()
    let blocks =  res.find(el => el.pagination.toLowerCase() === type.toLowerCase())
    console.log('getNormalizedBlockData', type, res, blocks)
    const flatGames = flatMap(blocks.blockConfig.map(block => (block.gameItemsIds || [])))
    const gameIds = [...new Set(flatGames)]
    blockGames = filterGamesByIds(gameIds).sort((m, n) => {
      return n.sort - m.sort;
    });
    // 给过滤后的游戏列表添加图片
    // blockGames.forEach( game => {
    //   setImgUrl(game);
    //   setMaintainanceStatus(game)
    //   setMaintainceDate(game)
    // })
    return blockGames
  }

  /**
   * 获取viewall的一个游戏列表
   * @param {*} type 
   * @param {*} blockName 
   * @returns 
   */
  export const getViewAllList = async(type, blockName) => {
    let res = getNormalizedBlockData()
    let blocks =  res.find(el => el.pagination.toLowerCase() === type.toLowerCase())
    let block = blocks.blockConfig.find(el => el.blockName === blockName)
    console.log('getViewAllList：', type, blockName, block)
    return block ? block._viewAllGames : []
  }
  export const getGameClassifyOptions = async() => {
    let res = getNormalizedBlockData()
    let gameClassifyOptions = []
    res.forEach( el => {
      // 获取 game classify options
      gameClassifyOptions.push({
        label: el.pagination,
        icon: el.pagination === 'ALL' ? `/assets/v4/icon_block_all.png` : el.iconH5,
        sortH5: el.sortH5
      })
    })
    return {
      gameClassifyOptions,
    }
  }

  // 获取所有推荐游戏
  export const getRecommendGameList = (type ='ALL') => {
    let list = []
    let res = getNormalizedBlockData()
    let blocks =  res.filter(el => el.pagination === type)[0]
    if(blocks.blockConfig.length > 0) {
      const gameData = blocks.blockConfig[blocks.blockConfig.length - 1]
      list = gameData._viewAllGames
    } else {
      list = []
    }
    return list
  }

  // 获取game Providers 搜索条件
  export const getGameProviders = async() =>{
    const data =  await fetchgameProviders()
    return data
  }
  // 滚动到底部 数据截取
  export const getNextPageGameList = (showGames, resultGames, showNumber) => {
    let newList = []
    if (showGames.length < resultGames.length) {
      let newGames = resultGames.slice(showGames.length, showGames.length + showNumber)
      newList = showGames.concat(newGames)
    } else {
      newList = showGames
    }
    return newList
  }

  // 缓存搜索结果
  export const memoize = (fn) => {
    const cache = new Map();
    return (...args) => {
      const key = JSON.stringify(args);
      if (cache.has(key)) {
        console.log('Cache hit!');
        return cache.get(key);
      }
      const result = fn.apply(this, args);
      // 限制缓存大小，避免内存占用过大
      if (cache.size > 50) {
        // 删除最早的缓存
        const firstKey = cache.keys().next().value;
        cache.delete(firstKey);
      }
      cache.set(key, result);
      return result;
    };
  }

  // 防抖函数
  export const debounce = (fn, delay) => {
    let timeout;
    return function (...args) {
      if (timeout) clearTimeout(timeout);
      timeout = setTimeout(() => {
        fn.apply(this, args);
      }, delay);
    };
  }


    /**
   * 根据gameId和platformId对游戏数组进行去重
   * 注意gameId可能是空的，而且会重复，因此需要platformId
   * @param {*} games 
   * @returns 
   */
  export const removeDuplicateGames = (games) => {
    const s = new Set();
    const result = games.filter((item) => {
      const key = `${item.gameId}--${item.platformId}`;
      if (s.has(key)) {
        return false;
      }
      s.add(key);
      return true;
    });

    return result;
  }