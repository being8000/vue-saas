import random from "loadsh/fp/random";
import md5 from "md5";
import Big from 'big.js'
import {
  APP_TYPE,
  CUSTOM_APP_ID,
  KA_7_KEY,
  StorageKey
} from "./const";
import {
  getBaseUrl,
  getOriginUrl,
  isUAT
} from "./env";
import { getAccessTokenFromStore } from "/api/service/auth";
const Encrypt = require("../jsencrypt.min.js");
const webKey =
  "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAgo22hZx9N2EXHh8ZspL/iHYcuL1tSdQ974nTkJHRlKRWNzyQqO6TSYouY+nA0y/WD2Pz2wwKwTDBFW82DNekYgFeKZ2bCrsG3Twi7tn3DbfFGKzXfBzXYv6sggL/1Ej2/ABzMVWIaAo8t9Wo5A+/12nOLQIwxsHXZTUrbCJeZYUAfRQFLyIp2/PxVeVd0bLhtEAAj8aJq8RlSlPYdUIgk+CJ+WVdUs7rhMd09MArgAFwB3iRPbBS4gf7QEswRaBDQ3fTJIYE6xTr53geuv9MAO6B2x0Qt0ctmrdGtjLdsoq2KWmlPXo/GS6uJadwQ+xR9JbudS4eZYKNYTf6zGsvVwIDAQAB";
// 加密
let encryptor = new Encrypt.JSEncrypt();
encryptor.setPublicKey(webKey); // 设置公钥

function _isHttp(url) {
  return url.substr(0, 4).toLowerCase() === "http";
}

const encryptProps = ["password", "mobileNo", "phone", "newEmail", "accountNo"];
const sortString = (str) => {
  return str.split("").sort().reverse().join();
};
const sortStringNew = str => {
  return str
    .split('')
    .sort()
    .reverse()
    .join('');
};


const randomFn = (n) => [...Array(n)].map((_) => random(0)(9)).join("");
export function signature({
  url = "",
  data = {},
  overrideRoute,
  token
}) {
  if (!data) {
    data = {
      productId: "C66",
    };
  } else {
    data.productId = "C66";
    encryptProps.forEach((i) => {
      if (data[i]) {
        data[i] = encryptor.encrypt(data[i]);
      }
    });
  }

  if (url[0] === "[") {
    delete data[url.slice(1, url.indexOf("]"))];
    url = url.slice(url.indexOf("]") + 1);
  }

  /**
 * 小程序的也加一下：
  请求头 ata-5 , 值为 13位时间戳 + 2位0-9随机数字
  请求头 ka-7, 值为 md5( ata-5(请求头) + 唯一key + url路径  + kx-2(请求头) )
  请求头 kx-2, 小程序唯一标识
  请求头 kkz-1,  值为 new Date().getTimezoneOffest()
 */

  const _url = _isHttp(url) ? url : getBaseUrl() + overrideRoute + url;
  let timenum = Date.now(); //时间戳
  const ata5 = timenum + '' + randomFn(2)
  const kx2 = CUSTOM_APP_ID
  const ka7 = md5(ata5 + KA_7_KEY + (overrideRoute + url).replace(/^\//g, '') + kx2)
  const kkz1 = new Date().getTimezoneOffset()


  const qid = md5(timenum + randomFn(6));
  const v = "1.0.3";
  const isAPPID = CUSTOM_APP_ID
  let headers = {
    'ata-5': ata5,
    'ka-7': ka7,
    'kx-2': kx2,
    'kkz-1': kkz1,
    Qid: qid,
    AppId: isAPPID,
    v: v,
    Accept: "application/json",
    "Content-Type": "application/json",
    Domainname: getOriginUrl(),
  };

  let token_str = "";
  if (token && url != "webToken") {
    headers.token = token.token;
    token_str = token.token + token.u2token;
  }

  // applets 开头不用替换 其他都走else 签名
  if (!url.startsWith('applets')) {
    headers.Sign = md5(
      (sortStringNew(JSON.stringify(data)) + qid + isAPPID + v) +
      token_str
    );
  } else {
    headers.Sign = md5(
      (sortString(JSON.stringify(data)) + qid + isAPPID + v).replace(/,/g, "") +
      token_str
    );
  }

  if (isUAT()) {
    // console.info("my.request->>url:", url);
    // console.info("my.request->>data:", data);
    // console.info("my.request->>stringify:", JSON.stringify(data));
    // console.info("my.request->>qid:", qid);
    // console.info("my.request->>isAPPID:", isAPPID);
    // console.info("my.request->>v:", v);
    // if (token) {
    //   console.info("my.request->>token:", token.token);
    //   console.info("my.request->>u2token:", token.u2token);
    // }
    // console.info("my.request->>token_str:", token_str);
  }
  return {
    headers,
    data,
    url: _url,
  };
}

/**
 * 从缓存中获取用户信息
 */
export const getAuthInfo = () => {
  // 从缓存中读取 Glife的授权信息
  const authInfo = getAccessTokenFromStore() || {}
  const {
    resultBody = {}
  } = authInfo
  return {
    customerId: resultBody.customerId, // 用户唯一ID，在某些接口中字段名为unionId
    accessToken: resultBody.accessToken,
    extendInfo: resultBody.extendInfo,
  }
}
/**
 * 从缓存中读取 用户信息
 */
export const getUserInfo = () => {
  const userInfo = my.getStorageSync({
    key: 'userInfo', // 缓存数据的key
  }).data
  const {
    avatar = '',
      bindFlag = null,
      createdDate = null,
      currency = null,
      customerId = null,
      face = null,
      flag = null,
      fromType = null,
      gameLimit = null,
      loginName = null,
      mobileNo = null,
      noLoginDays = null,
      onlineBet = null,
      parentId = null,
      productId = null,
      unionId = null
  } = userInfo || {}
  return {
    avatar, // 头像
    bindFlag,
    createdDate, //注册时间
    currency,
    customerId,
    face,
    flag,
    fromType,
    gameLimit,
    loginName,
    mobileNo,
    noLoginDays,
    onlineBet,
    parentId,
    productId,
    unionId
  }
}

/**
 * 用于统一App首次挂载会自动授权，授权之前需要在初始化清除用户缓存
 */
export function clearStorageBeforeAuth() {
  // 清楚历史弹框缓存
  my.removeStorageSync({
    key: 'closeKYCPopup', // 缓存数据的key
  })
}

/**
 * 用户整合获取支付所需参数
 */
export const normalizedPaymentData = () => {
  const userInfo = getUserInfo()
  const authInfo = getAuthInfo()
  console.log({
    mobileNo: userInfo.mobileNo,
    unionId: authInfo.customerId,
    externalToken: authInfo.externalToken,
    type: APP_TYPE
  })
  return {
    mobileNo: userInfo.mobileNo,
    unionId: authInfo.customerId,
    externalToken: authInfo.accessToken,
    type: APP_TYPE
  }
}

export function debounce(func, wait, immediate) {
  let timeout, _args, context, timestamp, result

  const later = function () {
    // 据上一次触发时间间隔
    const last = +new Date() - timestamp
    // 上次被包装函数被调用时间间隔 last 小于设定时间间隔 wait
    if (last < wait && last > 0) {
      timeout = setTimeout(later, wait - last)
    } else {
      timeout = null
      // 如果设定为immediate===true，因为开始边界已经调用过了此处无需调用
      if (!immediate) {
        result = func.apply(context, _args)
        if (!timeout) context = _args = null
      }
    }
  }

  return function (...args) {
    _args = args
    context = this
    timestamp = +new Date()
    const callNow = immediate && !timeout
    // 如果延时不存在，重新设定延时
    if (!timeout) timeout = setTimeout(later, wait)
    if (callNow) {
      result = func.apply(context, args)
      context = _args = null
    }

    return result
  }
}


export const strToJson = (str, def) => {
  try {
    return JSON.parse(str || JSON.stringify(def))
  } catch (error) {
    return def
  }
}
export const jsonToStr = (str) => {
  try {
    return JSON.stringify(str)
  } catch (error) {
    return ''
  }
}


// 获取当前页面的this
export const getCurrentCtx = () => {
  const pages = getCurrentPages() || [];
  const ctx = pages[pages.length - 1] || {};
  return ctx;
}

/**
 * 处理parse之后的html节点对象
 * 将figure元素替换为p，否则无法显示
 * img增加最大宽度限制，防止超出屏幕
 */
export const   processNodes = (nodes)  => {
  return nodes.map((node) => {
    if (node.name === "img") {
      // console.log(node.attrs)
      node.attrs["style"] = "max-width: 100%";
    } else if (node.name === "figure") {
      node.name = "p";
    }
    if (node.children) {
      node.children = processNodes(node.children);
    }
    // console.log(node)
    return node;
  });
}


/**
 * params
 */

 export const addNumber =(num1,num2) => {
   let a = new Big(Number(num1));
   let b = new Big(Number(num2));
   return a.plus(b).toString()
 }

 export const requestAnimationFrame = (fn)=>{
   setTimeout(()=>{
    fn()
   },16.6)
 }