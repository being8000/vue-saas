// /**
//  * @returns {{
//  *  startFetch: () => void
//  *  manualResolve: () => void
//  *  manualReject: () => void
//  *  reset: () => void
//  *  promiser: Promise<any>
//  * }}
//  */
export function createMicroApi(fetchFuncion) {
  let resolver = null
  let rejecter = null
  let promiser = new Promise((resolve, reject) => {
    resolver = resolve
    rejecter = reject
  })
  
  function reset() {
    promiser = new Promise((resolve, reject) => {
      resolver = resolve
      rejecter = reject
    })
  }

  function latestPromiser(){
    return promiser
  }
  function startFetch(params) {
    console.log('getBetAmount startFetch', params)
    if (fetchFuncion) {
      const promise = fetchFuncion(params)
      if (promise.then) {
        promise.then(resolver).catch(rejecter)
      }
    }
  }

  function manualResolve(data){
    resolver(data)
  }

  function manualReject(data){
    manualReject(data)
  }

  return {
    startFetch,
    promiser,
    manualResolve,
    manualReject,
    reset,
    latestPromiser
  }
}

/**
 * // 声明一个异步微任务API
const favoriteMicroTask = createMicroApi(fetchFavoriteGames)
// 在指定地方请求，如果需要登录后，则放到 afterLoginFunctions 函数中
favoriteMicroTask.startFetch()

// 在某个子页面或者子组件中使用, res为接口返回的值
let res = await favoriteMicroTask.promiser

 */