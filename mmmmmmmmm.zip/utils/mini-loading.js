import {
  debounce
} from ".";

export function getCustomLoadingInstance() {
  const pages = getCurrentPages() || []
  const ctx = pages[pages.length - 1]

  return {
    start() {
      ctx.setData({
        __isCustomGlobalLoading: true
      })
    },
    end() {
      ctx.setData({
        __isCustomGlobalLoading: false
      })
    }
  }
  // const instance = ctx.selectComponent('#custome-loading')
}
let instance = null
function init() {
  let count = 0;

  function end() {
    if (count <= 0) {
      count = 0
      my.hideLoading();
      // instance && instance.end()
      // instance = null
    }
  }

  function start() {
    if (count <= 1) {
      my.showLoading();
      // instance = getCustomLoadingInstance()
      // instance.start()
    }
  }
  const dEnd = debounce(end, 150)
  const dStart = debounce(start, 1000, true)
  return function () {
    return {
      start() {
        count++
        dStart()
      },
      end() {
        count--;
        dEnd()
      }
    }
  }
}

export const miniLoading = init()()